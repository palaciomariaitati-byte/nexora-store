import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CURRENT_VERSION = '2026.1.0';
const OTA_CLOUD_URL = process.env.NEXORA_OTA_URL || 'https://nexora-store-app.vercel.app/api/ota/restobar';

class OtaService {
  constructor() {
    this.currentVersion = CURRENT_VERSION;
    this.lastCheck = null;
    this.status = 'IDLE';
    this.timer = null;
  }

  async checkAndApplyUpdate() {
    try {
      this.status = 'BUSCANDO_ACTUALIZACION';
      this.lastCheck = new Date().toISOString();

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 7000);

      const resp = await fetch(`${OTA_CLOUD_URL}?clientVersion=${this.currentVersion}`, {
        method: 'GET',
        headers: {
          'x-nexora-client-id': 'RESTOBAR_ON_PREMISE',
          'User-Agent': `Nexora-POS/${this.currentVersion}`
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!resp.ok) {
        this.status = 'AL_DIA';
        return { updated: false, message: 'Sistema al día o servicio OTA no accesible.' };
      }

      const data = await resp.json();
      if (!data.updateAvailable) {
        this.status = 'AL_DIA';
        return { updated: false, message: 'La terminal ya cuenta con la última versión oficial.' };
      }

      // Si vienen parches de código en caliente (silent hot-patches)
      if (Array.isArray(data.hotPatches) && data.hotPatches.length > 0) {
        console.log(`[OTA Remoto] 📦 Aplicando ${data.hotPatches.length} parches en caliente silenciosamente...`);
        for (const patch of data.hotPatches) {
          if (patch.relativePath && patch.content) {
            const absPath = path.resolve(__dirname, '..', patch.relativePath);
            fs.mkdirSync(path.dirname(absPath), { recursive: true });
            fs.writeFileSync(absPath, patch.content, 'utf-8');
            console.log(`[OTA Remoto]  ✓ Archivo actualizado sin reiniciar: ${patch.relativePath}`);
          }
        }
      }

      this.currentVersion = data.latestVersion || this.currentVersion;
      this.status = 'ACTUALIZADO';
      return {
        updated: true,
        version: this.currentVersion,
        releaseNotes: data.releaseNotes
      };
    } catch (e) {
      this.status = 'ERROR_VERIFICACION';
      // Falla silenciosa: nunca interrumpe la caja del cliente
      return { updated: false, error: e.message };
    }
  }

  startBackgroundPoller(intervalMs = 3600000) {
    if (this.timer) clearInterval(this.timer);
    // Chequeo inicial diferido tras 15 segundos de arranque
    setTimeout(() => this.checkAndApplyUpdate(), 15000);
    this.timer = setInterval(() => this.checkAndApplyUpdate(), intervalMs);
    console.log('[OTA Remoto] 🛰️ Agente de actualización autónoma en segundo plano activo.');
  }
}

export const otaService = new OtaService();
export default otaService;
