/**
 * nora_controller.js - Tren Agéntico Nexora One ("By Nora") para Gastronomía y Bares 2026
 * 
 * Basado en la arquitectura del Tren Agéntico de Kioscos 2026:
 *  1. Motor de Visión Multimodal Open-Source Ultra Rápido (Qwen 3.8 27B en Groq LPU + Fallback Ollama Local)
 *  2. Archivo Físico Digital de Comprobantes con Timestamp y Proveedor (/data/comprobantes)
 *  3. Borrador Resiliente con Edición en Pantalla (sin bloqueos si la foto es borrosa o de prueba)
 *  4. Presets Realistas Gastronómicos para Demo & Testing Inmediato
 *  5. Conciliación Conversacional de Faltantes e Inyección Transaccional en SQLite
 */

import { Groq } from 'groq-sdk';
import { db } from './database.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '.env') });
dotenv.config({ path: path.resolve(__dirname, '..', '.env') });
const COMPROBANTES_DIR = path.resolve(__dirname, 'data', 'comprobantes');

// Asegurar existencia del directorio de almacenamiento físico de fotos de comprobantes
if (!fs.existsSync(COMPROBANTES_DIR)) {
  try {
    fs.mkdirSync(COMPROBANTES_DIR, { recursive: true });
  } catch (e) {
    console.warn('[Nora Comprobantes] Error creando carpeta comprobantes:', e.message);
  }
}

export class NoraBrainController {
  constructor(options = {}) {
    this.apiKey = (options.apiKey || process.env.GROQ_API_KEY || '').trim();
    this.sqliteDb = db;

    // Estado borrador en memoria para conciliación conversacional paso a paso
    this.activeDraftInvoice = null;

    // Motor Local Open-Source (Política Costo Cero: Ollama Local Nexora One / Susy Bot)
    this.ollamaBaseUrl = (process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434').trim();
    this.ollamaVisionModel = process.env.OLLAMA_VISION_MODEL || 'llama3.2-vision:latest';
    this.ollamaTextModel = process.env.LOCAL_MODEL_DEFAULT || 'llama3.3:latest';

    // Motor Primario Open-Source en Groq LPU (Ultra Rápido < 1.2s): Qwen 3.8 27B Multimodal
    this.groqVisionModel = process.env.GROQ_MODEL_VISION || 'qwen/qwen3.8-27b';
    this.textModels = [
      process.env.GROQ_MODEL_TEXT || 'qwen/qwen3.8-27b',
      'openai/gpt-oss-120b',
      'openai/gpt-oss-20b'
    ];
    this.sttModel = 'whisper-large-v3-turbo';

    this.client = this.apiKey ? new Groq({ apiKey: this.apiKey }) : null;
  }

  isReady() {
    return Boolean(this.apiKey || this.ollamaBaseUrl);
  }

  /**
   * Guarda la foto de la factura/remito en la carpeta de auditoría del restaurante
   */
  guardarImagenComprobante(imageBase64, proveedor = 'Proveedor') {
    if (!imageBase64 || imageBase64.length < 100) return '';
    try {
      const cleanBase64 = String(imageBase64).replace(/^data:image\/\w+;base64,/, '');
      const fecha = new Date().toISOString().split('T')[0];
      const slugProv = String(proveedor).replace(/[^a-z0-9]/gi, '_').slice(0, 25);
      const fileName = `${fecha}_${slugProv}_${Date.now()}.jpg`;
      const fullPath = path.join(COMPROBANTES_DIR, fileName);
      fs.writeFileSync(fullPath, Buffer.from(cleanBase64, 'base64'));
      return `/comprobantes/${fileName}`;
    } catch (e) {
      console.warn('[Nora Comprobantes] No se pudo guardar copia de imagen:', e.message);
      return '';
    }
  }

  /**
   * Presets Realistas Gastronómicos para Demo y Pruebas Rápidas sin ticket físico
   */
  obtenerPresetGastronomico(tipo = 'quilmes_cerveza') {
    const hoy = new Date().toISOString().split('T')[0];

    if (tipo === 'quilmes_cerveza' || tipo === 'bebidas') {
      return {
        supplierName: 'Cervecería y Maltería Quilmes S.A.',
        cuit: '30-50072352-9',
        invoiceType: 'Factura A',
        invoiceNumber: `0044-00${Math.floor(210000 + Math.random() * 89000)}`,
        invoiceDate: hoy,
        rubro: 'Bebidas & Cervecería',
        notes: 'Reparto barricas y packs de cerveza fría.',
        items: [
          { name: 'Barril Cerveza Rubia Clásica 50L', rubro: 'Bebidas', quantity: 2, unit: 'Barriles', costPerUnit: 68000, subtotal: 136000, recibido: true },
          { name: 'Cerveza Patagonia IPA 730ml x12', rubro: 'Bebidas', quantity: 4, unit: 'Packs', costPerUnit: 24500, subtotal: 98000, recibido: true },
          { name: 'Agua Mineral Eco de los Andes 1.5L x6', rubro: 'Bebidas', quantity: 6, unit: 'Packs', costPerUnit: 6200, subtotal: 37200, recibido: true }
        ]
      };
    }

    if (tipo === 'frigorifico_carnes' || tipo === 'carnes') {
      return {
        supplierName: 'Frigorífico San Telmo S.R.L.',
        cuit: '30-68912344-1',
        invoiceType: 'Factura A',
        invoiceNumber: `0003-00${Math.floor(115000 + Math.random() * 89000)}`,
        invoiceDate: hoy,
        rubro: 'Carnicería & Insumos',
        notes: 'Corte fresco envasado al vacío. Controlar pesaje.',
        items: [
          { name: 'Carne Vacuna Bife de Chorizo', rubro: 'Carnes', quantity: 18.5, unit: 'Kg', costPerUnit: 11200, subtotal: 207200, recibido: true },
          { name: 'Medallones Hamburguesa Especial 120g x40', rubro: 'Carnes', quantity: 2, unit: 'Cajas', costPerUnit: 34000, subtotal: 68000, recibido: true },
          { name: 'Pechuga de Pollo Fresca', rubro: 'Carnes', quantity: 12.0, unit: 'Kg', costPerUnit: 5800, subtotal: 69600, recibido: true }
        ]
      };
    }

    if (tipo === 'panaderia_almacen' || tipo === 'panaderia') {
      return {
        supplierName: 'Distribuidora Molinos & Panificados del Plata',
        cuit: '33-70891234-9',
        invoiceType: 'Factura B',
        invoiceNumber: `0012-00${Math.floor(340000 + Math.random() * 89000)}`,
        invoiceDate: hoy,
        rubro: 'Panadería & Lácteos',
        notes: 'Panes frescos de hamburguesa brioche y quesos.',
        items: [
          { name: 'Pan de Hamburguesa Brioche x10', rubro: 'Panadería', quantity: 15, unit: 'Packs', costPerUnit: 4200, subtotal: 63000, recibido: true },
          { name: 'Queso Mozzarella Barra Cilindro', rubro: 'Lácteos', quantity: 12.0, unit: 'Kg', costPerUnit: 8400, subtotal: 100800, recibido: true },
          { name: 'Discos de Masa Empanadas Horno x12', rubro: 'Almacén', quantity: 20, unit: 'Packs', costPerUnit: 1650, subtotal: 33000, recibido: true }
        ]
      };
    }

    // Por defecto: Verdulería Central con faltante simulado para nota de crédito
    return {
      supplierName: 'Mercado Central Verduras & Hortalizas',
      cuit: '20-28192033-4',
      invoiceType: 'Remito Oficial',
      invoiceNumber: `0001-00${Math.floor(580000 + Math.random() * 89000)}`,
      invoiceDate: hoy,
      rubro: 'Verdulería & Frescos',
      notes: 'OJO: Las bolsas de Cebolla Morada vinieron de menos (Reclamar nota de crédito).',
      items: [
        { name: 'Papa Blanca Seleccionada Bolsa 20kg', rubro: 'Verdulería', quantity: 4, unit: 'Bolsas', costPerUnit: 9800, subtotal: 39200, recibido: true },
        { name: 'Tomate Redondo Especial Cajón 18kg', rubro: 'Verdulería', quantity: 2, unit: 'Cajones', costPerUnit: 16500, subtotal: 33000, recibido: true },
        { name: 'Cebolla Morada Bolsa 18kg', rubro: 'Verdulería', quantity: 2, unit: 'Bolsas', costPerUnit: 11000, subtotal: 22000, recibido: false }
      ]
    };
  }

  /**
   * Motor de Visión Multimodal Open-Source y Resiliente (Qwen 3.8 LPU + Ollama Local)
   */
  async ejecutarVisionMultimodalJSON({ systemPrompt, userPrompt, imageBase64 }) {
    const cleanBase64 = String(imageBase64 || '').replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '').trim();
    const mimeMatch = String(imageBase64 || '').match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,/);
    const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
    const fullDataUrl = `data:${mimeType};base64,${cleanBase64}`;

    let lastErr = null;

    // 1. MOTOR PRIMARIO: Qwen 3.8 27B Multimodal en Groq LPU (Ultra Rápido)
    if (this.apiKey) {
      try {
        const gr = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.apiKey}`
          },
          body: JSON.stringify({
            model: this.groqVisionModel,
            messages: [
              { role: 'system', content: systemPrompt },
              {
                role: 'user',
                content: [
                  { type: 'image_url', image_url: { url: fullDataUrl } },
                  { type: 'text', text: userPrompt }
                ]
              }
            ],
            temperature: 0.1,
            response_format: { type: 'json_object' }
          }),
          signal: AbortSignal.timeout(9000)
        });

        if (gr.ok) {
          const gj = await gr.json();
          const rawContent = gj?.choices?.[0]?.message?.content || '';
          if (rawContent) {
            const cleaned = rawContent
              .replace(/<think>[\s\S]*?<\/think>/gi, '')
              .replace(/^```json\s*/i, '')
              .replace(/```\s*$/i, '')
              .trim();
            return JSON.parse(cleaned);
          }
        } else {
          const errText = await gr.text().catch(() => '');
          lastErr = new Error(`Groq Vision HTTP ${gr.status}: ${errText.slice(0, 100)}`);
          console.warn('[Nora Vision Groq]', lastErr.message);
        }
      } catch (err) {
        lastErr = err;
        console.warn('[Nora Vision Groq Fetch Error]', err.message);
      }
    }

    // 2. MOTOR SECUNDARIO: Ollama Local (Costo Cero / Offline)
    try {
      const resp = await fetch(`${this.ollamaBaseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.ollamaVisionModel,
          stream: false,
          format: 'json',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt, images: [cleanBase64] }
          ]
        }),
        signal: AbortSignal.timeout(6000)
      });

      if (resp.ok) {
        const data = await resp.json();
        const rawText = data?.message?.content || '';
        if (rawText) {
          const cleaned = rawText
            .replace(/<think>[\s\S]*?<\/think>/gi, '')
            .replace(/^```json\s*/i, '')
            .replace(/```\s*$/i, '')
            .trim();
          return JSON.parse(cleaned);
        }
      }
    } catch (err) {
      lastErr = lastErr || err;
    }

    throw lastErr || new Error('Motores de visión de Nora no respondieron.');
  }

  /**
   * 1. AGENTE DE VISIÓN MULTIMODAL & TREN AGÉNTICO GASTRONÓMICO
   * Inspecciona imágenes reales de comprobantes de compras, almacén y remitos de bebidas/carnes.
   */
  async parseInvoiceVision({
    imageBase64,
    supplierHint = '',
    rawTextHint = '',
    presetDemo = null,
    origen = 'CAMARA_SALON',
    operarioCaptura = 'Cajero'
  }) {
    // A. Si se solicitó simulación de preset rápido (Ideal para demostraciones y pruebas instantáneas)
    if (presetDemo) {
      const datosPreset = this.obtenerPresetGastronomico(presetDemo);
      const totalAmount = datosPreset.items.reduce((s, i) => s + (Number(i.subtotal) || (i.quantity * i.costPerUnit)), 0);

      this.activeDraftInvoice = {
        isLegible: true,
        rubro: datosPreset.rubro,
        supplierName: datosPreset.supplierName,
        cuit: datosPreset.cuit,
        invoiceType: datosPreset.invoiceType,
        invoiceNumber: datosPreset.invoiceNumber,
        invoiceDate: datosPreset.invoiceDate,
        totalAmount,
        confidenceScore: 0.99,
        items: datosPreset.items,
        notes: datosPreset.notes,
        status: 'pending_confirmation',
        origen,
        operarioCaptura,
        imageBase64: 'preset_demo'
      };

      const spokenResponse = `Listo ${operarioCaptura}. Cargué el comprobante de ${datosPreset.supplierName} con ${datosPreset.items.length} renglones por $${totalAmount.toLocaleString('es-AR')}. ¿Confirmás el ingreso al stock del restaurante?`;

      return {
        ok: true,
        success: true,
        isLegible: true,
        modo: 'PRESET_SIMULACION',
        spokenResponse,
        extractedData: this.activeDraftInvoice,
        pendingDraft: this.activeDraftInvoice
      };
    }

    if (!imageBase64) {
      return {
        ok: false,
        success: false,
        isLegible: false,
        error: 'No se recibió ninguna imagen de comprobante para procesar.',
        spokenResponse: 'No recibí ninguna imagen de comprobante para procesar.',
        extractedData: null
      };
    }

    const systemPrompt = `
Eres Nora AI, Directora de Operaciones (COO) y Sistema de Visión Multimodal de Nexora One para Bares y Restaurantes.
Inspecciona la imagen real de la factura, ticket o remito gastronómico con máxima exactitud.

REGLAS ESTRICTAS:
1. Extrae los artículos visibles, cantidades, unidades (Kg, Litros, Unidades, Packs, Barriles) y costos unitarios en pesos argentinos. No inventes productos no visibles.
2. Identifica el proveedor (ej. Cervecerías, Frigoríficos, Verdulerías, Panaderías, Mayoristas) y CUIT.
3. Clasifica el rubro gastronómico: "Bebidas", "Carnes", "Verdulería", "Panadería", "Lácteos", "Almacén", "Limpieza", "Varios".
4. DISCRIMINA EL IVA Y EL NETO: Si la factura es Tipo A o B con IVA especificado, extrae subtotal neto, alícuota de IVA (21%, 10.5% o Exento), monto de IVA y total final.
5. Si la imagen es una foto de prueba sin texto legible, devuelve "isLegible": false con notas.
6. Devuelve ÚNICAMENTE un objeto JSON válido con esta estructura:
{
  "isLegible": true,
  "rubro": "Bebidas | Carnes | Verdulería | Panadería | Almacén | Varios",
  "supplierName": "Nombre del proveedor o distribuidora",
  "cuit": "CUIT si es visible o vacío",
  "invoiceType": "Factura A | Factura B | Factura C | Remito",
  "invoiceNumber": "0001-00000000",
  "invoiceDate": "YYYY-MM-DD",
  "subtotalNeto": 0.0,
  "alicuotaIva": "21% | 10.5% | 0%",
  "ivaTotal": 0.0,
  "totalAmount": 0.0,
  "confidenceScore": 0.95,
  "items": [
    {
      "name": "Nombre exacto del ítem",
      "quantity": 1.0,
      "unit": "Kg / Litros / Unidades / Packs / Barriles",
      "costPerUnit": 0.0,
      "subtotal": 0.0
    }
  ],
  "notes": "Observaciones adicionales"
}
`;

    let parsedData = null;
    let visionErr = null;

    try {
      parsedData = await this.ejecutarVisionMultimodalJSON({
        systemPrompt,
        userPrompt: 'Lee con precisión los ítems, cantidades, costos y proveedor de este comprobante gastronómico para actualizar el inventario.',
        imageBase64
      });
    } catch (err) {
      visionErr = err;
      console.warn('[NoraBrain Vision Error]', err.message);
    }

    // Guardar copia física con timestamp para el contador/gerencia
    const savedImagePath = this.guardarImagenComprobante(imageBase64, parsedData?.supplierName || supplierHint || 'Camara_Salon');

    // Si la visión no pudo leer o salió borrosa, generamos borrador editable con la foto guardada
    if (!parsedData || parsedData.isLegible === false || !Array.isArray(parsedData.items) || parsedData.items.length === 0) {
      const fallbackDraft = {
        isLegible: false,
        rubro: 'Almacén / Gastronomía',
        supplierName: parsedData?.supplierName || supplierHint || 'Comprobante Capturado (Edición Manual)',
        cuit: parsedData?.cuit || '',
        invoiceType: 'Remito / Factura Proveedor',
        invoiceNumber: `CAM-${Date.now().toString().slice(-6)}`,
        invoiceDate: new Date().toISOString().split('T')[0],
        totalAmount: 1000.0,
        confidenceScore: 0.5,
        items: [
          {
            name: 'Insumo capturado por cámara (Editar nombre y costo)',
            quantity: 1,
            unit: 'Unidades',
            costPerUnit: 1000,
            subtotal: 1000
          }
        ],
        notes: parsedData?.notes || 'Foto capturada guardada. No se distinguieron renglones impresos con nitidez; borrador editable habilitado.',
        savedImagePath,
        status: 'pending_confirmation',
        imageBase64: 'saved_on_disk'
      };

      this.activeDraftInvoice = fallbackDraft;

      return {
        ok: true,
        success: true,
        isLegible: false,
        modo: 'BORRADOR_EDITABLE_CAMARA',
        savedImagePath,
        spokenResponse: 'Foto recibida y guardada en el archivo contable. Como la imagen no mostró renglones de factura nítidos, te abrí el borrador editable para que ajustes las cantidades o tomes otra foto más de cerca.',
        extractedData: fallbackDraft,
        pendingDraft: fallbackDraft
      };
    }

    // Calcular o validar totalAmount
    const computedTotal = parsedData.items.reduce((s, i) => s + (Number(i.subtotal) || (Number(i.quantity || 1) * Number(i.costPerUnit || 0))), 0);
    const finalTotal = Number(parsedData.totalAmount) || computedTotal;

    this.activeDraftInvoice = {
      ...parsedData,
      totalAmount: finalTotal,
      savedImagePath,
      status: 'pending_confirmation',
      imageBase64: 'saved_on_disk'
    };

    const rubroInfo = parsedData.rubro ? ` (${parsedData.rubro})` : '';
    const itemsSummary = parsedData.items.slice(0, 4).map((i) => `${i.quantity} ${i.unit || 'u.'} de ${i.name}`).join(', ');

    const spokenResponse = `Mirá ${operarioCaptura}, leí la ${parsedData.invoiceType || 'factura'} de ${parsedData.supplierName || 'proveedor'}${rubroInfo} con ${parsedData.items.length} artículos por $${finalTotal.toLocaleString('es-AR')}. ¿Confirmás el ingreso de estos insumos?`;

    return {
      ok: true,
      success: true,
      isLegible: true,
      modo: 'VISION_MULTIMODAL_ACTIVA',
      savedImagePath,
      spokenResponse,
      extractedData: this.activeDraftInvoice,
      pendingDraft: this.activeDraftInvoice
    };
  }

  /**
   * 2. COMANDOS DE VOZ Y CONCILIACIÓN ITERATIVA
   */
  async processVoiceCommand({ userSpeechText, sector = 'caja', user = 'Admin' }) {
    const text = String(userSpeechText).toLowerCase();

    // A. ¿Hay un borrador de remito pendiente de confirmación?
    if (this.activeDraftInvoice && this.activeDraftInvoice.status === 'pending_confirmation') {
      return this.handleDraftInvoiceConciliation(text, userSpeechText);
    }

    // B. Procesamiento conversacional estándar
    if (this.client) {
      try {
        const currentInventory = this.getAvailableInventoryList();
        const caja = this.sqliteDb.getCajaActual();

        const systemPrompt = `
Eres Nora AI, el cerebro gastronómico de MyJNexoraVisual.
El usuario te habla desde "${sector}". Total caja actual: $${caja.montoTotal}.
Inventario: ${JSON.stringify(currentInventory.slice(0, 10))}

ACCIONES:
- "UPDATE_STOCK": Cargar insumos. { quantity, productName, unit, costPerUnit }
- "QUERY_SALES": Consulta de recaudación o caja.
- "CHAT_GENERAL": Respuestas cordiales o asesoramiento.

Devuelve JSON:
{
  "action": "UPDATE_STOCK" | "QUERY_SALES" | "CHAT_GENERAL",
  "spokenResponse": "Respuesta breve de Nora (máximo 2 oraciones)",
  "payload": {}
}
`;

        const response = await this.client.chat.completions.create({
          model: this.textModels[0],
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userSpeechText }
          ],
          temperature: 0.2,
          response_format: { type: 'json_object' }
        });

        const parsed = JSON.parse(response.choices[0]?.message?.content || '{}');
        const executionResult = await this.executeAction(parsed);

        return {
          success: true,
          interpreted: parsed,
          executionResult
        };
      } catch (e) {
        console.warn('[NoraBrain Voice] Error con LLM, usando fallback local:', e.message);
      }
    }

    return this.fallbackVoiceCommand(userSpeechText);
  }

  /**
   * Conciliación Conversacional de Remitos / Facturas
   */
  async handleDraftInvoiceConciliation(text, originalSpeech) {
    const draft = this.activeDraftInvoice;

    // 1. Confirmación Total: "Todo en orden", "sí", "correcto", "recibí todo", "guardar"
    if (text.includes('si') || text.includes('sí') || text.includes('todo') || text.includes('correcto') || text.includes('orden') || text.includes('confirmar')) {
      const dbResult = this.sqliteDb.procesarFacturaIA({
        supplierName: draft.supplierName,
        invoiceType: draft.invoiceType,
        invoiceDate: draft.invoiceDate,
        totalAmount: draft.totalAmount,
        items: draft.items,
        rawText: draft.notes || draft.rawText,
        imageBase64: draft.savedImagePath || draft.imageBase64
      });

      this.activeDraftInvoice = null;

      const spoken = `Perfecto. Stock y gasto de ${draft.supplierName || 'insumos'} impactados correctamente en el sistema.`;
      return {
        success: true,
        interpreted: { action: 'CONFIRM_DRAFT', spokenResponse: spoken },
        executionResult: { updated: true, dbResult }
      };
    }

    // 2. Modificación de Faltantes: "faltaron X kg", "vino menos", "llegaron solo Y"
    if (text.includes('falto') || text.includes('faltaron') || text.includes('menos') || text.includes('solo')) {
      const matchNumber = text.match(/(\d+[\.,]?\d*)/);
      const diffAmount = matchNumber ? parseFloat(matchNumber[1].replace(',', '.')) : 2.0;

      if (draft.items && draft.items.length > 0) {
        draft.items[0].quantity = Math.max(0, draft.items[0].quantity - diffAmount);
        draft.items[0].subtotal = draft.items[0].quantity * (draft.items[0].costPerUnit || 1);
        draft.totalAmount = draft.items.reduce((s, i) => s + (i.subtotal || 0), 0);
      }

      const dbResult = this.sqliteDb.procesarFacturaIA({
        supplierName: draft.supplierName,
        invoiceType: draft.invoiceType,
        invoiceDate: draft.invoiceDate,
        totalAmount: draft.totalAmount,
        items: draft.items,
        rawText: `${draft.notes || ''} | Ajuste por faltante reportado: ${diffAmount}`
      });

      this.activeDraftInvoice = null;

      const spoken = `Entendido. Desconté los ${diffAmount} faltantes y actualicé el inventario real en el sistema.`;
      return {
        success: true,
        interpreted: { action: 'ADJUST_AND_CONFIRM_DRAFT', spokenResponse: spoken },
        executionResult: { updated: true, dbResult }
      };
    }

    // 3. Cancelar borrador
    if (text.includes('cancelar') || text.includes('no') || text.includes('descartar')) {
      this.activeDraftInvoice = null;
      return {
        success: true,
        interpreted: { action: 'CANCEL_DRAFT', spokenResponse: 'Borrador de remito cancelado. No se modificó el inventario.' },
        executionResult: { cancelled: true }
      };
    }

    return {
      success: true,
      pendingDraft: draft,
      interpreted: {
        action: 'AWAITING_CONFIRMATION',
        spokenResponse: '¿Deseas confirmar la recepción de todos los ítems o indicar algún faltante?'
      }
    };
  }

  generateFallbackDraft(rawText = '') {
    return {
      isLegible: false,
      supplierName: 'Comprobante no reconocido',
      invoiceType: 'Desconocido',
      invoiceDate: new Date().toISOString().split('T')[0],
      totalAmount: 0,
      items: [],
      notes: 'No fue posible extraer ítems automáticamente sin una imagen clara.'
    };
  }

  async executeAction(actionIntent) {
    const { action, payload } = actionIntent;
    if (action === 'QUERY_SALES') {
      const caja = this.sqliteDb.getCajaActual();
      return { totalCaja: caja.montoTotal, movimientos: caja.movimientos.length };
    }
    if (action === 'UPDATE_STOCK') {
      const qty = Number(payload.quantity) || 1;
      const name = payload.productName || 'Producto';
      const dbResult = this.sqliteDb.procesarFacturaIA({
        supplierName: 'Comando de Voz Nora',
        totalAmount: 0,
        items: [{ name, quantity: qty, unit: payload.unit || 'u.', costPerUnit: Number(payload.costPerUnit) || 0 }]
      });
      return { updated: true, dbResult };
    }
    return { handled: true };
  }

  getAvailableInventoryList() {
    try {
      return this.sqliteDb.getInventory().map((i) => ({
        id: i.id,
        name: i.name,
        stock: i.currentStock,
        min: i.minStock,
        unit: i.unit
      }));
    } catch (e) {
      return [];
    }
  }

  fallbackVoiceCommand(userSpeechText) {
    const text = (userSpeechText || '').toLowerCase();

    if (text.includes('caja') || text.includes('recaud') || text.includes('cuanto hay') || text.includes('plata')) {
      const caja = this.sqliteDb.getCajaActual();
      return {
        success: true,
        interpreted: {
          action: 'QUERY_SALES',
          spokenResponse: `El saldo actual en caja es de $${caja.montoTotal.toLocaleString('es-AR')}, con ${caja.movimientos.length} movimientos registrados.`
        },
        executionResult: { totalCaja: caja.montoTotal, movimientos: caja.movimientos.length }
      };
    }

    if (text.includes('stock') || text.includes('falta') || text.includes('inventario') || text.includes('insumo')) {
      const inventory = this.getAvailableInventoryList();
      const critical = inventory.filter((i) => i.stock <= i.min);
      if (critical.length > 0) {
        const items = critical.map((c) => `${c.name} (${c.stock} ${c.unit})`).join(', ');
        return {
          success: true,
          interpreted: {
            action: 'QUERY_STOCK',
            spokenResponse: `Atención: registramos ${critical.length} insumos en nivel crítico: ${items}.`
          },
          executionResult: { criticalItems: critical }
        };
      }
      return {
        success: true,
        interpreted: {
          action: 'QUERY_STOCK',
          spokenResponse: `Actualmente registramos ${inventory.length} insumos en inventario de depósito.`
        },
        executionResult: { inventoryCount: inventory.length }
      };
    }

    if (text.includes('hola') || text.includes('buen dia') || text.includes('buenas') || text.includes('nora')) {
      return {
        success: true,
        interpreted: {
          action: 'CHAT_GENERAL',
          spokenResponse: '¡Hola! Aquí está Nora. ¿En qué puedo asistirte en el salón o en la caja hoy?'
        },
        executionResult: { handled: true }
      };
    }

    if (text.includes('ayuda') || text.includes('que podes hacer') || text.includes('como funciona')) {
      return {
        success: true,
        interpreted: {
          action: 'CHAT_GENERAL',
          spokenResponse: 'Puedo consultar el saldo de caja, verificar stock de insumos, escanear remitos con la cámara para actualizar mercadería y liberar mesas.'
        },
        executionResult: { handled: true }
      };
    }

    return {
      success: true,
      interpreted: {
        action: 'CHAT_GENERAL',
        spokenResponse: `Comprendido. Registré tu consulta sobre "${userSpeechText}". Si necesitas consultar caja, stock de insumos o escanear un comprobante, estoy lista.`
      },
      executionResult: { handled: true }
    };
  }

  /**
   * Agente de Recepción y Derivación Automática de Pedidos de Clientes por WhatsApp
   */
  async interpretarPedidoClienteWhatsApp({ textoMensaje, clienteNombre = 'Cliente', clienteTelefono = '', menuDisponible = [] }) {
    const fallbackResponse = {
      esPedido: false,
      clienteNombre,
      direccion: '',
      tipo: 'delivery',
      items: [],
      total: 0,
      respuestaWhatsApp: `¡Hola ${clienteNombre}! Recibí tu mensaje. En breve te respondemos o podés consultar nuestra carta digital.`
    };

    if (!textoMensaje || textoMensaje.trim().length === 0) return fallbackResponse;

    // Resumen simplificado del menú para el LLM
    const catalogo = (menuDisponible || []).map(p => ({
      id: p.id,
      nombre: p.title || p.name,
      precio: Number(p.price) || 0,
      categoria: p.category || 'general'
    }));

    const systemPrompt = `
Eres Nora AI, Agente Recepcionista Inteligente de Nexora One para Bares y Restaurantes.
Tu trabajo es interpretar los mensajes entrantes de WhatsApp de los clientes del restaurante.

CATÁLOGO REAL DE PLATOS Y BEBIDAS DISPONIBLES:
${JSON.stringify(catalogo)}

REGLAS ESTRICTAS:
1. Determina si el mensaje es un PEDIDO DE COMIDA / BEBIDA ("esPedido": true) o una simple consulta/saludo ("esPedido": false).
2. Si es pedido:
   - Identifica cada plato o bebida pedido haciendo coincidencia con el catálogo.
   - Extrae la cantidad, precio unitario del catálogo y subtotal.
   - Detecta si especificó dirección para delivery ("Calle...", "Barrio...", "a mi casa...") o si aclara que pasa a retirar (tipo: "takeaway" o "delivery").
   - Extrae notas de personalización (ej. "sin cebolla", "bien cocida", "con limón").
3. Calcula el total sumando los subtotales de los ítems.
4. Redacta una "respuestaWhatsApp" cordial, clara y profesional confirmando exactamente lo que pidió, el total en pesos y que ya marchó a cocina.
5. Devuelve ÚNICAMENTE un JSON válido con esta estructura:
{
  "esPedido": true,
  "clienteNombre": "${clienteNombre}",
  "direccion": "Dirección detectada o vacía",
  "tipo": "delivery | takeaway",
  "items": [
    {
      "producto_id": 1,
      "title": "Nombre del plato según catálogo",
      "quantity": 1,
      "price": 5000,
      "subtotal": 5000,
      "notes": "aclaraciones del cliente o vacío",
      "category": "categoria"
    }
  ],
  "total": 5000,
  "respuestaWhatsApp": "Mensaje de respuesta para el cliente"
}
`;

    // Intentar con Groq LPU
    if (this.apiKey) {
      try {
        const resp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.apiKey}`
          },
          body: JSON.stringify({
            model: this.textModels[0] || 'llama-3.3-70b-versatile',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: `Mensaje del cliente (${clienteNombre}): "${textoMensaje}"` }
            ],
            temperature: 0.1,
            response_format: { type: 'json_object' }
          }),
          signal: AbortSignal.timeout(7000)
        });

        if (resp.ok) {
          const resJson = await resp.json();
          const raw = resJson.choices?.[0]?.message?.content || '{}';
          const cleaned = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
          return JSON.parse(cleaned);
        }
      } catch (e) {
        console.warn('[Nora WhatsApp Order Interpreter Groq]', e.message);
      }
    }

    // Fallback Ollama Local
    try {
      const resp = await fetch(`${this.ollamaBaseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.ollamaTextModel || 'llama3.3:latest',
          stream: false,
          format: 'json',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `Mensaje del cliente (${clienteNombre}): "${textoMensaje}"` }
          ]
        }),
        signal: AbortSignal.timeout(5000)
      });
      if (resp.ok) {
        const data = await resp.json();
        const raw = data?.message?.content || '{}';
        const cleaned = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
        return JSON.parse(cleaned);
      }
    } catch (e) {}

    return fallbackResponse;
  }
}

export const noraBrain = new NoraBrainController();
export default noraBrain;
