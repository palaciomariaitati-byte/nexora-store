@echo off
title Restobar POS 2026 - Terminal Soberana (Nexora One)
color 0B

echo ======================================================================
echo          RESTOBAR POS 2026 - SISTEMA GASTRONOMICO SOBERANO
echo                        Powered by Nexora One
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: 0. Verificacion de dependencias del servidor backend
if not exist "%ROOT_DIR%backend\node_modules" (
    echo  [0/3] Configurando modulos del servidor (solo en primer inicio)...
    call npm --prefix "%ROOT_DIR%backend" install --omit=dev
)

:: 1. Verificacion de interfaz compilada
echo  [1/3] Verificando compilacion de frontend...
if not exist "%ROOT_DIR%frontend\dist" (
    call npm --prefix "%ROOT_DIR%frontend" run build
) else (
    echo        Frontend compilado listo.
)

:: 2. Limpieza de puertos para evitar bloqueos
echo  [2/3] Liberando puertos de terminal (3035 y 3036)...
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3035" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3036" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

:: 3. Iniciar Servidor Unificado (Node/Express + SQLite WAL + UI Compilada en puerto 3035)
echo.
echo  [3/3] Iniciando Servidor Soberano y Salon...
start /min "Restobar POS 2026 (Nexora One)" cmd /c "cd /d "%ROOT_DIR%backend" && node server.js"

:: Si existe el codigo fuente frontend y se desea HMR dev, levantar 3036 opcional
if exist "%ROOT_DIR%frontend\src" (
    start /min "Restobar POS - Dev HMR" cmd /c "cd /d "%ROOT_DIR%frontend" && npx vite --port 3036 --host"
)

:: Espera breve para inicializar servidores
ping -n 4 127.0.0.1 >nul

echo.
echo  ======================================================================
echo   TERMINAL RESTOBAR 2026 ACTIVA
echo   - Servidor Soberano: http://localhost:3035/
echo   - Base SQLite:       %ROOT_DIR%backend\data\restobar.sqlite (Protegida)
echo   - Tren Agéntico:     Nora Vision Qwen 3.8 + WhatsApp Multi-Device
echo  ======================================================================
echo.

:: Detectar Chrome, Edge o navegador por defecto para modo aplicacion dedicada
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3035/
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3035/
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3035/
) else (
    start http://localhost:3035/
)

echo Sistema abierto en pantalla.
