/**
 * whatsapp_baileys_service.js - Motor Real de WhatsApp Multi-Device para Bares & Restaurantes 2026
 * 
 * Funciones del Tren Agéntico de Nora:
 *  1. Recepción y lectura automática de Facturas/Remitos por foto de proveedores o encargados.
 *  2. Recepción de Pedidos de Clientes (Delivery / Take Away) por texto/audio,
 *     interpretación con IA y derivación automática a Cocina (KDS) y Caja.
 *  3. Confirmación inmediata al cliente por WhatsApp.
 */

import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  downloadMediaMessage,
  fetchLatestBaileysVersion
} from '@whiskeysockets/baileys';
import QRCode from 'qrcode';
import pino from 'pino';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { db } from './database.js';
import { noraBrain } from './nora_controller.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const AUTH_DIR = path.join(__dirname, 'data', 'whatsapp_auth_session');

class WhatsAppRestobarService {
  constructor() {
    this.sock = null;
    this.qrDataUrl = '';
    this.status = 'INICIANDO_MOTOR_QR';
    this.linked = false;
    this.linkedPhone = '';
    this.linkedName = '';
    this.linkedAt = null;
    this.onStateChange = null;
    this.isConnecting = false;
    this.io = null; // Socket.io instance
    this.recentEvents = []; // Feed en vivo de eventos WhatsApp
  }

  setSocketIO(ioInstance) {
    this.io = ioInstance;
  }

  getState() {
    return {
      linked: this.linked,
      mode: this.status,
      qrDataUrl: this.qrDataUrl,
      linkedPhone: this.linkedPhone,
      linkedName: this.linkedName,
      linkedAt: this.linkedAt,
      recentEvents: this.recentEvents.slice(0, 20)
    };
  }

  notifyChange() {
    const state = this.getState();
    if (this.io) {
      this.io.emit('whatsapp:state', state);
    }
    if (typeof this.onStateChange === 'function') {
      this.onStateChange(state);
    }
  }

  logEvent(tipo, titulo, detalle) {
    const ev = {
      id: `wa_ev_${Date.now()}`,
      tipo,
      titulo,
      detalle,
      timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
    };
    this.recentEvents.unshift(ev);
    if (this.recentEvents.length > 50) this.recentEvents.pop();
    this.notifyChange();
  }

  async iniciarSesionWhatsApp() {
    if (this.isConnecting) return;
    this.isConnecting = true;

    try {
      if (!fs.existsSync(AUTH_DIR)) {
        fs.mkdirSync(AUTH_DIR, { recursive: true });
      }

      const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
      let version = [2, 3000, 1015901307];
      try {
        const latest = await fetchLatestBaileysVersion();
        if (latest && latest.version) version = latest.version;
      } catch (e) {}

      this.sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: 'silent' }),
        browser: ['Nora AI Restobar (Nexora One)', 'Chrome', '122.0.0']
      });

      this.sock.ev.on('creds.update', saveCreds);

      this.sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
          try {
            this.qrDataUrl = await QRCode.toDataURL(qr, {
              width: 240,
              margin: 2,
              color: { dark: '#0b0f19', light: '#ffffff' }
            });
            this.linked = false;
            this.status = 'ESPERANDO_ESCANEO_DISPOSITIVOS_VINCULADOS';
            this.notifyChange();
          } catch (err) {
            console.error('[WhatsApp Baileys] Error generando QR:', err.message);
          }
        }

        if (connection === 'open') {
          this.isConnecting = false;
          this.linked = true;
          this.qrDataUrl = '';
          this.status = 'VINCULADO_DISPOSITIVO_OFICIAL';
          const rawId = this.sock?.user?.id || '';
          this.linkedPhone = '+' + rawId.split(':')[0].split('@')[0];
          this.linkedName = this.sock?.user?.name || 'WhatsApp Restobar';
          this.linkedAt = new Date().toLocaleTimeString('es-AR');

          console.log(` ✅ [WHATSAPP RESTOBAR VINCULADO]: ${this.linkedPhone} (${this.linkedName})`);
          this.logEvent('CONEXION', 'WhatsApp Vinculado', `Número activo: ${this.linkedPhone}`);
          this.notifyChange();
        }

        if (connection === 'close') {
          this.isConnecting = false;
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

          if (!shouldReconnect) {
            this.limpiarYReiniciarQR();
          } else {
            this.status = 'RECONECTANDO_WHATSAPP';
            this.notifyChange();
            setTimeout(() => this.iniciarSesionWhatsApp(), 4000);
          }
        }
      });

      // ESCUCHA DE MENSAJES (FOTOS DE FACTURAS O PEDIDOS DE CLIENTES)
      this.sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const msg of messages) {
          try {
            if (!msg.message) continue;
            // Evitar mensajes de grupos o estados
            const remoteJid = msg.key.remoteJid || '';
            if (remoteJid.endsWith('@g.us') || remoteJid === 'status@broadcast') continue;

            const senderNumber = '+' + remoteJid.split('@')[0];
            const senderName = msg.pushName || senderNumber;
            const imgMsg = msg.message.imageMessage;
            const textMsg = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

            // CASO A: FOTO DE FACTURA / REMITO RECIBIDA
            if (imgMsg) {
              this.logEvent('FACTURA', 'Foto recibida', `De: ${senderName} (${senderNumber})`);

              const buffer = await downloadMediaMessage(
                msg,
                'buffer',
                {},
                { logger: pino({ level: 'silent' }), reuploadRequest: this.sock.updateMediaMessage }
              );

              if (buffer && buffer.length > 0) {
                const base64Image = `data:image/jpeg;base64,${buffer.toString('base64')}`;
                const resVision = await noraBrain.parseInvoiceVision({
                  imageBase64: base64Image,
                  supplierHint: `WhatsApp ${senderName}`,
                  origen: 'WHATSAPP_PROVEEDOR',
                  operarioCaptura: senderName
                });

                if (resVision.success && resVision.extractedData) {
                  const b = resVision.extractedData;
                  const total = Number(b.totalAmount) || 0;
                  const iva = b.ivaTotal ? `• *IVA discriminado:* $${Number(b.ivaTotal).toLocaleString('es-AR')}\n` : '';

                  await this.sock.sendMessage(remoteJid, {
                    text: `🤖 *Nora AI Restobar*\n\n✅ *Comprobante Procesado*\n• *Proveedor:* ${b.supplierName || 'Proveedor'}\n• *Tipo:* ${b.invoiceType || 'Factura/Remito'}\n• *Total:* $${total.toLocaleString('es-AR')} ARS\n${iva}• *Ítems detectados:* ${b.items?.length || 0}\n\n👉 Ya quedó registrado en la bandeja de inventario para confirmación de recepción.`
                  });

                  this.logEvent('FACTURA_PROCESADA', `Factura ${b.supplierName}`, `$${total.toLocaleString('es-AR')} - ${b.items?.length || 0} ítems`);
                }
              }
              continue;
            }

            // CASO B: MENSAJE DE TEXTO (PEDIDO DE CLIENTE O CONSULTA)
            if (textMsg && textMsg.trim().length > 1) {
              const resProceso = await this.procesarTextoEntrante({
                senderName,
                senderNumber,
                textMsg
              });

              if (resProceso.respuestaWhatsApp) {
                await this.sock.sendMessage(remoteJid, { text: resProceso.respuestaWhatsApp });
              }
            }
          } catch (err) {
            console.warn('[WhatsApp Upsert Warning]:', err.message);
          }
        }
      });
    } catch (e) {
      this.isConnecting = false;
      console.error('[WhatsApp Baileys Init Error]:', e.message);
      this.status = 'ERROR_REINTENTANDO';
      setTimeout(() => this.iniciarSesionWhatsApp(), 5000);
    }
  }

  async procesarTextoEntrante({ senderName = 'Cliente WhatsApp', senderNumber = '5491100000000', textMsg = '' }) {
    if (!textMsg || textMsg.trim().length === 0) {
      return { success: false, error: 'Mensaje vacío' };
    }

    const menuActual = db.getMenu();
    const interpretacion = await noraBrain.interpretarPedidoClienteWhatsApp({
      textoMensaje: textMsg,
      clienteNombre: senderName,
      clienteTelefono: senderNumber,
      menuDisponible: menuActual
    });

    if (interpretacion.esPedido && Array.isArray(interpretacion.items) && interpretacion.items.length > 0) {
      const comanda = db.procesarComanda({
        sessionId: null,
        tableId: null,
        dinerName: `${interpretacion.clienteNombre || senderName} (WA: ${senderNumber})`,
        items: interpretacion.items,
        tipo: interpretacion.tipo || 'delivery'
      });

      if (this.io) {
        const comandaTicket = {
          orderId: comanda.id,
          tableId: null,
          tableName: `🛵 Delivery WhatsApp (${interpretacion.clienteNombre || senderName})`,
          dinerName: comanda.dinerName,
          createdAt: comanda.createdAt,
          brandSignature: 'Nexora One',
          direccion: interpretacion.direccion || 'Consultar por chat',
          items: comanda.items.map(i => ({
            quantity: i.quantity,
            title: i.title,
            notes: i.notes,
            category: i.category || 'general'
          }))
        };

        this.io.emit('order_created', { order: comanda, session: null, comandaTicket });
        this.io.emit('inventory_updated', { inventory: db.getInventory() });
      }

      const respuesta = interpretacion.respuestaWhatsApp || 
        `🤖 *Restobar*\n¡Hola ${senderName}! Ya tomamos tu pedido:\n${interpretacion.items.map(i => `• ${i.quantity}x ${i.title}`).join('\n')}\n*Total:* $${Number(interpretacion.total || comanda.total).toLocaleString('es-AR')}\n\n👨‍🍳 Ya marchó el ticket a cocina y te avisamos cuando salga el cadete.`;

      this.logEvent('PEDIDO_WHATSAPP', `Pedido de ${senderName}`, `${interpretacion.items.length} platos - $${Number(comanda.total).toLocaleString('es-AR')}`);

      return {
        success: true,
        esPedido: true,
        comandaId: comanda.id,
        items: interpretacion.items,
        total: comanda.total,
        respuestaWhatsApp: respuesta
      };
    } else {
      const respuesta = interpretacion.respuestaWhatsApp ||
        `¡Hola ${senderName}! Soy Nora de Restobar. Puedes hacerme tu pedido por acá directamente o consultarnos lo que necesites.`;
      return {
        success: true,
        esPedido: false,
        respuestaWhatsApp: respuesta
      };
    }
  }

  async procesarFacturaEntrante({ imageBase64, supplierHint = 'WhatsApp', senderName = 'Proveedor' }) {
    if (!imageBase64) return { success: false, error: 'Imagen requerida' };
    const resVision = await noraBrain.parseInvoiceVision({
      imageBase64,
      supplierHint: `WhatsApp ${supplierHint}`,
      origen: 'WHATSAPP_PROVEEDOR',
      operarioCaptura: senderName
    });
    return resVision;
  }

  async enviarMensaje(numero, texto) {
    if (!this.linked || !this.sock) return false;
    try {
      const cleanPhone = String(numero).replace(/[^0-9]/g, '');
      const jid = `${cleanPhone}@s.whatsapp.net`;
      await this.sock.sendMessage(jid, { text });
      return true;
    } catch (e) {
      console.warn('[WhatsApp Send Warning]:', e.message);
      return false;
    }
  }

  async limpiarYReiniciarQR() {
    try {
      if (this.sock) {
        try { await this.sock.logout(); } catch (e) {}
        try { this.sock.end(); } catch (e) {}
      }
    } catch (e) {}

    this.sock = null;
    this.linked = false;
    this.linkedPhone = '';
    this.linkedName = '';
    this.qrDataUrl = '';
    this.isConnecting = false;
    this.status = 'GENERANDO_NUEVO_QR';
    this.notifyChange();

    try {
      if (fs.existsSync(AUTH_DIR)) {
        fs.rmSync(AUTH_DIR, { recursive: true, force: true });
      }
    } catch (e) {}

    setTimeout(() => this.iniciarSesionWhatsApp(), 800);
  }
}

export const whatsappService = new WhatsAppRestobarService();
export default whatsappService;
