import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const BASE_URL = 'http://localhost:3035';

console.log('==================================================================');
console.log(' ⚡ ESTRÉS Y CONTROL DE CALIDAD DE ALTA CONCURRENCIA: MYJNEXORAVISUAL');
console.log('==================================================================\n');

async function runStressTest() {
  const startTime = Date.now();
  let errorsCount = 0;
  let successCount = 0;

  try {
    // 1. Apertura de Caja con fondo inicial de $50.000
    console.log('💵 1. Ejecutando Apertura de Caja con $50.000...');
    const cajaRes = await fetch(`${BASE_URL}/api/erp/caja-inicial`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: 50000 })
    });
    const cajaData = await cajaRes.json();
    if (cajaRes.ok && cajaData.success) {
      console.log('   ✅ Caja aperturada correctamente con $50.000 ARS.');
      successCount++;
    } else {
      console.error('   ❌ Error en apertura de caja:', cajaData);
      errorsCount++;
    }

    // 2. Envío simultáneo de 50 pedidos de diferentes mesas con notas de ingredientes
    console.log('\n🚀 2. Disparando 50 pedidos simultáneos en paralelo con ingredientes personalizados...');
    const orderPromises = Array.from({ length: 50 }, async (_, i) => {
      const tableId = (i % 30) + 1;
      
      const sessionRes = await fetch(`${BASE_URL}/api/tables/${tableId}/session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comensales: (i % 4) + 1 })
      });
      const sessionData = await sessionRes.json();
      const sessionId = sessionData.session?.id;

      if (!sessionId) {
        throw new Error(`Mesa ${tableId}: ${sessionData.error || 'Sin sessionId'}`);
      }

      const orderRes = await fetch(`${BASE_URL}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          dinerName: `Comensal #${(i % 4) + 1}`,
          items: [
            {
              id: i % 2 === 0 ? 'm1' : 'm4',
              title: i % 2 === 0 ? 'Bife de Chorizo Premium (350g)' : 'Hamburguesa Doble Smash MyJ',
              quantity: 1,
              price: i % 2 === 0 ? 14500 : 9800,
              subtotal: i % 2 === 0 ? 14500 : 10800,
              notes: i % 2 === 0 
                ? '🔴 ❌ SIN CHIMICHURRI | 🟢 ➕ EXTRA PAPAS RÚSTICAS (+$1500)'
                : '🔴 ❌ SIN CEBOLLA | 🟢 ➕ EXTRA DOBLE QUESO (+$1000)',
              category: 'del-dia'
            }
          ]
        })
      });
      const orderData = await orderRes.json();
      if (orderRes.ok && orderData.success) {
        return true;
      } else {
        throw new Error(`Order ${i}: ${orderData.error || orderRes.statusText}`);
      }
    });

    const orderResults = await Promise.allSettled(orderPromises);
    const orderSuccesses = orderResults.filter(r => r.status === 'fulfilled').length;
    const orderFailures = orderResults.filter(r => r.status === 'rejected');

    if (orderFailures.length > 0) {
      console.log('   🔍 Muestra de errores en pedidos:', orderFailures.slice(0, 3).map(f => f.reason?.message));
    }
    console.log(`   📊 Pedidos Procesados: ${orderSuccesses}/50 Éxito | ${orderFailures.length}/50 Fallos.`);
    successCount += orderSuccesses;
    errorsCount += orderFailures.length;

    // 3. Procesamiento de 10 cargas de stock en depósito (ERP Inventory)
    console.log('\n📦 3. Procesando 10 cargas simultáneas de stock en Depósito (ERP)...');
    const inventoryPromises = Array.from({ length: 10 }, async (_, k) => {
      const invRes = await fetch(`${BASE_URL}/api/erp/inventory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `Insumo Test Carga Concurrente #${k + 1}`,
          category: 'Mercadería Estrés',
          stock: 100 + k * 10,
          unit: 'kg',
          minStock: 20
        })
      });
      const invData = await invRes.json();
      if (invRes.ok && invData.success) {
        return true;
      } else {
        throw new Error(`Inventory ${k}: ${invData.error || invRes.statusText}`);
      }
    });

    const invResults = await Promise.allSettled(inventoryPromises);
    const invSuccesses = invResults.filter(r => r.status === 'fulfilled').length;
    const invFailures = invResults.filter(r => r.status === 'rejected');
    console.log(`   📊 Cargas de Stock Procesadas: ${invSuccesses}/10 Éxito | ${invFailures.length}/10 Fallos.`);
    successCount += invSuccesses;
    errorsCount += invFailures.length;

    // 4. 20 Cierres de cuentas y comprobaciones de pago vía Nexora Pay
    console.log('\n💳 4. Procesando 20 verificaciones de pago y transacciones Nexora Pay...');
    const payPromises = Array.from({ length: 20 }, async (_, p) => {
      const payRes = await fetch(`${BASE_URL}/api/system/verificar-pago`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const payData = await payRes.json();
      if (payRes.ok && (payData.success || payData.licencia)) {
        return true;
      } else {
        throw new Error(`Payment ${p}: status=${payRes.status} body=${JSON.stringify(payData)}`);
      }
    });

    const payResults = await Promise.allSettled(payPromises);
    const paySuccesses = payResults.filter(r => r.status === 'fulfilled').length;
    const payFailures = payResults.filter(r => r.status === 'rejected');

    if (payFailures.length > 0) {
      console.log('   🔍 Muestra de errores en pagos:', payFailures.slice(0, 3).map(f => f.reason?.message));
    }

    console.log(`   📊 Transacciones Nexora Pay Procesadas: ${paySuccesses}/20 Éxito | ${payFailures.length}/20 Fallos.`);
    successCount += paySuccesses;
    errorsCount += payFailures.length;

    // Métricas de tiempo y rendimiento
    const totalTimeMs = Date.now() - startTime;
    const dbFilePath = path.join(__dirname, 'backend', 'data', 'store.json');
    let dbSizeKB = 0;
    if (fs.existsSync(dbFilePath)) {
      dbSizeKB = (fs.statSync(dbFilePath).size / 1024).toFixed(2);
    }

    console.log('\n==================================================================');
    console.log(' 📈 RESULTADOS DE AUDITORÍA Y ESTRÉS DE ALTA CONCURRENCIA');
    console.log('==================================================================');
    console.log(` ⏱️  Tiempo Total de Procesamiento: ${totalTimeMs} ms (${(totalTimeMs / 1000).toFixed(2)}s)`);
    console.log(` ✅ Operaciones Exitosas: ${successCount} / 81`);
    console.log(` ❌ Fallos Registrados: ${errorsCount}`);
    console.log(` 💾 Tamaño del Archivo DB (store.json): ${dbSizeKB} KB`);
    console.log(` 🔒 Escritura Atómica (.tmp + renameSync): SIN BLOQUEOS DETECTADOS`);
    console.log('==================================================================\n');

    if (errorsCount === 0) {
      console.log('🟢 PRUEBA DE ESTRÉS EXITOSA AL 100% (Código de Salida: 0)\n');
      process.exit(0);
    } else {
      console.error(`🔴 ALERTA: Se detectaron ${errorsCount} fallos durante la prueba de estrés.\n`);
      process.exit(1);
    }

  } catch (err) {
    console.error('💥 Error no controlado durante el script de estrés:', err);
    process.exit(1);
  }
}

runStressTest();
