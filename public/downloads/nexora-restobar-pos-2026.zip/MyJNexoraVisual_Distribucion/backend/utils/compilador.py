import os
import sys
import shutil
import subprocess

# Ensure UTF-8 stdout encoding for Windows console
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def compilar_suite_comercial():
    print("==================================================================")
    print(" [NEXORA AI] COMPILADOR INDUSTRIAL: MyJNexoraVisual - SUITE RESTOBAR")
    print("==================================================================")
    ruta_raiz = r"D:\BARES 2026"
    ruta_salida = os.path.join(ruta_raiz, "MyJNexoraVisual_Distribucion")
    
    if os.path.exists(ruta_salida):
        try:
            shutil.rmtree(ruta_salida)
        except Exception as e:
            print(f"[AVISO] No se pudo borrar distribucion previa: {e}")
    
    if not os.path.exists(ruta_salida):
        os.makedirs(ruta_salida)
    
    print("[NEXORA AI] Compilando la interfaz visual de React (Frontend)...")
    try:
        subprocess.run("npm run build", shell=True, check=True, cwd=os.path.join(ruta_raiz, "frontend"), stdout=subprocess.DEVNULL)
        print("[OK] Frontend compilado con exito en frontend/dist")
    except subprocess.CalledProcessError:
        print("[ERROR] Fallo la compilacion del Frontend.")
        return

    print("[NEXORA AI] Empaquetando backend y assets estaticos...")
    shutil.copytree(os.path.join(ruta_raiz, "backend"), os.path.join(ruta_salida, "backend"), ignore=shutil.ignore_patterns('*.tmp', 'backups/*'))
    shutil.copy(os.path.join(ruta_raiz, "ecosystem.config.cjs"), os.path.join(ruta_salida, "ecosystem.config.cjs"))
    shutil.copytree(os.path.join(ruta_raiz, "frontend", "dist"), os.path.join(ruta_salida, "frontend", "dist"))

    with open(os.path.join(ruta_salida, "Iniciar_SISTEMA.bat"), "w", encoding="utf-8") as f:
        f.write("@echo off\ntitle MyJNexoraVisual - SUITE COMERCIAL\ncall npx pm2 start ecosystem.config.cjs --silent\nstart http://localhost:3036\n")
        
    with open(os.path.join(ruta_salida, "detener_SISTEMA.bat"), "w", encoding="utf-8") as f:
        f.write("@echo off\ntitle MyJNexoraVisual - APAGADO DE SUITE\ncall npx pm2 kill --silent\ntimeout /t 2 > nul\n")
        
    print("==================================================================")
    print(" [OK] Compilacion industrial exitosa en carpeta de distribucion:")
    print(f" Path: {ruta_salida}")
    print("==================================================================")

if __name__ == "__main__":
    compilar_suite_comercial()
