@echo off
title MyJNexoraVisual - SUITE COMERCIAL
call npx pm2 start ecosystem.config.cjs --silent
start http://localhost:3036
