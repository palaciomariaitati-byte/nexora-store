module.exports = {
  apps: [
    {
      name: 'myjnexora-backend',
      script: './backend/server.js',
      env: { NODE_ENV: 'production', PORT: 3035 }
    },
    {
      name: 'myjnexora-frontend',
      script: 'node_modules/vite/bin/vite.js',
      args: '--host 0.0.0.0 --port 3036',
      env: { NODE_ENV: 'production' }
    }
  ]
};
