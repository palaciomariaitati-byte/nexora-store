@echo off
title MyJNexoraVisual - APAGADO DE SUITE
call npx pm2 kill --silent
timeout /t 2 > nul
