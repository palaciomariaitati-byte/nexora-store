# 🚀 INTEGRATION BLUEPRINT: NORA COGNITIVE AI ➔ BARES 2026 RESTOBAR
**Proyecto:** MyJNexoraVisual - Gastronomía & Bar OS 2026  
**Cerebro:** Nora AI (proveniente de `D:\Nora itu UTN`)  
**Destino:** `D:\BARES 2026\backend`  
**Fecha:** Octubre 2026  

---

## 1. 🔍 Resumen del Análisis de `D:\Nora itu UTN`

Del análisis de la arquitectura de Nora se identificaron los siguientes módulos clave:

| Módulo / Capacidad | Ubicación Original en `D:\Nora itu UTN` | Rol Original | Adaptación a Restobar POS |
| :--- | :--- | :--- | :--- |
| **Inferencia Multimodal & Router** | `src/lib/llm/router.ts` & `adapters/groqAdapter.ts` | Cascada LLM Groq (LPU) + Ollama Local con rotación de modelos. | Motor de procesamiento para OCR de facturas y comandos de voz de mozos/cocina. |
| **Voz & Transcripción (STT / TTS)** | `src/app/api/nora-transcribe/route.ts` & `src/hooks/useNoraAudio.ts` | Whisper Turbo en Groq para STT + Web Speech fallback y TTS. | Intercomunicador y toma de pedidos por voz en comanderas y barra. |
| **Visión & Telemetría Espacial** | `src/hooks/useNoraVision.ts` | Detección COCO-SSD + captura base64 para análisis óptico. | Escaneo con cámara para remitos/facturas y conteo de botellas/stock. |
| **Workflows & Resiliencia** | `src/lib/workflow.ts` | Pasos aislados con timeout y reintentos (RetryableError). | Carga atómica de inventario y pedidos sin bloquear el POS. |
| **Prompts & Perfiles** | `src/lib/prompts/index.ts` | Perfiles ("executive", "lazarillo", "tea"). | Nuevo perfil: `"gastronomic_sommelier_pos"`. |

---

## 2. 🗄️ Arquitectura del Backend & Migración a SQLite (`better-sqlite3`)

El backend actual en `D:\BARES 2026\backend` presenta:
* **Persistencia actual:** `database.js` serializa `data/store.json` completo con `fs.writeFileSync`.
* **Riesgo:** Bloqueo del Event Loop en alta concurrencia.
* **Solución de persistencia:** Base de datos relacional transaccional embebida con `better-sqlite3` en modo **WAL (Write-Ahead Logging)**, que garantiza 0 ms de bloqueo y ACID completo para:
  1. `inventory` (ingredientes, costos, stock mínimo).
  2. `invoices_ai` (facturas escaneadas por Nora con foto, OCR y detalle de ítems).
  3. `orders` & `tables` (pedidos de mozos y comensales).
  4. `caja_diaria` (apertura, movimientos, cierre).

---

## 3. 📦 Matriz de Exportación / Adaptación

```
D:\Nora itu UTN\                             D:\BARES 2026\backend\
├── src/lib/llm/adapters/groqAdapter.ts  ──►  ├── nora/groqAdapter.js (ESM puro)
├── src/lib/llm/router.ts                ──►  ├── nora/router.js
├── src/lib/prompts/index.ts             ──►  ├── nora/prompts.js (Especializado Gastronomía)
└── (Nueva capa de orquestación)         ──►  ├── nora_controller.js (Tool Calling + OCR + SQLite)
                                              └── database_sqlite.js (Motor better-sqlite3)
```

---

## 4. 🛠️ Hoja de Ruta de Implementación a Tres Bandas

1. **Instalación de Dependencias Clave en Backend:**
   * `npm install better-sqlite3 groq-sdk dotenv`
2. **Despliegue de `nora_controller.js`:**
   * Controlador con endpoints `/api/nora/voice-command`, `/api/nora/parse-invoice-vision` y `/api/nora/transcribe`.
3. **Inyección en `server.js`:**
   * Enrutamiento modular para no saturar el servidor HTTP principal.
4. **Integración con Frontend POS:**
   * Botón de micrófono en comandera de mozos y visor de cámara para escanear facturas en recepción de mercadería.
