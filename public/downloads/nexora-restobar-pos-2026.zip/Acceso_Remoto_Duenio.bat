@echo off
title MyJNexoraVisual - Acceso Remoto Seguro para el Dueno
color 0A

echo ======================================================================
echo           MYJNEXORAVISUAL - ACCESO REMOTO PARA EL DUENO
echo ======================================================================
echo.
echo  Iniciando tunel remoto HTTPS seguro con reconexion automatica infinita...
echo.

:loop
echo [%time%] Estableciendo tunel HTTPS en subdominio myjnexora-admin...
npx localtunnel --port 3036 --subdomain myjnexora-admin
echo.
echo ⚠️ Tunel desconectado. Reintentando en 5 segundos...
timeout /t 5 /nobreak >nul
goto loop
