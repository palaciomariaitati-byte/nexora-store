/**
 * useNoraVision.js: Hook de Captura y Telemetría Óptica
 * Adaptado de D:\Nora itu UTN\src\hooks\useNoraVision.ts
 */

import { useState, useRef, useCallback } from "react";

export function useNoraVision() {
  const [state, setState] = useState({
    isCameraActive: false,
    isProcessing: false,
    error: null,
    lastSnapshotBase64: null,
  });

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  // Iniciar cámara web o trasera
  const startCamera = useCallback(async (facingMode = "environment") => {
    try {
      setState((prev) => ({ ...prev, error: null, isProcessing: false }));

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }

      if (!navigator?.mediaDevices?.getUserMedia) {
        throw new Error("Su navegador o dispositivo no soporta acceso a la cámara.");
      }

      // Constraints resilientes para desktop y móviles
      const constraints = {
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      };

      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia(constraints);
      } catch (errConstraint) {
        // Fallback a cualquier video disponible si falla environment
        console.warn("[NoraVision] Fallback a restricciones de cámara básica:", errConstraint.message);
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      }

      streamRef.current = stream;

      // Esperar al siguiente tick para asegurar que el elemento <video> esté montado en el DOM
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute("autoplay", "");
          videoRef.current.setAttribute("playsinline", "");
          videoRef.current.setAttribute("muted", "");
          videoRef.current.muted = true;

          videoRef.current.onloadedmetadata = () => {
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
              playPromise.catch((e) => console.warn("[NoraVision] Reproducción diferida:", e));
            }
          };

          // Disparar play directo por seguridad
          const directPlay = videoRef.current.play();
          if (directPlay !== undefined) {
            directPlay.catch(() => {});
          }
        }
      }, 50);

      setState((prev) => ({ ...prev, isCameraActive: true }));
    } catch (err) {
      console.error("[NoraVision] Error accediendo a la cámara:", err);
      const friendlyMsg = err.name === "NotAllowedError" || err.name === "PermissionDeniedError"
        ? "⚠️ Permiso de cámara denegado. Habilita los permisos de video en el navegador."
        : `⚠️ No se pudo inicializar la cámara: ${err.message || 'Dispositivo no disponible'}`;

      setState((prev) => ({
        ...prev,
        isCameraActive: false,
        error: friendlyMsg,
      }));

      if (typeof window !== "undefined") {
        alert(friendlyMsg);
      }
    }
  }, []);

  // Detener cámara
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setState((prev) => ({ ...prev, isCameraActive: false }));
  }, []);

  // Capturar fotograma en Base64
  const captureSnapshot = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext("2d");
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL("image/jpeg", 0.85);

    setState((prev) => ({ ...prev, lastSnapshotBase64: base64 }));
    return base64;
  }, []);

  return {
    isCameraActive: state.isCameraActive,
    isProcessing: state.isProcessing,
    error: state.error,
    lastSnapshotBase64: state.lastSnapshotBase64,
    videoRef,
    canvasRef,
    startCamera,
    stopCamera,
    captureSnapshot,
    setIsProcessing: (val) => setState((prev) => ({ ...prev, isProcessing: val })),
  };
}
