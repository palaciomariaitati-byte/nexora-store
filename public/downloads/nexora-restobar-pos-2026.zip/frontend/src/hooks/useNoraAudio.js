/**
 * useNoraAudio.js: Hook de Voz Híbrida para Salón y Caja
 * Adaptado de D:\Nora itu UTN\src\hooks\useNoraAudio.ts
 */

import { useState, useRef, useCallback, useEffect } from "react";
import { sanitizeForTTS } from "../utils/audioUtils";

export function useNoraAudio(options = {}) {
  const { onTranscriptionComplete, onSpeechStart, onSpeechEnd } = options;

  const [state, setState] = useState({
    isRecording: false,
    isSpeaking: false,
    transcript: "",
    error: null,
  });

  const recognitionRef = useRef(null);
  const currentUtteranceRef = useRef(null);

  // Inicializar Web Speech Recognition nativo
  useEffect(() => {
    if (typeof window === "undefined") return;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = "es-AR";

      recognition.onstart = () => {
        setState((prev) => ({ ...prev, isRecording: true, error: null }));
        if (onSpeechStart) onSpeechStart();
      };

      recognition.onresult = (event) => {
        let currentText = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentText += event.results[i][0].transcript;
        }
        setState((prev) => ({ ...prev, transcript: currentText }));
      };

      recognition.onerror = (event) => {
        console.warn("[NoraAudio] Error en reconocimiento:", event.error);
        setState((prev) => ({ ...prev, isRecording: false, error: event.error }));
      };

      recognition.onend = () => {
        setState((prev) => {
          if (prev.transcript && onTranscriptionComplete) {
            onTranscriptionComplete(prev.transcript);
          }
          return { ...prev, isRecording: false };
        });
        if (onSpeechEnd) onSpeechEnd();
      };

      recognitionRef.current = recognition;
    }
  }, [onTranscriptionComplete, onSpeechStart, onSpeechEnd]);

  const startListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        setState((prev) => ({ ...prev, transcript: "", error: null }));
        recognitionRef.current.start();
      } catch (err) {
        console.warn("[NoraAudio] Reconocimiento ya iniciado:", err.message);
      }
    } else {
      setState((prev) => ({ ...prev, error: "Navegador sin soporte de voz nativa." }));
    }
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (err) {
        // Ignorar
      }
    }
  }, []);

  // Síntesis de voz natural de Nora
  const speak = useCallback((text) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

    window.speechSynthesis.cancel();
    const cleanText = sanitizeForTTS(text);
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = "es-AR";
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    // Buscar voz natural en español
    const voices = window.speechSynthesis.getVoices();
    const spanishVoice = voices.find(
      (v) => (v.lang.startsWith("es-AR") || v.lang.startsWith("es-419") || v.lang.startsWith("es")) &&
             (v.name.includes("Sabina") || v.name.includes("Natural") || v.name.includes("Google") || v.name.includes("Elena"))
    ) || voices.find((v) => v.lang.startsWith("es"));

    if (spanishVoice) utterance.voice = spanishVoice;

    utterance.onstart = () => setState((prev) => ({ ...prev, isSpeaking: true }));
    utterance.onend = () => setState((prev) => ({ ...prev, isSpeaking: false }));
    utterance.onerror = () => setState((prev) => ({ ...prev, isSpeaking: false }));

    currentUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, []);

  const stopSpeaking = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setState((prev) => ({ ...prev, isSpeaking: false }));
    }
  }, []);

  return {
    isRecording: state.isRecording,
    isSpeaking: state.isSpeaking,
    transcript: state.transcript,
    error: state.error,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
  };
}
