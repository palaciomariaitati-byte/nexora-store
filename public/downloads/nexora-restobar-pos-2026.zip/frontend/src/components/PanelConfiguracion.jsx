import React, { useState, useEffect } from 'react';
import { Settings, X, Globe, Sun, Palette, Check } from 'lucide-react';

export default function PanelConfiguracion() {
  const [isOpen, setIsOpen] = useState(false);
  const [idioma, setIdioma] = useState(() => localStorage.getItem('myj_idioma') || 'es');
  const [altoContraste, setAltoContraste] = useState(() => localStorage.getItem('myj_contraste') === 'true');
  const [colorAcento, setColorAcento] = useState(() => localStorage.getItem('myj_acento') || 'emerald');

  useEffect(() => {
    // Apply accent color to CSS root variables
    const root = document.documentElement;
    if (colorAcento === 'emerald') {
      root.style.setProperty('--primary', '#10b981');
      root.style.setProperty('--primary-hover', '#059669');
      root.style.setProperty('--primary-light', 'rgba(16,185,129,0.15)');
    } else if (colorAcento === 'cyan') {
      root.style.setProperty('--primary', '#06b6d4');
      root.style.setProperty('--primary-hover', '#0891b2');
      root.style.setProperty('--primary-light', 'rgba(6,182,212,0.15)');
    } else if (colorAcento === 'fuchsia') {
      root.style.setProperty('--primary', '#d946ef');
      root.style.setProperty('--primary-hover', '#c026d3');
      root.style.setProperty('--primary-light', 'rgba(217,70,239,0.15)');
    }

    // Apply high contrast mode class
    if (altoContraste) {
      document.body.classList.add('high-contrast-mode');
    } else {
      document.body.classList.remove('high-contrast-mode');
    }

    localStorage.setItem('myj_idioma', idioma);
    localStorage.setItem('myj_contraste', String(altoContraste));
    localStorage.setItem('myj_acento', colorAcento);
  }, [idioma, altoContraste, colorAcento]);

  return (
    <>
      {/* Botón flotante de configuración con icono de engranaje giratorio */}
      <button
        onClick={() => setIsOpen(true)}
        title="Configuración de Sistema & Usuario"
        style={{
          position: 'fixed',
          bottom: '24px',
          right: '24px',
          width: '52px',
          height: '52px',
          borderRadius: '99px',
          background: 'var(--primary, #10b981)',
          color: '#000',
          border: 'none',
          boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          zIndex: 9990,
          transition: 'all 0.3s ease'
        }}
      >
        <Settings size={26} className="spin-slow" />
      </button>

      {/* Panel Desplegable de Configuración */}
      {isOpen && (
        <div
          className="bottom-sheet-overlay animate-fade-in"
          onClick={() => setIsOpen(false)}
          style={{ zIndex: 9999 }}
        >
          <div
            className="bottom-sheet-content"
            onClick={e => e.stopPropagation()}
            style={{ maxWidth: '520px', background: '#09090b', color: '#fff', border: '1px solid rgba(255,255,255,0.15)' }}
          >
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 900, display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Settings style={{ color: 'var(--primary, #10b981)' }} />
                  Panel de Ajustes del Sistema
                </h3>
                <span style={{ fontSize: '0.75rem', color: '#a1a1aa' }}>
                  Nexora One, SUITE COMERCIAL O DE RESTOBAR
                </span>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                style={{ background: 'none', border: 'none', color: '#a1a1aa', cursor: 'pointer' }}
              >
                <X size={24} />
              </button>
            </div>

            {/* OPCIÓN 1: IDIOMA */}
            <div style={{ marginBottom: '20px', background: '#18181b', padding: '14px', borderRadius: '12px', border: '1px solid #27272a' }}>
              <div style={{ fontSize: '0.9rem', fontWeight: 800, marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '8px', color: '#fff' }}>
                <Globe size={18} style={{ color: 'var(--primary, #10b981)' }} />
                Idioma de la Interfaz
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <button
                  onClick={() => setIdioma('es')}
                  style={{
                    padding: '10px',
                    borderRadius: '8px',
                    border: idioma === 'es' ? '2px solid var(--primary, #10b981)' : '1px solid #3f3f46',
                    background: idioma === 'es' ? 'rgba(16,185,129,0.15)' : '#09090b',
                    color: '#fff',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px'
                  }}
                >
                  🇪🇸 Español Nativo {idioma === 'es' && <Check size={16} />}
                </button>
                <button
                  onClick={() => setIdioma('en')}
                  style={{
                    padding: '10px',
                    borderRadius: '8px',
                    border: idioma === 'en' ? '2px solid var(--primary, #10b981)' : '1px solid #3f3f46',
                    background: idioma === 'en' ? 'rgba(16,185,129,0.15)' : '#09090b',
                    color: '#fff',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px'
                  }}
                >
                  🇺🇸 English {idioma === 'en' && <Check size={16} />}
                </button>
              </div>
            </div>

            {/* OPCIÓN 2: ALTO CONTRASTE */}
            <div style={{ marginBottom: '20px', background: '#18181b', padding: '14px', borderRadius: '12px', border: '1px solid #27272a' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px', color: '#fff' }}>
                    <Sun size={18} style={{ color: 'var(--primary, #10b981)' }} />
                    Modo Contraste de Brillo Alto (Cocina)
                  </div>
                  <span style={{ fontSize: '0.75rem', color: '#a1a1aa' }}>
                    Aumenta la legibilidad del texto en entornos oscuros o con humo
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={altoContraste}
                  onChange={e => setAltoContraste(e.target.checked)}
                  style={{ width: '22px', height: '22px', accentColor: 'var(--primary, #10b981)', cursor: 'pointer' }}
                />
              </div>
            </div>

            {/* OPCIÓN 3: PALETA DE COLOR IA */}
            <div style={{ marginBottom: '20px', background: '#18181b', padding: '14px', borderRadius: '12px', border: '1px solid #27272a' }}>
              <div style={{ fontSize: '0.9rem', fontWeight: 800, marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '8px', color: '#fff' }}>
                <Palette size={18} style={{ color: 'var(--primary, #10b981)' }} />
                Paleta de Color del Acento IA
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
                {/* Esmeralda */}
                <button
                  onClick={() => setColorAcento('emerald')}
                  style={{
                    padding: '12px 8px',
                    borderRadius: '8px',
                    border: colorAcento === 'emerald' ? '2px solid #10b981' : '1px solid #3f3f46',
                    background: '#10b981',
                    color: '#000',
                    fontWeight: 900,
                    fontSize: '0.78rem',
                    cursor: 'pointer',
                    textAlign: 'center'
                  }}
                >
                  🟢 Esmeralda
                </button>

                {/* Cian */}
                <button
                  onClick={() => setColorAcento('cyan')}
                  style={{
                    padding: '12px 8px',
                    borderRadius: '8px',
                    border: colorAcento === 'cyan' ? '2px solid #06b6d4' : '1px solid #3f3f46',
                    background: '#06b6d4',
                    color: '#000',
                    fontWeight: 900,
                    fontSize: '0.78rem',
                    cursor: 'pointer',
                    textAlign: 'center'
                  }}
                >
                  🔹 Cian Neón
                </button>

                {/* Fucsia */}
                <button
                  onClick={() => setColorAcento('fuchsia')}
                  style={{
                    padding: '12px 8px',
                    borderRadius: '8px',
                    border: colorAcento === 'fuchsia' ? '2px solid #d946ef' : '1px solid #3f3f46',
                    background: '#d946ef',
                    color: '#000',
                    fontWeight: 900,
                    fontSize: '0.78rem',
                    cursor: 'pointer',
                    textAlign: 'center'
                  }}
                >
                  🌸 Fucsia Neón
                </button>
              </div>
            </div>

            {/* Footer Button */}
            <button
              onClick={() => setIsOpen(false)}
              className="btn btn-primary"
              style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: 800 }}
            >
              Guardar y Cerrar Ajustes
            </button>
          </div>
        </div>
      )}
    </>
  );
}
