import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Printer, Download, X, QrCode, Smartphone, ChefHat, Monitor, Sparkles } from 'lucide-react';

export default function ModalImprimirQRs({ isOpen, onClose, tables = [] }) {
  const [selectedMesaId, setSelectedMesaId] = useState(1);
  const [activeTab, setActiveTab] = useState('mesas'); // 'mesas' | 'sectores'

  if (!isOpen) return null;

  // Detección de host local dinámico para el QR
  const currentHost = typeof window !== 'undefined' ? window.location.host : 'localhost:3036';
  const protocol = typeof window !== 'undefined' ? window.location.protocol : 'http:';

  const getMesaUrl = (id) => `${protocol}//${currentHost}/#carta?mesa=${id}`;
  const getSectorUrl = (sector) => `${protocol}//${currentHost}/#${sector}`;

  const sectores = [
    { id: 'mozo', name: 'Mozo / Salón', desc: 'Acceso para mozos y toma de comandas en tablets', icon: Smartphone, color: '#0284c7' },
    { id: 'cocina', name: 'Cocina & KDS', desc: 'Pantalla de despacho y elaboración en cocina/barra', icon: ChefHat, color: '#e11d48' },
    { id: 'caja', name: 'Caja Central & Nora AI', desc: 'Cobros, facturación y control en mostrador', icon: Monitor, color: '#ea580c' }
  ];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bottom-sheet-overlay" onClick={onClose} style={{ zIndex: 99999 }}>
      <div 
        className="bottom-sheet-content" 
        onClick={(e) => e.stopPropagation()} 
        style={{ maxWidth: '680px', maxHeight: '90vh', overflowY: 'auto' }}
      >
        {/* Cabecera del Modal */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ background: 'var(--primary)', color: '#000', padding: '6px', borderRadius: '8px' }}>
              <QrCode size={20} />
            </div>
            <div>
              <h3 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-main)' }}>
                Generador & Impresor de Códigos QR Oficiales
              </h3>
              <p style={{ margin: 0, fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Imprime QRs individuales para cada mesa o paneles específicos de personal
              </p>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={24} />
          </button>
        </div>

        {/* Selector de Pestaña: QRs de Mesas vs QRs de Paneles */}
        <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', background: 'var(--bg-main)', padding: '4px', borderRadius: '10px' }}>
          <button
            onClick={() => setActiveTab('mesas')}
            style={{
              flex: 1,
              padding: '8px',
              borderRadius: '8px',
              border: 'none',
              fontWeight: 800,
              fontSize: '0.85rem',
              cursor: 'pointer',
              background: activeTab === 'mesas' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'mesas' ? '#000' : 'var(--text-main)'
            }}
          >
            🍽️ Códigos QR por Mesa (Clientes)
          </button>
          <button
            onClick={() => setActiveTab('sectores')}
            style={{
              flex: 1,
              padding: '8px',
              borderRadius: '8px',
              border: 'none',
              fontWeight: 800,
              fontSize: '0.85rem',
              cursor: 'pointer',
              background: activeTab === 'sectores' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'sectores' ? '#000' : 'var(--text-main)'
            }}
          >
            📱 QRs de Acceso por Sector (Mozos / Cocina)
          </button>
        </div>

        {/* 1. SECCIÓN: QR POR MESA */}
        {activeTab === 'mesas' && (
          <div>
            <div style={{ marginBottom: '14px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px', fontWeight: 700 }}>
                Selecciona la Mesa a Visualizar e Imprimir:
              </label>
              <select
                value={selectedMesaId}
                onChange={(e) => setSelectedMesaId(Number(e.target.value))}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '8px',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  color: 'var(--text-main)',
                  fontWeight: 800,
                  fontSize: '0.9rem'
                }}
              >
                {tables.map((t) => (
                  <option key={t.id} value={t.id}>
                    Mesa #{t.id} — {t.name} (Capacidad: {t.capacity} personas)
                  </option>
                ))}
              </select>
            </div>

            {/* Tarjeta Visual de Impresión Lista para Pegar en Mesa */}
            <div 
              id="qr-print-card"
              style={{
                background: '#ffffff',
                color: '#000000',
                padding: '28px 24px',
                borderRadius: '16px',
                border: '3px solid #000',
                textAlign: 'center',
                boxShadow: '0 8px 30px rgba(0,0,0,0.3)',
                maxWidth: '340px',
                margin: '0 auto 16px auto'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '1px', color: '#ea580c', marginBottom: '4px' }}>
                Nexora One Gastro
              </div>
              <h2 style={{ margin: '0 0 10px 0', fontSize: '1.8rem', fontWeight: 900, color: '#0f172a' }}>
                MESA #{selectedMesaId}
              </h2>
              
              <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '12px', border: '1px solid #cbd5e1', display: 'inline-block', marginBottom: '12px' }}>
                <QRCodeSVG
                  value={getMesaUrl(selectedMesaId)}
                  size={190}
                  level="H"
                  includeMargin={false}
                />
              </div>

              <div style={{ fontSize: '0.85rem', fontWeight: 800, color: '#1e293b', marginBottom: '4px' }}>
                📲 Escaneá con tu celular para ver la carta
              </div>
              <p style={{ margin: 0, fontSize: '0.72rem', color: '#64748b' }}>
                Tu mesa se conectará automáticamente con la barra y cocina.
              </p>
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={handlePrint}
                className="btn btn-primary"
                style={{ flex: 1, padding: '12px', fontSize: '0.92rem', fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
              >
                <Printer size={18} />
                🖨️ Imprimir Cartel Mesa #{selectedMesaId}
              </button>
            </div>
          </div>
        )}

        {/* 2. SECCIÓN: QR POR SECTOR (MOZOS, COCINA, CAJA) */}
        {activeTab === 'sectores' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '14px' }}>
            {sectores.map((sec) => (
              <div
                key={sec.id}
                style={{
                  background: 'var(--bg-main)',
                  borderRadius: '14px',
                  padding: '16px',
                  border: `2px solid ${sec.color}`,
                  textAlign: 'center',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '10px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: sec.color, fontWeight: 800, fontSize: '0.95rem' }}>
                  <sec.icon size={18} />
                  <span>{sec.name}</span>
                </div>
                
                <div style={{ background: '#fff', padding: '10px', borderRadius: '10px' }}>
                  <QRCodeSVG
                    value={getSectorUrl(sec.id)}
                    size={140}
                    level="M"
                  />
                </div>

                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  {sec.desc}
                </div>

                <button
                  onClick={handlePrint}
                  style={{
                    background: sec.color,
                    color: '#fff',
                    border: 'none',
                    padding: '6px 12px',
                    borderRadius: '6px',
                    fontSize: '0.78rem',
                    fontWeight: 800,
                    cursor: 'pointer',
                    width: '100%'
                  }}
                >
                  Imprimir QR {sec.name}
                </button>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
