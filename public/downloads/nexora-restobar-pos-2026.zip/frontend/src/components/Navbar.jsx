import React from 'react';
import { QrCode, Monitor, ChefHat, Printer, BarChart3, Sparkles, Utensils, Activity, Truck, Bike, Building2, MessageSquare, LogOut, ArrowLeft, ShieldCheck } from 'lucide-react';

export default function Navbar({ activeView, setActiveView, currentTableId, setSelectTableModalOpen, setIsChatOpen, userRole, onLogoutStaff }) {
  const role = userRole?.role || 'gerencia';
  const isGerencia = role === 'gerencia';
  const isCaja = role === 'caja' || isGerencia;
  const isCocina = role === 'cocina' || isGerencia;
  const isPanol = role === 'panol' || isGerencia;
  const isDelivery = role === 'delivery' || isGerencia;

  return (
    <header className="glass" style={{ position: 'sticky', top: 0, zIndex: 50, padding: '12px 20px', borderBottom: '1px solid var(--border-color)' }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
        
        {/* Brand Logo & Sector Title */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            background: 'linear-gradient(135deg, #f59e0b, #d97706)',
            padding: '8px 14px',
            borderRadius: '12px',
            color: '#083344',
            fontWeight: '900',
            fontFamily: 'var(--font-heading)',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '1.15rem',
            boxShadow: '0 4px 15px rgba(245,158,11,0.3)',
            letterSpacing: '0.5px'
          }}>
            <img 
              src="/logo.png" 
              alt="Nexora One" 
              onError={(e) => { e.currentTarget.style.display = 'none'; }}
              style={{ width: '22px', height: '22px', objectFit: 'contain' }} 
            />
            <Sparkles size={18} />
            <span>Nexora One</span>
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '1px', color: '#10b981', fontWeight: 800, display: 'block' }}>
              SUITE GASTRONÓMICA & POS
            </span>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Sector: <strong style={{ color: 'var(--primary)' }}>{userRole?.name || 'Salón Principal'}</strong>
            </span>
          </div>
        </div>

        {/* Navigation Tabs - STRICTLY ISOLATED BY ROLE */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '8px', overflowX: 'auto', padding: '4px 0' }}>
          
          {/* 1. Cliente (Siempre accesible) */}
          <button
            onClick={() => setActiveView('client')}
            className={`btn ${activeView === 'client' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ fontSize: '0.85rem', padding: '8px 14px', color: activeView === 'client' ? '#083344' : 'var(--text-main)' }}
          >
            <QrCode size={16} />
            <span>📱 Cliente (Mesa {currentTableId})</span>
          </button>

          {/* 2. Caja / Mostrador */}
          {isCaja && (
            <button
              onClick={() => setActiveView('cashier')}
              className={`btn ${activeView === 'cashier' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px', color: activeView === 'cashier' ? '#083344' : 'var(--text-main)' }}
            >
              <Monitor size={16} />
              <span>💻 Panel de Caja</span>
            </button>
          )}

          {/* 3. Delivery & Retiro */}
          {isCaja && (
            <button
              onClick={() => setActiveView('delivery')}
              className={`btn ${activeView === 'delivery' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <Truck size={16} />
              <span>🛵 Delivery & Retiro</span>
            </button>
          )}

          {/* 4. App Cadetes */}
          {(isDelivery || isCaja) && (
            <button
              onClick={() => setActiveView('driver')}
              className={`btn ${activeView === 'driver' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <Bike size={16} />
              <span>📱 App Cadetes / Repartidores</span>
            </button>
          )}

          {/* 5. KDS Cocina */}
          {isCocina && (
            <button
              onClick={() => setActiveView('kitchen')}
              className={`btn ${activeView === 'kitchen' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <ChefHat size={16} />
              <span>🍳 KDS Cocina/Barra</span>
            </button>
          )}

          {/* 6. Gestión de Carta */}
          {(isPanol || isGerencia) && (
            <button
              onClick={() => setActiveView('menu')}
              className={`btn ${activeView === 'menu' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <Utensils size={16} />
              <span>🍔 Gestión de Carta</span>
            </button>
          )}

          {/* 7. CRM & RPM */}
          {isCaja && (
            <button
              onClick={() => setActiveView('crmrpm')}
              className={`btn ${activeView === 'crmrpm' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <Activity size={16} />
              <span>📈 CRM & RPM Metrics</span>
            </button>
          )}

          {/* 8. ERP / Stock / Pañol */}
          {(isPanol || isGerencia) && (
            <button
              onClick={() => setActiveView('erp')}
              className={`btn ${activeView === 'erp' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <Building2 size={16} />
              <span>🏢 ERP & Pañol/Stock</span>
            </button>
          )}

          {/* 9. Impresora Comandas */}
          {isCaja && (
            <button
              onClick={() => setActiveView('printer')}
              className={`btn ${activeView === 'printer' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <Printer size={16} />
              <span>🖨️ Impresora Comandas</span>
            </button>
          )}

          {/* 10. Reportes (Presidencia / Gerencia) */}
          {isGerencia && (
            <button
              onClick={() => setActiveView('reports')}
              className={`btn ${activeView === 'reports' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.85rem', padding: '8px 14px' }}
            >
              <BarChart3 size={16} />
              <span>📊 Reportes & Propinas</span>
            </button>
          )}

          {/* 11. Intercomunicador */}
          {setIsChatOpen && (
            <button
              onClick={() => setIsChatOpen(true)}
              className="btn btn-primary"
              style={{ fontSize: '0.85rem', padding: '8px 14px', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', color: '#fff' }}
            >
              <MessageSquare size={16} />
              <span>💬 Intercomunicador</span>
            </button>
          )}

          {/* 12. Direct Access to Social & Gmail */}
          <button
            onClick={() => {
              const popup = window.open('', '_blank', 'width=450,height=550');
              popup.document.write(`
                <html>
                  <head>
                    <title>Redes Sociales & Gmail - Nexora One</title>
                    <style>
                      body { font-family: Arial, sans-serif; padding: 20px; background: #0d0f12; color: #fff; text-align: center; }
                      h2 { color: #f59e0b; margin-bottom: 8px; }
                      .link-btn { display: block; width: 100%; padding: 12px; margin: 10px 0; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 0.9rem; color: #fff; box-sizing: border-border-box; }
                      .ig { background: linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045); }
                      .fb { background: #1877F2; }
                      .tk { background: #000; border: 1px solid #333; }
                      .gm { background: #EA4335; }
                      .wa { background: #25D366; }
                    </style>
                  </head>
                  <body>
                    <h2>📱 Canales Oficiales & Redes</h2>
                    <p style="font-size: 0.85rem; color: #9ca3af;">Bar & Restaurant System - Nexora One</p>
                    <a href="https://instagram.com" target="_blank" class="link-btn ig">📸 Instagram Oficial</a>
                    <a href="https://facebook.com" target="_blank" class="link-btn fb">📘 Facebook Fanpage</a>
                    <a href="https://tiktok.com" target="_blank" class="link-btn tk">🎵 TikTok Oficial</a>
                    <a href="https://mail.google.com" target="_blank" class="link-btn gm">📧 Correo Gmail / Reservas</a>
                    <a href="https://wa.me/" target="_blank" class="link-btn wa">💬 WhatsApp Business Directo</a>
                  </body>
                </html>
              `);
            }}
            className="btn btn-secondary"
            style={{ fontSize: '0.85rem', padding: '8px 14px', borderColor: '#8b5cf6', color: '#a78bfa' }}
          >
            <span>📱 Redes & Gmail</span>
          </button>

          {/* 13. Botón de Retroceso / Cerrar Sesión de Sector */}
          {onLogoutStaff && (
            <button
              onClick={onLogoutStaff}
              className="btn btn-danger"
              style={{ fontSize: '0.8rem', padding: '8px 12px', display: 'flex', alignItems: 'center', gap: '4px' }}
            >
              <LogOut size={14} />
              <span>🔒 Salir / Cambiar Sector</span>
            </button>
          )}

        </nav>

      </div>
    </header>
  );
}
