import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('⚠️ Error autocapturado por ErrorBoundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          padding: '40px 20px',
          margin: '20px auto',
          maxWidth: '700px',
          background: '#09090b',
          border: '2px solid #ef4444',
          borderRadius: '16px',
          color: '#ffffff',
          textAlign: 'center',
          boxShadow: '0 8px 32px rgba(239, 68, 68, 0.3)'
        }}>
          <h2 style={{ fontSize: '1.5rem', color: '#ef4444', marginBottom: '12px', fontWeight: 800 }}>
            ⚠️ Error de Renderizado Capturado por Nexora Guard
          </h2>
          <p style={{ fontSize: '0.9rem', color: '#a1a1aa', marginBottom: '20px' }}>
            Se detectó un fallo al cargar esta vista del sector. El sistema ha aislado el componente para evitar el colapso del resto de la suite.
          </p>
          <div style={{
            background: '#18181b',
            padding: '12px 16px',
            borderRadius: '8px',
            fontFamily: 'monospace',
            fontSize: '0.8rem',
            color: '#f43f5e',
            textAlign: 'left',
            marginBottom: '20px',
            overflowX: 'auto'
          }}>
            {String(this.state.error?.message || this.state.error)}
          </div>
          <button
            onClick={() => {
              this.setState({ hasError: false, error: null });
              window.location.reload();
            }}
            style={{
              background: 'linear-gradient(135deg, #10b981, #059669)',
              color: '#000',
              border: 'none',
              padding: '10px 24px',
              borderRadius: '8px',
              fontWeight: 800,
              cursor: 'pointer'
            }}
          >
            🔄 Recargar Pantalla
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
