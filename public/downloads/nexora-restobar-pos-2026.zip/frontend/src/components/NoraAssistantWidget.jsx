import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Camera, Send, Bot, CheckCircle, AlertCircle, Volume2, Sparkles, X } from 'lucide-react';
import { useNoraAudio } from '../hooks/useNoraAudio';
import { useNoraVision } from '../hooks/useNoraVision';
import NoraVisionViewport from './NoraVisionViewport';

/**
 * NoraAssistantWidget.jsx: Widget Conversacional Inteligente para Caja Central & Gerencia
 * 
 * Permite conversar con Nora por texto o voz (STT/TTS) e interactuar con la cámara para
 * escanear remitos/facturas con conciliación conversacional paso a paso.
 */
export default function NoraAssistantWidget({ onInventoryChanged }) {
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      role: 'assistant',
      text: '¡Hola! Soy Nora, tu asistente operativa. Puedes pedirme consultas de caja, cargar remitos con la cámara o dictarme actualizaciones de stock.',
      timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [pendingDraft, setPendingDraft] = useState(null); // Factura borrador esperando confirmación
  const chatScrollRef = useRef(null);

  // Hook de Audio
  const audio = useNoraAudio({
    onTranscriptionComplete: (text) => {
      if (text && text.trim()) {
        handleSendMessage(text);
      }
    }
  });

  // Hook de Visión
  const vision = useNoraVision();

  // Scroll automático en el chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  // Enviar mensaje (Texto o Voz) al Backend de Nora
  const handleSendMessage = async (textToSend) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    setInputText('');
    const userMsg = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/nora/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          text: query,
          speechText: query,
          sector: 'caja_central',
          user: 'Cajero'
        })
      });
      const data = await res.json();

      const spokenResponse = data.interpreted?.spokenResponse || data.spokenResponse || 'Entendido.';
      const botMsg = {
        id: `bot_${Date.now()}`,
        role: 'assistant',
        text: spokenResponse,
        data: data.executionResult || null,
        draft: data.pendingDraft || null,
        timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
      audio.speak(spokenResponse);

      if (data.pendingDraft) {
        setPendingDraft(data.pendingDraft);
      }

      if (data.interpreted?.action === 'UPDATE_STOCK' || data.executionResult?.updated) {
        if (onInventoryChanged) onInventoryChanged();
      }
    } catch (err) {
      console.error('Error enviando mensaje a Nora:', err);
      const errMsg = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        text: 'Disculpa, tuve un problema de conexión con el motor de IA.',
        timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Capturar foto desde la cámara en vivo y enviar a Nora Vision
  const handleCaptureInvoice = async () => {
    const base64 = vision.captureSnapshot();
    if (!base64) return;

    vision.setIsProcessing(true);
    setIsLoading(true);

    const userMsg = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: '📷 [Escaneó un remito o factura con la cámara]',
      image: base64,
      timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
    };
    setMessages((prev) => [...prev, userMsg]);

    try {
      const res = await fetch('/api/nora/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          supplierHint: 'Recepción Caja Central'
        })
      });
      const data = await res.json();

      // Guardar también en bandeja de Gerencia para control
      try {
        await fetch('/api/erp/remitos-pendientes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            originSector: 'Caja Central',
            senderUser: 'Caja / Recepción',
            supplierName: data.extractedData?.supplierName || 'Foto Cámara Recepción',
            totalAmount: data.extractedData?.totalAmount || 0,
            imageBase64: base64,
            notes: 'Captura con cámara en vivo',
            autoAnalyzeWithNora: false
          })
        });
      } catch (rErr) {
        console.warn('Error guardando en remitos pendientes:', rErr);
      }

      const spoken = data.spokenResponse || `Leí el remito: ${data.extractedData?.items?.map(i => `${i.quantity} ${i.unit} de ${i.name}`).join(', ')}. ¿Recibiste todo en orden o hubo faltantes?`;
      
      const botMsg = {
        id: `bot_${Date.now()}`,
        role: 'assistant',
        text: spoken,
        draft: data.pendingDraft || null,
        timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
      audio.speak(spoken);

      if (data.pendingDraft) {
        setPendingDraft(data.pendingDraft);
      }
      vision.stopCamera();
    } catch (err) {
      console.error('Error procesando visión con Nora:', err);
      const errMsg = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        text: 'No pude procesar la imagen del remito. Intenta tomar la foto con mejor iluminación.',
        timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      vision.setIsProcessing(false);
      setIsLoading(false);
    }
  };

  // Subir archivo de imagen para análisis de Nora Vision y/o envío a Gerencia
  const handleFileUploadToNora = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result;
      setIsLoading(true);

      const userMsg = {
        id: `usr_${Date.now()}`,
        role: 'user',
        text: `📁 [Subió foto/comprobante: ${file.name}]`,
        image: base64,
        timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, userMsg]);

      try {
        // Enviar a Nora Vision para análisis
        const res = await fetch('/api/nora/vision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64,
            supplierHint: file.name
          })
        });
        const data = await res.json();

        // Registrar también en la bandeja de remitos de Gerencia para control remoto
        try {
          await fetch('/api/erp/remitos-pendientes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              originSector: 'Caja Central',
              senderUser: 'Caja / Recepción',
              supplierName: data.extractedData?.supplierName || file.name,
              totalAmount: data.extractedData?.totalAmount || 0,
              imageBase64: base64,
              notes: `Subido desde Caja por archivo: ${file.name}`,
              autoAnalyzeWithNora: false
            })
          });
        } catch (rErr) {
          console.warn('Error guardando en remitos pendientes:', rErr);
        }

        const spoken = data.spokenResponse || `Analicé el comprobante: detecté ${data.extractedData?.items?.length || 0} ítems y envié una copia a Gerencia para control. ¿Confirmas la carga al inventario?`;

        const botMsg = {
          id: `bot_${Date.now()}`,
          role: 'assistant',
          text: spoken,
          draft: data.pendingDraft || null,
          timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
        };

        setMessages((prev) => [...prev, botMsg]);
        audio.speak(spoken);

        if (data.pendingDraft) {
          setPendingDraft(data.pendingDraft);
        }
      } catch (err) {
        console.error('Error procesando imagen con Nora:', err);
        const errMsg = {
          id: `err_${Date.now()}`,
          role: 'assistant',
          text: 'No pude procesar la imagen seleccionada. Asegúrate de que sea un formato JPG o PNG claro.',
          timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages((prev) => [...prev, errMsg]);
      } finally {
        setIsLoading(false);
        e.target.value = ''; // Reset input
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      background: 'var(--bg-card, #121826)',
      borderRadius: '12px',
      border: '1px solid var(--border-color)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-md)'
    }}>
      {/* HEADER DEL WIDGET */}
      <div style={{
        padding: '14px 18px',
        background: 'linear-gradient(135deg, rgba(8, 51, 68, 0.95), rgba(27, 67, 83, 0.8))',
        borderBottom: '1px solid rgba(228, 168, 52, 0.2)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #e4a834, #d97706)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#083344'
          }}>
            <Bot size={20} />
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: '0.95rem', color: '#fff', display: 'flex', alignItems: 'center', gap: '6px' }}>
              Nora AI Brain <Sparkles size={14} style={{ color: '#e4a834' }} />
            </div>
            <div style={{ fontSize: '0.72rem', color: '#38bdf8' }}>
              {audio.isSpeaking ? 'Hablando...' : (audio.isRecording ? 'Escuchando tu voz...' : 'Cerebro Activo')}
            </div>
          </div>
        </div>

        {/* Acciones de Cabecera: Activar Cámara & Subir Archivo/Foto */}
        <div style={{ display: 'flex', gap: '6px' }}>
          {/* Subir archivo de imagen/foto */}
          <label
            title="Subir foto o comprobante de factura para Nora"
            style={{
              background: 'rgba(255,255,255,0.12)',
              border: '1px solid rgba(255,255,255,0.2)',
              color: '#fff',
              padding: '6px 10px',
              borderRadius: '8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.78rem',
              fontWeight: 700
            }}
          >
            <span>📁</span>
            <span>Subir Foto</span>
            <input
              type="file"
              accept="image/*"
              style={{ display: 'none' }}
              onChange={handleFileUploadToNora}
            />
          </label>

          <button
            onClick={() => vision.isCameraActive ? vision.stopCamera() : vision.startCamera('environment')}
            style={{
              background: vision.isCameraActive ? '#ef4444' : 'rgba(255,255,255,0.12)',
              border: '1px solid rgba(255,255,255,0.2)',
              color: '#fff',
              padding: '6px 12px',
              borderRadius: '8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.78rem',
              fontWeight: 700
            }}
          >
            <Camera size={14} />
            {vision.isCameraActive ? 'Cerrar' : 'Escanear'}
          </button>
        </div>
      </div>

      {/* VIEWPORT DE CÁMARA (Si está activa) */}
      <div style={{ padding: vision.isCameraActive ? '12px 12px 0 12px' : '0' }}>
        <NoraVisionViewport
          isCameraActive={vision.isCameraActive}
          onCloseCamera={vision.stopCamera}
          videoRef={vision.videoRef}
          canvasRef={vision.canvasRef}
          onCapture={handleCaptureInvoice}
          isProcessing={vision.isProcessing}
        />
      </div>

      {/* VENTANA DE HISTORIAL DE CHAT CONVERSACIONAL */}
      <div
        ref={chatScrollRef}
        style={{
          flex: 1,
          padding: '16px',
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          background: 'var(--bg-main, #e2e8f0)'
        }}
      >
        {messages.map((msg) => {
          const isBot = msg.role === 'assistant';
          return (
            <div
              key={msg.id}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: isBot ? 'flex-start' : 'flex-end',
                maxWidth: '90%',
                alignSelf: isBot ? 'flex-start' : 'flex-end'
              }}
            >
              <div style={{
                background: isBot ? 'var(--bg-card, #ffffff)' : 'linear-gradient(135deg, #d97706, #b45309)',
                color: isBot ? 'var(--text-main, #0f172a)' : '#ffffff',
                padding: '12px 16px',
                borderRadius: isBot ? '16px 16px 16px 4px' : '16px 16px 4px 16px',
                border: isBot ? '1.5px solid var(--border-color, #cbd5e1)' : 'none',
                fontSize: '0.86rem',
                lineHeight: '1.45',
                boxShadow: isBot ? 'var(--shadow-sm)' : '0 4px 12px rgba(217, 119, 6, 0.3)'
              }}>
                {msg.image && (
                  <img
                    src={msg.image}
                    alt="Remito capturado"
                    style={{ width: '100%', maxHeight: '140px', objectFit: 'cover', borderRadius: '8px', marginBottom: '8px' }}
                  />
                )}
                {msg.text}

                {/* Si hay borrador pendiente, mostrar botones rápidos de confirmación */}
                {msg.draft && (
                  <div style={{ marginTop: '8px', display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => handleSendMessage('Sí, recibí todo en orden')}
                      style={{
                        background: '#10b981',
                        color: '#fff',
                        border: 'none',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '0.72rem',
                        fontWeight: 700,
                        cursor: 'pointer'
                      }}
                    >
                      ✓ Confirmar todo
                    </button>
                    <button
                      onClick={() => handleSendMessage('Faltó mercadería')}
                      style={{
                        background: '#ef4444',
                        color: '#fff',
                        border: 'none',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '0.72rem',
                        fontWeight: 700,
                        cursor: 'pointer'
                      }}
                    >
                      ✕ Hubo faltantes
                    </button>
                  </div>
                )}
              </div>
              <span style={{ fontSize: '0.68rem', color: 'var(--text-muted, #64748b)', marginTop: '3px', padding: '0 4px' }}>
                {msg.timestamp}
              </span>
            </div>
          );
        })}

        {isLoading && (
          <div style={{
            alignSelf: 'flex-start',
            padding: '8px 14px',
            background: 'var(--bg-card, rgba(27, 67, 83, 0.3))',
            borderRadius: '12px',
            fontSize: '0.78rem',
            color: '#0284c7',
            fontStyle: 'italic',
            border: '1px solid var(--border-color, rgba(2, 132, 199, 0.2))'
          }}>
            Nora está pensando...
          </div>
        )}
      </div>

      {/* FOOTER CON BOTÓN DE MICRÓFONO E INPUT DE TEXTO */}
      <div style={{
        padding: '12px 14px',
        background: 'var(--bg-card, rgba(8, 51, 68, 0.4))',
        borderTop: '1px solid var(--border-color, rgba(228, 168, 52, 0.15))',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}>
        {/* Botón de Micrófono */}
        <button
          onClick={audio.isRecording ? audio.stopListening : audio.startListening}
          title={audio.isRecording ? 'Detener grabación' : 'Hablar con Nora'}
          style={{
            width: '42px',
            height: '42px',
            borderRadius: '50%',
            background: audio.isRecording ? '#ef4444' : 'linear-gradient(135deg, #10b981, #059669)',
            border: 'none',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            flexShrink: 0,
            transition: 'all 0.2s ease',
            boxShadow: audio.isRecording ? '0 0 12px #ef4444' : 'none'
          }}
        >
          {audio.isRecording ? <MicOff size={18} /> : <Mic size={18} />}
        </button>

        {/* Input de Texto */}
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Escribe o dicta a Nora..."
          style={{
            flex: 1,
            background: 'var(--bg-main, rgba(15, 23, 42, 0.8))',
            border: '1px solid var(--border-color, rgba(255, 255, 255, 0.15))',
            borderRadius: '20px',
            color: 'var(--text-main, #fff)',
            padding: '10px 16px',
            fontSize: '0.85rem',
            outline: 'none'
          }}
        />

        {/* Botón Enviar */}
        <button
          onClick={() => handleSendMessage()}
          disabled={!inputText.trim() || isLoading}
          style={{
            width: '38px',
            height: '38px',
            borderRadius: '50%',
            background: inputText.trim() ? '#e4a834' : 'rgba(150,150,150,0.15)',
            border: 'none',
            color: inputText.trim() ? '#083344' : '#94a3b8',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: inputText.trim() ? 'pointer' : 'default',
            flexShrink: 0
          }}
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  );
}
