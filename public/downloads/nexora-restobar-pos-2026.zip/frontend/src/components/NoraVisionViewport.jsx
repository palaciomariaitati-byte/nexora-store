import React from 'react';
import { X, Camera, RefreshCw } from 'lucide-react';

export default function NoraVisionViewport({
  isCameraActive,
  onCloseCamera,
  videoRef,
  canvasRef,
  onCapture,
  isProcessing = false
}) {
  if (!isCameraActive) return null;

  return (
    <div style={{
      position: 'relative',
      borderRadius: '12px',
      overflow: 'hidden',
      background: '#090d16',
      border: '2px solid var(--primary, #e4a834)',
      boxShadow: '0 8px 30px rgba(0,0,0,0.6)',
      marginBottom: '14px'
    }}>
      {/* Header del HUD */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '8px 12px',
        background: 'rgba(8, 51, 68, 0.9)',
        color: '#fff',
        fontSize: '0.82rem',
        fontWeight: 700
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            background: '#10b981',
            display: 'inline-block'
          }} />
          <span>Nora Vision — Escaneo de Remito / Factura</span>
        </div>
        <button
          onClick={onCloseCamera}
          style={{
            background: 'none',
            border: 'none',
            color: '#a1a1aa',
            cursor: 'pointer',
            padding: '2px'
          }}
        >
          <X size={16} />
        </button>
      </div>

      {/* Video Viewport con Guía Óptica */}
      <div style={{ position: 'relative', width: '100%', height: '240px', background: '#000', overflow: 'hidden' }}>
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
        />
        <canvas ref={canvasRef} style={{ display: 'none' }} />

        {/* Retícula de Enfoque Adaptativa para Factura / Ticket Térmico Alargado */}
        <div style={{
          position: 'absolute',
          top: '10px',
          bottom: '10px',
          left: '50%',
          transform: 'translateX(-50%)',
          width: '68%',
          maxWidth: '280px',
          border: '2px dashed #f59e0b',
          borderRadius: '10px',
          background: 'rgba(245, 158, 11, 0.05)',
          boxShadow: '0 0 20px rgba(245, 158, 11, 0.25), inset 0 0 15px rgba(0,0,0,0.6)',
          pointerEvents: 'none',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          padding: '8px'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: '0.65rem',
            color: '#f59e0b',
            fontWeight: 800,
            textTransform: 'uppercase',
            letterSpacing: '0.5px'
          }}>
            <span>▲ ENCABEZADO / CUIT</span>
            <span>PROVEEDOR</span>
          </div>

          <div style={{ textAlign: 'center' }}>
            <span style={{
              background: 'rgba(0,0,0,0.85)',
              padding: '4px 10px',
              borderRadius: '6px',
              fontSize: '0.72rem',
              color: '#38bdf8',
              fontWeight: 700,
              border: '1px solid rgba(56, 189, 248, 0.4)'
            }}>
              📄 Ítem | Cant | P. Unitario | Subtotal
            </span>
          </div>

          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: '0.65rem',
            color: '#10b981',
            fontWeight: 800,
            textTransform: 'uppercase'
          }}>
            <span>▼ TOTAL COMPROBANTE</span>
            <span>PIE / FECHA</span>
          </div>
        </div>
      </div>

      {/* Footer con Disparador */}
      <div style={{
        padding: '10px 12px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background: '#0d131f'
      }}>
        <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
          {isProcessing ? 'Analizando con IA...' : 'Iluminación clara'}
        </span>
        <button
          onClick={onCapture}
          disabled={isProcessing}
          style={{
            background: 'linear-gradient(135deg, #e4a834, #d97706)',
            color: '#083344',
            border: 'none',
            padding: '8px 16px',
            borderRadius: '8px',
            fontWeight: 800,
            fontSize: '0.85rem',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          {isProcessing ? <RefreshCw className="animate-spin" size={16} /> : <Camera size={16} />}
          {isProcessing ? 'Procesando...' : 'Capturar & Leer'}
        </button>
      </div>
    </div>
  );
}
