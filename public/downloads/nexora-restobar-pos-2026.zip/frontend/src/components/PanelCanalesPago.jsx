import React, { useState, useEffect } from 'react';
import { CreditCard, QrCode, Lock, Eye, EyeOff, ShieldCheck, Check, Save, Zap, Building2, Percent } from 'lucide-react';
import { api } from '../services/api';

export default function PanelCanalesPago() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  // Show / Hide Password state
  const [showMpToken, setShowMpToken] = useState(false);
  const [showMpClientId, setShowMpClientId] = useState(false);
  const [showBankPublic, setShowBankPublic] = useState(false);
  const [showBankPrivate, setShowBankPrivate] = useState(false);

  // Form Data State
  const [gateways, setGateways] = useState({
    mercadoPago: {
      accessToken: '',
      clientId: '',
      collectorId: 'myj.restobar.mp',
      sandboxMode: true
    },
    bancarizado: {
      adquirente: 'fiserv', // 'fiserv' | 'payway' | 'getnet' | 'firstdata'
      publicKey: '',
      privateKey: '',
      environment: 'homologacion' // 'homologacion' | 'produccion'
    },
    promociones: {
      cuotasHabilitadas: ['1', '3'],
      descuentoEfvo: 10,
      recargoCuotas: 0
    }
  });

  useEffect(() => {
    loadGateways();
  }, []);

  const loadGateways = async () => {
    setLoading(true);
    try {
      const res = await api.getPaymentGateways();
      if (res.success && res.data) {
        setGateways(prev => ({
          ...prev,
          ...res.data
        }));
      }
    } catch (err) {
      console.error('Error al cargar pasarelas de pago:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMessage('');
    try {
      const res = await api.savePaymentGateways(gateways);
      if (res.success) {
        setSuccessMessage('🔒 Credenciales de Pasarelas de Pago encriptadas y guardadas correctamente.');
        setTimeout(() => setSuccessMessage(''), 5000);
      }
    } catch (err) {
      alert('Error al guardar pasarelas de pago: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const toggleCuota = (cuotaStr) => {
    setGateways(prev => {
      const current = prev.promociones.cuotasHabilitadas || [];
      const updated = current.includes(cuotaStr)
        ? current.filter(c => c !== cuotaStr)
        : [...current, cuotaStr];
      return {
        ...prev,
        promociones: {
          ...prev.promociones,
          cuotasHabilitadas: updated
        }
      };
    });
  };

  if (loading) {
    return (
      <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
        Cargando configuración de pasarelas financieras...
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '10px 0 40px 0' }}>
      
      {/* Banner Encabezado Estilo Neón */}
      <div className="glass-accent" style={{ padding: '20px 24px', borderRadius: 'var(--radius-lg)', marginBottom: '24px', border: '1px solid rgba(16,185,129,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 900, display: 'flex', alignItems: 'center', gap: '10px', color: '#fff' }}>
            <CreditCard style={{ color: '#10b981' }} />
            Administración de Pasarelas de Pago Multicanal
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
            Configuración segura de Access Tokens para Mercado Pago y Adquirentes Bancarios (Visa, Mastercard, Cabal)
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'rgba(16,185,129,0.1)', padding: '8px 14px', borderRadius: 'var(--radius-md)', border: '1px solid #10b981' }}>
          <ShieldCheck size={20} style={{ color: '#10b981' }} />
          <span style={{ fontSize: '0.8rem', fontWeight: 800, color: '#10b981' }}>Encriptación AES-256 Activa</span>
        </div>
      </div>

      {successMessage && (
        <div style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid #10b981', color: '#10b981', padding: '14px 20px', borderRadius: 'var(--radius-md)', marginBottom: '20px', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Check size={20} />
          {successMessage}
        </div>
      )}

      <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        
        {/* SECCIÓN 1: MERCADO PAGO & WALLETS (QR) */}
        <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)', border: '1px solid rgba(6,182,212,0.3)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px', color: '#06b6d4' }}>
              <QrCode size={22} />
              1. Mercado Pago (Cobro QR & Billeteras Virtuales)
            </h3>
            <span style={{ fontSize: '0.75rem', fontWeight: 800, color: gateways.mercadoPago.sandboxMode ? '#f59e0b' : '#10b981', background: 'rgba(255,255,255,0.05)', padding: '4px 10px', borderRadius: '6px' }}>
              {gateways.mercadoPago.sandboxMode ? '⚠️ Modo Sandbox (Pruebas)' : '🟢 Modo Producción (En Vivo)'}
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '16px' }}>
            
            {/* Access Token */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Access Token de Producción (APP_USR-...):
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showMpToken ? 'text' : 'password'}
                  value={gateways.mercadoPago.accessToken}
                  onChange={e => setGateways(prev => ({
                    ...prev,
                    mercadoPago: { ...prev.mercadoPago, accessToken: e.target.value }
                  }))}
                  placeholder="APP_USR-xxxxxx-xxxxxx-xxxxxx"
                  style={{
                    width: '100%',
                    background: 'var(--bg-main)',
                    border: '1px solid var(--border-color)',
                    color: '#fff',
                    padding: '10px 40px 10px 12px',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.88rem',
                    fontFamily: 'var(--font-mono)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowMpToken(!showMpToken)}
                  style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
                >
                  {showMpToken ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Client ID / Public Key */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Client ID / Public Key (Public Token):
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showMpClientId ? 'text' : 'password'}
                  value={gateways.mercadoPago.clientId}
                  onChange={e => setGateways(prev => ({
                    ...prev,
                    mercadoPago: { ...prev.mercadoPago, clientId: e.target.value }
                  }))}
                  placeholder="APP_USR-xxxxxxxx-xxxx-xxxx"
                  style={{
                    width: '100%',
                    background: 'var(--bg-main)',
                    border: '1px solid var(--border-color)',
                    color: '#fff',
                    padding: '10px 40px 10px 12px',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.88rem',
                    fontFamily: 'var(--font-mono)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowMpClientId(!showMpClientId)}
                  style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
                >
                  {showMpClientId ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Collector ID / Alias MP */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Alias CVU / Collector ID en Pantalla:
              </label>
              <input
                type="text"
                value={gateways.mercadoPago.collectorId}
                onChange={e => setGateways(prev => ({
                  ...prev,
                  mercadoPago: { ...prev.mercadoPago, collectorId: e.target.value }
                }))}
                placeholder="myj.restobar.mp"
                style={{
                  width: '100%',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  color: '#fff',
                  padding: '10px 12px',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.88rem'
                }}
              />
            </div>

            {/* Sandbox Mode Switch */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginTop: 'auto', paddingTop: '10px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', userSelect: 'none' }}>
                <input
                  type="checkbox"
                  checked={gateways.mercadoPago.sandboxMode}
                  onChange={e => setGateways(prev => ({
                    ...prev,
                    mercadoPago: { ...prev.mercadoPago, sandboxMode: e.target.checked }
                  }))}
                  style={{ width: '20px', height: '20px', accentColor: '#06b6d4', cursor: 'pointer' }}
                />
                <span style={{ fontSize: '0.88rem', fontWeight: 700, color: '#fff' }}>
                  Activar Modo Sandbox (Entorno de Testeo sin cobro real)
                </span>
              </label>
            </div>

          </div>
        </div>

        {/* SECCIÓN 2: PASARELAS BANCARIZADAS & TARJETAS (Visa, Mastercard, Cabal) */}
        <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)', border: '1px solid rgba(217,70,239,0.3)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px', color: '#d946ef' }}>
              <Building2 size={22} />
              2. Pasarelas Bancarizadas & Adquirentes (Visa, Mastercard, Cabal)
            </h3>
            <span style={{ fontSize: '0.75rem', fontWeight: 800, color: '#d946ef', background: 'rgba(255,255,255,0.05)', padding: '4px 10px', borderRadius: '6px' }}>
              {gateways.bancarizado.environment === 'homologacion' ? '🧪 Homologación (Test)' : '⚡ Producción Live'}
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '16px' }}>
            
            {/* Adquirente Selector */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Adquirente / Red de Procesamiento:
              </label>
              <select
                value={gateways.bancarizado.adquirente}
                onChange={e => setGateways(prev => ({
                  ...prev,
                  bancarizado: { ...prev.bancarizado, adquirente: e.target.value }
                }))}
                style={{
                  width: '100%',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  color: '#fff',
                  padding: '10px 12px',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.88rem',
                  fontWeight: 700
                }}
              >
                <option value="fiserv">Fiserv / Clover Argentina (Visa & Mastercard)</option>
                <option value="payway">Payway / Prisma Medios de Pago</option>
                <option value="getnet">Getnet Santander (Posnet Dual)</option>
                <option value="firstdata">First Data / Posnet Tradicional</option>
              </select>
            </div>

            {/* Entorno Homologación vs Producción */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Entorno de Ejecución:
              </label>
              <select
                value={gateways.bancarizado.environment}
                onChange={e => setGateways(prev => ({
                  ...prev,
                  bancarizado: { ...prev.bancarizado, environment: e.target.value }
                }))}
                style={{
                  width: '100%',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  color: '#fff',
                  padding: '10px 12px',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.88rem',
                  fontWeight: 700
                }}
              >
                <option value="homologacion">🧪 Homologación (Pruebas con Tarjetas de Test)</option>
                <option value="produccion">⚡ Producción en Vivo (Cobros Reales)</option>
              </select>
            </div>

            {/* Public Key Bancaria */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Clave Pública / Public API Key:
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showBankPublic ? 'text' : 'password'}
                  value={gateways.bancarizado.publicKey}
                  onChange={e => setGateways(prev => ({
                    ...prev,
                    bancarizado: { ...prev.bancarizado, publicKey: e.target.value }
                  }))}
                  placeholder="pub_key_live_xxxxxxxxxxxx"
                  style={{
                    width: '100%',
                    background: 'var(--bg-main)',
                    border: '1px solid var(--border-color)',
                    color: '#fff',
                    padding: '10px 40px 10px 12px',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.88rem',
                    fontFamily: 'var(--font-mono)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowBankPublic(!showBankPublic)}
                  style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
                >
                  {showBankPublic ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Secret Key Bancaria */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                Clave Privada / Private Secret Key:
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showBankPrivate ? 'text' : 'password'}
                  value={gateways.bancarizado.privateKey}
                  onChange={e => setGateways(prev => ({
                    ...prev,
                    bancarizado: { ...prev.bancarizado, privateKey: e.target.value }
                  }))}
                  placeholder="sec_key_live_xxxxxxxxxxxx"
                  style={{
                    width: '100%',
                    background: 'var(--bg-main)',
                    border: '1px solid var(--border-color)',
                    color: '#fff',
                    padding: '10px 40px 10px 12px',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.88rem',
                    fontFamily: 'var(--font-mono)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowBankPrivate(!showBankPrivate)}
                  style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
                >
                  {showBankPrivate ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* SECCIÓN 3: CUOTAS & PROMOCIONES */}
        <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)', border: '1px solid rgba(16,185,129,0.3)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px', color: '#10b981' }}>
              <Percent size={22} />
              3. Configuración de Cuotas & Descuentos por Canal
            </h3>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
            
            {/* Cuotas Selector */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '8px' }}>
                Cuotas sin Interés Habilitadas en Salón/App:
              </label>
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                {['1', '3', '6', '12'].map(c => {
                  const isSelected = (gateways.promociones.cuotasHabilitadas || []).includes(c);
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => toggleCuota(c)}
                      style={{
                        padding: '8px 16px',
                        borderRadius: 'var(--radius-sm)',
                        border: isSelected ? '2px solid #10b981' : '1px solid var(--border-color)',
                        background: isSelected ? 'rgba(16,185,129,0.2)' : 'var(--bg-main)',
                        color: isSelected ? '#10b981' : 'var(--text-main)',
                        fontWeight: 800,
                        cursor: 'pointer'
                      }}
                    >
                      {c} {c === '1' ? 'Cuota (Pago Único)' : 'Cuotas'}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Descuento Efectivo */}
            <div>
              <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '6px' }}>
                % Descuento por Pago en Efectivo:
              </label>
              <input
                type="number"
                value={gateways.promociones.descuentoEfvo}
                onChange={e => setGateways(prev => ({
                  ...prev,
                  promociones: { ...prev.promociones, descuentoEfvo: Number(e.target.value) }
                }))}
                style={{
                  width: '100%',
                  background: 'var(--bg-main)',
                  border: '1px solid var(--border-color)',
                  color: '#fff',
                  padding: '10px 12px',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.88rem'
                }}
              />
            </div>

          </div>
        </div>

        {/* BOTÓN SUBMIT DE GUARDA ENCRIPTADA */}
        <button
          type="submit"
          disabled={saving}
          className="btn btn-primary"
          style={{ padding: '18px', fontSize: '1.1rem', fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', cursor: 'pointer' }}
        >
          <Lock size={20} />
          {saving ? 'Encriptando & Guardando en Servidor...' : '🔒 Guardar y Encriptar Credenciales de Pasarelas'}
        </button>

      </form>
    </div>
  );
}
