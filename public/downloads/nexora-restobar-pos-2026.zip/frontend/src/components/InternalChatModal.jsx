import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, Bell, AlertTriangle, Info, X, ShieldCheck } from 'lucide-react';
import { api, socket } from '../services/api';

export default function InternalChatModal({ isOpen, onClose, currentRoleName }) {
  const [messages, setMessages] = useState([]);
  const [newMessageText, setNewMessageText] = useState('');
  const [targetSector, setTargetSector] = useState('Todos los Sectores');
  const [messageType, setMessageType] = useState('info');

  useEffect(() => {
    if (isOpen) {
      fetchMessages();
    }

    const handleNewMessage = () => fetchMessages();
    socket.on('internal_message_created', handleNewMessage);

    return () => {
      socket.off('internal_message_created', handleNewMessage);
    };
  }, [isOpen]);

  const fetchMessages = async () => {
    try {
      const res = await api.getInternalMessages();
      setMessages(res.messages || []);
    } catch (err) {
      console.error('Error fetching internal messages:', err);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessageText.trim()) return;

    try {
      await api.sendInternalMessage({
        senderSector: currentRoleName || 'General',
        targetSector,
        message: newMessageText,
        type: messageType
      });

      setNewMessageText('');
      fetchMessages();
    } catch (err) {
      alert('Error enviando mensaje interno: ' + err.message);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="bottom-sheet-overlay" onClick={onClose}>
      <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '550px', maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
        
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <MessageSquare size={20} />
            💬 Intercomunicador & Chat de Personal
          </h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={22} />
          </button>
        </div>

        {/* Quick Alert Presets */}
        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '6px' }}>Alertas Rápidas por Sector:</div>
        <div style={{ display: 'flex', gap: '6px', marginBottom: '12px', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={() => {
              setTargetSector('Pañol / Depósito');
              setMessageType('warning');
              setNewMessageText('⚠️ Solicitud urgente de reposición de insumos a Cocina');
            }}
            style={{ padding: '4px 8px', borderRadius: '4px', background: 'rgba(245, 158, 11, 0.15)', border: '1px solid #f59e0b', color: '#f59e0b', fontSize: '0.75rem', cursor: 'pointer', fontWeight: 700 }}
          >
            ⚠️ Pedir Reposición a Pañol
          </button>

          <button
            type="button"
            onClick={() => {
              setTargetSector('Presidencia / Gerencia');
              setMessageType('info');
              setNewMessageText('📢 Notificación de Arqueo / Rendición enviada a Gerencia');
            }}
            style={{ padding: '4px 8px', borderRadius: '4px', background: 'rgba(59, 130, 246, 0.15)', border: '1px solid #3b82f6', color: '#3b82f6', fontSize: '0.75rem', cursor: 'pointer', fontWeight: 700 }}
          >
            📢 Reportar a Gerencia
          </button>

          <button
            type="button"
            onClick={() => {
              setTargetSector('Caja / Mostrador');
              setMessageType('info');
              setNewMessageText('🍳 Platos de la ronda listos para retirar de Cocina');
            }}
            style={{ padding: '4px 8px', borderRadius: '4px', background: 'rgba(16, 185, 129, 0.15)', border: '1px solid #10b981', color: '#10b981', fontSize: '0.75rem', cursor: 'pointer', fontWeight: 700 }}
          >
            🍳 Platos Listos a Caja
          </button>
        </div>

        {/* Messages Feed */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px', padding: '10px', background: 'var(--bg-main)', borderRadius: 'var(--radius-md)', marginBottom: '14px', minHeight: '220px', maxHeight: '340px' }}>
          {messages.length === 0 ? (
            <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '20px', fontSize: '0.85rem' }}>
              No hay mensajes recientes en el intercomunicador.
            </div>
          ) : (
            messages.map(msg => (
              <div
                key={msg.id}
                style={{
                  padding: '8px 12px',
                  borderRadius: 'var(--radius-sm)',
                  background: msg.type === 'warning' ? 'rgba(239, 68, 68, 0.12)' : 'var(--bg-card)',
                  border: `1px solid ${msg.type === 'warning' ? '#ef4444' : 'var(--border-color)'}`
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '2px' }}>
                  <span style={{ fontWeight: 800, color: 'var(--primary)' }}>{msg.senderSector} ➔ {msg.targetSector}</span>
                  <span style={{ color: 'var(--text-muted)' }}>{msg.timestamp}</span>
                </div>
                <div style={{ fontSize: '0.85rem', color: '#fff', fontWeight: msg.type === 'warning' ? 700 : 400 }}>
                  {msg.message}
                </div>
              </div>
            ))
          )}
        </div>

        {/* New Message Form */}
        <form onSubmit={handleSendMessage} style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div style={{ display: 'flex', gap: '8px' }}>
            <select
              value={targetSector}
              onChange={e => setTargetSector(e.target.value)}
              style={{ background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem' }}
            >
              <option value="Todos los Sectores">🌐 Todos los Sectores</option>
              <option value="Presidencia / Gerencia">👑 Presidencia / Gerencia</option>
              <option value="Pañol / Depósito">📦 Pañol / Depósito</option>
              <option value="Cocina / Barra">🍳 Cocina / Barra</option>
              <option value="Caja / Mostrador">🍻 Salón / Caja / Mostrador</option>
              <option value="Delivery / Cadetes">🛵 Delivery / Cadetes</option>
            </select>

            <select
              value={messageType}
              onChange={e => setMessageType(e.target.value)}
              style={{ background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem' }}
            >
              <option value="info">ℹ️ Informativo</option>
              <option value="warning">⚠️ Alerta / Urgente</option>
            </select>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <input
              type="text"
              required
              value={newMessageText}
              onChange={e => setNewMessageText(e.target.value)}
              placeholder="Escribe un comunicado interno para el personal..."
              style={{ flex: 1, background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px 12px', borderRadius: 'var(--radius-sm)', fontSize: '0.85rem' }}
            />
            <button type="submit" className="btn btn-primary" style={{ padding: '10px 16px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Send size={16} />
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
