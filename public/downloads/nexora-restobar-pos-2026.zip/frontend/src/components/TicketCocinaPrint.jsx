import React from 'react';

/**
 * TicketCocinaPrint.jsx: Comanda de Impresión Térmica para Cocina / Barra (58mm y 80mm)
 * 
 * Reglas Estrictas:
 *  - Oculto en la pantalla (@media screen { display: none; })
 *  - Visible únicamente al imprimir (@media print { display: block; })
 *  - ESTRICTAMENTE SIN PRECIOS NI TOTALES (Solo N° de Mesa, Hora, Ítems y Notas de Elaboración).
 */
export default function TicketCocinaPrint({ ticketData }) {
  if (!ticketData) return null;

  const {
    orderId = 'ORD-00',
    tableName = 'Mesa 1',
    dinerName = 'Salón',
    items = [],
    createdAt = new Date().toISOString(),
    notes = ''
  } = ticketData;

  const formatHora = (dateStr) => {
    try {
      return new Date(dateStr).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return '';
    }
  };

  return (
    <div className="ticket-cocina-thermal-container">
      <style>{`
        @media screen {
          .ticket-cocina-thermal-container {
            display: none !important;
          }
        }
        @media print {
          body * {
            visibility: hidden;
          }
          .ticket-cocina-thermal-container,
          .ticket-cocina-thermal-container * {
            visibility: visible;
          }
          .ticket-cocina-thermal-container {
            display: block !important;
            position: absolute;
            left: 0;
            top: 0;
            width: 80mm;
            max-width: 80mm;
            padding: 2mm;
            margin: 0;
            font-family: 'Courier New', Courier, monospace;
            font-size: 13px;
            line-height: 1.25;
            color: #000;
            background: #fff;
          }
          @page {
            size: 80mm auto;
            margin: 0;
          }
        }
      `}</style>

      <div style={{ textAlign: 'center', borderBottom: '2px dashed #000', paddingBottom: '6px', marginBottom: '8px' }}>
        <h2 style={{ margin: '0 0 2px 0', fontSize: '20px', fontWeight: 'bold' }}>*** COCINA / BARRA ***</h2>
        <div style={{ fontSize: '18px', fontWeight: 'bold', margin: '4px 0' }}>
          {tableName.toUpperCase()}
        </div>
        <div style={{ fontSize: '12px' }}>
          COMANDA: #{orderId.slice(-6).toUpperCase()} | HORA: {formatHora(createdAt)}
        </div>
        {dinerName && <div style={{ fontSize: '12px', fontStyle: 'italic' }}>Mozo/Comensal: {dinerName}</div>}
      </div>

      {/* LISTA DE PLATOS Y BEBIDAS - ESTRICTAMENTE SIN PRECIOS */}
      <div style={{ borderBottom: '2px dashed #000', paddingBottom: '8px', marginBottom: '8px' }}>
        {items.map((item, idx) => (
          <div key={idx} style={{ marginBottom: '8px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '15px', fontWeight: 'bold' }}>
              <span>[{item.quantity}x] {item.title || item.name}</span>
            </div>
            {item.notes && (
              <div style={{
                fontSize: '13px',
                fontWeight: 'bold',
                paddingLeft: '12px',
                marginTop: '2px',
                borderLeft: '2px solid #000'
              }}>
                &gt;&gt; NOTA: {item.notes}
              </div>
            )}
          </div>
        ))}
      </div>

      {notes && (
        <div style={{ fontSize: '13px', fontWeight: 'bold', borderBottom: '1px solid #000', paddingBottom: '4px', marginBottom: '8px' }}>
          OBSERVACIÓN GENERAL: {notes}
        </div>
      )}

      <div style={{ textAlign: 'center', fontSize: '11px', paddingTop: '4px' }}>
        --- FIN DE COMANDA COCINA ---
      </div>
    </div>
  );
}
