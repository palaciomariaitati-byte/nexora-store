import React, { useState, useEffect } from 'react';
import { Printer, RefreshCw, CheckCircle2, Ticket } from 'lucide-react';
import { socket } from '../services/api';

export default function TicketPrinterModal() {
  const [tickets, setTickets] = useState([]);
  const [activeTab, setActiveTab] = useState('comandas'); // 'comandas' | 'precuentas'

  useEffect(() => {
    // Escuchar eventos de comandas creadas y pagos
    const handleOrderCreated = (data) => {
      if (data.comandaTicket) {
        setTickets(prev => [
          {
            type: 'comanda',
            id: data.comandaTicket.orderId,
            timestamp: new Date().toLocaleTimeString(),
            data: data.comandaTicket
          },
          ...prev
        ]);
      }
    };

    const handlePaymentReceived = (data) => {
      if (data.payment) {
        setTickets(prev => [
          {
            type: 'precuenta',
            id: data.payment.id,
            timestamp: new Date().toLocaleTimeString(),
            data: data.payment
          },
          ...prev
        ]);
      }
    };

    socket.on('order_created', handleOrderCreated);
    socket.on('payment_received', handlePaymentReceived);

    return () => {
      socket.off('order_created', handleOrderCreated);
      socket.off('payment_received', handlePaymentReceived);
    };
  }, []);

  const filteredTickets = tickets.filter(t => activeTab === 'comandas' ? t.type === 'comanda' : t.type === 'precuenta');

  const triggerPrint = (ticket) => {
    window.print();
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '20px auto', padding: '20px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Printer style={{ color: 'var(--primary)' }} />
            Centro de Impresión de Comandas & Pre-cuentas
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: '4px' }}>
            Control térmico automático para cocina, barra y control del mozo (Firma: <strong>Nexora One</strong>)
          </p>
        </div>

        {/* Tab Filters */}
        <div style={{ display: 'flex', gap: '8px', background: 'var(--bg-card)', padding: '4px', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
          <button
            onClick={() => setActiveTab('comandas')}
            className={`btn ${activeTab === 'comandas' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            📋 Comandas Cocina/Barra ({tickets.filter(t => t.type === 'comanda').length})
          </button>

          <button
            onClick={() => setActiveTab('precuentas')}
            className={`btn ${activeTab === 'precuentas' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            🧾 Tickets de Caja ({tickets.filter(t => t.type === 'precuenta').length})
          </button>
        </div>
      </div>

      {/* Ticket List / Grid */}
      {filteredTickets.length === 0 ? (
        <div className="glass" style={{ textAlign: 'center', padding: '60px 20px', borderRadius: 'var(--radius-lg)' }}>
          <Ticket size={48} style={{ color: 'var(--text-muted)', marginBottom: '16px' }} />
          <h3 style={{ fontSize: '1.2rem', color: 'var(--text-muted)' }}>No hay tickets en cola actualmente</h3>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '8px' }}>
            Realiza un pedido desde la app móvil del cliente para ver la emisión del ticket térmico en tiempo real.
          </p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '24px' }}>
          {filteredTickets.map((t, idx) => (
            <div key={t.id + idx} className="animate-fade-in">
              {t.type === 'comanda' ? (
                <div className="thermal-ticket">
                  <div className="thermal-ticket-header">
                    <h3 style={{ fontSize: '1.1rem', fontWeight: 800 }}>*** COMANDA DE COCINA ***</h3>
                    <p style={{ fontSize: '1rem', fontWeight: 700, marginTop: '4px', background: '#000', color: '#fff', padding: '2px 8px', borderRadius: '4px' }}>
                      {t.data.tableName}
                    </p>
                    <p style={{ fontSize: '0.8rem', color: '#555', marginTop: '4px' }}>
                      Comensal: {t.data.dinerName} | Hora: {t.timestamp}
                    </p>
                    <p style={{ fontSize: '0.75rem', fontWeight: 700, color: '#888', marginTop: '2px' }}>
                      Ref: #{t.id.slice(-6)}
                    </p>
                  </div>

                  <div className="thermal-ticket-body">
                    <table style={{ width: '100%', fontSize: '0.9rem', borderCollapse: 'collapse' }}>
                      <thead>
                        <tr style={{ borderBottom: '1px solid #999', textAlign: 'left' }}>
                          <th style={{ padding: '4px 0' }}>Cant</th>
                          <th style={{ padding: '4px 0' }}>Producto</th>
                        </tr>
                      </thead>
                      <tbody>
                        {t.data.items.map((item, i) => (
                          <tr key={i} style={{ borderBottom: '1px dashed #ddd' }}>
                            <td style={{ fontWeight: 800, fontSize: '1.05rem', padding: '6px 0', verticalAlign: 'top', width: '40px' }}>
                              [{item.quantity}x]
                            </td>
                            <td style={{ padding: '6px 0' }}>
                              <strong style={{ fontSize: '0.95rem' }}>{item.title}</strong>
                              {item.notes && (
                                <div style={{ fontSize: '0.8rem', color: '#c53030', fontWeight: 700, marginTop: '2px' }}>
                                  ⚠️ Nota: {item.notes}
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="thermal-ticket-footer">
                    <p style={{ fontWeight: 700 }}>* Mozo: Despachar a la brevedad *</p>
                    <p style={{ fontSize: '0.7rem', marginTop: '6px', color: '#777' }}>
                      Desarrollado por <strong>Nexora One</strong>
                    </p>
                    <button
                      onClick={() => triggerPrint(t)}
                      style={{
                        marginTop: '12px',
                        width: '100%',
                        padding: '8px',
                        background: '#000',
                        color: '#fff',
                        border: 'none',
                        borderRadius: '6px',
                        fontWeight: 700,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px'
                      }}
                    >
                      <Printer size={14} /> Imprimir Comanda ESC/POS
                    </button>
                  </div>
                </div>
              ) : (
                /* Ticket Pre-cuenta / Pago */
                <div className="thermal-ticket" style={{ borderTop: '6px solid #10b981' }}>
                  <div className="thermal-ticket-header">
                    <h3 style={{ fontSize: '1.1rem', fontWeight: 800 }}>*** COMPROBANTE DE PAGO ***</h3>
                    <p style={{ fontSize: '1rem', fontWeight: 700, marginTop: '4px', background: '#10b981', color: '#fff', padding: '2px 8px', borderRadius: '4px' }}>
                      {t.data.tableName}
                    </p>
                    <p style={{ fontSize: '0.8rem', color: '#555', marginTop: '4px' }}>
                      Cliente: {t.data.dinerName} | Fecha: {t.timestamp}
                    </p>
                  </div>

                  <div className="thermal-ticket-body">
                    <p style={{ fontSize: '0.85rem', marginBottom: '8px' }}>
                      <strong>Medio de Pago:</strong> {t.data.paymentMethod ? t.data.paymentMethod.toUpperCase() : 'ELECTRONICO'}
                    </p>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', margin: '4px 0' }}>
                      <span>Subtotal Consumo:</span>
                      <strong>${t.data.subtotal?.toLocaleString('es-AR')}</strong>
                    </div>
                    {t.data.tipAmount > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', color: '#d97706', margin: '4px 0' }}>
                        <span>Propina Mozo ({t.data.tipPercentage}%):</span>
                        <strong>+${t.data.tipAmount?.toLocaleString('es-AR')}</strong>
                      </div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: 800, marginTop: '8px', paddingTop: '8px', borderTop: '2px solid #000' }}>
                      <span>TOTAL PAGADO:</span>
                      <span>${t.data.totalAmount?.toLocaleString('es-AR')}</span>
                    </div>
                  </div>

                  <div className="thermal-ticket-footer">
                    <p style={{ fontWeight: 700, color: '#10b981' }}>¡Muchas gracias por su visita!</p>
                    <p style={{ fontSize: '0.75rem', marginTop: '6px', color: '#666' }}>
                      Sistema Inteligente <strong>Nexora One</strong>
                    </p>
                    <button
                      onClick={() => triggerPrint(t)}
                      style={{
                        marginTop: '12px',
                        width: '100%',
                        padding: '8px',
                        background: '#10b981',
                        color: '#fff',
                        border: 'none',
                        borderRadius: '6px',
                        fontWeight: 700,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px'
                      }}
                    >
                      <Printer size={14} /> Imprimir Comprobante
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

    </div>
  );
}
