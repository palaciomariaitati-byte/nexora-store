export type LicenseStatus = 'activo' | 'alerta' | 'suspendido';
export type SystemRole = 'gerencia' | 'caja' | 'cocina' | 'delivery' | 'panol' | 'mozo';
export type TableStatus = 'libre' | 'ocupada' | 'pedido_entrante' | 'preparando' | 'pago_solicitado';
export type OrderStatus = 'recibido' | 'en_cocina' | 'listo' | 'entregado' | 'cancelado';
export type OrderItemStatus = 'pendiente' | 'preparando' | 'listo' | 'pagado' | 'cancelado';
export type OrderType = 'salon' | 'delivery' | 'takeaway';
export type PaymentMethod = 'efectivo' | 'tarjeta' | 'mercado_pago' | 'transferencia';

export interface SectorAccess {
  role: SystemRole;
  name: string;
  allowedViews: string[];
}

export interface TableSession {
  id: string;
  tableId: number;
  tableName?: string;
  comensales: number;
  status: 'open' | 'closed';
  createdAt: string;
}

export interface Table {
  id: number;
  name: string;
  capacity: number;
  status: TableStatus;
  activeSessionId: string | null;
  comensales?: number;
  opened_at?: string;
  activeSession?: TableSession | null;
  orders?: Order[];
  ordersCount?: number;
  unpaidTotal?: number;
}

export interface MenuItem {
  id: string;
  title: string;
  category: string;
  price: number;
  description: string;
  isDailySpecial: boolean | number;
  tag?: string;
  image?: string;
  available: boolean | number;
}

export interface MenuCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface OrderItem {
  id: string;
  producto_id?: string;
  title: string;
  quantity: number;
  price: number;
  subtotal: number;
  notes?: string;
  status: OrderItemStatus;
  isPaid?: boolean;
}

export interface Order {
  id: string;
  sessionId: string;
  tableId: number | null;
  orderNumber: string;
  dinerName: string;
  status: OrderStatus;
  total: number;
  tipo: OrderType;
  items: OrderItem[];
  createdAt: string;
}

export interface PaymentItem {
  itemId: string;
  title: string;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface PaymentPayload {
  sessionId: string;
  tableId: number;
  dinerName: string;
  paidItems: PaymentItem[];
  paymentMethod: PaymentMethod;
  subtotal: number;
  tipPercentage: number;
  tipAmount: number;
  totalAmount: number;
}
