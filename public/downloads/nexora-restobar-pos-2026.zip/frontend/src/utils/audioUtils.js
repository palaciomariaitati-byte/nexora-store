/**
 * audioUtils.js: Normalización y Sanitización Fonética para Síntesis de Voz (TTS)
 * Adaptado de D:\Nora itu UTN\src\utils\audioUtils.ts
 */

export function sanitizeForTTS(text) {
  if (!text) return "";

  let sanitized = String(text);

  // 1. Eliminar artefactos de markdown, tags y bloques de pensamiento
  sanitized = sanitized
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .replace(/<thinking>[\s\S]*?<\/thinking>/gi, "")
    .replace(/^Thinking:?\s*/i, "")
    .replace(/```[\s\S]*?```/g, "")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/[*#_~`>\[\]\(\)\{\}\\]+/g, " ");

  // 2. Normalizar operadores matemáticos y símbolos a palabras habladas
  sanitized = sanitized.replace(/(\d+)\s*[xX*×]\s*(\d+)/g, "$1 por $2");
  sanitized = sanitized.replace(/(\d+)\s*\+\s*(\d+)/g, "$1 más $2");
  sanitized = sanitized.replace(/(\d+)\s*[-−–]\s*(\d+)/g, "$1 menos $2");
  sanitized = sanitized.replace(/(\d+)\s*[\/÷]\s*(\d+)/g, "$1 dividido $2");
  sanitized = sanitized.replace(/(\d+)\s*%/g, "$1 por ciento");
  sanitized = sanitized.replace(/\$/g, " pesos ");
  sanitized = sanitized.replace(/(\d+)\s*=\s*(\d+)/g, "$1 es igual a $2");
  sanitized = sanitized.replace(/\s*=\s*/g, " es igual a ");

  // Limpiar espacios múltiples
  return sanitized.replace(/\s+/g, " ").trim();
}
