// Global Centralized Network Resolution Helper for Nexora One
// Guarantees 100% device linking compatibility on any local Wi-Fi without 'localhost' errors.

let cachedLocalIp = '192.168.1.219';

export const setGlobalLocalIp = (ip) => {
  if (ip && ip !== 'localhost' && ip !== '127.0.0.1' && ip !== '0.0.0.0') {
    cachedLocalIp = ip.trim();
  }
};

export const getResolvedHost = () => {
  const currentHost = window.location.hostname;
  if (currentHost && currentHost !== 'localhost' && currentHost !== '127.0.0.1' && currentHost !== '0.0.0.0') {
    return currentHost;
  }
  return cachedLocalIp;
};

export const getCleanDeviceUrl = (queryParams = '') => {
  const host = getResolvedHost();
  const port = window.location.port || '3036';
  const protocol = window.location.protocol || 'http:';
  const cleanQuery = queryParams ? (queryParams.startsWith('?') ? queryParams : `?${queryParams}`) : '';
  return `${protocol}//${host}:${port}/${cleanQuery}`;
};
