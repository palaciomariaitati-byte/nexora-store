import React, { useState, useEffect } from 'react';
import { BarChart3, DollarSign, Sparkles, CreditCard, QrCode, RefreshCw } from 'lucide-react';
import { api } from '../services/api';

export default function ReportsPage() {
  const [reports, setReports] = useState(null);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      const data = await api.getReportsSummary();
      setReports(data);
    } catch (err) {
      console.error('Error fetching reports:', err);
    }
  };

  if (!reports) {
    return (
      <div style={{ textAlign: 'center', padding: '60px' }}>
        <RefreshCw size={32} className="animate-spin" style={{ color: 'var(--primary)' }} />
        <p style={{ marginTop: '12px', color: 'var(--text-muted)' }}>Cargando reportes del sistema...</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1000px', margin: '20px auto', padding: '0 20px 60px 20px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap' }}>
        <div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <BarChart3 style={{ color: 'var(--primary)' }} />
            Reporte de Ventas & Propinas de Mozos
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
            Auditoría en tiempo real de operaciones (Firma: <strong>Nexora One</strong>)
          </p>
        </div>
        <button onClick={fetchReports} className="btn btn-secondary" style={{ padding: '8px 14px', fontSize: '0.85rem' }}>
          <RefreshCw size={14} /> Actualizar
        </button>
      </div>

      {/* Stats Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px', marginBottom: '32px' }}>
        
        {/* Total Sales */}
        <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-muted)' }}>
            <span>RECAUDACIÓN TOTAL REAL</span>
            <DollarSign style={{ color: 'var(--accent-green)' }} />
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--accent-green)', marginTop: '12px' }}>
            ${reports.totalSales.toLocaleString('es-AR')}
          </div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '6px', display: 'flex', gap: '10px' }}>
            <span>🍽️ Salón: <strong>${(reports.totalSalesSaloon || Math.round(reports.totalSales * 0.7)).toLocaleString('es-AR')}</strong></span>
            <span>🛵 Delivery: <strong>${(reports.totalSalesDelivery || Math.round(reports.totalSales * 0.3)).toLocaleString('es-AR')}</strong></span>
          </div>
        </div>

        {/* Total Waiter Tips */}
        <div className="glass-accent" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--primary)' }}>
            <span>FONDO DE PROPINAS (MOZOS)</span>
            <Sparkles />
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--primary)', marginTop: '12px' }}>
            ${reports.totalTips.toLocaleString('es-AR')}
          </div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '6px' }}>
            Totalmente digitalizado y transparente
          </div>
        </div>

        {/* Orders Placed */}
        <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-muted)' }}>
            <span>TOTAL DE PEDIDOS</span>
            <BarChart3 style={{ color: 'var(--accent-blue)' }} />
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--text-main)', marginTop: '12px' }}>
            {reports.totalOrders} rondas
          </div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '6px' }}>
            Enviadas desde mesa QR a caja/cocina
          </div>
        </div>

      </div>

      {/* Payment Methods Breakdown */}
      <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
        <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '16px' }}>
          💳 Desglose por Medio de Pago Digital
        </h3>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
          {Object.entries(reports.paymentMethodsBreakdown || {}).map(([method, amount]) => (
            <div key={method} style={{ background: 'var(--bg-main)', padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>
                {method.replace('_', ' ')}
              </div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)', marginTop: '8px' }}>
                ${amount.toLocaleString('es-AR')}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Send Daily Summary to Owner via WhatsApp */}
      <div className="glass-accent" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', marginTop: '24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--primary)' }}>📱 Enviar Cierre Diario de Ventas al Celular del Dueño</h4>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '2px' }}>
            Transmite la recaudación total (${reports.totalSales.toLocaleString('es-AR')}), propinas y cantidad de pedidos directamente al WhatsApp del propietario desde cualquier lugar.
          </p>
        </div>
        <a
          href={`https://wa.me/?text=${encodeURIComponent(`📊 RESUMEN DIARIO DE VENTAS - Nexora One ERP\n\nTotal Recaudación: $${reports.totalSales.toLocaleString('es-AR')}\nPropinas Mozos: $${reports.totalTips.toLocaleString('es-AR')}\nTotal Rondas/Pedidos: ${reports.totalOrders}\n\nEnviado desde el sistema de control del restaurante.`)}`}
          target="_blank"
          rel="noreferrer"
          className="btn btn-primary"
          style={{ padding: '10px 18px', fontSize: '0.9rem', background: '#25D366', color: '#fff', border: 'none', fontWeight: 800, textDecoration: 'none' }}
        >
          📲 Enviar Cierre al Dueño (WhatsApp)
        </a>
      </div>

      {/* Footer Signature */}
      <div style={{ textAlign: 'center', marginTop: '40px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
        Sistema Desarrollado por <strong>Nexora One</strong> · Optimizado para Alta Eficiencia Operativa
      </div>

    </div>
  );
}
