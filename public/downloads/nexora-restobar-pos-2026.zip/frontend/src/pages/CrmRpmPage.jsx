import React, { useState, useEffect } from 'react';
import { Users, Activity, Award, TrendingUp, Clock, Plus, Search, ShieldCheck, Heart, Sparkles, X } from 'lucide-react';
import { api, socket } from '../services/api';

export default function CrmRpmPage() {
  const [activeTab, setActiveTab] = useState('crm'); // 'crm' | 'rpm'
  const [customers, setCustomers] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    level: 'Nuevo',
    visitsCount: 1,
    totalSpent: 0,
    favoriteDish: '',
    notes: ''
  });

  useEffect(() => {
    fetchData();

    const handleCrmUpdated = () => fetchData();
    const handleOrderCreated = () => fetchData();

    socket.on('crm_updated', handleCrmUpdated);
    socket.on('order_created', handleOrderCreated);

    return () => {
      socket.off('crm_updated', handleCrmUpdated);
      socket.off('order_created', handleOrderCreated);
    };
  }, []);

  const fetchData = async () => {
    try {
      const crmRes = await api.getCustomers();
      setCustomers(crmRes.customers || []);

      const rpmRes = await api.getRpmMetrics();
      setMetrics(rpmRes.metrics || null);
    } catch (err) {
      console.error('Error fetching CRM/RPM data:', err);
    }
  };

  const handleSaveCustomer = async (e) => {
    e.preventDefault();
    if (!formData.name) {
      alert('Ingresa el nombre del cliente');
      return;
    }

    try {
      await api.createCustomer(formData);
      setIsCustomerModalOpen(false);
      setFormData({
        name: '',
        phone: '',
        email: '',
        level: 'Nuevo',
        visitsCount: 1,
        totalSpent: 0,
        favoriteDish: '',
        notes: ''
      });
      fetchData();
    } catch (err) {
      alert('Error registrando cliente: ' + err.message);
    }
  };

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery)
  );

  return (
    <div style={{ maxWidth: '1200px', margin: '20px auto', padding: '0 20px 60px 20px' }}>
      
      {/* Top Title & Tab Selector */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Activity style={{ color: 'var(--primary)' }} />
            Módulo CRM & RPM (Fidelización & Rendimiento)
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
            Control de clientes frecuentes y métricas de desempeño del restaurante · Firma: <strong>Nexora One</strong>
          </p>
        </div>

        {/* Tab Selector */}
        <div style={{ display: 'flex', gap: '8px', background: 'var(--bg-card)', padding: '4px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
          <button
            onClick={() => setActiveTab('crm')}
            className={`btn ${activeTab === 'crm' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 18px', fontSize: '0.85rem' }}
          >
            <Users size={16} /> CRM Clientes ({customers.length})
          </button>
          <button
            onClick={() => setActiveTab('rpm')}
            className={`btn ${activeTab === 'rpm' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 18px', fontSize: '0.85rem' }}
          >
            <TrendingUp size={16} /> RPM Rendimiento
          </button>
        </div>
      </div>

      {/* CRM SECTION */}
      {activeTab === 'crm' && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
            {/* Search Input */}
            <div style={{ position: 'relative', flex: '1', maxWidth: '400px' }}>
              <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Buscar cliente por nombre, teléfono o email..."
                style={{
                  width: '100%',
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  color: '#fff',
                  padding: '10px 12px 10px 38px',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.85rem'
                }}
              />
            </div>

            <button onClick={() => setIsCustomerModalOpen(true)} className="btn btn-primary" style={{ padding: '10px 16px', fontSize: '0.9rem' }}>
              <Plus size={16} /> Registrar Cliente Frecuente
            </button>
          </div>

          {/* Customer Cards Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '20px' }}>
            {filteredCustomers.map(cust => (
              <div key={cust.id} className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                    <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>{cust.name}</h3>
                    <span className={`badge ${cust.level.includes('VIP') ? 'badge-warning' : 'badge-info'}`}>
                      {cust.level}
                    </span>
                  </div>

                  <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'flex', flexDirection: 'column', gap: '4px', marginBottom: '12px' }}>
                    {cust.phone && <div>📞 {cust.phone}</div>}
                    {cust.email && <div>✉️ {cust.email}</div>}
                  </div>

                  <div style={{ background: 'var(--bg-main)', padding: '10px 12px', borderRadius: 'var(--radius-sm)', marginBottom: '12px', fontSize: '0.8rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span>Visitas registradas:</span>
                      <strong>{cust.visitsCount} veces</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span>Consumo Total:</span>
                      <strong style={{ color: 'var(--accent-green)' }}>${cust.totalSpent.toLocaleString('es-AR')}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span>Plato Favorito:</span>
                      <strong style={{ color: 'var(--primary)' }}>{cust.favoriteDish}</strong>
                    </div>
                  </div>

                  {cust.notes && (
                    <div style={{ fontSize: '0.75rem', color: 'var(--primary)', fontStyle: 'italic', background: 'var(--primary-light)', padding: '8px 10px', borderRadius: 'var(--radius-sm)' }}>
                      💡 Nota: {cust.notes}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* RPM METRICS SECTION */}
      {activeTab === 'rpm' && metrics && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* Key Indicators Row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
            
            <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span>TIEMPO PROMEDIO COCINA</span>
                <Clock style={{ color: 'var(--primary)' }} />
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--primary)', marginTop: '8px' }}>
                {metrics.avgPrepMinutes} min
              </div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Métrica de agilidad del KDS</span>
            </div>

            <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span>TICKET PROMEDIO PAGO</span>
                <TrendingUp style={{ color: 'var(--accent-green)' }} />
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--accent-green)', marginTop: '8px' }}>
                ${metrics.avgTicket.toLocaleString('es-AR')}
              </div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Gasto promedio por cobro</span>
            </div>

            <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span>ROTACIÓN DE MESAS</span>
                <Users style={{ color: 'var(--accent-blue)' }} />
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: '#fff', marginTop: '8px' }}>
                {metrics.activeTablesCount} / {metrics.totalTables} ocupadas
              </div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Ocupación actual del salón</span>
            </div>

          </div>

          {/* Top Selling Dishes Ranking */}
          <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Award style={{ color: 'var(--primary)' }} />
              Ranking de Platos & Bebidas Más Vendidos (Top 5)
            </h3>

            {metrics.topDishes.length === 0 ? (
              <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Aún no hay suficientes ventas registradas para armar el ranking.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                {metrics.topDishes.map((dish, idx) => (
                  <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '99px',
                      background: idx === 0 ? 'var(--primary)' : 'var(--bg-card-hover)',
                      color: idx === 0 ? '#000' : '#fff',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '0.9rem'
                    }}>
                      #{idx + 1}
                    </div>

                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', fontWeight: 700, marginBottom: '4px' }}>
                        <span>{dish.title}</span>
                        <span style={{ color: 'var(--primary)' }}>{dish.count} unidades</span>
                      </div>
                      <div style={{ height: '8px', background: 'var(--bg-main)', borderRadius: '99px', overflow: 'hidden' }}>
                        <div style={{
                          height: '100%',
                          width: `${Math.min(100, (dish.count / (metrics.topDishes[0].count || 1)) * 100)}%`,
                          background: 'linear-gradient(90deg, #f59e0b, #d97706)',
                          borderRadius: '99px'
                        }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* CREATE CUSTOMER MODAL */}
      {isCustomerModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsCustomerModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '500px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800 }}>Registrar Cliente Frecuente (CRM)</h3>
              <button onClick={() => setIsCustomerModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer}>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Nombre Completo *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ej: Javier López"
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Teléfono</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+54 9 11..."
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Nivel de Cliente</label>
                  <select
                    value={formData.level}
                    onChange={e => setFormData({ ...formData, level: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="Nuevo">Nuevo</option>
                    <option value="Frecuente">Frecuente</option>
                    <option value="VIP 🌟">VIP 🌟</option>
                  </select>
                </div>
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Plato Favorito</label>
                <input
                  type="text"
                  value={formData.favoriteDish}
                  onChange={e => setFormData({ ...formData, favoriteDish: e.target.value })}
                  placeholder="Ej: Bife de Chorizo"
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Notas Especiales (Alergias, Preferencias de Mesa)</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Ej: Prefiere mesa tranquila, le gusta la carne jugosa..."
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '14px', fontSize: '1rem' }}>
                Guardar Cliente en CRM
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
