import React, { useState, useEffect } from 'react';
import { 
  Truck, PackageCheck, Clock, MapPin, Phone, MessageSquare, 
  Plus, Check, X, Printer, User, DollarSign, RefreshCw, ShoppingBag, QrCode
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { api, socket } from '../services/api';
import { getCleanDeviceUrl } from '../utils/networkHelper';

export default function DeliveryDashboard() {
  const [deliveries, setDeliveries] = useState([]);
  const [activeFilter, setActiveFilter] = useState('all');
  const [menu, setMenu] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [isShareDriverModalOpen, setIsShareDriverModalOpen] = useState(false);
  const [driverCustomHost, setDriverCustomHost] = useState('');

  const getDriverAppUrl = () => {
    if (driverCustomHost.trim()) return driverCustomHost.trim();
    return getCleanDeviceUrl('driver=true');
  };
  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    address: '',
    notes: '',
    deliveryType: 'delivery',
    driverName: 'Cadete Propio 1',
    paymentMethod: 'efectivo',
    selectedItems: []
  });

  useEffect(() => {
    fetchDeliveries();
    fetchMenu();

    const handleDeliveryCreated = () => fetchDeliveries();
    const handleDeliveryUpdated = () => fetchDeliveries();

    socket.on('delivery_created', handleDeliveryCreated);
    socket.on('delivery_updated', handleDeliveryUpdated);

    return () => {
      socket.off('delivery_created', handleDeliveryCreated);
      socket.off('delivery_updated', handleDeliveryUpdated);
    };
  }, []);

  const fetchDeliveries = async () => {
    try {
      const res = await api.getDeliveries();
      setDeliveries(res.deliveries || []);
    } catch (err) {
      console.error('Error fetching deliveries:', err);
    }
  };

  const fetchMenu = async () => {
    try {
      const res = await api.getMenu();
      setMenu(res.menu || []);
    } catch (err) {
      console.error('Error fetching menu:', err);
    }
  };

  const handleUpdateStatus = async (id, status, driverName) => {
    try {
      await api.updateDeliveryStatus(id, status, driverName);
      fetchDeliveries();
    } catch (err) {
      alert('Error actualizando pedido de delivery: ' + err.message);
    }
  };

  const handleSaveDelivery = async (e) => {
    e.preventDefault();
    if (!formData.customerName || formData.selectedItems.length === 0) {
      alert('Ingresa el nombre del cliente y al menos 1 producto');
      return;
    }

    const totalAmount = formData.selectedItems.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);

    try {
      await api.createDeliveryOrder({
        ...formData,
        items: formData.selectedItems,
        totalAmount
      });
      setIsModalOpen(false);
      setFormData({
        customerName: '',
        phone: '',
        address: '',
        notes: '',
        deliveryType: 'delivery',
        driverName: 'Cadete Propio 1',
        paymentMethod: 'efectivo',
        selectedItems: []
      });
      fetchDeliveries();
    } catch (err) {
      alert('Error creando delivery: ' + err.message);
    }
  };

  const addItemToFormOrder = (menuItem) => {
    setFormData(prev => {
      const existingIdx = prev.selectedItems.findIndex(i => i.title === menuItem.title);
      if (existingIdx > -1) {
        const updated = [...prev.selectedItems];
        updated[existingIdx].quantity += 1;
        updated[existingIdx].subtotal = updated[existingIdx].quantity * updated[existingIdx].unitPrice;
        return { ...prev, selectedItems: updated };
      }
      return {
        ...prev,
        selectedItems: [
          ...prev.selectedItems,
          { title: menuItem.title, quantity: 1, unitPrice: menuItem.price, subtotal: menuItem.price, notes: '' }
        ]
      };
    });
  };

  const filteredDeliveries = deliveries.filter(d => 
    activeFilter === 'all' || d.status === activeFilter
  );

  const getStatusBadge = (status) => {
    switch (status) {
      case 'recibido':
        return <span className="badge badge-warning animate-glow">🔴 Recibido</span>;
      case 'preparando':
        return <span className="badge badge-info">🟠 En Cocina</span>;
      case 'en_camino':
        return <span className="badge badge-purple animate-glow">🔵 En Camino</span>;
      case 'entregado':
        return <span className="badge badge-success">🟢 Entregado</span>;
      case 'cancelado':
        return <span className="badge badge-danger">❌ Cancelado</span>;
      default:
        return <span className="badge badge-secondary">{status}</span>;
    }
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '20px auto', padding: '0 20px 60px 20px' }}>
      
      {/* Header Banner */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Truck style={{ color: 'var(--primary)' }} />
            Centro de Despacho & Delivery (Takeaway & Envíos)
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
            Control de envíos a domicilio, cadetes y retiros por mostrador · Firma: <strong>Nexora One</strong>
          </p>
        </div>

        <button onClick={() => setIsModalOpen(true)} className="btn btn-primary" style={{ padding: '10px 18px', fontSize: '0.95rem' }}>
          <Plus size={18} /> + Nuevo Pedido Delivery / Teléfono
        </button>
      </div>

      {/* Independent Driver App Link Banner */}
      <div className="glass-accent" style={{ padding: '14px 18px', borderRadius: 'var(--radius-md)', marginBottom: '20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '10px' }}>
        <div>
          <strong style={{ color: 'var(--primary)', fontSize: '0.9rem' }}>📱 App Independiente para el Cadete / Repartidor:</strong>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '2px' }}>
            Envía esta URL al smartphone del cadete para que vea <strong>únicamente</strong> sus viajes asignados, mapa GPS y QR de propina:
          </div>
          <code style={{ fontSize: '0.85rem', color: '#fff', background: 'var(--bg-main)', padding: '2px 8px', borderRadius: '4px', marginTop: '4px', display: 'inline-block' }}>
            {`${window.location.protocol}//${window.location.hostname}:${window.location.port}/?driver=true`}
          </code>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={() => setIsShareDriverModalOpen(true)}
            className="btn btn-primary"
            style={{ fontSize: '0.8rem', padding: '8px 14px', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', color: '#fff' }}
          >
            📲 Generar QR / Enlace 4G para Cadetes
          </button>
          <a
            href={`${window.location.protocol}//${window.location.hostname}:${window.location.port}/?driver=true`}
            target="_blank"
            rel="noreferrer"
            className="btn btn-secondary"
            style={{ fontSize: '0.8rem', padding: '8px 14px' }}
          >
            🔗 Abrir App Cadete
          </a>
        </div>
      </div>

      {/* Stats Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px', marginBottom: '24px' }}>
        <div className="glass" style={{ padding: '18px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
            <span>ACTIVOS EN CAMINO</span>
            <Truck style={{ color: 'var(--primary)' }} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--primary)', marginTop: '6px' }}>
            {deliveries.filter(d => d.status === 'en_camino').length} envíos
          </div>
        </div>

        <div className="glass" style={{ padding: '18px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
            <span>EN PREPARACIÓN</span>
            <Clock style={{ color: 'var(--accent-blue)' }} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-blue)', marginTop: '6px' }}>
            {deliveries.filter(d => d.status === 'preparando' || d.status === 'recibido').length} comandas
          </div>
        </div>

        <div className="glass" style={{ padding: '18px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
            <span>ENTREGADOS HOY</span>
            <PackageCheck style={{ color: 'var(--accent-green)' }} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-green)', marginTop: '6px' }}>
            {deliveries.filter(d => d.status === 'entregado').length} entregas
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '12px', marginBottom: '20px' }}>
        {[
          { id: 'all', label: '🚚 Todos los Envíos' },
          { id: 'recibido', label: '🔴 Nuevos / Por Aceptar' },
          { id: 'preparando', label: '🟠 En Cocina' },
          { id: 'en_camino', label: '🔵 En Camino' },
          { id: 'entregado', label: '🟢 Entregados' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id)}
            className={`btn ${activeFilter === tab.id ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem', whiteSpace: 'nowrap' }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Delivery Cards Grid */}
      {filteredDeliveries.length === 0 ? (
        <div className="glass" style={{ textAlign: 'center', padding: '60px 20px', borderRadius: 'var(--radius-lg)' }}>
          <Truck size={48} style={{ color: 'var(--text-muted)', marginBottom: '16px' }} />
          <h3 style={{ fontSize: '1.2rem', color: 'var(--text-muted)' }}>Sin envíos en este estado</h3>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '20px' }}>
          {filteredDeliveries.map(del => (
            <div key={del.id} className="glass animate-fade-in" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', border: '1px solid var(--border-accent)' }}>
              <div>
                
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                  <div>
                    <span style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--primary)' }}>{del.orderNumber}</span>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: 800 }}>{del.customerName}</h3>
                  </div>
                  {getStatusBadge(del.status)}
                </div>

                {/* Address & Contact */}
                <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-md)', marginBottom: '14px', fontSize: '0.85rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '6px', fontWeight: 700, color: '#fff', marginBottom: '6px' }}>
                    <MapPin size={16} style={{ color: 'var(--primary)', flexShrink: 0, marginTop: '2px' }} />
                    <span>{del.address}</span>
                  </div>

                  {del.phone && (
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '6px' }}>
                      <span style={{ color: 'var(--text-muted)' }}>📞 {del.phone}</span>
                      <a
                        href={`https://wa.me/${del.phone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        style={{ background: '#25D366', color: '#fff', padding: '4px 8px', borderRadius: '4px', textDecoration: 'none', fontWeight: 700, fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '4px' }}
                      >
                        <MessageSquare size={12} /> WhatsApp
                      </a>
                    </div>
                  )}

                  {del.notes && (
                    <div style={{ fontSize: '0.75rem', color: 'var(--primary)', fontStyle: 'italic', marginTop: '6px', borderTop: '1px dashed var(--border-color)', paddingTop: '6px' }}>
                      📝 Nota: {del.notes}
                    </div>
                  )}
                </div>

                {/* Items Detail */}
                <div style={{ marginBottom: '14px' }}>
                  <div style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '4px' }}>Detalle del Pedido:</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    {del.items.map((item, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                        <span>[{item.quantity}x] {item.title} {item.notes && <small style={{ color: 'var(--primary)' }}>({item.notes})</small>}</span>
                        <strong>${(item.subtotal || item.unitPrice * item.quantity).toLocaleString('es-AR')}</strong>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: 800, borderTop: '1px solid var(--border-color)', paddingTop: '8px', marginTop: '8px' }}>
                    <span>Total Pedido:</span>
                    <span style={{ color: 'var(--primary)' }}>${del.totalAmount.toLocaleString('es-AR')}</span>
                  </div>
                </div>

                {/* Driver / Cadete */}
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span>Repartidor asignado:</span>
                  <strong style={{ color: '#fff' }}>{del.driverName || 'Sin asignar'}</strong>
                </div>

              </div>

              {/* Status Action Buttons */}
              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {del.status === 'recibido' && (
                  <button
                    onClick={() => handleUpdateStatus(del.id, 'preparando', del.driverName)}
                    className="btn btn-primary"
                    style={{ width: '100%', padding: '8px', fontSize: '0.85rem' }}
                  >
                    👨‍🍳 Pasar a Cocina (Preparar)
                  </button>
                )}

                {del.status === 'preparando' && (
                  <button
                    onClick={() => {
                      const driverName = prompt('Escribe el Nombre del Cadete / Repartidor que lleva el pedido:', del.driverName || 'Cadete Propio 1');
                      if (driverName) handleUpdateStatus(del.id, 'en_camino', driverName);
                    }}
                    className="btn btn-primary"
                    style={{ width: '100%', padding: '8px', fontSize: '0.85rem' }}
                  >
                    🛵 Asignar Cadete & En Camino
                  </button>
                )}

                {del.status === 'en_camino' && (
                  <button
                    onClick={() => handleUpdateStatus(del.id, 'entregado', del.driverName)}
                    className="btn btn-success"
                    style={{ width: '100%', padding: '8px', fontSize: '0.85rem' }}
                  >
                    ✅ Marcar Entregado & Cobrado
                  </button>
                )}

                <button
                  onClick={() => window.print()}
                  className="btn btn-secondary"
                  style={{ width: '100%', padding: '6px', fontSize: '0.75rem' }}
                >
                  <Printer size={12} /> Imprimir Comanda de Envío
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* CREATE MANUAL DELIVERY ORDER MODAL */}
      {isModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '650px', maxHeight: '85vh', overflowY: 'auto' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Truck style={{ color: 'var(--primary)' }} />
                Cargar Pedido de Delivery / Teléfono
              </h3>
              <button onClick={() => setIsModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSaveDelivery}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Nombre Cliente *</label>
                  <input
                    type="text"
                    required
                    value={formData.customerName}
                    onChange={e => setFormData({ ...formData, customerName: e.target.value })}
                    placeholder="Ej: Javier López"
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Teléfono / WhatsApp</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+54 9 11..."
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Dirección de Entrega Completa *</label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Ej: Av. Cabildo 2450 4B"
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              {/* Menu selector */}
              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Seleccionar Productos:</label>
                <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', paddingBottom: '8px', marginBottom: '8px' }}>
                  {menu.map(m => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => addItemToFormOrder(m)}
                      style={{ padding: '6px 12px', borderRadius: 'var(--radius-sm)', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', fontSize: '0.8rem', whiteSpace: 'nowrap', cursor: 'pointer' }}
                    >
                      + {m.title} (${m.price})
                    </button>
                  ))}
                </div>

                {/* Added items list */}
                {formData.selectedItems.length > 0 && (
                  <div style={{ background: 'var(--bg-main)', padding: '10px', borderRadius: 'var(--radius-sm)', fontSize: '0.85rem' }}>
                    {formData.selectedItems.map((item, idx) => (
                      <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderBottom: '1px dashed var(--border-color)' }}>
                        <span>{item.quantity}x {item.title}</span>
                        <strong>${item.subtotal.toLocaleString('es-AR')}</strong>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '14px', fontSize: '1rem' }}>
                🚀 Confirmar y Enviar a Cocina
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SHARE 4G DRIVER LINK & QR MODAL */}
      {isShareDriverModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsShareDriverModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '420px', textAlign: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <QrCode style={{ color: 'var(--primary)' }} />
                Enlace & QR 4G/5G para Cadetes
              </h3>
              <button onClick={() => setIsShareDriverModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '14px' }}>
              Los repartidores pueden escanear este QR con la cámara de su celular para abrir la <strong>App Cadete Independiente</strong> en la calle (Wi-Fi o Datos 4G/5G):
            </p>

            {/* Vector QR Code Display */}
            <div style={{ background: '#fff', padding: '16px', borderRadius: 'var(--radius-md)', display: 'inline-block', marginBottom: '16px' }}>
              <QRCodeSVG
                value={getDriverAppUrl()}
                size={200}
                includeMargin={true}
              />
              <div style={{ color: '#000', fontSize: '0.8rem', fontWeight: 800, marginTop: '6px' }}>
                Escanea para abrir App Cadete (4G/5G)
              </div>
            </div>

            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                URL / Dominio Público o Túnel 4G (Opcional si usas IP pública / Localtunnel):
              </label>
              <input
                type="text"
                value={driverCustomHost}
                onChange={e => setDriverCustomHost(e.target.value)}
                placeholder="Ej: https://myjnecoravisual-delivery.loca.lt/?driver=true"
                style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem', textAlign: 'center' }}
              />
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              <a
                href={`https://wa.me/?text=${encodeURIComponent(`Hola! Aquí tienes la App de Cadetes Nexora One para tomar envíos en vivo: ${getDriverAppUrl()}`)}`}
                target="_blank"
                rel="noreferrer"
                style={{
                  flex: 1,
                  background: '#25D366',
                  color: '#fff',
                  padding: '12px',
                  borderRadius: 'var(--radius-sm)',
                  textDecoration: 'none',
                  fontWeight: 800,
                  fontSize: '0.85rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px'
                }}
              >
                <MessageSquare size={16} /> Enviar por WhatsApp
              </a>

              <button
                onClick={() => {
                  navigator.clipboard.writeText(getDriverAppUrl());
                  alert('URL copiada al portapapeles!');
                }}
                className="btn btn-secondary"
                style={{ padding: '12px', fontSize: '0.85rem' }}
              >
                📋 Copiar Link
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
