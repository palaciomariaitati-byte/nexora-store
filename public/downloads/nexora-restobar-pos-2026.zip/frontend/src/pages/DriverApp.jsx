import React, { useState, useEffect } from 'react';
import { 
  Truck, Navigation, MapPin, Phone, MessageSquare, 
  CheckCircle, QrCode, DollarSign, Package, Clock, ShieldCheck, Zap, X, ChevronRight
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { api, socket } from '../services/api';

export default function DriverApp() {
  const [driverStats, setDriverStats] = useState(null);
  const [deliveries, setDeliveries] = useState([]);
  const [isOnline, setIsOnline] = useState(true);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('feed'); // 'feed' | 'my_trips' | 'stats'

  const [isNetworkOffline, setIsNetworkOffline] = useState(!navigator.onLine);

  useEffect(() => {
    fetchDriverData();

    const handleOnline = () => { setIsNetworkOffline(false); fetchDriverData(); };
    const handleOffline = () => setIsNetworkOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const handleDeliveryCreated = () => fetchDriverData();
    const handleDeliveryUpdated = () => fetchDriverData();

    socket.on('delivery_created', handleDeliveryCreated);
    socket.on('delivery_updated', handleDeliveryUpdated);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      socket.off('delivery_created', handleDeliveryCreated);
      socket.off('delivery_updated', handleDeliveryUpdated);
    };
  }, []);

  const fetchDriverData = async () => {
    try {
      const statsRes = await api.getDriverStats();
      setDriverStats(statsRes);
      localStorage.setItem('cached_driver_stats', JSON.stringify(statsRes));

      const delRes = await api.getDeliveries();
      setDeliveries(delRes.deliveries || []);
      localStorage.setItem('cached_driver_deliveries', JSON.stringify(delRes.deliveries || []));
    } catch (err) {
      console.warn('Network offline, loading cached driver data from localStorage');
      const cachedStats = localStorage.getItem('cached_driver_stats');
      const cachedDel = localStorage.getItem('cached_driver_deliveries');
      if (cachedStats) setDriverStats(JSON.parse(cachedStats));
      if (cachedDel) setDeliveries(JSON.parse(cachedDel));
    }
  };

  const handleRejectOrder = async (orderId) => {
    if (!driverStats?.driver?.name) return;
    try {
      await api.rejectDeliveryOrder(orderId, driverStats.driver.name);
      fetchDriverData();
    } catch (err) {
      alert('Error rechazando pedido: ' + err.message);
    }
  };

  const handleClaimOrder = async (orderId) => {
    if (!driverStats?.driver?.name) return;
    try {
      await api.claimDeliveryOrder(orderId, driverStats.driver.name);
      fetchDriverData();
    } catch (err) {
      alert('Error tomando pedido: ' + err.message);
    }
  };

  const handleCompleteOrder = async (orderId) => {
    try {
      await api.updateDeliveryStatus(orderId, 'entregado');
      fetchDriverData();
    } catch (err) {
      alert('Error completando entrega: ' + err.message);
    }
  };

  // Deliveries waiting for a driver (Radar)
  const availableOrders = deliveries.filter(d => 
    (d.status === 'recibido' || d.status === 'preparando') && d.deliveryType === 'delivery'
  );

  // Deliveries claimed by this driver currently active
  const myActiveOrders = deliveries.filter(d => 
    d.status === 'en_camino' && (driverStats?.driver?.name && d.driverName.includes(driverStats.driver.name.split(' ')[0]))
  );

  // Deliveries completed today
  const myCompletedOrders = deliveries.filter(d => 
    d.status === 'entregado'
  );

  return (
    <div style={{ maxWidth: '480px', margin: '0 auto', minHeight: '100vh', background: '#0b0f19', color: '#fff', paddingBottom: '90px' }}>
      
      {/* Mobile Top Header */}
      <div style={{ background: 'var(--bg-card)', padding: '16px 20px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'linear-gradient(135deg, #10b981, #059669)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 }}>
            🛵
          </div>
          <div>
            <select
              value={driverStats?.driver?.name || 'Cadete Propio 1'}
              onChange={(e) => {
                const newName = e.target.value;
                setDriverStats(prev => ({
                  ...prev,
                  driver: { ...prev?.driver, name: newName }
                }));
              }}
              style={{ background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '4px 8px', borderRadius: '6px', fontWeight: 800, fontSize: '0.85rem' }}
            >
              <option value="Cadete Propio 1">🛵 Cadete Propio 1</option>
              <option value="Cadete Propio 2">🛵 Cadete Propio 2</option>
              <option value="Gonzalo (Repartidor)">🛵 Gonzalo (Repartidor)</option>
              <option value="Lucas (Moto Fast)">🛵 Lucas (Moto Fast)</option>
            </select>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>{driverStats?.driver?.vehicle || 'Moto Delivery (Repartidor Activo)'}</div>
          </div>
        </div>

        {/* Online / Offline Status Toggle */}
        <button
          onClick={() => setIsOnline(!isOnline)}
          style={{
            padding: '6px 12px',
            borderRadius: '99px',
            background: isOnline ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)',
            color: isOnline ? '#10b981' : '#ef4444',
            border: `1px solid ${isOnline ? '#10b981' : '#ef4444'}`,
            fontSize: '0.8rem',
            fontWeight: 800,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: isOnline ? '#10b981' : '#ef4444', display: 'inline-block' }} />
          {isOnline ? 'ONLINE' : 'OFFLINE'}
        </button>
      </div>

      {/* OFFLINE RESILIENCY BANNER */}
      {isNetworkOffline && (
        <div style={{ background: '#f59e0b', color: '#000', padding: '8px 16px', fontSize: '0.8rem', fontWeight: 800, textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
          <span>📡 MODO OFFLINE EN CALLE: Usando caché local. Tus entregas se sincronizarán al recuperar señal.</span>
        </div>
      )}

      {/* Driver Performance Summary Cards (Solo Cadete) */}
      <div style={{ padding: '16px 20px' }}>
        <div className="glass" style={{ padding: '18px', borderRadius: 'var(--radius-lg)', background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(16, 185, 129, 0.1))', border: '1px solid var(--primary-light)', marginBottom: '16px' }}>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 700 }}>RECAUDACIÓN DEL DÍA</span>
            <button
              onClick={() => setIsQrModalOpen(true)}
              style={{
                background: 'var(--primary)',
                color: '#000',
                border: 'none',
                padding: '6px 12px',
                borderRadius: 'var(--radius-sm)',
                fontSize: '0.75rem',
                fontWeight: 800,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
            >
              <QrCode size={14} /> Mi QR Propina
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', textAlign: 'center' }}>
            <div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--accent-green)' }}>
                ${(driverStats?.todayEarnings || 0).toLocaleString('es-AR')}
              </div>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Ganancias</span>
            </div>

            <div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)' }}>
                ${(driverStats?.todayTips || 0).toLocaleString('es-AR')}
              </div>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Propinas</span>
            </div>

            <div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#fff' }}>
                {driverStats?.todayDeliveriesCount || 0}
              </div>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Envíos</span>
            </div>
          </div>

        </div>

        {/* Tab Navigation */}
        <div style={{ display: 'flex', gap: '6px', background: 'var(--bg-card)', padding: '4px', borderRadius: 'var(--radius-md)', marginBottom: '16px' }}>
          <button
            onClick={() => setActiveTab('feed')}
            style={{
              flex: 1,
              padding: '8px',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              background: activeTab === 'feed' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'feed' ? '#000' : '#fff',
              fontWeight: 800,
              fontSize: '0.8rem',
              cursor: 'pointer'
            }}
          >
            Radar ({availableOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('my_trips')}
            style={{
              flex: 1,
              padding: '8px',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              background: activeTab === 'my_trips' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'my_trips' ? '#000' : '#fff',
              fontWeight: 800,
              fontSize: '0.8rem',
              cursor: 'pointer'
            }}
          >
            En Camino ({myActiveOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            style={{
              flex: 1,
              padding: '8px',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              background: activeTab === 'stats' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'stats' ? '#000' : '#fff',
              fontWeight: 800,
              fontSize: '0.8rem',
              cursor: 'pointer'
            }}
          >
            Historial ({myCompletedOrders.length})
          </button>
        </div>

        {/* TAB 1: RADAR / INCOMING ORDERS FEED */}
        {activeTab === 'feed' && (
          <div>
            {!isOnline ? (
              <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-muted)' }}>
                Estás en modo OFFLINE. Conéctate para recibir solicitudes de delivery.
              </div>
            ) : availableOrders.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-muted)' }}>
                <Zap size={36} style={{ marginBottom: '10px', color: 'var(--primary)' }} />
                <div style={{ fontWeight: 700 }}>Buscando pedidos cercanos...</div>
                <div style={{ fontSize: '0.75rem', marginTop: '4px' }}>Los nuevos pedidos del restaurante aparecerán aquí al instante.</div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                {availableOrders.map(ord => (
                  <div key={ord.id} className="glass animate-fade-in" style={{ padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--primary-light)' }}>
                    
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                      <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--primary)' }}>{ord.orderNumber}</span>
                      <span className="badge badge-warning">⚡ Listo para llevar</span>
                    </div>

                    <h4 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '6px' }}>{ord.customerName}</h4>
                    
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: '#fff', marginBottom: '10px' }}>
                      <MapPin size={16} style={{ color: 'var(--primary)', flexShrink: 0 }} />
                      <strong>{ord.address}</strong>
                    </div>

                    <div style={{ background: 'var(--bg-main)', padding: '8px 10px', borderRadius: 'var(--radius-sm)', marginBottom: '12px', fontSize: '0.8rem', display: 'flex', justifyContent: 'space-between' }}>
                      <span>Monto a Cobrar / Pagar:</span>
                      <strong style={{ color: 'var(--accent-green)' }}>${ord.totalAmount.toLocaleString('es-AR')} ({ord.paymentMethod})</strong>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                      <button
                        onClick={() => handleClaimOrder(ord.id)}
                        className="btn btn-success"
                        style={{ padding: '10px', fontSize: '0.85rem', fontWeight: 800 }}
                      >
                        🟢 ACEPTAR
                      </button>

                      <button
                        onClick={() => handleRejectOrder(ord.id)}
                        className="btn btn-danger"
                        style={{ padding: '10px', fontSize: '0.85rem', fontWeight: 800 }}
                      >
                        🔴 RECHAZAR
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: ACTIVE TRIPS (EN CAMINO WITH GPS NAVIGATION) */}
        {activeTab === 'my_trips' && (
          <div>
            {myActiveOrders.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-muted)' }}>
                No tienes viajes activos en curso. Ve a la pestaña Radar para aceptar uno.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {myActiveOrders.map(trip => (
                  <div key={trip.id} className="glass animate-fade-in" style={{ padding: '18px', borderRadius: 'var(--radius-md)', border: '2px solid var(--primary)' }}>
                    
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                      <span style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--primary)' }}>{trip.orderNumber}</span>
                      <span className="badge badge-purple animate-glow">🛵 EN CAMINO</span>
                    </div>

                    <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '6px' }}>{trip.customerName}</h3>
                    
                    <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-md)', marginBottom: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '0.9rem', fontWeight: 700, marginBottom: '8px' }}>
                        <MapPin size={18} style={{ color: 'var(--primary)', flexShrink: 0, marginTop: '2px' }} />
                        <span>{trip.address}</span>
                      </div>

                      {/* GPS Navigation Buttons */}
                      <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                        <a
                          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(trip.address)}`}
                          target="_blank"
                          rel="noreferrer"
                          style={{
                            flex: 1,
                            background: '#4285F4',
                            color: '#fff',
                            padding: '8px',
                            borderRadius: 'var(--radius-sm)',
                            textDecoration: 'none',
                            fontWeight: 800,
                            fontSize: '0.8rem',
                            textAlign: 'center',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '4px'
                          }}
                        >
                          <Navigation size={14} /> Google Maps GPS
                        </a>

                        {trip.phone && (
                          <a
                            href={`https://wa.me/${trip.phone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noreferrer"
                            style={{
                              background: '#25D366',
                              color: '#fff',
                              padding: '8px 12px',
                              borderRadius: 'var(--radius-sm)',
                              textDecoration: 'none',
                              fontWeight: 800,
                              fontSize: '0.8rem',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '4px'
                            }}
                          >
                            <MessageSquare size={14} /> WhatsApp
                          </a>
                        )}
                      </div>
                    </div>

                    {/* Order summary */}
                    <div style={{ fontSize: '0.85rem', marginBottom: '12px' }}>
                      <div style={{ color: 'var(--text-muted)', marginBottom: '4px' }}>Productos a entregar:</div>
                      {trip.items.map((it, i) => (
                        <div key={i} style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>{it.quantity}x {it.title}</span>
                          <strong>${(it.subtotal || it.unitPrice * it.quantity).toLocaleString('es-AR')}</strong>
                        </div>
                      ))}
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: 800, borderTop: '1px solid var(--border-color)', paddingTop: '6px', marginTop: '6px' }}>
                        <span>Cobrar al Cliente:</span>
                        <span style={{ color: 'var(--accent-green)' }}>${trip.totalAmount.toLocaleString('es-AR')}</span>
                      </div>
                    </div>

                    {/* Completion Action */}
                    <button
                      onClick={() => handleCompleteOrder(trip.id)}
                      className="btn btn-success"
                      style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: 800 }}
                    >
                      ✅ LLEGUÉ Y ENTREGUÉ EL PEDIDO
                    </button>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: STATS & COMPLETED HISTORY */}
        {activeTab === 'stats' && (
          <div>
            <h4 style={{ fontSize: '1rem', fontWeight: 800, marginBottom: '12px' }}>Entregas Realizadas Hoy ({myCompletedOrders.length})</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {myCompletedOrders.map(c => (
                <div key={c.id} className="glass" style={{ padding: '12px 16px', borderRadius: 'var(--radius-md)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: '0.9rem' }}>{c.customerName}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{c.address}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ color: 'var(--accent-green)', fontWeight: 800 }}>+ $1.800 tarifa</div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Total: ${c.totalAmount.toLocaleString('es-AR')}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* DRIVER TIP QR MODAL */}
      {isQrModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsQrModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '380px', textAlign: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Mi QR de Propina Digital</h3>
              <button onClick={() => setIsQrModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '16px' }}>
              Muestra este código QR al cliente para recibir tu propina directamente en tu billetera virtual Mercado Pago:
            </p>

            <div style={{ background: '#fff', padding: '16px', borderRadius: 'var(--radius-md)', display: 'inline-block', marginBottom: '16px' }}>
              <QRCodeSVG
                value={`https://mpago.la/pos/${driverStats?.driver?.tipAlias || 'carlos.cadete.mp'}`}
                size={200}
                includeMargin={true}
              />
            </div>

            <div style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--primary)', marginBottom: '16px' }}>
              Alias CBU / MP: <u>{driverStats?.driver?.tipAlias}</u>
            </div>

            <button onClick={() => setIsQrModalOpen(false)} className="btn btn-primary" style={{ width: '100%', padding: '12px' }}>
              Entendido
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
