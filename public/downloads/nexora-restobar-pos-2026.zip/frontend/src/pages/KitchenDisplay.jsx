import React, { useState, useEffect } from 'react';
import { ChefHat, Wine, Clock, CheckCircle, AlertTriangle, Sparkles, User, Utensils } from 'lucide-react';
import { api, socket } from '../services/api';

export default function KitchenDisplay() {
  const [orders, setOrders] = useState([]);
  const [activeFilter, setActiveFilter] = useState('all'); // 'all' | 'cocina' | 'barra'
  const [alertaVisual, setAlertaVisual] = useState(null);
  const [alertaTimer, setAlertaTimer] = useState(null);

  useEffect(() => {
    fetchOrders();

    const handleNewOrder = (data) => {
      fetchOrders();
      
      const orderPayload = data?.order || data;
      if (orderPayload) {
        setAlertaVisual(orderPayload);
        if (alertaTimer) clearTimeout(alertaTimer);
        const timer = setTimeout(() => {
          setAlertaVisual(null);
        }, 6000);
        setAlertaTimer(timer);
      }
    };

    const handleUpdate = () => {
      fetchOrders();
    };

    socket.on('order_created', handleNewOrder);
    socket.on('new_order', handleNewOrder);
    socket.on('order_status_changed', handleUpdate);
    socket.on('order_cancelled', handleUpdate);
    socket.on('table_updated', handleUpdate);

    return () => {
      socket.off('order_created', handleNewOrder);
      socket.off('new_order', handleNewOrder);
      socket.off('order_status_changed', handleUpdate);
      socket.off('order_cancelled', handleUpdate);
      socket.off('table_updated', handleUpdate);
      if (alertaTimer) clearTimeout(alertaTimer);
    };
  }, []);

  const fetchOrders = async () => {
    try {
      let activeOrders = [];
      try {
        const rawOrders = await api.getOrders();
        activeOrders = (rawOrders || []).filter(o => 
          o.status !== 'delivered' && 
          o.status !== 'paid' && 
          o.status !== 'cancelled' && 
          o.status !== 'completed' && 
          o.status !== 'ready'
        );
      } catch (e) {
        const tables = await api.getTables();
        activeOrders = (tables || []).flatMap(table => 
          (table.orders || []).filter(o => 
            o.status !== 'delivered' && 
            o.status !== 'paid' && 
            o.status !== 'cancelled' && 
            o.status !== 'completed' && 
            o.status !== 'ready'
          )
        );
      }
      setOrders(activeOrders);
    } catch (err) {
      console.error('Error al obtener comandas de cocina:', err);
    }
  };

  const handleItemStatusToggle = async (orderId, itemId, currentStatus) => {
    const nextStatus = currentStatus === 'pending' ? 'preparing' : currentStatus === 'preparing' ? 'ready' : 'pending';
    try {
      await api.updateOrderItemStatus(orderId, itemId, nextStatus);
      fetchOrders();
    } catch (err) {
      console.error('Error al actualizar estado de plato:', err);
    }
  };

  const handleCompleteTable = async (tableGroup) => {
    try {
      const promises = tableGroup.orders.map(ord => api.updateOrderStatus(ord.id, 'ready'));
      await Promise.all(promises);
      fetchOrders();
    } catch (err) {
      console.error('Error al despachar comanda de mesa:', err);
    }
  };

  // 🧠 Algoritmo de Unificación Atómica por Mesa
  const groupOrdersByTable = (ordersList) => {
    const tableMap = {};

    ordersList.forEach(ord => {
      const key = String(ord.tableId || ord.mesaId || '1');
      if (!tableMap[key]) {
        tableMap[key] = {
          tableId: ord.tableId || ord.mesaId || '1',
          tableName: ord.tableName || `Mesa ${ord.tableId || '1'}`,
          orders: [],
          allItems: [],
          earliestCreatedAt: ord.createdAt
        };
      }

      tableMap[key].orders.push(ord);

      if (new Date(ord.createdAt) < new Date(tableMap[key].earliestCreatedAt)) {
        tableMap[key].earliestCreatedAt = ord.createdAt;
      }

      (ord.items || []).forEach(item => {
        tableMap[key].allItems.push({
          ...item,
          orderId: ord.id,
          dinerName: item.dinerName || ord.dinerName || 'Comensal'
        });
      });
    });

    return Object.values(tableMap);
  };

  const groupedTables = groupOrdersByTable(orders).map(table => {
    const itemsFiltered = table.allItems.filter(item => {
      if (activeFilter === 'cocina') {
        return (item.category || '').toLowerCase() !== 'bebidas';
      }
      if (activeFilter === 'barra') {
        return (item.category || '').toLowerCase() === 'bebidas';
      }
      return true;
    });

    return {
      ...table,
      displayItems: itemsFiltered
    };
  }).filter(table => table.displayItems.length > 0);

  return (
    <div style={{ maxWidth: '1400px', margin: '16px auto', padding: '0 16px 60px 16px', position: 'relative' }}>
      
      {/* 🔔 CARTEL DE IMPACTO VISUAL MASIVO ENTRANTE (Desaparece a los 6s) */}
      {alertaVisual && (
        <div
          onClick={() => setAlertaVisual(null)}
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 9999,
            background: 'rgba(220, 38, 38, 0.96)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#ffffff',
            textAlign: 'center',
            padding: '24px 16px',
            boxShadow: '0 0 100px rgba(239, 68, 68, 0.9)',
            backdropFilter: 'blur(10px)',
            cursor: 'pointer'
          }}
        >
          <div style={{ fontSize: '2.5rem', fontWeight: 900, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: '12px' }}>
            🔔 ¡NUEVA COMANDA ENTRANTE!
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 900, background: '#000', padding: '10px 24px', borderRadius: '16px', border: '2px solid #fff' }}>
            MESA #{alertaVisual.tableId || alertaVisual.mesaId || '1'} — {alertaVisual.dinerName || 'Cliente'}
          </div>

          <div style={{ marginTop: '20px', background: 'rgba(0,0,0,0.85)', padding: '16px 24px', borderRadius: '16px', maxWidth: '700px', width: '100%', border: '1px solid rgba(255,255,255,0.3)' }}>
            <div style={{ fontSize: '1.1rem', fontWeight: 800, marginBottom: '10px', color: '#f59e0b' }}>
              Platos a Elaborar Inmediatamente:
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', textAlign: 'left' }}>
              {Array.isArray(alertaVisual.items) && alertaVisual.items.map((item, idx) => (
                <div key={idx} style={{ fontSize: '1.1rem', fontWeight: 800, color: '#fff', borderBottom: '1px solid rgba(255,255,255,0.1)', paddingBottom: '6px' }}>
                  • [{item.quantity || 1}x] {item.title || item.nombre}
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setAlertaVisual(null)}
            style={{
              marginTop: '24px',
              padding: '14px 32px',
              fontSize: '1.1rem',
              fontWeight: 900,
              background: '#ffffff',
              color: '#000000',
              border: 'none',
              borderRadius: '99px',
              cursor: 'pointer',
              boxShadow: '0 10px 30px rgba(0,0,0,0.5)'
            }}
          >
            🍳 ENTENDIDO — DESPACHAR COMANDA (Cierra en 6s)
          </button>
        </div>
      )}

      {/* Encabezado del Sistema de Pantalla de Cocina (KDS) */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <ChefHat style={{ color: 'var(--primary)' }} />
            Pantalla de Despacho e Interfaz de Cocina (KDS)
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.82rem', marginTop: '4px' }}>
            Agrupación Atómica por Mesa · <strong>Nexora One, SUITE COMERCIAL O DE RESTOBAR</strong>
          </p>
        </div>

        {/* Filter Buttons */}
        <div style={{ display: 'flex', gap: '6px', background: 'var(--bg-card)', padding: '4px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', flexWrap: 'wrap' }}>
          <button
            onClick={() => setActiveFilter('all')}
            className={`btn ${activeFilter === 'all' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '6px 14px', fontSize: '0.8rem' }}
          >
            🔥 Todas ({groupedTables.length} Mesas)
          </button>
          <button
            onClick={() => setActiveFilter('cocina')}
            className={`btn ${activeFilter === 'cocina' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '6px 14px', fontSize: '0.8rem' }}
          >
            🍳 Solo Cocina
          </button>
          <button
            onClick={() => setActiveFilter('barra')}
            className={`btn ${activeFilter === 'barra' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '6px 14px', fontSize: '0.8rem' }}
          >
            🍹 Solo Barra
          </button>
        </div>
      </div>

      {/* Ticket Cards Responsive Grid */}
      {groupedTables.length === 0 ? (
        <div className="glass" style={{ textAlign: 'center', padding: '60px 20px', borderRadius: 'var(--radius-lg)' }}>
          <ChefHat size={48} style={{ color: 'var(--text-muted)', marginBottom: '16px' }} />
          <h3 style={{ fontSize: '1.2rem', color: 'var(--text-muted)' }}>¡Sin comandas pendientes!</h3>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '8px' }}>
            Todo al día en cocina y barra. Los nuevos pedidos se agruparán automáticamente por mesa.
          </p>
        </div>
      ) : (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: '16px'
        }}>
          {groupedTables.map((tableGroup, idx) => {
            const readyItemsCount = tableGroup.displayItems.filter(i => i.status === 'ready').length;
            const totalItemsCount = tableGroup.displayItems.length;
            const isAllReady = readyItemsCount === totalItemsCount && totalItemsCount > 0;

            return (
              <div
                key={tableGroup.tableId + '_' + idx}
                className="glass animate-fade-in"
                style={{
                  borderRadius: 'var(--radius-lg)',
                  overflow: 'hidden',
                  border: isAllReady ? '2px solid #10b981' : '1px solid var(--border-accent)',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  background: 'var(--bg-card)'
                }}
              >
                {/* Ticket Top Header - UNIFIED TABLE HEADER */}
                <div style={{ background: isAllReady ? 'rgba(16,185,129,0.2)' : 'var(--primary-light)', padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-accent)' }}>
                  <div>
                    <h3 style={{ fontSize: '1.3rem', fontWeight: 900, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      Mesa #{tableGroup.tableId}
                    </h3>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      {tableGroup.orders.length} {tableGroup.orders.length === 1 ? 'Pedido' : 'Pedidos Unificados'}
                    </span>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>
                      {new Date(tableGroup.earliestCreatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                    <span className={`badge ${isAllReady ? 'badge-success' : 'badge-warning'}`} style={{ fontSize: '0.65rem', marginTop: '2px' }}>
                      {isAllReady ? '✓ PLATOS LISTOS' : `PREPARANDO (${readyItemsCount}/${totalItemsCount})`}
                    </span>
                  </div>
                </div>

                {/* Items List inside Unified Table Card */}
                <div style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {tableGroup.displayItems.map((item, i) => {
                    let quitados = Array.isArray(item.ingredientesQuitados) ? [...item.ingredientesQuitados] : [];
                    let extras = Array.isArray(item.ingredientesExtras) ? [...item.ingredientesExtras] : [];
                    let rawNotes = item.notes || '';
                    let userClarificationNote = '';

                    if (rawNotes.includes('SIN:') || rawNotes.includes('EXTRA:')) {
                      const parts = rawNotes.split('|').map(p => p.trim());
                      const otherNotes = [];
                      parts.forEach(part => {
                        if (part.startsWith('SIN:')) {
                          const parsed = part.replace('SIN:', '').split(',').map(s => s.trim()).filter(Boolean);
                          parsed.forEach(pItem => { if (!quitados.includes(pItem)) quitados.push(pItem); });
                        } else if (part.startsWith('EXTRA:')) {
                          const parsed = part.replace('EXTRA:', '').split(',').map(s => s.trim()).filter(Boolean);
                          parsed.forEach(pItem => { if (!extras.includes(pItem)) extras.push(pItem); });
                        } else {
                          otherNotes.push(part);
                        }
                      });
                      userClarificationNote = otherNotes.join(' | ');
                    } else {
                      userClarificationNote = rawNotes;
                    }

                    return (
                      <div
                        key={item.id + '_' + i}
                        onClick={() => handleItemStatusToggle(item.orderId, item.id, item.status)}
                        style={{
                          padding: '10px 12px',
                          borderRadius: 'var(--radius-sm)',
                          background: item.status === 'ready' ? 'rgba(16,185,129,0.15)' : 'var(--bg-main)',
                          border: item.status === 'ready' ? '2px solid #10b981' : '1px solid var(--border-color)',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'flex-start',
                          justifyContent: 'space-between',
                          gap: '8px'
                        }}
                      >
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '0.72rem', color: '#06b6d4', fontWeight: 800, marginBottom: '2px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <User size={12} /> {item.dinerName}
                          </div>

                          <div style={{ fontWeight: 800, fontSize: '0.95rem', textDecoration: item.status === 'ready' ? 'line-through' : 'none', color: '#fff' }}>
                            [{item.quantity}x] {item.title || item.nombre}
                          </div>

                          {/* Display removed ingredients badge */}
                          {quitados.length > 0 && (
                            <div style={{ marginTop: '4px', display: 'flex', flexDirection: 'column', gap: '2px' }}>
                              {quitados.map((ing, qIdx) => (
                                <span key={qIdx} style={{ fontSize: '0.75rem', color: '#ef4444', fontWeight: 900, background: 'rgba(239,68,68,0.2)', border: '1px solid rgba(239,68,68,0.4)', padding: '2px 6px', borderRadius: '4px', display: 'inline-block' }}>
                                  ❌ SIN {String(ing).toUpperCase()}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Display extra ingredients badge */}
                          {extras.length > 0 && (
                            <div style={{ marginTop: '4px', display: 'flex', flexDirection: 'column', gap: '2px' }}>
                              {extras.map((ing, eIdx) => (
                                <span key={eIdx} style={{ fontSize: '0.75rem', color: '#10b981', fontWeight: 900, background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.4)', padding: '2px 6px', borderRadius: '4px', display: 'inline-block' }}>
                                  ➕ EXTRA {String(ing).toUpperCase()}
                                </span>
                              ))}
                            </div>
                          )}

                          {userClarificationNote && (
                            <div style={{ fontSize: '0.78rem', color: '#f59e0b', fontWeight: 700, marginTop: '4px', background: 'rgba(245,158,11,0.1)', padding: '3px 6px', borderRadius: '4px', border: '1px dashed #f59e0b' }}>
                              💬 Nota: {userClarificationNote}
                            </div>
                          )}
                        </div>

                        <span className={`badge ${item.status === 'ready' ? 'badge-success' : 'badge-warning'}`} style={{ fontSize: '0.7rem', padding: '4px 8px', flexShrink: 0 }}>
                          {item.status === 'ready' ? '✔ LISTO' : '🍳 PREPARAR'}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Complete Ticket Action */}
                <div style={{ padding: '10px 14px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-card)' }}>
                  <button
                    onClick={() => handleCompleteTable(tableGroup)}
                    className={`btn ${isAllReady ? 'btn-success' : 'btn-primary'}`}
                    style={{ width: '100%', padding: '10px', fontSize: '0.85rem', fontWeight: 800 }}
                  >
                    <CheckCircle size={16} /> {isAllReady ? 'Despachar Comanda de Mesa' : 'Despachar Todos los Platos'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
