import React, { useState, useEffect } from 'react';
import { 
  Building2, Package, DollarSign, Users, Truck, AlertTriangle, 
  Plus, Edit2, Check, X, ArrowUpRight, ArrowDownRight, RefreshCw, Layers
} from 'lucide-react';
import { api, socket } from '../services/api';
import PanelCanalesPago from '../components/PanelCanalesPago';
import MenuAdminPage from './MenuAdminPage';

export default function ErpAdminPage({ defaultTab = 'inventory' }) {
  const [activeTab, setActiveTab] = useState(defaultTab); // 'inventory' | 'remitos' | 'kardex' | 'menu' | 'accounting' | 'journal' | 'staff' | 'suppliers' | 'gateways'
  const [inventory, setInventory] = useState([]);
  const [remitosPendientes, setRemitosPendientes] = useState([]);
  const [stockMovements, setStockMovements] = useState([]);
  const [staff, setStaff] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [accounting, setAccounting] = useState(null);
  const [journalEntries, setJournalEntries] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [poFilter, setPoFilter] = useState('all'); // 'all' | 'pendiente' | 'recibida'
  const [selectedRemitoForReview, setSelectedRemitoForReview] = useState(null);

  // Sincronizar defaultTab si cambia desde props
  useEffect(() => {
    if (defaultTab) setActiveTab(defaultTab);
  }, [defaultTab]);

  // Modals state
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [isAiInvoiceModalOpen, setIsAiInvoiceModalOpen] = useState(false);
  const [isPoModalOpen, setIsPoModalOpen] = useState(false);

  // Nora AI Invoice Scanner state
  const [aiInvoiceText, setAiInvoiceText] = useState('');
  const [aiParsedResult, setAiParsedResult] = useState(null);
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);

  // Purchase Order Form State
  const [poForm, setPoForm] = useState({
    supplierName: 'Frigorífico Barchic Salta',
    paymentCondition: 'contado', // 'contado' | 'credito'
    notes: '',
    items: [{ name: 'Carne Vacuna Picada', quantity: 15, unit: 'Kg', estCost: 7800 }]
  });

  // Form states
  const [stockItemForm, setStockItemForm] = useState({ name: '', category: 'Varios', currentStock: 10, minStock: 5, unit: 'Kg', costPerUnit: 1000 });
  const [expenseForm, setExpenseForm] = useState({ concept: '', amount: '', category: 'Operativos' });
  const [staffForm, setStaffForm] = useState({ name: '', role: 'Personal', type: 'fijo', phone: '', salary: 350000 });
  const [supplierForm, setSupplierForm] = useState({ companyName: '', contactPerson: '', phone: '', category: 'Carnes', debt: 0 });

  // Low stock calculation
  const lowStockItems = (inventory || []).filter(item => Number(item.currentStock) <= Number(item.minStock));

  useEffect(() => {
    fetchErpData();

    const handleUpdate = () => fetchErpData();
    socket.on('inventory_updated', handleUpdate);
    socket.on('remito_enviado_gerencia', handleUpdate);
    socket.on('remito_aprobado', handleUpdate);
    socket.on('remito_rechazado', handleUpdate);
    socket.on('staff_updated', handleUpdate);
    socket.on('suppliers_updated', handleUpdate);
    socket.on('accounting_updated', handleUpdate);
    socket.on('purchase_orders_updated', handleUpdate);

    return () => {
      socket.off('inventory_updated', handleUpdate);
      socket.off('remito_enviado_gerencia', handleUpdate);
      socket.off('remito_aprobado', handleUpdate);
      socket.off('remito_rechazado', handleUpdate);
      socket.off('staff_updated', handleUpdate);
      socket.off('suppliers_updated', handleUpdate);
      socket.off('accounting_updated', handleUpdate);
      socket.off('purchase_orders_updated', handleUpdate);
    };
  }, []);

  const fetchErpData = async () => {
    try {
      const invRes = await api.getInventory();
      setInventory(invRes.inventory || []);

      const remRes = await api.getRemitosPendientes();
      setRemitosPendientes(remRes.remitos || []);

      const movRes = await api.getStockMovements(50);
      setStockMovements(movRes.movements || []);

      const stRes = await api.getStaff();
      setStaff(stRes.staff || []);

      const supRes = await api.getSuppliers();
      setSuppliers(supRes.suppliers || []);

      const accRes = await api.getAccountingSummary();
      setAccounting(accRes.accounting || null);

      const jRes = await api.getJournalEntries();
      setJournalEntries(jRes.journalEntries || []);

      const poRes = await api.getPurchaseOrders();
      setPurchaseOrders(poRes.purchaseOrders || []);
    } catch (err) {
      console.error('Error fetching ERP data:', err);
    }
  };

  const handleExportWord = () => {
    const header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' "+
      "xmlns:w='urn:schemas-microsoft-com:office:word' "+
      "xmlns='http://www.w3.org/TR/REC-html40'>"+
      "<head><meta charset='utf-8'><title>Libro Diario Contable - Nexora One</title></head><body>";
    
    let tableHtml = `<h2 style="color: #1e3a8a;">MYJNEXORA VISUAL - LIBRO DIARIO CONTABLE MENSUAL</h2>`;
    tableHtml += `<p><strong>Agente Auditora:</strong> Nora AI Contadora</p>`;
    tableHtml += `<p><strong>Empresa:</strong> BARS & RESTAURANTS SYSTEM</p>`;
    tableHtml += `<p><strong>Fecha de Generación:</strong> ${new Date().toLocaleDateString('es-AR')}</p><hr/>`;
    
    tableHtml += `<table border="1" cellspacing="0" cellpadding="8" style="width: 100%; border-collapse: collapse;">`;
    tableHtml += `<tr style="background-color: #f1f5f9;"><th>N° Asiento</th><th>Fecha</th><th>Concepto / Glosa</th><th>Cuenta Debe</th><th>Importe Debe ($)</th><th>Cuenta Haber</th><th>Importe Haber ($)</th><th>Auditoría Nora AI</th></tr>`;

    journalEntries.forEach(entry => {
      tableHtml += `<tr>
        <td>${entry.id}</td>
        <td>${entry.date}</td>
        <td>${entry.concept}</td>
        <td>${entry.debeAccount}</td>
        <td>$${Number(entry.debeAmount).toLocaleString('es-AR')}</td>
        <td>${entry.haberAccount}</td>
        <td>$${Number(entry.haberAmount).toLocaleString('es-AR')}</td>
        <td>${entry.noraNote}</td>
      </tr>`;
    });

    tableHtml += `</table></body></html>`;

    const blob = new Blob(['\ufeff' + header + tableHtml], {
      type: 'application/msword'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Libro_Diario_Contable_NoraAI_${new Date().toISOString().slice(0, 10)}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handlePrintPdf = () => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Libro Diario Contable - Nora AI</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; color: #111; }
            h1 { color: #0f172a; margin-bottom: 4px; }
            .subtitle { color: #64748b; font-size: 0.9rem; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; font-size: 0.85rem; }
            th { background: #f8fafc; font-weight: bold; }
            .debe { color: #047857; font-weight: bold; }
            .haber { color: #b91c1c; font-weight: bold; }
            .footer { margin-top: 30px; font-size: 0.8rem; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 10px; }
          </style>
        </head>
        <body>
          <h1>📘 LIBRO DIARIO CONTABLE OFICIAL</h1>
          <div class="subtitle">Generado y Auditado por <strong>Nora AI - Contadora del Bar (Nexora One)</strong> | Fecha: ${new Date().toLocaleDateString('es-AR')}</div>
          <table>
            <thead>
              <tr>
                <th>Asiento</th>
                <th>Fecha</th>
                <th>Concepto / Glosa Operativa</th>
                <th>Cuenta DEBE</th>
                <th>Monto DEBE</th>
                <th>Cuenta HABER</th>
                <th>Monto HABER</th>
              </tr>
            </thead>
            <tbody>
              ${journalEntries.map(e => `
                <tr>
                  <td><strong>${e.id}</strong></td>
                  <td>${e.date}</td>
                  <td>${e.concept}</td>
                  <td>${e.debeAccount}</td>
                  <td class="debe">$${Number(e.debeAmount).toLocaleString('es-AR')}</td>
                  <td>${e.haberAccount}</td>
                  <td class="haber">$${Number(e.haberAmount).toLocaleString('es-AR')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="footer">
            Documento Contable Oficial listo para ser presentado al Contador de la empresa. Firma Desarrolladora: Nexora One ERP.
          </div>
          <script>
            window.onload = function() { window.print(); };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Subir imagen real a Nora Vision (OCR & IA Multimodal)
  const handleFileUploadToNora = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result;
      setAiInvoiceText(`Foto / Comprobante: ${file.name}`);
      setIsAiAnalyzing(true);

      try {
        const res = await fetch('/api/nora/vision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64,
            supplierHint: file.name
          })
        });
        const data = await res.json();

        if (data.extractedData) {
          setAiParsedResult(data.extractedData);
        } else {
          setAiParsedResult({
            invoiceType: 'Comprobante Físico / Foto Papel',
            supplierName: 'Proveedor Comercial',
            invoiceDate: new Date().toLocaleDateString('es-AR'),
            items: [
              { inventoryId: 'inv_1', name: 'Insumo Detectado', quantity: 1, unit: 'Kg', costPerUnit: 1000, subtotal: 1000 }
            ],
            totalAmount: 1000
          });
        }
      } catch (err) {
        console.error('Error analizando con Nora Vision:', err);
        alert('Error analizando imagen: ' + err.message);
      } finally {
        setIsAiAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Estado para edición y ajuste manual de remito (Human-in-the-loop)
  const [editingRemitoItems, setEditingRemitoItems] = useState([]);
  const [isEditRemitoModalOpen, setIsEditRemitoModalOpen] = useState(false);

  // Abrir modal de revisión y ajuste manual de mercadería/precios
  const openReviewRemitoModal = (remito) => {
    setSelectedRemitoForReview(remito);
    const analysis = remito.analysisJson ? JSON.parse(remito.analysisJson) : null;
    const initialItems = (analysis?.items && analysis.items.length > 0)
      ? analysis.items.map(it => ({
          name: it.name || 'Insumo',
          quantity: Number(it.quantity) || 1,
          unit: it.unit || 'Kg',
          costPerUnit: Number(it.costPerUnit) || 0
        }))
      : [{ name: 'Insumo Detectado', quantity: 1, unit: 'Kg', costPerUnit: Number(remito.totalAmount) || 0 }];
    setEditingRemitoItems(initialItems);
    setIsEditRemitoModalOpen(true);
  };

  // Gerencia: Aprobar remito con posible ajuste de mercadería (Compensación Humana)
  const handleApproveRemitoWithOverride = async () => {
    if (!selectedRemitoForReview) return;
    try {
      await api.approveRemito(selectedRemitoForReview.id, 'Gerencia General', editingRemitoItems);
      fetchErpData();
      setIsEditRemitoModalOpen(false);
      setSelectedRemitoForReview(null);
      alert(`✅ Remito compensado y aprobado con éxito! Stock e importes corregidos en depósito y kardex.`);
    } catch (err) {
      alert('Error aprobando remito corregido: ' + err.message);
    }
  };

  // Gerencia: Aprobar remito enviado por Caja / Depósito directo
  const handleApproveRemito = async (remito) => {
    openReviewRemitoModal(remito);
  };

  // Gerencia: Rechazar remito
  const handleRejectRemito = async (remito) => {
    const motivo = prompt('Ingresa el motivo del rechazo para notificar a la caja/depósito:', 'Comprobante no corresponde o mercadería incompleta');
    if (motivo === null) return;
    try {
      await api.rejectRemito(remito.id, 'Gerencia General', motivo);
      fetchErpData();
      alert(`❌ Remito rechazado.`);
      setSelectedRemitoForReview(null);
    } catch (err) {
      alert('Error rechazando remito: ' + err.message);
    }
  };

  const handleCreatePo = async (e) => {
    e.preventDefault();
    try {
      const res = await api.createPurchaseOrder(poForm);
      const newOrder = res.order || {
        id: `OC-${purchaseOrders.length + 101}`,
        date: new Date().toLocaleDateString('es-AR'),
        supplierName: poForm.supplierName,
        paymentCondition: poForm.paymentCondition,
        status: 'pendiente',
        totalEstimated: (poForm.items || []).reduce((sum, i) => sum + (Number(i.quantity) * Number(i.estCost || 1000)), 0),
        items: poForm.items,
        notes: poForm.notes
      };
      setPurchaseOrders(prev => [newOrder, ...prev]);
      setIsPoModalOpen(false);
      fetchErpData();
      alert(`✅ Orden de Compra N° ${newOrder.id} generada con éxito! Abriendo duplicado impreso...`);
      handlePrintPurchaseOrder(newOrder);
    } catch (err) {
      alert('Error creando Orden de Compra: ' + err.message);
    }
  };

  const handleReceivePo = async (orderId) => {
    try {
      await api.receivePurchaseOrder(orderId);
      fetchErpData();
      alert(`✅ Mercadería Corroborada con Éxito! Se incrementó el stock en Pañol y se registró el egreso contable.`);
    } catch (err) {
      alert('Error al corroborar orden: ' + err.message);
    }
  };

  const handleCreateStockItem = async (e) => {
    e.preventDefault();
    try {
      await api.addInventoryItem(stockItemForm);
      setIsStockModalOpen(false);
      setStockItemForm({ name: '', category: 'Varios', currentStock: 10, minStock: 5, unit: 'Kg', costPerUnit: 1000 });
      fetchErpData();
      alert('✅ Insumo de Stock cargado con éxito!');
    } catch (err) {
      alert('Error cargando insumo: ' + err.message);
    }
  };

  const handleCreateExpense = async (e) => {
    e.preventDefault();
    try {
      await api.addExpense(expenseForm);
      setIsExpenseModalOpen(false);
      setExpenseForm({ concept: '', amount: '', category: 'Operativos' });
      fetchErpData();
      alert('✅ Gasto Fijo / Operativo registrado con éxito!');
    } catch (err) {
      alert('Error registrando gasto: ' + err.message);
    }
  };

  const handleCreateStaff = async (e) => {
    e.preventDefault();
    try {
      await api.addStaffMember(staffForm);
      setIsStaffModalOpen(false);
      setStaffForm({ name: '', role: 'Personal', type: 'fijo', phone: '', salary: 350000 });
      fetchErpData();
      alert('✅ Empleado / Cadete cargado con éxito en RRHH!');
    } catch (err) {
      alert('Error cargando empleado: ' + err.message);
    }
  };

  const handleCreateSupplier = async (e) => {
    e.preventDefault();
    try {
      await api.addSupplier(supplierForm);
      setIsSupplierModalOpen(false);
      setSupplierForm({ companyName: '', contactPerson: '', phone: '', category: 'Carnes', debt: 0 });
      fetchErpData();
      alert('✅ Proveedor registrado con éxito!');
    } catch (err) {
      alert('Error cargando proveedor: ' + err.message);
    }
  };

  const handlePrintPurchaseOrder = (order) => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>ORDEN DE COMPRA N° ${order.id}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 25px; color: #111; max-width: 800px; margin: 0 auto; }
            .header { border-bottom: 2px solid #000; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
            .title { font-size: 1.8rem; font-weight: bold; letter-spacing: 1px; color: #0f172a; }
            .order-no { font-size: 1.4rem; color: #d97706; font-weight: bold; }
            .meta { background: #f8fafc; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #e2e8f0; font-size: 0.9rem; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #cbd5e1; padding: 10px 14px; text-align: left; font-size: 0.9rem; }
            th { background: #f1f5f9; font-weight: bold; }
            .checkbox { width: 40px; text-align: center; font-size: 1.1rem; }
            .footer { margin-top: 40px; padding-top: 16px; border-top: 2px dashed #94a3b8; display: flex; justify-content: space-between; font-size: 0.95rem; font-weight: bold; }
            .stamp { background: #e0f2fe; color: #0369a1; padding: 6px 12px; border-radius: 4px; display: inline-block; margin-top: 8px; font-size: 0.85rem; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="title">BARS & RESTAURANTS SYSTEM</div>
              <div style="font-size: 0.8rem; color: #64748b;">Firma Desarrolladora: Nexora One ERP</div>
            </div>
            <div class="order-no">ORDEN DE COMPRA N° ${order.id}</div>
          </div>

          <div class="meta">
            <div>📅 <strong>Fecha de Emisión:</strong> ${order.date}</div>
            <div>🛵 <strong>Comprobante para Cadete / Repartidor de Compras</strong></div>
            ${order.notes ? `<div>📝 <strong>Notas:</strong> ${order.notes}</div>` : ''}
          </div>

          <h3>LISTA DE INSUMOS A COMPRAR / CORROBORAR:</h3>
          <table>
            <thead>
              <tr>
                <th class="checkbox">OK</th>
                <th>Insumo / Mercadería</th>
                <th>Cantidad a Comprar</th>
                <th>Costo Unitario Est.</th>
                <th>Subtotal Est.</th>
              </tr>
            </thead>
            <tbody>
              ${(order.items || []).map(i => `
                <tr>
                  <td class="checkbox">[ &nbsp; ]</td>
                  <td><strong>${i.name}</strong></td>
                  <td>${i.quantity} ${i.unit || 'Kg'}</td>
                  <td>$${Number(i.estCost || 0).toLocaleString('es-AR')}</td>
                  <td>$${(Number(i.quantity) * Number(i.estCost || 0)).toLocaleString('es-AR')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="footer">
            <div>
              <div>🏬 PROVEEDOR: <u>${order.supplierName || 'Proveedor General'}</u></div>
              <div class="stamp">CONDICIÓN DE PAGO: <strong>${order.paymentCondition === 'credito' ? 'A CRÉDITO / CTA. CTE.' : 'AL CONTADO'}</strong></div>
            </div>
            <div style="text-align: right;">
              <div>TOTAL ESTIMADO:</div>
              <div style="font-size: 1.4rem; color: #047857;">$${Number(order.totalEstimated || 0).toLocaleString('es-AR')}</div>
            </div>
          </div>

          <script>
            window.onload = function() { window.print(); };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleAnalyzeInvoiceWithAI = async () => {
    if (!aiInvoiceText) return alert('Ingresa o pega la factura/remito');
    setIsAiAnalyzing(true);
    try {
      const res = await api.parseInvoiceWithAI(aiInvoiceText);
      setAiParsedResult(res.extractedData || null);
    } catch (err) {
      alert('Error analizando con IA: ' + err.message);
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  const handleApproveAiStockLoad = async () => {
    if (!aiParsedResult?.items) return;
    try {
      // 1. Update stock quantities
      for (const item of aiParsedResult.items) {
        const invItem = inventory.find(i => i.id === item.inventoryId || i.name.toLowerCase().includes(item.name.toLowerCase().split(' ')[0]));
        if (invItem) {
          const newStock = Number(invItem.currentStock) + Number(item.quantity);
          await api.updateInventoryStock(invItem.id, newStock);
        }
      }

      // 2. Record expense in accounting
      await api.addExpense({
        concept: `Compra Insumos - ${aiParsedResult.supplierName}`,
        amount: aiParsedResult.totalAmount,
        category: 'Mercaderías'
      });

      alert(`✅ Carga Aprobada con Éxito por la IA! Se incrementó el stock y se registró el gasto de $${aiParsedResult.totalAmount.toLocaleString('es-AR')}`);
      setIsAiInvoiceModalOpen(false);
      setAiInvoiceText('');
      setAiParsedResult(null);
      fetchErpData();
    } catch (err) {
      alert('Error aplicando carga de stock: ' + err.message);
    }
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '20px auto', padding: '0 20px 60px 20px' }}>
      
      {/* Top Title & Navigation */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Building2 style={{ color: 'var(--primary)' }} />
            Módulo ERP Empresarial & Gestión Integral
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
            Control de Stock, Finanzas, Personal (RRHH) y Proveedores · Firma: <strong>Nexora One ERP</strong>
          </p>
        </div>

        {/* Tab Selector */}
        <div style={{ display: 'flex', gap: '8px', background: 'var(--bg-card)', padding: '4px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', flexWrap: 'wrap' }}>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`btn ${activeTab === 'inventory' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            <Package size={16} /> 📦 Stock & Depósito ({inventory.length})
          </button>

          <button
            onClick={() => setActiveTab('remitos')}
            className={`btn ${activeTab === 'remitos' ? 'btn-primary' : 'btn-secondary'}`}
            style={{
              padding: '8px 16px',
              fontSize: '0.85rem',
              background: activeTab === 'remitos' ? 'linear-gradient(135deg, #0284c7, #0369a1)' : '',
              position: 'relative'
            }}
          >
            <span>📥 Bandeja Remitos & Facturas</span>
            {remitosPendientes.filter(r => r.status === 'pendiente').length > 0 && (
              <span style={{
                marginLeft: '6px',
                background: '#ef4444',
                color: '#fff',
                fontSize: '0.7rem',
                padding: '2px 6px',
                borderRadius: '10px',
                fontWeight: 900
              }}>
                {remitosPendientes.filter(r => r.status === 'pendiente').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('kardex')}
            className={`btn ${activeTab === 'kardex' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            📈 Kardex / Movimientos ({stockMovements.length})
          </button>

          <button
            onClick={() => setActiveTab('menu')}
            className={`btn ${activeTab === 'menu' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem', background: activeTab === 'menu' ? 'linear-gradient(135deg, #10b981, #059669)' : '' }}
          >
            🍽️ Carta, Precios & Recetas
          </button>

          <button
            onClick={() => setActiveTab('accounting')}
            className={`btn ${activeTab === 'accounting' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            <DollarSign size={16} /> Finanzas & Contabilidad
          </button>
          <button
            onClick={() => setActiveTab('journal')}
            className={`btn ${activeTab === 'journal' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem', background: activeTab === 'journal' ? 'linear-gradient(135deg, #10b981, #059669)' : '' }}
          >
            <Layers size={16} /> 📊 Asientos Contables (Nora AI)
          </button>
          <button
            onClick={() => setActiveTab('po')}
            className={`btn ${activeTab === 'po' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem', background: activeTab === 'po' ? 'linear-gradient(135deg, #f59e0b, #d97706)' : '' }}
          >
            <Truck size={16} /> 📋 Órdenes de Compra ({purchaseOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('staff')}
            className={`btn ${activeTab === 'staff' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            <Users size={16} /> Personal (RRHH) ({staff.length})
          </button>
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`btn ${activeTab === 'suppliers' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            <Truck size={16} /> Proveedores ({suppliers.length})
          </button>
          <button
            onClick={() => setActiveTab('gateways')}
            className={`btn ${activeTab === 'gateways' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '8px 16px', fontSize: '0.85rem', background: activeTab === 'gateways' ? 'linear-gradient(135deg, #06b6d4, #d946ef)' : '' }}
          >
            💳 Pasarelas de Pago
          </button>
        </div>
      </div>

      {/* 1. STOCK & INSUMOS TAB */}
      {activeTab === 'inventory' && (
        <div>
          
          {/* Low Stock Alert Box */}
          {lowStockItems.length > 0 && (
            <div className="glass-accent animate-pulse-border" style={{ padding: '16px 20px', borderRadius: 'var(--radius-lg)', marginBottom: '20px', border: '1px solid #ef4444' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#ef4444', fontWeight: 800, fontSize: '1rem', marginBottom: '8px' }}>
                <AlertTriangle size={20} />
                ⚠️ ALERTA AUTOMÁTICA DE REPOSICIÓN ({lowStockItems.length} insumos con bajo stock):
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '10px' }}>
                {lowStockItems.map(item => (
                  <div key={item.id} style={{ background: 'rgba(239, 68, 68, 0.1)', padding: '10px 14px', borderRadius: 'var(--radius-sm)', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
                    <div style={{ fontWeight: 800 }}>{item.name}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      Stock actual: <strong style={{ color: '#ef4444' }}>{item.currentStock} {item.unit}</strong> (Mínimo: {item.minStock} {item.unit})
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--primary)', marginTop: '4px', fontWeight: 700 }}>
                      👉 Reposición sugerida a pedir: +{(item.minStock * 3 - item.currentStock).toFixed(1)} {item.unit}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '10px' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Inventario de Materia Prima e Insumos</h3>
            
            <div style={{ display: 'flex', gap: '8px' }}>
              <button onClick={() => setIsAiInvoiceModalOpen(true)} className="btn btn-primary" style={{ padding: '8px 14px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #8b5cf6, #6d28d9)', border: 'none', color: '#fff', fontWeight: 800 }}>
                🤖 Lectura Factura / Remito con Nora AI
              </button>
              <button onClick={() => setIsStockModalOpen(true)} className="btn btn-secondary" style={{ padding: '8px 14px', fontSize: '0.85rem' }}>
                <Plus size={16} /> + Cargar Insumo Manual
              </button>
            </div>
          </div>

          <div className="glass" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-card-hover)', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '14px 16px' }}>Materia Prima / Insumo</th>
                  <th style={{ padding: '14px 16px' }}>Rubro</th>
                  <th style={{ padding: '14px 16px' }}>Stock Actual</th>
                  <th style={{ padding: '14px 16px' }}>Mínimo</th>
                  <th style={{ padding: '14px 16px' }}>Costo Unit.</th>
                  <th style={{ padding: '14px 16px' }}>Estado</th>
                  <th style={{ padding: '14px 16px' }}>Acción Stock</th>
                </tr>
              </thead>
              <tbody>
                {inventory.map(item => {
                  const isLow = item.currentStock <= item.minStock;
                  return (
                    <tr key={item.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                      <td style={{ padding: '14px 16px', fontWeight: 800 }}>{item.name}</td>
                      <td style={{ padding: '14px 16px', color: 'var(--text-muted)' }}>{item.category}</td>
                      <td style={{ padding: '14px 16px', fontWeight: 800, color: isLow ? '#ef4444' : 'var(--accent-green)' }}>
                        {item.currentStock} {item.unit}
                      </td>
                      <td style={{ padding: '14px 16px', color: 'var(--text-muted)' }}>{item.minStock} {item.unit}</td>
                      <td style={{ padding: '14px 16px' }}>${item.costPerUnit.toLocaleString('es-AR')}</td>
                      <td style={{ padding: '14px 16px' }}>
                        {isLow ? (
                          <span className="badge badge-danger">⚠️ Reponer Urgente</span>
                        ) : (
                          <span className="badge badge-success">Suficiente</span>
                        )}
                      </td>
                      <td style={{ padding: '14px 16px' }}>
                        <button
                          onClick={() => {
                            const val = prompt(`Ingresa el nuevo valor de stock para ${item.name}:`, item.currentStock);
                            if (val !== null && !isNaN(val)) handleUpdateStock(item.id, val);
                          }}
                          className="btn btn-secondary"
                          style={{ padding: '4px 10px', fontSize: '0.75rem' }}
                        >
                          ✏️ Ajustar
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 1B. BANDEJA DE REMITOS Y FACTURAS PENDIENTES (CONTROL REMOTO DE GERENCIA) */}
      {activeTab === 'remitos' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
            <div>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span>📥 Bandeja de Control de Remitos & Facturas de Compra</span>
                <span className="badge badge-purple">Nora Vision Audit</span>
              </h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                Fotos y comprobantes enviados desde <strong>Caja Central o Recepción</strong> para control, validación y carga contable remota.
              </p>
            </div>

            <button
              onClick={() => setIsAiInvoiceModalOpen(true)}
              className="btn btn-primary"
              style={{ padding: '9px 16px', background: 'linear-gradient(135deg, #8b5cf6, #6d28d9)', border: 'none', color: '#fff', fontWeight: 800 }}
            >
              🤖 Cargar Nueva Factura / Foto con Nora
            </button>
          </div>

          {remitosPendientes.length === 0 ? (
            <div className="glass" style={{ padding: '40px', textAlign: 'center', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>📭</div>
              <h4 style={{ fontSize: '1.1rem', fontWeight: 700 }}>No hay remitos pendientes de revisión</h4>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '6px' }}>
                Cuando el personal de caja o pañol tome una foto a un remito de proveedor o suba una factura, aparecerá aquí inmediatamente para tu aprobación.
              </p>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '16px' }}>
              {remitosPendientes.map(remito => {
                const analysis = remito.analysisJson ? (typeof remito.analysisJson === 'string' ? JSON.parse(remito.analysisJson) : remito.analysisJson) : null;
                const isPending = remito.status === 'pendiente';

                return (
                  <div
                    key={remito.id}
                    className="glass"
                    style={{
                      padding: '18px',
                      borderRadius: 'var(--radius-lg)',
                      border: isPending ? '2px solid #38bdf8' : '1px solid var(--border-color)',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      position: 'relative'
                    }}
                  >
                    <div>
                      {/* Cabecera del Remito */}
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                        <div>
                          <div style={{ fontWeight: 800, fontSize: '1.05rem', color: 'var(--text-main)' }}>
                            {remito.supplierName || 'Proveedor'}
                          </div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            Enviado por: <strong>{remito.senderUser}</strong> ({remito.originSector})
                          </div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                            📅 {new Date(remito.createdAt).toLocaleString('es-AR')}
                          </div>
                        </div>

                        <div>
                          {remito.status === 'pendiente' && <span className="badge badge-warning">🕒 Pendiente Control</span>}
                          {remito.status === 'aprobado' && <span className="badge badge-success">✅ Aprobado / En Stock</span>}
                          {remito.status === 'rechazado' && <span className="badge badge-danger">❌ Rechazado</span>}
                        </div>
                      </div>

                      {/* Vista previa de foto o comprobante */}
                      {remito.imageBase64 && (
                        <div style={{ margin: '10px 0', borderRadius: '8px', overflow: 'hidden', border: '1px solid var(--border-color)', maxHeight: '160px', background: '#000' }}>
                          <img
                            src={remito.imageBase64.startsWith('data:') ? remito.imageBase64 : `data:image/jpeg;base64,${remito.imageBase64}`}
                            alt="Comprobante"
                            style={{ width: '100%', height: '160px', objectFit: 'contain', cursor: 'pointer' }}
                            onClick={() => {
                              const w = window.open('');
                              w.document.write(`<img src="${remito.imageBase64}" style="max-width: 100%; height: auto;" />`);
                            }}
                            title="Toca para ampliar foto"
                          />
                        </div>
                      )}

                      {/* Resumen extraído por Nora AI */}
                      {analysis && (
                        <div style={{ background: 'rgba(56, 189, 248, 0.08)', padding: '10px 12px', borderRadius: '8px', border: '1px solid rgba(56, 189, 248, 0.25)', marginBottom: '12px' }}>
                          <div style={{ fontSize: '0.75rem', fontWeight: 800, color: '#38bdf8', marginBottom: '6px' }}>
                            🤖 Ítems Leídos por Nora Vision:
                          </div>
                          {analysis.items && analysis.items.length > 0 ? (
                            <ul style={{ margin: 0, paddingLeft: '16px', fontSize: '0.8rem', color: 'var(--text-main)' }}>
                              {analysis.items.map((it, idx) => (
                                <li key={idx}>
                                  <strong>{it.quantity} {it.unit || 'u.'}</strong> - {it.name} (${Number(it.costPerUnit || 0).toLocaleString('es-AR')}/u)
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Sin ítems desglosados</div>
                          )}
                        </div>
                      )}

                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.95rem', fontWeight: 800, borderTop: '1px solid var(--border-color)', paddingTop: '8px', marginTop: '6px' }}>
                        <span>Total Comprobante:</span>
                        <span style={{ color: 'var(--accent-green)' }}>${Number(remito.totalAmount || 0).toLocaleString('es-AR')}</span>
                      </div>
                    </div>

                    {/* Acciones de Gerencia */}
                    {isPending ? (
                      <div style={{ display: 'flex', gap: '8px', marginTop: '14px' }}>
                        <button
                          onClick={() => handleApproveRemito(remito)}
                          className="btn btn-success"
                          style={{ flex: 1, padding: '8px', fontSize: '0.82rem', fontWeight: 800 }}
                        >
                          ✅ Aprobar & Cargar
                        </button>
                        <button
                          onClick={() => handleRejectRemito(remito)}
                          className="btn btn-secondary"
                          style={{ flex: 1, padding: '8px', fontSize: '0.82rem', color: '#ef4444', borderColor: 'rgba(239,68,68,0.4)' }}
                        >
                          ❌ Rechazar
                        </button>
                      </div>
                    ) : (
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '10px', textAlign: 'right' }}>
                        Revisado por: <strong>{remito.reviewedBy || 'Gerencia'}</strong> el {remito.reviewedAt ? new Date(remito.reviewedAt).toLocaleDateString('es-AR') : ''}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 1C. KARDEX Y HISTORIAL DE MOVIMIENTOS DE STOCK */}
      {activeTab === 'kardex' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <h3 style={{ fontSize: '1.3rem', fontWeight: 800 }}>Historial de Movimientos de Stock (Kardex)</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
              Trazabilidad en tiempo real de cada entrada y salida de materias primas por ventas, remitos o mermas.
            </p>
          </div>

          <div className="glass" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-card-hover)', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '12px 16px' }}>Fecha y Hora</th>
                  <th style={{ padding: '12px 16px' }}>Insumo</th>
                  <th style={{ padding: '12px 16px' }}>Tipo</th>
                  <th style={{ padding: '12px 16px' }}>Cantidad</th>
                  <th style={{ padding: '12px 16px' }}>Stock Anterior</th>
                  <th style={{ padding: '12px 16px' }}>Stock Resultante</th>
                  <th style={{ padding: '12px 16px' }}>Motivo</th>
                  <th style={{ padding: '12px 16px' }}>Operador</th>
                </tr>
              </thead>
              <tbody>
                {stockMovements.length === 0 ? (
                  <tr>
                    <td colSpan="8" style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)' }}>
                      No se registran movimientos recientes de stock.
                    </td>
                  </tr>
                ) : (
                  stockMovements.map(m => (
                    <tr key={m.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                      <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>
                        {new Date(m.createdAt).toLocaleString('es-AR')}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: 800 }}>{m.itemName}</td>
                      <td style={{ padding: '12px 16px' }}>
                        {m.tipo === 'ingreso' && <span className="badge badge-success">⬆️ Ingreso</span>}
                        {m.tipo === 'egreso' && <span className="badge badge-danger">⬇️ Egreso</span>}
                        {m.tipo === 'ajuste' && <span className="badge badge-info">🔄 Ajuste</span>}
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: 800, color: m.tipo === 'ingreso' ? 'var(--accent-green)' : '#ef4444' }}>
                        {m.tipo === 'ingreso' ? `+${m.cantidad}` : `-${m.cantidad}`}
                      </td>
                      <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>{m.stockAnterior}</td>
                      <td style={{ padding: '12px 16px', fontWeight: 800 }}>{m.stockNuevo}</td>
                      <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>
                        {m.motivo === 'remito_proveedor' ? '📄 Remito Proveedor' : (m.motivo === 'venta_comanda' ? '🍽️ Venta Comanda' : m.motivo)}
                      </td>
                      <td style={{ padding: '12px 16px' }}>{m.usuario || 'Sistema'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 1D. CARTA, PRECIOS & RECETAS (100% GESTIONABLE POR EL CLIENTE) */}
      {activeTab === 'menu' && (
        <div style={{ marginTop: '10px' }}>
          <MenuAdminPage />
        </div>
      )}

      {/* 2. CONTABILIDAD & FINANZAS TAB */}
      {activeTab === 'accounting' && accounting && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* Tarjeta de Identificación Fiscal de la Empresa (CUIT/CUIL & Razón Social) */}
          <div className="glass" style={{
            padding: '16px 20px',
            borderRadius: 'var(--radius-lg)',
            borderLeft: '4px solid var(--primary)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '12px'
          }}>
            <div>
              <div style={{ fontSize: '0.72rem', color: 'var(--primary)', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px' }}>
                DATOS FISCALES & CONTABLES DEL COMERCIO
              </div>
              <h3 style={{ margin: '2px 0 4px 0', fontSize: '1.25rem', fontWeight: 900, color: 'var(--text-main)' }}>
                Nexora One Gastro S.A.
              </h3>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
                <span>CUIT / CUIL: <strong style={{ color: 'var(--text-main)', fontFamily: 'var(--font-mono)' }}>30-71849204-9</strong></span>
                <span>Condición IVA: <strong style={{ color: 'var(--accent-green)' }}>Responsable Inscripto</strong></span>
                <span>Ingresos Brutos: <strong style={{ color: 'var(--text-main)' }}>901-482019-3</strong></span>
                <span>Domicilio Fiscal: <strong>Av. Belgrano 1420, Salón Central</strong></span>
              </div>
            </div>

            <a
              href="#driver"
              style={{
                background: 'linear-gradient(135deg, #0284c7, #0369a1)',
                color: '#fff',
                padding: '10px 16px',
                borderRadius: '10px',
                textDecoration: 'none',
                fontWeight: 800,
                fontSize: '0.85rem',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                boxShadow: '0 4px 12px rgba(2, 132, 199, 0.35)'
              }}
            >
              <Truck size={18} />
              Ver Sección Delivery & Cadetes 🛵
            </a>
          </div>

          {/* Executive Financial Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
            
            <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
                <span>INGRESOS BRUTOS TOTALES</span>
                <ArrowUpRight style={{ color: 'var(--accent-green)' }} />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-green)', marginTop: '8px' }}>
                ${accounting.totalGrossRevenue.toLocaleString('es-AR')}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Salón: ${accounting.totalSalesSaloon.toLocaleString('es-AR')} | Delivery: ${accounting.totalSalesDelivery.toLocaleString('es-AR')}
              </div>
            </div>

            <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
                <span>COSTOS & GASTOS TOTALES</span>
                <ArrowDownRight style={{ color: '#ef4444' }} />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#ef4444', marginTop: '8px' }}>
                ${accounting.totalCosts.toLocaleString('es-AR')}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Mercadería/Gastos: ${accounting.totalOperationalExpenses.toLocaleString('es-AR')} | Sueldos: ${accounting.totalStaffPayroll.toLocaleString('es-AR')}
              </div>
            </div>

            <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', border: '2px solid var(--primary)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
                <span>MARGEN NETO RESULTANTE</span>
                <DollarSign style={{ color: 'var(--primary)' }} />
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: accounting.netProfit >= 0 ? 'var(--primary)' : '#ef4444', marginTop: '8px' }}>
                ${accounting.netProfit.toLocaleString('es-AR')}
              </div>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Ganancia neta real de la empresa</span>
            </div>

          </div>

          {/* Expense Log & Add Expense Button */}
          <div className="glass" style={{ padding: '24px', borderRadius: 'var(--radius-lg)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Registro Contable de Egresos y Compras</h3>
              <button onClick={() => setIsExpenseModalOpen(true)} className="btn btn-primary" style={{ padding: '8px 14px', fontSize: '0.85rem' }}>
                <Plus size={16} /> + Registrar Nuevo Gasto
              </button>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-card-hover)', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '12px 14px' }}>Fecha</th>
                  <th style={{ padding: '12px 14px' }}>Concepto</th>
                  <th style={{ padding: '12px 14px' }}>Categoría</th>
                  <th style={{ padding: '12px 14px' }}>Monto</th>
                </tr>
              </thead>
              <tbody>
                {accounting.expenses.map(exp => (
                  <tr key={exp.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                    <td style={{ padding: '12px 14px', color: 'var(--text-muted)' }}>{new Date(exp.date).toLocaleDateString()}</td>
                    <td style={{ padding: '12px 14px', fontWeight: 700 }}>{exp.concept}</td>
                    <td style={{ padding: '12px 14px' }}><span className="badge badge-info">{exp.category}</span></td>
                    <td style={{ padding: '12px 14px', fontWeight: 800, color: '#ef4444' }}>-${exp.amount.toLocaleString('es-AR')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* 3. PERSONAL & RRHH TAB (Garantiza gestión de PINs y Turnos) */}
      {activeTab === 'staff' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Nómina de Personal, Claves PIN & Asignación de Turnos</h3>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Cada comercio puede personalizar las claves PIN de sus empleados. Los PINs configurados aquí permiten el ingreso inmediato al sector correspondiente.
              </p>
            </div>
            <button onClick={() => setIsStaffModalOpen(true)} className="btn btn-primary" style={{ padding: '8px 14px', fontSize: '0.85rem' }}>
              <Plus size={16} /> + Cargar Nuevo Empleado & PIN
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '20px' }}>
            {staff.map(st => (
              <div key={st.id} className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-accent)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#fff' }}>{st.name}</h4>
                  <span className="badge badge-info" style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                    {st.role}
                  </span>
                </div>

                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '12px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div>⏰ Turno Asignado: <strong style={{ color: 'var(--primary)' }}>{st.shift || 'Turno Mañana'}</strong></div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-main)', padding: '6px 10px', borderRadius: '6px', marginTop: '4px' }}>
                    <span>🔑 PIN de Acceso: <strong style={{ color: '#06b6d4', fontSize: '1rem', fontFamily: 'monospace' }}>{st.pin || '1111'}</strong></span>
                    <button
                      onClick={async () => {
                        const newPin = prompt(`Ingresa el nuevo PIN de acceso para ${st.name}:`, st.pin || '');
                        if (newPin && !isNaN(newPin)) {
                          await api.updateStaffMember(st.id, { pin: newPin });
                          fetchErpData();
                          alert(`✅ PIN de acceso actualizado a "${newPin}" para ${st.name}`);
                        }
                      }}
                      style={{ background: 'var(--primary)', color: '#000', border: 'none', padding: '2px 8px', borderRadius: '4px', fontSize: '0.7rem', fontWeight: 800, cursor: 'pointer' }}
                    >
                      ✏️ Cambiar PIN
                    </button>
                  </div>
                </div>

                <div style={{ background: 'var(--bg-main)', padding: '10px 12px', borderRadius: 'var(--radius-sm)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Sueldo Mensual:</span>
                  <strong style={{ color: 'var(--accent-green)', fontSize: '1rem' }}>
                    ${Number(st.salary || 0).toLocaleString('es-AR')}
                  </strong>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. PROVEEDORES TAB */}
      {activeTab === 'suppliers' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Directorio de Proveedores & Deudas</h3>
            <button onClick={() => setIsSupplierModalOpen(true)} className="btn btn-primary" style={{ padding: '8px 14px', fontSize: '0.85rem' }}>
              <Plus size={16} /> + Nuevo Proveedor
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '20px' }}>
            {suppliers.map(sup => (
              <div key={sup.id} className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <h4 style={{ fontSize: '1.1rem', fontWeight: 800 }}>{sup.companyName}</h4>
                  <span className="badge badge-info">{sup.category}</span>
                </div>

                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                  <div>👤 Contacto: <strong>{sup.contactPerson}</strong></div>
                  <div>📞 Teléfono: {sup.phone}</div>
                </div>

                <div style={{ background: 'var(--bg-main)', padding: '10px 12px', borderRadius: 'var(--radius-sm)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Saldo Pendiente:</span>
                  <strong style={{ color: sup.debt > 0 ? '#ef4444' : 'var(--accent-green)', fontSize: '1.05rem' }}>
                    ${sup.debt.toLocaleString('es-AR')}
                  </strong>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. ASIENTOS CONTABLES Y LIBRO DIARIO TAB (NORA AI CONTADORA) */}
      {activeTab === 'journal' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <h3 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                🧠 Nora AI - Contadora Nativa del Bar
              </h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                Asientos del Libro Diario contable por partida doble (DEBE / HABER) auditados automáticamente. Listos para ser presentados al contador en Word (.doc) o PDF impreso.
              </p>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                onClick={handlePrintPdf}
                className="btn btn-primary"
                style={{ padding: '10px 16px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px' }}
              >
                🖨️ Imprimir / PDF (Libro Diario Físico)
              </button>

              <button
                onClick={handleExportWord}
                className="btn btn-secondary"
                style={{ padding: '10px 16px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px', borderColor: 'var(--primary)', color: 'var(--primary)', fontWeight: 700 }}
              >
                📝 Exportar a Word (.doc Editable)
              </button>
            </div>
          </div>

          <div className="glass" style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-card-hover)', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '14px 16px' }}>Asiento N°</th>
                  <th style={{ padding: '14px 16px' }}>Fecha</th>
                  <th style={{ padding: '14px 16px' }}>Concepto / Operación Comercial</th>
                  <th style={{ padding: '14px 16px' }}>Cuenta DEBE (Débito)</th>
                  <th style={{ padding: '14px 16px' }}>Importe DEBE</th>
                  <th style={{ padding: '14px 16px' }}>Cuenta HABER (Crédito)</th>
                  <th style={{ padding: '14px 16px' }}>Importe HABER</th>
                  <th style={{ padding: '14px 16px' }}>Auditoría Nora AI</th>
                </tr>
              </thead>
              <tbody>
                {(!journalEntries || journalEntries.length === 0) ? (
                  <tr>
                    <td colSpan="8" style={{ padding: '30px', textAlign: 'center', color: 'var(--text-muted)' }}>
                      No hay asientos contables registrados en este período mensual todavía. Realiza ventas o compras para ver los asientos auditados por Nora AI.
                    </td>
                  </tr>
                ) : (
                  (journalEntries || []).map(entry => (
                    <tr key={entry?.id || Math.random()} style={{ borderBottom: '1px solid var(--border-color)' }}>
                      <td style={{ padding: '14px 16px', fontWeight: 800, color: 'var(--primary)' }}>{entry?.id || '-'}</td>
                      <td style={{ padding: '14px 16px', color: 'var(--text-muted)' }}>{entry?.date || '-'}</td>
                      <td style={{ padding: '14px 16px', fontWeight: 700 }}>{entry?.concept || 'Asiento General'}</td>
                      <td style={{ padding: '14px 16px', color: 'var(--accent-green)' }}>{entry?.debeAccount || 'Caja'}</td>
                      <td style={{ padding: '14px 16px', fontWeight: 800, color: 'var(--accent-green)' }}>${Number(entry?.debeAmount || 0).toLocaleString('es-AR')}</td>
                      <td style={{ padding: '14px 16px', color: '#ef4444' }}>{entry?.haberAccount || 'Ventas'}</td>
                      <td style={{ padding: '14px 16px', fontWeight: 800, color: '#ef4444' }}>${Number(entry?.haberAmount || 0).toLocaleString('es-AR')}</td>
                      <td style={{ padding: '14px 16px', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        <span style={{ background: 'rgba(16, 185, 129, 0.1)', color: '#10b981', padding: '2px 8px', borderRadius: '4px', border: '1px solid rgba(16, 185, 129, 0.3)' }}>
                          ✓ {entry?.noraNote || 'Auditado por Nora AI'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. ÓRDENES DE COMPRA PARA CADETES TAB */}
      {activeTab === 'po' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <h3 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                📋 Historial & Auditoría de Órdenes de Compra
              </h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                💾 <strong>Duplicado Guardado en Base de Datos:</strong> Todas las órdenes quedan respaldadas permanentemente para la auditoría de cierre mensual.
              </p>
            </div>

            <button
              onClick={() => setIsPoModalOpen(true)}
              className="btn btn-primary"
              style={{ padding: '10px 18px', fontSize: '0.9rem', background: 'linear-gradient(135deg, #f59e0b, #d97706)', border: 'none', color: '#000', fontWeight: 800 }}
            >
              + Nueva Orden de Compra (Cadete)
            </button>
          </div>

          {/* Monthly Audit Summary Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px', marginBottom: '20px' }}>
            <div className="glass" style={{ padding: '16px', borderRadius: 'var(--radius-md)' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>ÓRDENES EMITIDAS MES</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--primary)', marginTop: '4px' }}>
                {purchaseOrders.length} Comprobantes
              </div>
            </div>

            <div className="glass" style={{ padding: '16px', borderRadius: 'var(--radius-md)' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>TOTAL INVERTIDO EN COMPRAS</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-green)', marginTop: '4px' }}>
                ${purchaseOrders.reduce((sum, o) => sum + Number(o.totalEstimated || 0), 0).toLocaleString('es-AR')}
              </div>
            </div>

            <div className="glass" style={{ padding: '16px', borderRadius: 'var(--radius-md)' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>COMPRAS RECIBIDAS / CORROBORADAS</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#38bdf8', marginTop: '4px' }}>
                {purchaseOrders.filter(o => o.status === 'recibida').length} / {purchaseOrders.length}
              </div>
            </div>
          </div>

          {/* Filter Bar */}
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', flexWrap: 'wrap' }}>
            <button
              onClick={() => setPoFilter('all')}
              className={`btn ${poFilter === 'all' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.8rem', padding: '6px 12px' }}
            >
              Todas ({purchaseOrders.length})
            </button>

            <button
              onClick={() => setPoFilter('pendiente')}
              className={`btn ${poFilter === 'pendiente' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.8rem', padding: '6px 12px' }}
            >
              ⏳ En Calle / Pendientes ({purchaseOrders.filter(o => o.status === 'pendiente').length})
            </button>

            <button
              onClick={() => setPoFilter('recibida')}
              className={`btn ${poFilter === 'recibida' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.8rem', padding: '6px 12px' }}
            >
              ✓ Recibidas & Corroboradas ({purchaseOrders.filter(o => o.status === 'recibida').length})
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(400px, 1fr))', gap: '20px' }}>
            {purchaseOrders
              .filter(o => poFilter === 'all' || o.status === poFilter)
              .map(order => (
              <div key={order.id} className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', border: order.status === 'recibida' ? '1px solid var(--accent-green)' : '1px solid var(--primary)' }}>
                
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <div style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)' }}>
                    ORDEN DE COMPRA N° {order.id}
                  </div>
                  <span className={`badge ${order.status === 'recibida' ? 'badge-success' : 'badge-warning'}`}>
                    {order.status === 'recibida' ? '✓ Recibida e Ingresada' : '⏳ Pendiente de Compra'}
                  </span>
                </div>

                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                  <div>📅 Fecha: <strong>{order.date}</strong></div>
                  <div>🏬 Proveedor: <strong>{order.supplierName}</strong></div>
                  <div>💳 Condición de Pago: <strong style={{ color: order.paymentCondition === 'credito' ? '#38bdf8' : 'var(--accent-green)' }}>
                    {order.paymentCondition === 'credito' ? 'A CRÉDITO / CTA. CTE.' : 'AL CONTADO'}
                  </strong></div>
                </div>

                {/* Items Checklist Table */}
                <div style={{ background: 'var(--bg-main)', borderRadius: 'var(--radius-sm)', padding: '10px', marginBottom: '16px' }}>
                  <div style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--text-muted)', marginBottom: '6px', textTransform: 'uppercase' }}>
                    Insumos Solicitados:
                  </div>
                  {(order.items || []).map((item, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', padding: '4px 0', borderBottom: '1px dashed var(--border-color)' }}>
                      <span>[ &nbsp; ] <strong>{item.name}</strong></span>
                      <span style={{ color: 'var(--primary)' }}>{item.quantity} {item.unit || 'Kg'}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', fontWeight: 800, marginTop: '8px', paddingTop: '6px', borderTop: '1px solid var(--border-color)' }}>
                    <span>Total Estimado:</span>
                    <span style={{ color: 'var(--accent-green)' }}>${Number(order.totalEstimated || 0).toLocaleString('es-AR')}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  <button
                    onClick={() => handlePrintPurchaseOrder(order)}
                    className="btn btn-secondary"
                    style={{ flex: 1, padding: '8px', fontSize: '0.8rem' }}
                  >
                    🖨️ Imprimir p/ Cadete
                  </button>

                  {order.status === 'pendiente' ? (
                    <button
                      onClick={() => handleReceivePo(order.id)}
                      className="btn btn-primary"
                      style={{ flex: 1, padding: '8px', fontSize: '0.8rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', color: '#fff', fontWeight: 800 }}
                    >
                      ✅ Corroborar e Ingresar Stock
                    </button>
                  ) : (
                    <div style={{ flex: 1, textAlign: 'center', fontSize: '0.8rem', color: 'var(--accent-green)', padding: '8px', fontWeight: 700 }}>
                      ✓ Stock e Insumos Ingresados
                    </div>
                  )}
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. PASARELAS DE PAGO TAB */}
      {activeTab === 'gateways' && (
        <PanelCanalesPago />
      )}

      {/* MODAL CREATE STOCK ITEM */}
      {isStockModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsStockModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '500px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--primary)' }}>
                📦 Cargar Nuevo Insumo de Stock / Pañol
              </h3>
              <button onClick={() => setIsStockModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleCreateStockItem}>
              
              {/* 1. Nombre del insumo */}
              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                  Nombre del Insumo / Mercadería *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Carne Vacuna Picada / Queso Mozzarella / Cerveza IPA"
                  value={stockItemForm.name}
                  onChange={e => setStockItemForm({ ...stockItemForm, name: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              {/* 2. Categoría y Unidad de Medida */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                    Categoría / Rubro
                  </label>
                  <select
                    value={stockItemForm.category || 'Carnes'}
                    onChange={e => setStockItemForm({ ...stockItemForm, category: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="Carnes">🥩 Carnes y Chacinados</option>
                    <option value="Bebidas">🍹 Bebidas y Barriles</option>
                    <option value="Verduras">🥬 Verdulería y Frescos</option>
                    <option value="Lácteos">🧀 Lácteos y Quesos</option>
                    <option value="Secos">🥖 Panadería y Harinas</option>
                    <option value="Varios">📦 Varios y Limpieza</option>
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                    Unidad de Medida / Peso *
                  </label>
                  <select
                    value={stockItemForm.unit || 'Kg'}
                    onChange={e => setStockItemForm({ ...stockItemForm, unit: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="Kg">⚖️ Kg (Kilogramos)</option>
                    <option value="g">⚖️ Gramos (g)</option>
                    <option value="Lts">🧪 Litros (Lts)</option>
                    <option value="Unidades">🔢 Unidades (U)</option>
                    <option value="Packs">📦 Packs (Paquetes)</option>
                    <option value="Cajas">📦 Cajas</option>
                  </select>
                </div>
              </div>

              {/* 3. Cantidad Stock Actual & Stock Mínimo */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--accent-green)', display: 'block', marginBottom: '4px' }}>
                    📦 Stock Inicial ({stockItemForm.unit || 'Kg'})
                  </label>
                  <input
                    type="number"
                    required
                    step="any"
                    placeholder={`Ej: 10 ${stockItemForm.unit || 'Kg'}`}
                    value={stockItemForm.currentStock}
                    onChange={e => setStockItemForm({ ...stockItemForm, currentStock: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Cantidad física en depósito</span>
                </div>

                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: '#f59e0b', display: 'block', marginBottom: '4px' }}>
                    ⚠️ Alerta Mínimo ({stockItemForm.unit || 'Kg'})
                  </label>
                  <input
                    type="number"
                    required
                    step="any"
                    placeholder={`Ej: 5 ${stockItemForm.unit || 'Kg'}`}
                    value={stockItemForm.minStock}
                    onChange={e => setStockItemForm({ ...stockItemForm, minStock: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Límite para aviso de reposición</span>
                </div>
              </div>

              {/* 4. Costo por unidad en pesos */}
              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                  💵 Costo / Precio de Compra por {stockItemForm.unit || 'Kg'} ($ ARS)
                </label>
                <input
                  type="number"
                  required
                  step="any"
                  placeholder="Ej: 7800"
                  value={stockItemForm.costPerUnit}
                  onChange={e => setStockItemForm({ ...stockItemForm, costPerUnit: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: 800 }}>
                💾 Guardar Insumo en Pañol
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL CREATE EXPENSE / GASTOS FIJOS DEL LOCAL */}
      {isExpenseModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsExpenseModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '450px' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, marginBottom: '6px' }}>🏛️ Registrar Gasto Fijo / Operativo</h3>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '14px' }}>
              Registra facturas de servicios, impuestos, alquileres o mantenimiento del local:
            </p>
            <form onSubmit={handleCreateExpense}>
              <div style={{ marginBottom: '10px' }}>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                  Atajos de Gastos Fijos del Local:
                </label>
                <select
                  onChange={e => {
                    if (e.target.value) setExpenseForm({ ...expenseForm, concept: e.target.value, category: 'Gastos Fijos' });
                  }}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: 'var(--radius-sm)' }}
                >
                  <option value="">⚡ Seleccionar Atajo de Gasto Fijo...</option>
                  <option value="Factura de Luz / EDESA Electricidad">⚡ Factura de Luz (EDESA / Electricidad)</option>
                  <option value="Servicio de Agua y Cloacas">💧 Servicio de Agua y Cloacas</option>
                  <option value="Internet Fibra Óptica & Teléfono">🌐 Internet Fibra Óptica & Teléfono</option>
                  <option value="Alquiler / Renta Mensual del Local">🏢 Alquiler / Renta Mensual del Local</option>
                  <option value="Impuestos AFIP / ARCA (Monotributo/IVA)">🏛️ Impuestos AFIP / ARCA (Monotributo / IVA)</option>
                  <option value="Tasa Municipal de Comercio e Industria">🏙️ Tasa Municipal de Comercio e Industria</option>
                </select>
              </div>

              <input
                type="text"
                required
                placeholder="Concepto del gasto (Ej: Factura de Luz EDESA)"
                value={expenseForm.concept}
                onChange={e => setExpenseForm({ ...expenseForm, concept: e.target.value })}
                style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)', marginBottom: '10px' }}
              />
              <input
                type="number"
                required
                placeholder="Monto a pagar ($)"
                value={expenseForm.amount}
                onChange={e => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)', marginBottom: '14px' }}
              />
              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', fontWeight: 800 }}>
                💾 Guardar Gasto Fijo & Generar Asiento
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL AI INVOICE OCR SCANNER */}
      {isAiInvoiceModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsAiInvoiceModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '600px', maxHeight: '85vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                🤖 Nora AI - Agente Nativa Inteligente (Lectura de Comprobantes)
              </h3>
              <button onClick={() => setIsAiInvoiceModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
              Pega el texto o <strong>adjunta el archivo de la factura/remito</strong>. <strong>Nora AI</strong> interpretará los insumos, cantidades e importes para añadirlos automáticamente al stock:
            </p>

            {/* Dual Capture Controls: Camera Photo + File Upload + QR Scanner */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '10px', marginBottom: '14px' }}>
              
              {/* Option A: Direct Camera Capture from Smartphone */}
              <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', border: '2px dashed var(--primary)', textAlign: 'center' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 800, marginBottom: '6px' }}>
                  📸 Sacar Foto con Cámara (Papel Físico)
                </div>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleFileUploadToNora}
                  style={{ fontSize: '0.75rem', color: 'var(--text-muted)', cursor: 'pointer', width: '100%' }}
                />
              </div>

              {/* Option B: QR Code AFIP / ARCA Scanner */}
              <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', border: '2px dashed #38bdf8', textAlign: 'center' }}>
                <div style={{ fontSize: '0.8rem', color: '#38bdf8', fontWeight: 800, marginBottom: '6px' }}>
                  🔍 Escanear QR AFIP / ARCA de Factura
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const qrSample = "https://www.afip.gob.ar/fe/qr/?p=eyJ2ZXIiOjEsImZlY2hhIjoiMjAyNi0wOC0xMCIsImN1aXQiOjMwNzExMjM0NTY3LCJwdG9WdGEiOjQsInRpcG9DcHRlIjoxLCJudW1DcHRlIjoxMjk4NCwiaW1wb3J0ZSI6MjYwOTAwfQ==";
                    const parsedSample = "Factura A AFIP/ARCA CUIT: 30-71123456-7 N° 0004-0012984 - 25.5 kg Carne Vacuna Picada $198.900, 10 kg Queso Mozzarella $62.000";
                    setAiInvoiceText(parsedSample);
                    alert("🔍 QR AFIP/ARCA Escaneado con Éxito!\n\nDatos leídos: CUIT 30-71123456-7 | Comprobante N° 0004-0012984 | Importe: $260.900");
                  }}
                  style={{ background: '#38bdf8', color: '#000', border: 'none', padding: '6px 12px', borderRadius: '4px', fontSize: '0.75rem', fontWeight: 800, cursor: 'pointer' }}
                >
                  ⚡ Escanear QR con Cámara
                </button>
              </div>

            </div>

            {/* AI / Photo Extracted Results (Editable by User) */}
            {aiParsedResult && (
              <div className="glass-accent" style={{ padding: '16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--primary-light)' }}>
                
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--primary)' }}>
                    COMPROBANTE A CARGAR AL STOCK:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const updatedItems = [
                        ...aiParsedResult.items,
                        { inventoryId: 'inv_new', name: '', quantity: 1, unit: 'Kg', costPerUnit: 1000, subtotal: 1000 }
                      ];
                      const total = updatedItems.reduce((sum, i) => sum + (Number(i.quantity) * Number(i.costPerUnit)), 0);
                      setAiParsedResult({ ...aiParsedResult, items: updatedItems, totalAmount: total });
                    }}
                    style={{ background: 'var(--primary)', color: '#000', border: 'none', padding: '4px 10px', borderRadius: '4px', fontSize: '0.75rem', fontWeight: 800, cursor: 'pointer' }}
                  >
                    + Agregar Insumo
                  </button>
                </div>

                <div style={{ marginBottom: '10px' }}>
                  <input
                    type="text"
                    placeholder="Nombre del Proveedor (Ej: Frigorífico Barchic / Carnicería)"
                    value={aiParsedResult.supplierName}
                    onChange={e => setAiParsedResult({ ...aiParsedResult, supplierName: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: '4px', fontSize: '0.8rem', marginBottom: '8px' }}
                  />
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '12px' }}>
                  {aiParsedResult.items.map((item, idx) => (
                    <div key={idx} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: '8px', background: 'var(--bg-main)', padding: '8px', borderRadius: 'var(--radius-sm)' }}>
                      <input
                        type="text"
                        placeholder="Nombre de insumo"
                        value={item.name}
                        onChange={e => {
                          const updated = [...aiParsedResult.items];
                          updated[idx].name = e.target.value;
                          const total = updated.reduce((sum, i) => sum + (Number(i.quantity) * Number(i.costPerUnit)), 0);
                          setAiParsedResult({ ...aiParsedResult, items: updated, totalAmount: total });
                        }}
                        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px', borderRadius: '4px', fontSize: '0.8rem' }}
                      />
                      <input
                        type="number"
                        placeholder="Cantidad"
                        value={item.quantity}
                        onChange={e => {
                          const updated = [...aiParsedResult.items];
                          updated[idx].quantity = e.target.value;
                          updated[idx].subtotal = Number(e.target.value) * Number(updated[idx].costPerUnit);
                          const total = updated.reduce((sum, i) => sum + (Number(i.quantity) * Number(i.costPerUnit)), 0);
                          setAiParsedResult({ ...aiParsedResult, items: updated, totalAmount: total });
                        }}
                        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px', borderRadius: '4px', fontSize: '0.8rem' }}
                      />
                      <input
                        type="number"
                        placeholder="Precio Unit."
                        value={item.costPerUnit}
                        onChange={e => {
                          const updated = [...aiParsedResult.items];
                          updated[idx].costPerUnit = e.target.value;
                          updated[idx].subtotal = Number(updated[idx].quantity) * Number(e.target.value);
                          const total = updated.reduce((sum, i) => sum + (Number(i.quantity) * Number(i.costPerUnit)), 0);
                          setAiParsedResult({ ...aiParsedResult, items: updated, totalAmount: total });
                        }}
                        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px', borderRadius: '4px', fontSize: '0.8rem' }}
                      />
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: '1.05rem', marginBottom: '14px' }}>
                  <span>Total Compra a Cargar:</span>
                  <span style={{ color: 'var(--accent-green)' }}>${Number(aiParsedResult.totalAmount || 0).toLocaleString('es-AR')}</span>
                </div>

                <button
                  onClick={handleApproveAiStockLoad}
                  className="btn btn-success"
                  style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: 800 }}
                >
                  ✅ APROBAR E INCREMENTAR STOCK AUTOMÁTICAMENTE
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* MODAL CREATE NEW PURCHASE ORDER FOR CADETES */}
      {isPoModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsPoModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '550px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)' }}>
                📋 Generar Orden de Compra N° OC-{purchaseOrders.length + 101}
              </h3>
              <button onClick={() => setIsPoModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleCreatePo}>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                  Nombre del Proveedor / Comercio:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Frigorífico Barchic Salta / Panadería San José"
                  value={poForm.supplierName}
                  onChange={e => setPoForm({ ...poForm, supplierName: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                  Condición de Pago al Pie del Comprobante:
                </label>
                <select
                  value={poForm.paymentCondition}
                  onChange={e => setPoForm({ ...poForm, paymentCondition: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                >
                  <option value="contado">💵 AL CONTADO (Cadete paga en efectivo/tarjeta)</option>
                  <option value="credito">💳 A CRÉDITO / CTA. CTE. (Cargar a cuenta corriente del bar)</option>
                </select>
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                  Notas para el Cadete / Repartidor:
                </label>
                <input
                  type="text"
                  placeholder="Ej: Retirar antes de las 18:00 hs y pedir factura A"
                  value={poForm.notes}
                  onChange={e => setPoForm({ ...poForm, notes: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              {/* Items List */}
              <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <span style={{ fontSize: '0.85rem', fontWeight: 800 }}>Insumos a Comprar:</span>
                  <button
                    type="button"
                    onClick={() => setPoForm({
                      ...poForm,
                      items: [...poForm.items, { name: '', quantity: 1, unit: 'Kg', estCost: 1000 }]
                    })}
                    style={{ background: 'var(--primary)', color: '#000', border: 'none', padding: '4px 8px', borderRadius: '4px', fontSize: '0.75rem', fontWeight: 800, cursor: 'pointer' }}
                  >
                    + Agregar Insumo
                  </button>
                </div>

                {poForm.items.map((item, index) => (
                  <div key={index} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: '8px', marginBottom: '6px' }}>
                    <input
                      type="text"
                      required
                      placeholder="Nombre (Ej: Queso Mozzarella)"
                      value={item.name}
                      onChange={e => {
                        const updated = [...poForm.items];
                        updated[index].name = e.target.value;
                        setPoForm({ ...poForm, items: updated });
                      }}
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px', borderRadius: '4px', fontSize: '0.8rem' }}
                    />
                    <input
                      type="number"
                      required
                      placeholder="Cantidad"
                      value={item.quantity}
                      onChange={e => {
                        const updated = [...poForm.items];
                        updated[index].quantity = e.target.value;
                        setPoForm({ ...poForm, items: updated });
                      }}
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px', borderRadius: '4px', fontSize: '0.8rem' }}
                    />
                    <input
                      type="number"
                      required
                      placeholder="Costo Est. ($)"
                      value={item.estCost}
                      onChange={e => {
                        const updated = [...poForm.items];
                        updated[index].estCost = e.target.value;
                        setPoForm({ ...poForm, items: updated });
                      }}
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px', borderRadius: '4px', fontSize: '0.8rem' }}
                    />
                  </div>
                ))}
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: 800 }}>
                📋 Generar e Imprimir Orden de Compra
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL CREATE STAFF MEMBER */}
      {isStaffModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsStaffModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '450px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)' }}>Cargar Empleado / Cadete (RRHH)</h3>
              <button onClick={() => setIsStaffModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleCreateStaff}>
              <div style={{ marginBottom: '10px' }}>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Nombre y Apellido del Empleado *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Carlos Gómez / Maria Cajera"
                  value={staffForm.name}
                  onChange={e => setStaffForm({ ...staffForm, name: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Sector / Rol de Acceso</label>
                  <select
                    value={staffForm.role || 'caja'}
                    onChange={e => setStaffForm({ ...staffForm, role: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="caja">Salón / Caja / Mostrador</option>
                    <option value="cocina">Cocina / Barra (KDS)</option>
                    <option value="delivery">Delivery / Cadetes</option>
                    <option value="panol">Pañol / Depósito / Stock</option>
                    <option value="gerencia">Presidencia / Gerencia</option>
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: '0.75rem', color: '#06b6d4', fontWeight: 800, display: 'block', marginBottom: '4px' }}>🔑 PIN de Acceso Personal *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: 5555"
                    value={staffForm.pin || ''}
                    onChange={e => setStaffForm({ ...staffForm, pin: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid #06b6d4', color: '#06b6d4', fontWeight: 800, fontFamily: 'monospace', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '14px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Turno Asignado</label>
                  <input
                    type="text"
                    placeholder="Ej: Turno Noche (18h a 02h)"
                    value={staffForm.shift || ''}
                    onChange={e => setStaffForm({ ...staffForm, shift: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Sueldo / Tarifa Mensual ($)</label>
                  <input
                    type="number"
                    required
                    placeholder="Ej: 450000"
                    value={staffForm.salary}
                    onChange={e => setStaffForm({ ...staffForm, salary: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', fontWeight: 800 }}>
                💾 Guardar Empleado & Habilitar PIN de Acceso
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL CREATE SUPPLIER */}
      {isSupplierModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsSupplierModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '450px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)' }}>Cargar Nuevo Proveedor</h3>
              <button onClick={() => setIsSupplierModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleCreateSupplier}>
              <div style={{ marginBottom: '10px' }}>
                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Razón Social / Empresa *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Frigorífico Barchic / Panadería San José"
                  value={supplierForm.companyName}
                  onChange={e => setSupplierForm({ ...supplierForm, companyName: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Persona de Contacto</label>
                  <input
                    type="text"
                    placeholder="Ej: Juan Pérez"
                    value={supplierForm.contactPerson}
                    onChange={e => setSupplierForm({ ...supplierForm, contactPerson: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Categoría / Rubro</label>
                  <select
                    value={supplierForm.category}
                    onChange={e => setSupplierForm({ ...supplierForm, category: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="Carnes">🥩 Carnes y Chacinados</option>
                    <option value="Bebidas">🍹 Bebidas y Cervezas</option>
                    <option value="Verduras">🥬 Verdulería y Frescos</option>
                    <option value="Lácteos">🧀 Lácteos y Quesos</option>
                    <option value="Secos">🥖 Panadería y Secos</option>
                    <option value="Varios">📦 Varios / Limpieza</option>
                  </select>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '14px' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Teléfono / WhatsApp</label>
                  <input
                    type="text"
                    placeholder="+54 9 387..."
                    value={supplierForm.phone}
                    onChange={e => setSupplierForm({ ...supplierForm, phone: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Saldo / Deuda Inicial ($)</label>
                  <input
                    type="number"
                    value={supplierForm.debt}
                    onChange={e => setSupplierForm({ ...supplierForm, debt: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              </div>
              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px', fontWeight: 800 }}>
                💾 Guardar Proveedor en Directorio
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DE COMPENSACIÓN & AJUSTE HUMANO DE REMITO (HUMAN-IN-THE-LOOP) */}
      {isEditRemitoModalOpen && selectedRemitoForReview && (
        <div className="bottom-sheet-overlay" onClick={() => setIsEditRemitoModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '800px', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '1.3rem', fontWeight: 900, color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>✏️ Control y Compensación Humana de Factura</span>
                </h3>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '4px 0 0 0' }}>
                  Proveedor: <strong>{selectedRemitoForReview.supplierName}</strong> · ¿Vino mercadería incompleta o con diferencias? Ajusta las cantidades exactas antes de ingresar a stock.
                </p>
              </div>
              <button onClick={() => setIsEditRemitoModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            {/* Foto del Comprobante si existe */}
            {selectedRemitoForReview.imageBase64 && (
              <div style={{ marginBottom: '14px', borderRadius: '8px', overflow: 'hidden', border: '1px solid var(--border-color)', maxHeight: '180px', background: '#000', display: 'flex', justifyContent: 'center' }}>
                <img
                  src={selectedRemitoForReview.imageBase64.startsWith('data:') ? selectedRemitoForReview.imageBase64 : `data:image/jpeg;base64,${selectedRemitoForReview.imageBase64}`}
                  alt="Foto Comprobante"
                  style={{ maxHeight: '180px', objectFit: 'contain' }}
                />
              </div>
            )}

            {/* Tabla de Ítems Editables */}
            <div style={{ background: 'var(--bg-main)', borderRadius: '8px', padding: '12px', border: '1px solid var(--border-color)', marginBottom: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--primary)' }}>
                  📦 Mercadería a Ingresar en Depósito:
                </span>
                <button
                  type="button"
                  onClick={() => setEditingRemitoItems(prev => [...prev, { name: '', quantity: 1, unit: 'Kg', costPerUnit: 0 }])}
                  className="btn btn-secondary"
                  style={{ fontSize: '0.75rem', padding: '4px 10px' }}
                >
                  <Plus size={14} /> Agregar Fila
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {editingRemitoItems.map((item, idx) => (
                  <div key={idx} style={{ display: 'grid', gridTemplateColumns: '3fr 1.2fr 1fr 1.5fr 40px', gap: '8px', alignItems: 'center' }}>
                    <input
                      type="text"
                      value={item.name}
                      onChange={e => {
                        const copy = [...editingRemitoItems];
                        copy[idx].name = e.target.value;
                        setEditingRemitoItems(copy);
                      }}
                      placeholder="Insumo / Mercadería"
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '7px 10px', borderRadius: '4px', fontSize: '0.85rem' }}
                    />
                    <input
                      type="number"
                      step="0.01"
                      value={item.quantity}
                      onChange={e => {
                        const copy = [...editingRemitoItems];
                        copy[idx].quantity = Number(e.target.value) || 0;
                        setEditingRemitoItems(copy);
                      }}
                      placeholder="Cantidad"
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '7px 10px', borderRadius: '4px', fontSize: '0.85rem' }}
                    />
                    <input
                      type="text"
                      value={item.unit}
                      onChange={e => {
                        const copy = [...editingRemitoItems];
                        copy[idx].unit = e.target.value;
                        setEditingRemitoItems(copy);
                      }}
                      placeholder="Unidad (Kg/u)"
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '7px 10px', borderRadius: '4px', fontSize: '0.85rem' }}
                    />
                    <input
                      type="number"
                      value={item.costPerUnit}
                      onChange={e => {
                        const copy = [...editingRemitoItems];
                        copy[idx].costPerUnit = Number(e.target.value) || 0;
                        setEditingRemitoItems(copy);
                      }}
                      placeholder="Costo Unitario ($)"
                      style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '7px 10px', borderRadius: '4px', fontSize: '0.85rem' }}
                    />
                    <button
                      type="button"
                      onClick={() => setEditingRemitoItems(prev => prev.filter((_, i) => i !== idx))}
                      style={{ background: 'rgba(239, 68, 68, 0.2)', border: 'none', color: '#ef4444', borderRadius: '4px', height: '34px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                      title="Eliminar fila"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ))}
              </div>

              {/* Total recalculado por compensación humana */}
              <div style={{ marginTop: '14px', paddingTop: '10px', borderTop: '1px dashed var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                  Total Real Corregido por Gerencia:
                </span>
                <span style={{ fontSize: '1.2rem', fontWeight: 900, color: 'var(--accent-green)' }}>
                  ${editingRemitoItems.reduce((acc, it) => acc + (Number(it.quantity) * Number(it.costPerUnit)), 0).toLocaleString('es-AR')}
                </span>
              </div>
            </div>

            {/* Botones de Confirmación */}
            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                type="button"
                onClick={() => setIsEditRemitoModalOpen(false)}
                className="btn btn-secondary"
                style={{ flex: 1, padding: '10px' }}
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleApproveRemitoWithOverride}
                className="btn btn-success"
                style={{ flex: 2, padding: '10px', fontWeight: 900 }}
              >
                ✅ Confirmar Compensación & Cargar Stock
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
