import React, { useState, useEffect } from 'react';
import { 
  Monitor, Users, Clock, DollarSign, CheckCircle2, 
  AlertCircle, Printer, X, RefreshCw, Sparkles, Receipt, QrCode, Plus
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { api, socket } from '../services/api';
import { getCleanDeviceUrl } from '../utils/networkHelper';

export default function CashierDashboard({ onSelectTableForClient }) {
  const [tables, setTables] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [tableDetails, setTableDetails] = useState(null);
  const [reports, setReports] = useState(null);
  const [isQrPrintModalOpen, setIsQrPrintModalOpen] = useState(false);
  const [qrModalTable, setQrModalTable] = useState(null);
  const [serverIp, setServerIp] = useState('');

  // Caja Inicial & Phone Orders State
  const [cajaInicial, setCajaInicial] = useState(50000);
  const [isPhoneOrderModalOpen, setIsPhoneOrderModalOpen] = useState(false);
  const [menuItems, setMenuItems] = useState([]);
  const [phoneForm, setPhoneForm] = useState({
    customerName: '',
    phone: '',
    deliveryType: 'delivery',
    address: '',
    notes: '',
    paymentMethod: 'efectivo',
    selectedItems: []
  });

  const getTableUrl = (tableId) => {
    return getCleanDeviceUrl(`mesa=${tableId}`);
  };

  const handleEditCajaInicial = async () => {
    const val = prompt('Ingresa el nuevo Importe de Caja Inicial al Día (Fondo de Cambio):', cajaInicial);
    if (val && !isNaN(val)) {
      try {
        const res = await api.setCajaInicial(Number(val));
        setCajaInicial(res.cajaInicial || Number(val));
        alert(`✅ Fondo de Cambio de Apertura actualizado a $${Number(val).toLocaleString('es-AR')}`);
      } catch (err) {
        setCajaInicial(Number(val));
      }
    }
  };

  const handleCreatePhoneOrder = async (e) => {
    e.preventDefault();
    if (!phoneForm.customerName || phoneForm.selectedItems.length === 0) {
      return alert('Ingresa el nombre del cliente y al menos 1 producto');
    }
    try {
      await api.createDelivery({
        customerName: phoneForm.customerName,
        phone: phoneForm.phone,
        address: phoneForm.deliveryType === 'delivery' ? phoneForm.address : 'Retiro en Mostrador / Takeaway',
        notes: `Pedido Telefónico / WhatsApp - ${phoneForm.notes}`,
        deliveryType: phoneForm.deliveryType,
        driverName: 'Por Asignar',
        paymentMethod: phoneForm.paymentMethod,
        selectedItems: phoneForm.selectedItems
      });
      setIsPhoneOrderModalOpen(false);
      setPhoneForm({
        customerName: '',
        phone: '',
        deliveryType: 'delivery',
        address: '',
        notes: '',
        paymentMethod: 'efectivo',
        selectedItems: []
      });
      alert('✅ Pedido Telefónico / WhatsApp ingresado con éxito! Enviado a cocina.');
      fetchReports();
    } catch (err) {
      alert('Error creando pedido telefónico: ' + err.message);
    }
  };

  const handleAddNewTable = async () => {
    const nextTableId = tables.length > 0 ? Math.max(...tables.map(t => Number(t.id))) + 1 : 1;
    const newTable = {
      id: nextTableId,
      name: `Mesa ${nextTableId}`,
      capacity: 4,
      status: 'libre',
      activeSessionId: null
    };
    const updated = [...tables, newTable];
    setTables(updated);
    alert(`✅ Mesa #${nextTableId} agregada con éxito al plano del local!`);
  };

  useEffect(() => {
    fetchTables();
    fetchReports();

    api.getCajaInicial().then(res => {
      const raw = res?.cajaInicial;
      const monto = typeof raw === 'object' && raw !== null ? Number(raw.monto || raw.amount || 0) : Number(raw || 50000);
      setCajaInicial(monto);
    }).catch(e => console.log(e));

    api.getMenu().then(res => {
      if (res?.menu) setMenuItems(res.menu);
    }).catch(e => console.log(e));

    // Adaptive Auto IP Detection for QR scanning on any Wi-Fi
    api.getNetworkInfo().then(info => {
      if (info?.localIp) setServerIp(info.localIp);
    }).catch(e => console.log(e));

    const handleTableUpdated = () => {
      fetchTables();
      fetchReports();
    };

    const handleOrderCreated = () => {
      fetchTables();
    };

    const handlePaymentReceived = () => {
      fetchTables();
      fetchReports();
    };

    socket.on('table_updated', handleTableUpdated);
    socket.on('order_created', handleOrderCreated);
    socket.on('payment_received', handlePaymentReceived);

    return () => {
      socket.off('table_updated', handleTableUpdated);
      socket.off('order_created', handleOrderCreated);
      socket.off('payment_received', handlePaymentReceived);
    };
  }, []);

  const fetchTables = async () => {
    try {
      const data = await api.getTables();
      setTables(data);
    } catch (err) {
      console.error('Error fetching tables:', err);
    }
  };

  const fetchReports = async () => {
    try {
      const data = await api.getReportsSummary();
      setReports(data);
    } catch (err) {
      console.error('Error fetching reports:', err);
    }
  };

  const openTableDrawer = async (table) => {
    setSelectedTable(table);
    try {
      const details = await api.getTable(table.id);
      setTableDetails(details);
    } catch (err) {
      console.error('Error fetching table details:', err);
    }
  };

  const handleCloseTable = async (tableId) => {
    if (!confirm(`¿Confirmas liberar y cerrar la Mesa #${tableId}?`)) return;
    try {
      await api.closeTable(tableId);
      setSelectedTable(null);
      setTableDetails(null);
      fetchTables();
    } catch (err) {
      alert('Error cerrando mesa: ' + err.message);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'libre':
        return <span className="badge badge-success">🟢 Libre</span>;
      case 'ocupada':
        return <span className="badge badge-warning">🟡 Viendo Menú</span>;
      case 'pedido_entrante':
        return <span className="badge badge-info animate-glow">🔵 Pedido Entrante</span>;
      case 'preparando':
        return <span className="badge badge-purple">🟠 En Cocina/Barra</span>;
      case 'pago_solicitado':
        return <span className="badge badge-warning animate-glow" style={{ background: '#8b5cf6', color: '#fff' }}>🟣 Solicita Pago</span>;
      default:
        return <span className="badge badge-info">{status}</span>;
    }
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '20px auto', padding: '0 20px 60px 20px' }}>
      
      {/* Top Banner Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px', marginBottom: '24px' }}>
        
        {/* Fondo de Cambio / Caja Inicial */}
        <div className="glass-accent" style={{ padding: '20px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--primary-light)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--primary)', fontSize: '0.8rem', fontWeight: 800 }}>
            <span>💵 CAJA INICIAL / CAMBIO AL DÍA</span>
            <button onClick={handleEditCajaInicial} style={{ background: 'var(--primary)', color: '#000', border: 'none', padding: '2px 8px', borderRadius: '4px', fontSize: '0.7rem', fontWeight: 800, cursor: 'pointer' }}>
              ✏️ Ajustar Fondo
            </button>
          </div>
          <div style={{ fontSize: '1.7rem', fontWeight: 800, color: 'var(--primary)', marginTop: '8px' }}>
            ${cajaInicial.toLocaleString('es-AR')}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Total Arqueo Estimado: <strong>${(cajaInicial + (reports?.totalSales || 0)).toLocaleString('es-AR')}</strong>
          </div>
        </div>

        <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            <span>TOTAL VENTAS DEL DÍA</span>
            <DollarSign size={18} style={{ color: 'var(--accent-green)' }} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-green)', marginTop: '8px' }}>
            ${reports ? reports.totalSales.toLocaleString('es-AR') : '0'}
          </div>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Operaciones confirmadas</span>
        </div>

        <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            <span>PROPINAS ACUMULADAS MOZOS</span>
            <Sparkles size={18} style={{ color: 'var(--primary)' }} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--primary)', marginTop: '8px' }}>
            ${reports ? reports.totalTips.toLocaleString('es-AR') : '0'}
          </div>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Recaudación transparente</span>
        </div>

        <div className="glass" style={{ padding: '20px', borderRadius: 'var(--radius-lg)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
            <span>MESAS ACTIVAS CON CUENTA</span>
            <Users size={18} style={{ color: 'var(--accent-blue)' }} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--text-main)', marginTop: '8px' }}>
            {tables.filter(t => t.status !== 'libre').length} / {tables.length}
          </div>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Capacidad del salón</span>
        </div>
      </div>

      {/* Main Grid: Salon Tables */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '10px' }}>
        <h2 style={{ fontSize: '1.4rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Monitor style={{ color: 'var(--primary)' }} />
          Matriz de Mesas en Salón ({tables.length} Mesas)
        </h2>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          <button
            onClick={() => setIsPhoneOrderModalOpen(true)}
            className="btn btn-primary"
            style={{ padding: '8px 16px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)', border: 'none', color: '#fff', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <span>📞 Nuevo Pedido Telefónico / WhatsApp</span>
          </button>
          <button
            onClick={() => setIsQrPrintModalOpen(true)}
            className="btn btn-primary"
            style={{ padding: '8px 16px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', color: '#fff', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <QrCode size={16} /> 🖨️ Panel de Impresión de QRs ({tables.length})
          </button>
          <button
            onClick={handleAddNewTable}
            className="btn btn-secondary"
            style={{ padding: '8px 14px', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <Plus size={16} /> + Agregar Mesa
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '20px' }}>
        {tables.map(table => (
          <div
            key={table.id}
            onClick={() => openTableDrawer(table)}
            className="glass"
            style={{
              padding: '20px',
              borderRadius: 'var(--radius-lg)',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              border: table.status === 'pedido_entrante' || table.status === 'pago_solicitado'
                ? '2px solid var(--primary)'
                : '1px solid var(--border-color)',
              position: 'relative'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800 }}>{table.name}</h3>
              {getStatusBadge(table.status)}
            </div>

            {table.activeSession ? (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '4px' }}>
                  <span>Comensales:</span>
                  <strong style={{ color: 'var(--text-main)' }}>{table.activeSession.comensales} personas</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                  <span>Pedidos realizados:</span>
                  <strong style={{ color: 'var(--text-main)' }}>{table.ordersCount} rondas</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: 800, borderTop: '1px solid var(--border-color)', paddingTop: '8px' }}>
                  <span>Saldo Pendiente:</span>
                  <span style={{ color: 'var(--primary)' }}>${table.unpaidTotal.toLocaleString('es-AR')}</span>
                </div>
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '16px 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                Mesa lista para recibir clientes con QR
              </div>
            )}

            <div style={{ display: 'flex', gap: '8px', marginTop: '14px' }}>
              <button
                onClick={(e) => { e.stopPropagation(); setQrModalTable(table); }}
                className="btn btn-secondary"
                style={{ flex: 1, padding: '8px 6px', fontSize: '0.75rem', fontWeight: 700 }}
              >
                📱 Ver / Escanear QR
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); openTableDrawer(table); }}
                className="btn btn-primary"
                style={{ flex: 1, padding: '8px 6px', fontSize: '0.75rem', fontWeight: 700 }}
              >
                🔍 Detalle Mesa
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* TABLE DETAILS DRAWER */}
      {selectedTable && tableDetails && (
        <div className="bottom-sheet-overlay" onClick={() => setSelectedTable(null)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '700px' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div>
                <h3 style={{ fontSize: '1.5rem', fontWeight: 800 }}>{selectedTable.name} · Detalle de Consumos</h3>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Firma: <strong>Nexora One</strong></span>
              </div>
              <button onClick={() => setSelectedTable(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            {tableDetails.activeSession ? (
              <div>
                <div style={{ background: 'var(--bg-main)', padding: '12px 16px', borderRadius: 'var(--radius-md)', marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>ID Sesión Abierta</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>{tableDetails.activeSession.id}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Comensales</div>
                    <div style={{ fontWeight: 700, textAlign: 'right' }}>{tableDetails.activeSession.comensales} personas</div>
                  </div>
                </div>

                {/* Orders Breakdown */}
                <h4 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '10px' }}>Comandas & Pedidos de la Mesa:</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '300px', overflowY: 'auto', marginBottom: '20px' }}>
                  {tableDetails.orders.length === 0 ? (
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Sin pedidos ingresados aún.</div>
                  ) : (
                    tableDetails.orders.map(ord => (
                      <div key={ord.id} style={{ background: 'var(--bg-card-hover)', padding: '12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '8px' }}>
                          <strong>{ord.dinerName}</strong>
                          <span className="badge badge-info">{ord.status}</span>
                        </div>
                        {ord.items.map((item, i) => (
                          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', padding: '4px 0', borderBottom: '1px dashed var(--border-color)' }}>
                            <span>{item.quantity}x {item.title} {item.notes && <small style={{ color: 'var(--primary)' }}>({item.notes})</small>}</span>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <span>${item.subtotal.toLocaleString('es-AR')}</span>
                              {item.isPaid ? (
                                <span style={{ color: '#10b981', fontSize: '0.75rem', fontWeight: 700 }}>[PAGADO]</span>
                              ) : (
                                <span style={{ color: '#f59e0b', fontSize: '0.75rem' }}>[PENDIENTE]</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ))
                  )}
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'flex', gap: '12px' }}>
                  <button
                    onClick={() => handleCloseTable(selectedTable.id)}
                    className="btn btn-danger"
                    style={{ flex: 1, padding: '12px' }}
                  >
                    🔒 Cerrar & Liberar Mesa #{selectedTable.id}
                  </button>
                </div>

              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '40px 0' }}>
                <p style={{ color: 'var(--text-muted)' }}>Esta mesa no tiene ninguna sesión activa en este momento.</p>
              </div>
            )}

          </div>
        </div>
      )}

      {/* MODAL PRINT QR TABLES PANEL */}
      {isQrPrintModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsQrPrintModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '900px', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              <div>
                <h3 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <QrCode size={24} />
                  Panel de Impresión de Códigos QR por Mesa (Salón)
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                  Cada QR apunta exactamente a su número de mesa (`?mesa=X`) para abrir la App del Cliente · Desarrollado por <strong>Nexora One</strong>
                </p>
                
                {/* IP Selector for Wi-Fi mobile scanners */}
                <div style={{ marginTop: '8px', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8rem' }}>
                  <span style={{ color: 'var(--primary)', fontWeight: 700 }}>🌐 IP de Red Wi-Fi para Escaneo:</span>
                  <input
                    type="text"
                    value={serverIp}
                    onChange={e => setServerIp(e.target.value)}
                    placeholder="Ej: 192.168.1.219"
                    style={{ background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '4px 8px', borderRadius: '4px', fontSize: '0.8rem', width: '140px' }}
                  />
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>(Auto-detectada para Celulares en Wi-Fi)</span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <button
                  onClick={() => window.print()}
                  className="btn btn-primary"
                  style={{ padding: '8px 16px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', color: '#fff' }}
                >
                  <Printer size={16} /> Imprimir Todos los Carteles
                </button>
                <button
                  onClick={handleAddNewTable}
                  className="btn btn-secondary"
                  style={{ padding: '8px 14px', fontSize: '0.85rem' }}
                >
                  <Plus size={16} /> + Agregar Mesa #{tables.length + 1}
                </button>
                <button onClick={() => setIsQrPrintModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', marginLeft: '8px' }}>
                  <X size={24} />
                </button>
              </div>
            </div>

            {/* Banner Informativo de Vinculación de Tablets según Presupuesto */}
            <div style={{ background: 'rgba(6, 182, 212, 0.15)', border: '1px solid #06b6d4', padding: '14px 18px', borderRadius: '12px', marginBottom: '20px', color: '#06b6d4' }}>
              <div style={{ fontWeight: 900, fontSize: '0.95rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <QrCode size={18} /> 📱 VINCULACIÓN DE TABLETS & COMANDERAS MÓVILES DEL PERSONAL
              </div>
              <div style={{ fontSize: '0.82rem', marginTop: '4px', color: '#fff' }}>
                Las tablets de los mozos y celulares de personal se conectan a la red Wi-Fi local escaneando los códigos QR o ingresando a <strong>{`http://${serverIp || 'localhost'}:3036/`}</strong>.
              </div>
              <div style={{ fontSize: '0.75rem', marginTop: '4px', color: 'var(--text-muted)' }}>
                ℹ️ Cantidad de dispositivos habilitados: Según el límite acordado en el presupuesto de su contrato. Para computadoras adicionales en red, utilice el archivo instalador oficial brindado.
              </div>
            </div>

            {/* Grid of Printable Table QR Cards */}
            <div className="printable-qr-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '16px', padding: '10px 0' }}>
              {tables.map(table => {
                const tableUrl = getTableUrl(table.id);
                return (
                  <div
                    key={table.id}
                    className="glass"
                    style={{
                      padding: '16px',
                      borderRadius: 'var(--radius-md)',
                      textAlign: 'center',
                      background: '#ffffff',
                      color: '#000000',
                      border: '2px solid #10b981',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                    }}
                  >
                    <div style={{ fontSize: '0.75rem', fontWeight: 800, textTransform: 'uppercase', color: '#059669', letterSpacing: '1px', marginBottom: '2px' }}>
                      ESCANEA Y PIDE AQUÍ
                    </div>
                    <div style={{ fontSize: '1.4rem', fontWeight: 900, color: '#111827', marginBottom: '10px' }}>
                      {table.name}
                    </div>

                    <div style={{ background: '#fff', padding: '10px', display: 'inline-block', borderRadius: '8px', border: '1px solid #e5e7eb' }}>
                      <QRCodeSVG
                        value={tableUrl}
                        size={150}
                        includeMargin={true}
                      />
                    </div>

                    <div style={{ fontSize: '0.75rem', color: '#4b5563', marginTop: '8px', fontWeight: 700 }}>
                      Mesa #{table.id} · Capacidad: {table.capacity} personas
                    </div>
                    <div style={{ fontSize: '0.65rem', color: '#9ca3af', marginTop: '4px' }}>
                      Powered by <strong>Nexora One</strong>
                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        </div>
      )}

      {/* INDIVIDUAL TABLE QR CODE MODAL */}
      {qrModalTable && (
        <div className="bottom-sheet-overlay" onClick={() => setQrModalTable(null)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '420px', textAlign: 'center' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <QrCode size={20} /> Código QR de {qrModalTable.name}
              </h3>
              <button onClick={() => setQrModalTable(null)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <div style={{ background: '#ffffff', padding: '20px', borderRadius: '16px', border: '3px solid #10b981', display: 'inline-block', marginBottom: '16px', boxShadow: '0 8px 25px rgba(0,0,0,0.3)' }}>
              <div style={{ fontSize: '0.8rem', fontWeight: 900, textTransform: 'uppercase', color: '#059669', letterSpacing: '1px', marginBottom: '4px' }}>
                ESCANEA CON TU CELULAR Y PIDE
              </div>
              <div style={{ fontSize: '1.6rem', fontWeight: 900, color: '#111827', marginBottom: '12px' }}>
                {qrModalTable.name}
              </div>

              <QRCodeSVG
                value={getTableUrl(qrModalTable.id)}
                size={200}
                includeMargin={true}
              />

              <div style={{ fontSize: '0.75rem', color: '#4b5563', marginTop: '10px', fontWeight: 700 }}>
                Enlace Directo Wi-Fi:
              </div>
              <div style={{ fontSize: '0.7rem', color: '#2563eb', fontWeight: 700, wordBreak: 'break-all' }}>
                {getTableUrl(qrModalTable.id)}
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <button
                onClick={() => {
                  const printWin = window.open('', '_blank');
                  printWin.document.write(`
                    <html>
                      <head><title>QR ${qrModalTable.name}</title></head>
                      <body style="font-family: Arial, sans-serif; text-align: center; padding: 40px;">
                        <h2 style="font-size: 2rem;">ESCANEA Y PIDE AQUÍ</h2>
                        <h1 style="font-size: 3rem; margin: 10px 0;">${qrModalTable.name}</h1>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(getTableUrl(qrModalTable.id))}" />
                        <p style="font-weight: bold; margin-top: 15px;">Firma: Nexora One Smart Restaurant System</p>
                        <script>window.onload = function() { window.print(); };</script>
                      </body>
                    </html>
                  `);
                  printWin.document.close();
                }}
                className="btn btn-primary"
                style={{ width: '100%', padding: '10px', fontSize: '0.85rem', background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none', color: '#fff', fontWeight: 800 }}
              >
                🖨️ Imprimir Cartel / Sticker de esta Mesa
              </button>

              <button
                onClick={() => {
                  const tableId = qrModalTable.id;
                  setQrModalTable(null);
                  onSelectTableForClient(tableId);
                }}
                className="btn btn-secondary"
                style={{ width: '100%', padding: '10px', fontSize: '0.85rem', fontWeight: 700 }}
              >
                📲 Abrir Menú Digital como Cliente (Simular Pedido)
              </button>
            </div>

          </div>
        </div>
      )}

      {/* MODAL NUEVO PEDIDO TELEFÓNICO / WHATSAPP DESDE CAJA */}
      {isPhoneOrderModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsPhoneOrderModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '540px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--primary)' }}>
                📞 Nuevo Pedido Telefónico / WhatsApp
              </h3>
              <button onClick={() => setIsPhoneOrderModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleCreatePhoneOrder}>
              
              <div style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                  Nombre del Cliente *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Marcelo Gómez / María Fernández"
                  value={phoneForm.customerName}
                  onChange={e => setPhoneForm({ ...phoneForm, customerName: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                    Teléfono / WhatsApp *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="+54 9 387..."
                    value={phoneForm.phone}
                    onChange={e => setPhoneForm({ ...phoneForm, phone: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                    Modalidad
                  </label>
                  <select
                    value={phoneForm.deliveryType}
                    onChange={e => setPhoneForm({ ...phoneForm, deliveryType: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="delivery">🛵 Delivery a Domicilio</option>
                    <option value="takeaway">🛍️ Retiro en Mostrador / Takeaway</option>
                  </select>
                </div>
              </div>

              {phoneForm.deliveryType === 'delivery' && (
                <div style={{ marginBottom: '12px' }}>
                  <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                    Dirección de Entrega *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Av. Belgrano 1420 3°B"
                    value={phoneForm.address}
                    onChange={e => setPhoneForm({ ...phoneForm, address: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              )}

              {/* Product Selection */}
              <div style={{ background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', marginBottom: '12px' }}>
                <label style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--primary)', display: 'block', marginBottom: '8px' }}>
                  🛒 Seleccionar Productos del Menú:
                </label>
                <div style={{ maxHeight: '160px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {menuItems.map(item => {
                    const isSelected = phoneForm.selectedItems.some(i => i.id === item.id);
                    return (
                      <div
                        key={item.id}
                        onClick={() => {
                          if (isSelected) {
                            setPhoneForm({
                              ...phoneForm,
                              selectedItems: phoneForm.selectedItems.filter(i => i.id !== item.id)
                            });
                          } else {
                            setPhoneForm({
                              ...phoneForm,
                              selectedItems: [...phoneForm.selectedItems, { ...item, quantity: 1 }]
                            });
                          }
                        }}
                        style={{
                          padding: '8px 10px',
                          borderRadius: '6px',
                          background: isSelected ? 'rgba(245, 158, 11, 0.15)' : 'var(--bg-card)',
                          border: isSelected ? '1px solid var(--primary)' : '1px solid var(--border-color)',
                          cursor: 'pointer',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}
                      >
                        <span style={{ fontSize: '0.85rem', fontWeight: isSelected ? 800 : 400 }}>
                          {item.title} (${item.price?.toLocaleString('es-AR')})
                        </span>
                        <span style={{ fontSize: '0.75rem', color: isSelected ? 'var(--primary)' : 'var(--text-muted)' }}>
                          {isSelected ? '✓ Seleccionado' : '+ Agregar'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Payment Method */}
              <div style={{ marginBottom: '14px' }}>
                <label style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-main)', display: 'block', marginBottom: '4px' }}>
                  Forma de Pago
                </label>
                <select
                  value={phoneForm.paymentMethod}
                  onChange={e => setPhoneForm({ ...phoneForm, paymentMethod: e.target.value })}
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '10px', borderRadius: 'var(--radius-sm)' }}
                >
                  <option value="efectivo">💵 Efectivo (Paga al entregar/retirar)</option>
                  <option value="mercadopago">📲 Transferencia Mercado Pago</option>
                  <option value="tarjeta">💳 Tarjeta Débito / Crédito</option>
                </select>
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '14px', fontSize: '1rem', fontWeight: 800 }}>
                🚀 Confirmar Pedido Telefónico & Enviar a Cocina
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
