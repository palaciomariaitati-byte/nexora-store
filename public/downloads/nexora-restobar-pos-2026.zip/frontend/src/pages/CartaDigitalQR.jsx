import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import { Utensils, ShoppingBag, CheckCircle, Clock, Plus, Minus, Send, Sparkles } from 'lucide-react';

/**
 * CartaDigitalQR.jsx: Carta Digital QR Mobile-First para Comensales en Mesa
 * 
 * 1. Lee el parámetro de mesa desde la URL (ej. ?mesa=3 o #carta?mesa=3).
 * 2. Al montarse, envía un POST automático a /api/mesas/ocupar para poner la mesa en rojo (ocupada) en Caja Central.
 * 3. Permite al cliente armar su pedido y enviarlo directamente a la cocina con 1 clic.
 */
export default function CartaDigitalQR() {
  // Obtener ID de la mesa desde query param o hash
  const getMesaFromUrl = () => {
    try {
      const search = new URLSearchParams(window.location.search);
      const queryMesa = search.get('mesa') || search.get('m') || search.get('table');
      if (queryMesa && !isNaN(queryMesa)) return Number(queryMesa);

      const hash = window.location.hash;
      const hashMatch = hash.match(/mesa=(\d+)/i) || hash.match(/mesa\/(\d+)/i);
      if (hashMatch && hashMatch[1]) return Number(hashMatch[1]);
    } catch (e) {
      console.error(e);
    }
    return 1; // Fallback Mesa 1
  };

  const mesaId = getMesaFromUrl();
  const [menu, setMenu] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('del-dia');
  const [cart, setCart] = useState([]);
  const [comensales, setComensales] = useState(2);
  const [dinerName, setDinerName] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [loading, setLoading] = useState(true);

  // Ocupar mesa automáticamente al escanear QR y cargar menú
  useEffect(() => {
    const initCarta = async () => {
      try {
        setLoading(true);

        // 1. Notificar a Caja Central que la mesa fue ocupada por escaneo de QR
        fetch('/api/mesas/ocupar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tableId: mesaId, comensales })
        }).catch((err) => console.warn('Aviso ocupar mesa:', err));

        // 2. Cargar Menú
        const menuData = await api.getMenu();
        setMenu(menuData.menu || []);
        setCategories(menuData.categories || []);
      } catch (err) {
        console.error('Error cargando carta digital:', err);
      } finally {
        setLoading(false);
      }
    };

    initCarta();
  }, [mesaId]);

  // Agregar al carrito
  const addToCart = (dish) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === dish.id);
      if (existing) {
        return prev.map((item) =>
          item.id === dish.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...dish, quantity: 1, notes: '' }];
    });
  };

  // Modificar cantidad
  const updateQuantity = (dishId, delta) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === dishId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean)
    );
  };

  // Total acumulado
  const totalCart = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Enviar pedido a cocina
  const handleSendOrder = async () => {
    if (cart.length === 0) return;

    try {
      const sessRes = await api.startSession(mesaId, comensales);
      const sessionId = sessRes.session?.id;

      await api.createOrder({
        sessionId,
        dinerName: dinerName.trim() ? `${dinerName.trim()} (${comensales} pers.)` : `Mesa ${mesaId} (${comensales} pers.)`,
        items: cart.map((i) => ({
          id: i.id,
          title: i.title,
          price: i.price,
          quantity: i.quantity,
          subtotal: i.price * i.quantity,
          notes: i.notes || orderNotes || ''
        }))
      });

      setIsSent(true);
      setCart([]);
    } catch (err) {
      alert('Error enviando pedido: ' + err.message);
    }
  };

  const filteredMenu = menu.filter((item) =>
    selectedCategory === 'all' ? true : item.category === selectedCategory
  );

  return (
    <div style={{
      maxWidth: '520px',
      margin: '0 auto',
      minHeight: '100vh',
      background: '#090d16',
      color: '#f8fafc',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      paddingBottom: '90px'
    }}>
      {/* HEADER DE CARTA QR */}
      <header style={{
        background: 'linear-gradient(135deg, #083344 0%, #1e293b 100%)',
        padding: '20px 18px',
        borderBottom: '2px solid rgba(228, 168, 52, 0.4)',
        position: 'sticky',
        top: 0,
        zIndex: 50
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: '#e4a834', fontWeight: 800, letterSpacing: '1px' }}>
              Carta Digital Inteligente
            </div>
            <h1 style={{ margin: '2px 0 0 0', fontSize: '1.4rem', fontWeight: 900 }}>
              Mesa #{mesaId}
            </h1>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '6px' }}>
            <div style={{
              background: 'rgba(16, 185, 129, 0.15)',
              border: '1px solid #10b981',
              color: '#10b981',
              padding: '4px 10px',
              borderRadius: '20px',
              fontSize: '0.72rem',
              fontWeight: 800,
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#10b981' }} />
              Mesa Ocupada
            </div>

            {/* Selector de Personas en la mesa */}
            <div style={{
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid rgba(245, 158, 11, 0.3)',
              borderRadius: '8px',
              padding: '2px 6px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.72rem'
            }}>
              <span style={{ color: '#94a3b8' }}>👥 Personas:</span>
              <button
                onClick={() => setComensales(Math.max(1, comensales - 1))}
                style={{ background: '#334155', border: 'none', color: '#fff', width: '20px', height: '20px', borderRadius: '4px', cursor: 'pointer', fontWeight: 800 }}
              >-</button>
              <strong style={{ color: '#f59e0b', fontSize: '0.85rem' }}>{comensales}</strong>
              <button
                onClick={() => setComensales(comensales + 1)}
                style={{ background: '#334155', border: 'none', color: '#fff', width: '20px', height: '20px', borderRadius: '4px', cursor: 'pointer', fontWeight: 800 }}
              >+</button>
            </div>
          </div>
        </div>

        {/* SELECTOR DE CATEGORÍAS */}
        <div style={{
          display: 'flex',
          gap: '8px',
          overflowX: 'auto',
          marginTop: '14px',
          paddingBottom: '4px'
        }}>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              style={{
                background: selectedCategory === cat.id ? 'linear-gradient(135deg, #e4a834, #d97706)' : 'rgba(255,255,255,0.08)',
                color: selectedCategory === cat.id ? '#083344' : '#94a3b8',
                border: 'none',
                padding: '6px 14px',
                borderRadius: '16px',
                fontSize: '0.78rem',
                fontWeight: 800,
                whiteSpace: 'nowrap',
                cursor: 'pointer'
              }}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </header>

      {/* CONFIRMACIÓN DE PEDIDO ENVIADO & DEMORA ESTIMADA EN VIVO */}
      {isSent && (
        <div style={{
          background: 'linear-gradient(145deg, rgba(16, 185, 129, 0.15) 0%, rgba(8, 51, 68, 0.4) 100%)',
          border: '1.5px solid #10b981',
          padding: '16px',
          margin: '16px',
          borderRadius: '16px',
          textAlign: 'center',
          boxShadow: '0 8px 24px rgba(0,0,0,0.4)'
        }}>
          <CheckCircle size={36} style={{ color: '#10b981', margin: '0 auto 8px auto' }} />
          <h3 style={{ margin: '0 0 4px 0', fontSize: '1.2rem', color: '#fff', fontWeight: 900 }}>¡Pedido en Cocina!</h3>
          <p style={{ margin: '0 0 12px 0', fontSize: '0.82rem', color: '#94a3b8' }}>
            Tu comanda fue recibida por la cocina y barra. Ya ingresó a elaboración.
          </p>

          {/* CHIP DE TIEMPO DE ESPERA ESTIMADO (15-25m máx 30m) */}
          <div style={{
            background: 'rgba(0, 0, 0, 0.65)',
            border: '1px solid rgba(245, 158, 11, 0.4)',
            borderRadius: '12px',
            padding: '10px 14px',
            marginBottom: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Clock size={20} style={{ color: '#f59e0b' }} />
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontSize: '0.72rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700 }}>
                  Tiempo Estimado de Salida
                </div>
                <div style={{ fontSize: '1.05rem', fontWeight: 900, color: '#f59e0b', fontFamily: 'var(--font-mono)' }}>
                  15 - 25 min máx.
                </div>
              </div>
            </div>
            <span style={{
              background: 'rgba(16, 185, 129, 0.2)',
              color: '#34d399',
              fontSize: '0.70rem',
              fontWeight: 800,
              padding: '4px 8px',
              borderRadius: '6px'
            }}>
              EN COLA VINCULADA
            </span>
          </div>

          <button
            onClick={() => setIsSent(false)}
            style={{
              background: '#10b981',
              color: '#fff',
              border: 'none',
              padding: '8px 18px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer'
            }}
          >
            + Pedir algo más
          </button>
        </div>
      )}

      {/* LISTADO DE PLATOS */}
      <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {filteredMenu.map((dish) => {
          const itemInCart = cart.find((i) => i.id === dish.id);
          return (
            <div
              key={dish.id}
              style={{
                background: 'linear-gradient(145deg, #131b2e 0%, #0d1322 100%)',
                borderRadius: '16px',
                padding: '14px',
                border: '1px solid rgba(245, 158, 11, 0.15)',
                display: 'flex',
                gap: '14px',
                alignItems: 'center',
                boxShadow: '0 8px 24px rgba(0, 0, 0, 0.45)',
                position: 'relative',
                overflow: 'hidden'
              }}
            >
              {dish.image && (
                <div style={{ position: 'relative', width: '95px', height: '95px', flexShrink: 0, borderRadius: '12px', overflow: 'hidden', boxShadow: '0 4px 12px rgba(0,0,0,0.5)' }}>
                  <img
                    src={dish.image}
                    alt={dish.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                  {dish.isDailySpecial ? (
                    <span style={{
                      position: 'absolute',
                      bottom: '4px',
                      left: '4px',
                      background: 'rgba(0,0,0,0.85)',
                      color: '#f59e0b',
                      fontSize: '0.58rem',
                      fontWeight: 800,
                      padding: '2px 5px',
                      borderRadius: '4px',
                      border: '1px solid rgba(245,158,11,0.5)'
                    }}>
                      ESPECIAL
                    </span>
                  ) : null}
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                  <h4 style={{ margin: 0, fontSize: '0.96rem', fontWeight: 800, color: '#f8fafc', letterSpacing: '-0.2px' }}>
                    {dish.title}
                  </h4>
                </div>
                <p style={{ margin: '0 0 8px 0', fontSize: '0.74rem', color: '#94a3b8', lineHeight: '1.35', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {dish.description}
                </p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '1.05rem', fontWeight: 900, color: '#f59e0b', fontFamily: 'var(--font-mono)' }}>
                    ${dish.price.toLocaleString('es-AR')}
                  </span>

                  {itemInCart ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#1e293b', padding: '4px 8px', borderRadius: '8px' }}>
                      <button
                        onClick={() => updateQuantity(dish.id, -1)}
                        style={{ background: '#334155', border: 'none', color: '#fff', width: '24px', height: '24px', borderRadius: '4px', cursor: 'pointer' }}
                      >
                        <Minus size={14} />
                      </button>
                      <span style={{ fontWeight: 800, color: '#e4a834' }}>{itemInCart.quantity}</span>
                      <button
                        onClick={() => updateQuantity(dish.id, 1)}
                        style={{ background: '#334155', border: 'none', color: '#fff', width: '24px', height: '24px', borderRadius: '4px', cursor: 'pointer' }}
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => addToCart(dish)}
                      style={{
                        background: 'linear-gradient(135deg, #e4a834, #d97706)',
                        color: '#083344',
                        border: 'none',
                        padding: '6px 14px',
                        borderRadius: '8px',
                        fontWeight: 800,
                        fontSize: '0.8rem',
                        cursor: 'pointer'
                      }}
                    >
                      + Agregar
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* BARRA FLOTANTE DE CHECKOUT (MESA COMENSAL) */}
      {cart.length > 0 && (
        <div style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          maxWidth: '520px',
          margin: '0 auto',
          background: 'rgba(8, 51, 68, 0.98)',
          borderTop: '2px solid #e4a834',
          padding: '14px 18px',
          backdropFilter: 'blur(10px)',
          zIndex: 99
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <span style={{ fontSize: '0.85rem', color: '#94a3b8' }}>
              {cart.reduce((s, i) => s + i.quantity, 0)} ítems seleccionados
            </span>
            <span style={{ fontSize: '1.2rem', fontWeight: 900, color: '#e4a834' }}>
              ${totalCart.toLocaleString('es-AR')}
            </span>
          </div>

          <button
            onClick={handleSendOrder}
            style={{
              width: '100%',
              background: 'linear-gradient(135deg, #10b981, #059669)',
              color: '#fff',
              border: 'none',
              padding: '12px',
              borderRadius: '10px',
              fontWeight: 900,
              fontSize: '0.95rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              boxShadow: '0 4px 16px rgba(16, 185, 129, 0.4)'
            }}
          >
            <Send size={18} />
            Enviar Pedido a Cocina
          </button>
        </div>
      )}
    </div>
  );
}
