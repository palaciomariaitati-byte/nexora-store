import React, { useState, useEffect } from 'react';
import { api, socket } from '../services/api';
import TicketCocinaPrint from '../components/TicketCocinaPrint';
import NoraAssistantWidget from '../components/NoraAssistantWidget';
import ModalImprimirQRs from '../components/ModalImprimirQRs';
import { Printer, Plus, Utensils, Clock, CheckCircle, RefreshCw, AlertTriangle, QrCode, Sparkles, Camera, EyeOff, ShieldCheck, Wifi } from 'lucide-react';

/**
 * CajaCentral.jsx: Layout Split-Screen para Terminal Única de Restobar
 * 
 * Lado Izquierdo: Grilla interactiva de mesas, toma de pedidos rápida y botón para disparar ticket térmico.
 * Lado Derecho: NoraAssistantWidget fijo y siempre accesible para dictar órdenes, consultar caja y escanear remitos.
 */
export default function CajaCentral() {
  const [tables, setTables] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [menu, setMenu] = useState([]);
  const [currentOrderItems, setCurrentOrderItems] = useState([]);
  const [dinerName, setDinerName] = useState('Salón');
  const [orderNotes, setOrderNotes] = useState('');
  const [activeTicketToPrint, setActiveTicketToPrint] = useState(null);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lowStockAlerts, setLowStockAlerts] = useState([]);
  
  // Feature-flag modular para el anexo de visión (VITE_ENABLE_NORA_VISION)
  const isVisionEnabledEnv = import.meta.env.VITE_ENABLE_NORA_VISION !== 'false' && import.meta.env.VITE_ENABLE_NORA_VISION !== false;
  const [isVisionModuleActive, setIsVisionModuleActive] = useState(isVisionEnabledEnv);

  // Telemetría y versión del sistema local
  const [systemVersion, setSystemVersion] = useState({ version: '2026.1.0', licenseStatus: 'active', synced: true });

  useEffect(() => {
    fetch('/api/system/version')
      .then(res => res.json())
      .then(data => {
        if (data.version) {
          setSystemVersion({
            version: data.version,
            licenseStatus: data.licenseStatus || 'active',
            synced: true
          });
        }
      })
      .catch(() => {
        setSystemVersion(prev => ({ ...prev, synced: false }));
      });
  }, []);

  // Cargar mesas, menú y alertas de stock
  const loadData = async () => {
    try {
      setLoading(true);
      const [tablesData, menuData, alertsData] = await Promise.all([
        api.getTables(),
        api.getMenu(),
        api.getLowStockAlerts()
      ]);
      setTables(tablesData || []);
      setMenu(menuData.menu || []);
      setLowStockAlerts(alertsData?.alerts || []);
      if (!selectedTable && tablesData && tablesData.length > 0) {
        setSelectedTable(tablesData[0]);
      }
    } catch (e) {
      console.error('Error cargando datos de Caja Central:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    socket.on('table_updated', () => loadData());
    socket.on('stock_alert', (data) => {
      if (data?.alerts) setLowStockAlerts(data.alerts);
    });
    socket.on('order_created', (data) => {
      loadData();
      if (data?.comandaTicket) {
        setActiveTicketToPrint(data.comandaTicket);
        setTimeout(() => {
          window.print();
        }, 300);
      }
    });

    socket.on('dish_ready', (data) => {
      loadData();
      // Alerta sonora sutil y toast
      try {
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        audio.volume = 0.5;
        audio.play().catch(() => {});
      } catch (e) {}

      // Toast emergente en Caja Central
      const notification = document.createElement('div');
      notification.innerHTML = `🔔 <strong>¡PLATO LISTO PARA SERVIR!</strong><br/>Mesa #${data.tableId} (${data.dinerName || 'Cliente'})`;
      notification.style.cssText = 'position:fixed;bottom:24px;right:24px;background:linear-gradient(135deg, #10b981, #059669);color:#fff;padding:16px 22px;border-radius:14px;box-shadow:0 10px 30px rgba(16,185,129,0.5);z-index:99999;font-size:0.92rem;font-weight:800;border:2px solid #fff;animation:fadeIn 0.3s ease;';
      document.body.appendChild(notification);
      setTimeout(() => { notification.remove(); }, 6000);
    });

    socket.on('inventory_updated', () => loadData());

    return () => {
      socket.off('table_updated');
      socket.off('order_created');
      socket.off('dish_ready');
      socket.off('inventory_updated');
    };
  }, []);

  // Agregar ítem al pedido en curso
  const handleAddItem = (dish) => {
    setCurrentOrderItems((prev) => {
      const existing = prev.find((i) => i.id === dish.id);
      if (existing) {
        return prev.map((i) => (i.id === dish.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { ...dish, quantity: 1, notes: '' }];
    });
  };

  // Modificar cantidad o eliminar
  const handleUpdateQty = (dishId, delta) => {
    setCurrentOrderItems((prev) =>
      prev
        .map((i) => {
          if (i.id === dishId) {
            const newQty = i.quantity + delta;
            return newQty > 0 ? { ...i, quantity: newQty } : null;
          }
          return i;
        })
        .filter(Boolean)
    );
  };

  // Enviar pedido y disparar impresión de comanda térmica
  const handleSendOrderAndPrint = async () => {
    if (!selectedTable || currentOrderItems.length === 0) return;

    try {
      // 1. Iniciar o recuperar sesión
      const sessRes = await api.startSession(selectedTable.id, 2);
      const sessionId = sessRes.session?.id;

      // 2. Crear comanda
      const orderRes = await api.createOrder({
        sessionId,
        dinerName: dinerName || 'Salón',
        items: currentOrderItems.map((i) => ({
          id: i.id,
          title: i.title,
          price: i.price,
          quantity: i.quantity,
          subtotal: i.price * i.quantity,
          notes: i.notes || orderNotes || ''
        }))
      });

      // 3. Preparar e invocar Ticket Térmico de Cocina (Sin precios)
      const ticket = {
        orderId: orderRes.order?.id || `ORD-${Date.now().toString().slice(-4)}`,
        tableName: selectedTable.name,
        dinerName,
        createdAt: new Date().toISOString(),
        items: currentOrderItems,
        notes: orderNotes
      };

      setActiveTicketToPrint(ticket);
      setCurrentOrderItems([]);
      setOrderNotes('');

      // Disparar ventana de impresión térmica nativa
      setTimeout(() => {
        window.print();
      }, 250);

      loadData();
    } catch (e) {
      alert('Error enviando comanda: ' + e.message);
    }
  };

  // Cobrar y Liberar Mesa (vuelve a color verde)
  const handleLiberarMesa = async () => {
    if (!selectedTable) return;
    if (!window.confirm(`¿Confirmas cobrar y liberar la ${selectedTable.name}?`)) return;

    try {
      const res = await fetch('/api/mesas/liberar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableId: selectedTable.id })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentOrderItems([]);
        setOrderNotes('');
        await loadData();
      } else {
        alert('Error liberando mesa: ' + data.error);
      }
    } catch (err) {
      alert('Error de conexión al liberar mesa: ' + err.message);
    }
  };

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: isVisionModuleActive ? '1fr 420px' : '1fr',
      gap: '16px',
      padding: '16px',
      height: 'calc(100vh - 75px)',
      boxSizing: 'border-box',
      background: 'var(--bg-main)',
      color: 'var(--text-main)',
      transition: 'grid-template-columns 0.25s ease'
    }}>
      {/* COMPONENTE OCULTO DE IMPRESIÓN TÉRMICA DE COCINA */}
      <TicketCocinaPrint ticketData={activeTicketToPrint} />

      {/* LADO IZQUIERDO: SALÓN, MESAS Y COMANDAS */}
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '14px',
        overflowY: 'auto',
        width: '100%'
      }}>
        {/* BANNER DE ALERTA DE STOCK CRÍTICO / FALTANTES PARA CAJA */}
        {lowStockAlerts.length > 0 && (
          <div style={{
            background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.15), rgba(185, 28, 28, 0.25))',
            border: '1px solid #ef4444',
            borderRadius: '10px',
            padding: '10px 14px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '8px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.82rem', color: '#fca5a5' }}>
              <AlertTriangle size={18} style={{ color: '#ef4444', flexShrink: 0 }} />
              <span>
                <strong style={{ color: '#fff' }}>Alerta de Faltantes ({lowStockAlerts.length} insumos al límite):</strong>{' '}
                {lowStockAlerts.slice(0, 3).map(a => `${a.name} (${a.currentStock} ${a.unit})`).join(', ')}
                {lowStockAlerts.length > 3 && ` y ${lowStockAlerts.length - 3} más.`}
              </span>
            </div>
            <a
              href="#deposito"
              style={{
                fontSize: '0.75rem',
                fontWeight: 800,
                color: '#fff',
                background: '#ef4444',
                padding: '4px 10px',
                borderRadius: '6px',
                textDecoration: 'none'
              }}
            >
              Ver Depósito ➔
            </a>
          </div>
        )}

        {/* GRILLA DE MESAS RÁPIDAS */}
        <div style={{
          background: 'var(--bg-card)',
          borderRadius: '12px',
          padding: '16px 18px',
          border: '1px solid var(--border-color)',
          boxShadow: 'var(--shadow-md)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <h3 style={{ margin: 0, fontSize: '0.95rem', color: 'var(--text-main)', fontWeight: 800 }}>
                Salón Activo — Seleccionar Mesa
              </h3>
              <button
                onClick={() => setIsQrModalOpen(true)}
                style={{
                  background: 'linear-gradient(135deg, #f59e0b, #d97706)',
                  color: '#000',
                  border: 'none',
                  padding: '4px 10px',
                  borderRadius: '6px',
                  fontSize: '0.72rem',
                  fontWeight: 800,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  boxShadow: '0 2px 8px rgba(245, 158, 11, 0.3)'
                }}
              >
                <QrCode size={13} />
                <span>Imprimir QRs Mesas & Paneles</span>
              </button>

              {/* Botón sutil de activación/demostración del Módulo Nora Vision */}
              {!isVisionModuleActive ? (
                <button
                  onClick={() => setIsVisionModuleActive(true)}
                  style={{
                    background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15), rgba(59, 130, 246, 0.2))',
                    color: '#38bdf8',
                    border: '1px solid rgba(56, 189, 248, 0.35)',
                    padding: '4px 12px',
                    borderRadius: '6px',
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    transition: 'all 0.2s ease'
                  }}
                  title="Desplegar módulo de escaneo de remitos, facturas y asistente de voz"
                >
                  <Sparkles size={13} style={{ color: '#38bdf8' }} />
                  <span>Activar Módulo Nora Vision (Demo 15 días)</span>
                </button>
              ) : (
                <button
                  onClick={() => setIsVisionModuleActive(false)}
                  style={{
                    background: 'rgba(255, 255, 255, 0.05)',
                    color: 'var(--text-muted)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    padding: '4px 8px',
                    borderRadius: '6px',
                    fontSize: '0.70rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                  title="Ocultar panel lateral de visión para expandir grilla de salón"
                >
                  <EyeOff size={12} />
                  <span>Ocultar Visión</span>
                </button>
              )}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Mesa actual: <strong style={{ color: 'var(--primary)' }}>{selectedTable?.name || 'Ninguna'}</strong>
              </span>

              {/* Indicador de Versión y Sincronización Local */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  background: 'rgba(255, 255, 255, 0.04)',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  borderRadius: '20px',
                  padding: '3px 9px',
                  fontSize: '0.68rem',
                  color: '#94a3b8',
                  fontFamily: 'monospace'
                }}
                title={`Restobar POS v${systemVersion.version} - Estado: ${systemVersion.licenseStatus} (SQLite Local)`}
              >
                <span
                  style={{
                    width: '6px',
                    height: '6px',
                    borderRadius: '50%',
                    background: systemVersion.synced ? '#10b981' : '#f59e0b',
                    display: 'inline-block'
                  }}
                />
                <span>v{systemVersion.version}</span>
                <span style={{ color: '#0ea5e9', fontWeight: 'bold' }}>Core OK</span>
              </div>
            </div>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(75px, 1fr))',
            gap: '10px',
            maxHeight: '125px',
            overflowY: 'auto'
          }}>
            {tables.map((t) => {
              const isSelected = selectedTable?.id === t.id;
              const isOcupada = t.status !== 'libre';
              return (
                <button
                  key={t.id}
                  onClick={() => setSelectedTable(t)}
                  style={{
                    padding: '8px 4px',
                    borderRadius: '12px',
                    border: isSelected ? '2px solid #f59e0b' : '1px solid var(--border-color)',
                    background: isSelected 
                      ? 'linear-gradient(180deg, rgba(245, 158, 11, 0.2) 0%, rgba(19, 25, 38, 0.95) 100%)' 
                      : (isOcupada ? 'linear-gradient(180deg, rgba(239, 68, 68, 0.15) 0%, rgba(19, 25, 38, 0.9) 100%)' : 'var(--bg-card-hover)'),
                    color: 'var(--text-main)',
                    fontWeight: 700,
                    fontSize: '0.78rem',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px',
                    boxShadow: isSelected 
                      ? '0 0 14px rgba(245, 158, 11, 0.45), inset 0 0 10px rgba(245, 158, 11, 0.2)' 
                      : (isOcupada ? '0 0 8px rgba(239, 68, 68, 0.25)' : 'var(--shadow-sm)'),
                    transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <div style={{
                    width: '18px',
                    height: '18px',
                    borderRadius: '50%',
                    border: isOcupada ? '2px solid #ef4444' : '2px solid #10b981',
                    boxShadow: isOcupada ? '0 0 8px #ef4444' : '0 0 8px #10b981',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '0.55rem',
                    fontWeight: 900
                  }}>
                    {t.id}
                  </div>
                  <span style={{
                    fontSize: '0.62rem',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: isOcupada ? '#f87171' : '#34d399'
                  }}>
                    {isOcupada ? 'Ocupada' : 'Libre'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* CATÁLOGO RÁPIDO & COMANDERA DE CARGA */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1.2fr 0.8fr',
          gap: '14px',
          flex: 1,
          minHeight: 0
        }}>
          {/* Menú de Platos */}
          <div style={{
            background: 'var(--bg-card)',
            borderRadius: '12px',
            padding: '16px',
            border: '1px solid var(--border-color)',
            boxShadow: 'var(--shadow-md)',
            display: 'flex',
            flexDirection: 'column'
          }}>
            <h4 style={{ margin: '0 0 12px 0', fontSize: '0.92rem', color: 'var(--text-main)', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '6px' }}>
              🍔 Menú & Platos Rápidos
            </h4>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
              gap: '12px',
              overflowY: 'auto',
              flex: 1,
              paddingRight: '4px'
            }}>
              {menu.map((dish) => (
                <div
                  key={dish.id}
                  onClick={() => handleAddItem(dish)}
                  style={{
                    background: 'var(--bg-card-hover)',
                    borderRadius: '12px',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    border: '1px solid var(--border-color)',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
                    boxShadow: 'var(--shadow-sm)',
                    position: 'relative'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-3px)';
                    e.currentTarget.style.borderColor = 'var(--primary)';
                    e.currentTarget.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.5), 0 0 15px rgba(245, 158, 11, 0.25)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
                  }}
                >
                  {/* Foto de Plato Gourmet */}
                  {dish.image ? (
                    <div style={{ width: '100%', height: '85px', overflow: 'hidden', position: 'relative' }}>
                      <img
                        src={dish.image}
                        alt={dish.title}
                        style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s ease' }}
                        onError={(e) => { e.currentTarget.style.display = 'none'; }}
                      />
                      {dish.tag && (
                        <span style={{
                          position: 'absolute',
                          top: '6px',
                          left: '6px',
                          background: 'rgba(0,0,0,0.75)',
                          backdropFilter: 'blur(6px)',
                          color: '#f59e0b',
                          fontSize: '0.62rem',
                          fontWeight: 800,
                          padding: '2px 6px',
                          borderRadius: '6px',
                          border: '1px solid rgba(245, 158, 11, 0.4)'
                        }}>
                          {dish.tag}
                        </span>
                      )}
                    </div>
                  ) : null}

                  <div style={{ padding: '10px', display: 'flex', flexDirection: 'column', gap: '4px', flex: 1, justifyContent: 'space-between' }}>
                    <div style={{ fontWeight: 700, fontSize: '0.80rem', color: 'var(--text-main)', lineHeight: '1.2' }}>
                      {dish.title}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px' }}>
                      <span style={{ fontWeight: 800, fontSize: '0.90rem', color: 'var(--primary)', fontFamily: 'var(--font-mono)' }}>
                        ${dish.price.toLocaleString('es-AR')}
                      </span>
                      <span style={{
                        background: 'rgba(245, 158, 11, 0.15)',
                        color: 'var(--primary)',
                        width: '22px',
                        height: '22px',
                        borderRadius: '6px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '0.85rem',
                        fontWeight: 800
                      }}>+</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Resumen de Comanda a Despachar */}
          <div style={{
            background: 'var(--bg-card)',
            borderRadius: '12px',
            padding: '16px',
            border: '1px solid var(--border-color)',
            boxShadow: 'var(--shadow-md)',
            display: 'flex',
            flexDirection: 'column'
          }}>
            <h4 style={{ margin: '0 0 12px 0', fontSize: '0.92rem', color: 'var(--text-main)', fontWeight: 800 }}>
              📝 Comanda Actual: {selectedTable?.name || 'Sin Mesa'}
            </h4>

            {/* Lista de ítems */}
            <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {currentOrderItems.length === 0 ? (
                <div style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.82rem', padding: '30px 10px' }}>
                  Toca platos a la izquierda para armar la orden.
                </div>
              ) : (
                currentOrderItems.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      background: 'var(--bg-card-hover)',
                      padding: '10px 12px',
                      borderRadius: '8px',
                      border: '1px solid var(--border-color)',
                      boxShadow: 'var(--shadow-sm)'
                    }}
                  >
                    <div style={{ fontSize: '0.82rem', color: 'var(--text-main)', fontWeight: 600 }}>
                      {item.title}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <button
                        onClick={() => handleUpdateQty(item.id, -1)}
                        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: 'var(--text-main)', width: '24px', height: '24px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}
                      >
                        -
                      </button>
                      <span style={{ fontSize: '0.82rem', fontWeight: 800, color: 'var(--primary)', minWidth: '16px', textAlign: 'center' }}>{item.quantity}</span>
                      <button
                        onClick={() => handleUpdateQty(item.id, 1)}
                        style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: 'var(--text-main)', width: '24px', height: '24px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}
                      >
                        +
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Input notas de comanda */}
            <input
              type="text"
              placeholder="Notas para cocina (ej: sin sal, punto jugoso)"
              value={orderNotes}
              onChange={(e) => setOrderNotes(e.target.value)}
              style={{
                width: '100%',
                background: '#0b0f19',
                border: '1px solid rgba(255,255,255,0.1)',
                padding: '8px',
                borderRadius: '6px',
                color: '#fff',
                fontSize: '0.78rem',
                margin: '10px 0',
                boxSizing: 'border-box'
              }}
            />

            {/* Botón de Enviar e Imprimir */}
            <button
              onClick={handleSendOrderAndPrint}
              disabled={currentOrderItems.length === 0}
              style={{
                background: currentOrderItems.length > 0 ? 'linear-gradient(135deg, #10b981, #059669)' : '#334155',
                color: '#fff',
                border: 'none',
                padding: '12px',
                borderRadius: '8px',
                fontWeight: 800,
                fontSize: '0.88rem',
                cursor: currentOrderItems.length > 0 ? 'pointer' : 'default',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                marginBottom: '8px'
              }}
            >
              <Printer size={16} />
              Enviar a Cocina & Imprimir
            </button>

            {/* Botón de Cobrar y Liberar Mesa */}
            <button
              onClick={handleLiberarMesa}
              disabled={!selectedTable || selectedTable.status === 'libre'}
              style={{
                background: selectedTable?.status !== 'libre' ? 'linear-gradient(135deg, #ef4444, #dc2626)' : '#334155',
                color: '#fff',
                border: 'none',
                padding: '10px',
                borderRadius: '8px',
                fontWeight: 800,
                fontSize: '0.85rem',
                cursor: selectedTable?.status !== 'libre' ? 'pointer' : 'not-allowed',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                boxShadow: selectedTable?.status !== 'libre' ? '0 4px 14px rgba(239, 68, 68, 0.4)' : 'none'
              }}
            >
              <CheckCircle size={16} />
              Cobrar y Liberar Mesa
            </button>
          </div>
        </div>
      </div>

      {/* LADO DERECHO: NORA AI WIDGET CONVERSACIONAL MODULAR (Feature-Flag) */}
      {isVisionModuleActive && (
        <div style={{ height: '100%', minWidth: '400px' }}>
          <NoraAssistantWidget onInventoryChanged={() => loadData()} />
        </div>
      )}

      {/* MODAL DE IMPRESIÓN DE CÓDIGOS QR INDIVIDUALES Y PANELES */}
      <ModalImprimirQRs
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
        tables={tables}
      />
    </div>
  );
}
