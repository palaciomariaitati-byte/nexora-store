import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  Users, ShoppingBag, Sparkles, Utensils, Wine, Cake, 
  Plus, Minus, Check, CreditCard, QrCode, ArrowRight, 
  DollarSign, Clock, HelpCircle, X, ShieldCheck, Copy
} from 'lucide-react';
import { api, socket } from '../services/api';

export default function ClientApp({ tableId = 1 }) {
  // State
  const [comensales, setComensales] = useState(2);
  const [session, setSession] = useState(null);
  const [categories, setCategories] = useState([]);
  const [menu, setMenu] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('del-dia');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Customization modal state
  const [customizingItem, setCustomizingItem] = useState(null);
  const [itemNote, setItemNote] = useState('');
  const [dinerName, setDinerName] = useState('Comensal 1');

  // Checkout Payment States
  const [paymentType, setPaymentType] = useState('total'); // 'total' | 'individual'
  const [selectedItemsToPay, setSelectedItemsToPay] = useState([]);
  const [tipPercentage, setTipPercentage] = useState(10);
  const [customTip, setCustomTip] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('mercado_pago');
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [completedPaymentData, setCompletedPaymentData] = useState(null);

  // Load Menu and Table Session on Mount & Table Switch
  useEffect(() => {
    loadData();

    socket.emit('join_room', `table_${tableId}`);

    const handleTableUpdated = (data) => {
      if (Number(data.tableId) === Number(tableId)) {
        refreshOrders();
      }
    };

    const handleOrderStatusChanged = (data) => {
      refreshOrders();
    };

    const handleDishReady = (data) => {
      refreshOrders();
      if (Number(data.tableId) === Number(tableId)) {
        try {
          const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
          audio.volume = 0.6;
          audio.play().catch(() => {});
        } catch (e) {}
        alert(`🔔 ¡COCINA AVISA: PLATO LISTO PARA SERVIR EN ESTA MESA #${tableId}!`);
      }
    };

    socket.on('table_updated', handleTableUpdated);
    socket.on('order_status_changed', handleOrderStatusChanged);
    socket.on('dish_ready', handleDishReady);

    return () => {
      socket.off('table_updated', handleTableUpdated);
      socket.off('order_status_changed', handleOrderStatusChanged);
      socket.off('dish_ready', handleDishReady);
    };
  }, [tableId]);

  const loadData = async () => {
    try {
      const menuRes = await api.getMenu();
      setCategories(menuRes.categories);
      setMenu(menuRes.menu);

      const tableData = await api.getTable(tableId);
      if (tableData.activeSession) {
        setSession(tableData.activeSession);
        setOrders(tableData.orders || []);
      } else {
        // Automatically start session if none active
        const newSess = await api.startSession(tableId, comensales);
        setSession(newSess.session);
        setOrders([]);
      }
    } catch (err) {
      console.error('Error loading client data:', err);
    }
  };

  const refreshOrders = async () => {
    try {
      const tableData = await api.getTable(tableId);
      if (tableData.activeSession) {
        setSession(tableData.activeSession);
        setOrders(tableData.orders || []);
      }
    } catch (err) {
      console.error('Error refreshing orders:', err);
    }
  };

  const handleStartSession = async (count) => {
    setComensales(count);
    const res = await api.startSession(tableId, count);
    setSession(res.session);
  };

  // Cart operations
  const openCustomizeModal = (item) => {
    setCustomizingItem(item);
    setItemNote('');
  };

  const addToCart = (item, note = '') => {
    setCart(prev => {
      const existingIndex = prev.findIndex(i => i.menuItemId === item.id && i.notes === note);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += 1;
        return updated;
      }
      return [...prev, {
        menuItemId: item.id,
        title: item.title,
        price: item.price,
        image: item.image,
        category: item.category,
        quantity: 1,
        notes: note
      }];
    });
    setCustomizingItem(null);
  };

  const updateCartQuantity = (index, delta) => {
    setCart(prev => {
      const updated = [...prev];
      const newQty = updated[index].quantity + delta;
      if (newQty <= 0) {
        updated.splice(index, 1);
      } else {
        updated[index].quantity = newQty;
      }
      return updated;
    });
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  // Submit Order to Kitchen & Bar
  const handleSendOrder = async () => {
    if (!session || cart.length === 0) return;

    try {
      const res = await api.createOrder({
        sessionId: session.id,
        dinerName,
        items: cart
      });

      if (res.success) {
        setCart([]);
        setIsCartOpen(false);
        refreshOrders();
      }
    } catch (err) {
      alert('Error enviando pedido: ' + err.message);
    }
  };

  // Timer ticker state for live 60-second countdowns
  const [nowTime, setNowTime] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => {
      setNowTime(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const recentCancellableOrders = orders.filter(ord => {
    if (ord.status === 'cancelled') return false;
    const elapsed = Math.floor((nowTime - new Date(ord.createdAt).getTime()) / 1000);
    return elapsed >= 0 && elapsed < 60;
  });

  const handleCancelOrder = async (orderId) => {
    if (!confirm('¿Confirmas anular este pedido antes de que pase a cocina?')) return;
    try {
      const res = await api.cancelOrder(orderId);
      if (res.success) {
        alert('✅ Pedido anulado con éxito. No se enviará a cocina ni se cobrará.');
        refreshOrders();
      }
    } catch (err) {
      alert('Error anulando pedido: ' + err.message);
    }
  };

  // Accumulated Session Unpaid Items
  const allUnpaidItems = orders.flatMap(order => 
    (order.items || [])
      .filter(item => !item.isPaid && order.status !== 'cancelled')
      .map(item => ({ ...item, orderId: order.id, orderCreated: order.createdAt }))
  );

  const accumulatedUnpaidTotal = allUnpaidItems.reduce((sum, item) => sum + item.subtotal, 0);

  // Auto pre-select all unpaid items when checkout modal opens or order list changes
  useEffect(() => {
    if (allUnpaidItems.length > 0) {
      if (selectedItemsToPay.length === 0 || paymentType === 'total') {
        setSelectedItemsToPay(allUnpaidItems.map(item => item.id));
      }
    }
  }, [isCheckoutOpen, paymentType, orders.length]);

  // Split Payment helper
  const toggleItemForPayment = (itemId) => {
    setSelectedItemsToPay(prev => 
      prev.includes(itemId) ? prev.filter(id => id !== itemId) : [...prev, itemId]
    );
  };

  const calculateSubtotalToPay = () => {
    if (paymentType === 'total') {
      return accumulatedUnpaidTotal;
    }
    return allUnpaidItems
      .filter(item => selectedItemsToPay.includes(item.id))
      .reduce((sum, item) => sum + item.subtotal, 0);
  };

  const subtotalToPay = calculateSubtotalToPay();
  
  const activeTipPercent = customTip !== '' ? Number(customTip) : tipPercentage;
  const tipAmount = Math.round((subtotalToPay * activeTipPercent) / 100);
  const grandTotalToPay = subtotalToPay + tipAmount;

  // Process Final Payment
  const handleProcessPayment = async () => {
    if (subtotalToPay <= 0) {
      alert('Selecciona al menos un producto para abonar');
      return;
    }

    const itemsPaying = paymentType === 'total' 
      ? allUnpaidItems 
      : allUnpaidItems.filter(item => selectedItemsToPay.includes(item.id));

    try {
      const res = await api.processPayment({
        sessionId: session.id,
        tableId,
        dinerName,
        paidItems: itemsPaying,
        paymentMethod,
        subtotal: subtotalToPay,
        tipPercentage: activeTipPercent,
        tipAmount,
        totalAmount: grandTotalToPay
      });

      if (res.success) {
        setCompletedPaymentData(res.receiptTicket);
        setPaymentCompleted(true);
        refreshOrders();
      }
    } catch (err) {
      alert('Error al procesar el pago: ' + err.message);
    }
  };

  // Filtered Menu Items
  const filteredMenu = menu.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div style={{ maxWidth: '640px', margin: '0 auto', padding: '16px 16px 100px 16px' }}>
      
      {/* Header Banner: Table Info & Diner Selector */}
      <div className="glass-accent" style={{ padding: '16px', borderRadius: 'var(--radius-lg)', marginBottom: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span className="badge badge-warning" style={{ background: 'var(--primary-light)', color: 'var(--primary)', borderColor: 'var(--border-accent)' }}>
                <QrCode size={12} /> QR ESCANEADO
              </span>
              <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--primary)', letterSpacing: '0.5px' }}>Nexora One</span>
            </div>
            <h1 style={{ fontSize: '1.6rem', fontWeight: 800, marginTop: '4px' }}>
              Mesa #{tableId}
            </h1>
          </div>

          {/* Comensales Picker */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Comensales</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'var(--bg-card)', padding: '4px 8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
              <button 
                onClick={() => handleStartSession(Math.max(1, comensales - 1))}
                style={{ background: 'none', border: 'none', color: 'var(--primary)', cursor: 'pointer' }}
              >
                <Minus size={14} />
              </button>
              <span style={{ fontWeight: 700, minWidth: '20px', textAlign: 'center' }}>{comensales}</span>
              <button 
                onClick={() => handleStartSession(comensales + 1)}
                style={{ background: 'none', border: 'none', color: 'var(--primary)', cursor: 'pointer' }}
              >
                <Plus size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Input Diner Name */}
        <div style={{ marginTop: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>Tu nombre:</span>
          <input
            type="text"
            value={dinerName}
            onChange={(e) => setDinerName(e.target.value)}
            placeholder="Ej: Javier"
            style={{
              width: '100%',
              background: 'var(--bg-card)',
              border: '1px solid var(--border-color)',
              color: 'var(--text-main)',
              padding: '6px 12px',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.85rem'
            }}
          />
        </div>
      </div>

      {/* SOCIAL MEDIA & PHOTO SHARING FOR TABLE CLIENTS */}
      <div className="glass-accent" style={{ padding: '16px 20px', borderRadius: 'var(--radius-lg)', marginBottom: '20px', border: '1px solid var(--border-accent)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '1.2rem' }}>📸</span>
            <div>
              <div style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--primary)' }}>
                ¡Subí tu Foto o Comentario desde Mesa {tableId}!
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                Compartí tu experiencia en Instagram, Google o TikTok y etiquetanos
              </div>
            </div>
          </div>
        </div>

        {/* Dual Actions: Camera Capture + Review links */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px', marginTop: '10px' }}>
          
          {/* Direct Photo Upload */}
          <label style={{
            background: 'var(--bg-main)',
            border: '2px dashed var(--primary)',
            padding: '10px',
            borderRadius: 'var(--radius-sm)',
            textAlign: 'center',
            cursor: 'pointer',
            display: 'block'
          }}>
            <div style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--primary)', marginBottom: '4px' }}>
              📷 Tomar Foto a la Mesa / Plato
            </div>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  alert(`📸 ¡Foto capturada desde Mesa ${tableId}!\n\n¡Gracias por compartir tu momento! Podés etiquetarnos en Instagram: @bar.myjnecoravisual`);
                }
              }}
              style={{ display: 'none' }}
            />
            <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Toca para abrir cámara</span>
          </label>

          {/* Social Links */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noreferrer"
              style={{ background: 'linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)', textDecoration: 'none', fontSize: '0.8rem', fontWeight: 800, textAlign: 'center' }}
            >
              📸 Subir & Etiquetar en Instagram
            </a>
            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noreferrer"
              style={{ background: '#4285F4', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)', textDecoration: 'none', fontSize: '0.8rem', fontWeight: 800, textAlign: 'center' }}
            >
              ⭐ Dejar Reseña en Google Maps
            </a>
          </div>

        </div>
      </div>

      {/* 60-SECOND CANCELLATION / GRACE PERIOD BANNER */}
      {recentCancellableOrders.length > 0 && (
        <div style={{ marginBottom: '20px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {recentCancellableOrders.map(ord => {
            const elapsed = Math.floor((nowTime - new Date(ord.createdAt).getTime()) / 1000);
            const secondsLeft = Math.max(0, 60 - elapsed);
            const progressPercent = Math.round((secondsLeft / 60) * 100);

            return (
              <div
                key={ord.id}
                className="glass animate-fade-in"
                style={{
                  padding: '16px',
                  borderRadius: 'var(--radius-lg)',
                  border: '1px solid #f59e0b',
                  background: 'rgba(245,158,11,0.08)'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 800, color: '#f59e0b', fontSize: '0.95rem' }}>
                    <Clock size={18} className="animate-spin" />
                    <span>Período de Gracia: {secondsLeft}s restantes</span>
                  </div>
                  <span className="badge badge-warning">MARCHANDO EN BREVE</span>
                </div>

                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '10px' }}>
                  Tenés <strong>60 segundos</strong> para anular o modificar tu pedido antes de que la cocina comience la elaboración.
                </p>

                {/* Progress bar */}
                <div style={{ height: '6px', background: 'var(--bg-main)', borderRadius: '99px', overflow: 'hidden', marginBottom: '12px' }}>
                  <div 
                    style={{
                      height: '100%',
                      width: `${progressPercent}%`,
                      background: 'linear-gradient(90deg, #f59e0b, #ef4444)',
                      transition: 'width 1s linear'
                    }}
                  />
                </div>

                {/* Items preview */}
                <div style={{ fontSize: '0.85rem', fontWeight: 600, marginBottom: '12px' }}>
                  {ord.items.map(i => `${i.quantity}x ${i.title}`).join(', ')} (${ord.totalAmount.toLocaleString('es-AR')})
                </div>

                {/* Cancel Button */}
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleCancelOrder(ord.id)}
                    className="btn btn-danger"
                    style={{ flex: 1, padding: '8px 12px', fontSize: '0.85rem' }}
                  >
                    🚫 Anular Pedido ({secondsLeft}s)
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Account Balance Summary Bar (Cuenta Abierta) */}
      {allUnpaidItems.length > 0 && (
        <div 
          onClick={() => setIsCheckoutOpen(true)}
          className="glass animate-glow" 
          style={{
            padding: '14px 18px',
            borderRadius: 'var(--radius-md)',
            marginBottom: '20px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderLeft: '4px solid var(--primary)',
            cursor: 'pointer'
          }}
        >
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 700, textTransform: 'uppercase' }}>
              Cuenta Abierta en Mesa #{tableId}
            </div>
            <div style={{ fontSize: '1.2rem', fontWeight: 800 }}>
              ${accumulatedUnpaidTotal.toLocaleString('es-AR')}
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              {allUnpaidItems.length} ítems consumidos · Toca para pagar o dividir
            </span>
          </div>

          <button className="btn btn-primary" style={{ padding: '8px 14px', fontSize: '0.85rem' }}>
            Pedir Cuenta
          </button>
        </div>
      )}

      {/* Category Tabs (Platos del Día, A la carta, Bebidas, Postres) */}
      <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '8px', marginBottom: '16px' }}>
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            style={{
              padding: '10px 16px',
              borderRadius: 'var(--radius-md)',
              whiteSpace: 'nowrap',
              fontWeight: 600,
              fontSize: '0.9rem',
              border: selectedCategory === cat.id ? '1px solid var(--primary)' : '1px solid var(--border-color)',
              background: selectedCategory === cat.id ? 'var(--primary-light)' : 'var(--bg-card)',
              color: selectedCategory === cat.id ? 'var(--primary)' : 'var(--text-main)',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Menu Cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {filteredMenu.map(item => (
          <div 
            key={item.id}
            className="glass"
            style={{
              borderRadius: 'var(--radius-md)',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'row',
              gap: '12px',
              padding: '12px',
              position: 'relative',
              transition: 'transform 0.2s ease',
              border: item.isDailySpecial ? '1px solid rgba(245,158,11,0.5)' : '1px solid var(--border-color)'
            }}
          >
            {/* Daily Special Highlight Badge */}
            {item.isDailySpecial && (
              <div style={{
                position: 'absolute',
                top: '8px',
                left: '8px',
                background: 'linear-gradient(135deg, #f59e0b, #d97706)',
                color: '#000',
                fontWeight: 800,
                fontSize: '0.65rem',
                padding: '3px 8px',
                borderRadius: '99px',
                zIndex: 2,
                boxShadow: '0 2px 8px rgba(0,0,0,0.5)'
              }}>
                🌟 PLATO DEL DÍA
              </div>
            )}

            {/* Thumbnail */}
            <div style={{ width: '100px', height: '100px', borderRadius: 'var(--radius-sm)', overflow: 'hidden', flexShrink: 0, position: 'relative' }}>
              <img 
                src={item.image} 
                alt={item.title} 
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
            </div>

            {/* Info */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-main)' }}>
                  {item.title}
                </h3>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '4px', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {item.description}
                </p>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '8px' }}>
                <span style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--primary)' }}>
                  ${item.price.toLocaleString('es-AR')}
                </span>

                <button
                  onClick={() => openCustomizeModal(item)}
                  className="btn btn-primary"
                  style={{ padding: '6px 14px', fontSize: '0.82rem', fontWeight: 700 }}
                >
                  <Plus size={14} /> Personalizar Ingredientes
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Floating Bottom Cart Bar */}
      {cart.length > 0 && (
        <div style={{ position: 'fixed', bottom: '20px', left: '16px', right: '16px', maxWidth: '608px', margin: '0 auto', zIndex: 90 }}>
          <div 
            onClick={() => setIsCartOpen(true)}
            className="glass animate-fade-in"
            style={{
              background: 'linear-gradient(135deg, #f59e0b, #d97706)',
              color: '#000',
              padding: '14px 20px',
              borderRadius: 'var(--radius-lg)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxShadow: '0 10px 30px rgba(245,158,11,0.5)',
              cursor: 'pointer'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ background: '#000', color: '#fff', borderRadius: '99px', padding: '6px 12px', fontWeight: 800, fontSize: '0.9rem' }}>
                {cart.reduce((s, i) => s + i.quantity, 0)}
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: '1rem' }}>Ver Mi Pedido</div>
                <div style={{ fontSize: '0.75rem', opacity: 0.9 }}>Mesa #{tableId} · {dinerName}</div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 800, fontSize: '1.2rem' }}>
              ${cartTotal.toLocaleString('es-AR')}
              <ArrowRight size={20} />
            </div>
          </div>
        </div>
      )}

      {/* ITEM CUSTOMIZATION & INGREDIENTS MODAL */}
      {customizingItem && (
        <ItemCustomizerModal 
          item={customizingItem}
          onClose={() => setCustomizingItem(null)}
          onAddToCart={(itemToAdd, finalPrice, noteString, quitados, extras) => {
            setCart(prev => {
              const existingIndex = prev.findIndex(i => i.menuItemId === itemToAdd.id && i.notes === noteString);
              if (existingIndex > -1) {
                const updated = [...prev];
                updated[existingIndex].quantity += 1;
                return updated;
              }
              return [...prev, {
                menuItemId: itemToAdd.id,
                title: itemToAdd.title,
                price: finalPrice,
                image: itemToAdd.image,
                category: itemToAdd.category,
                quantity: 1,
                notes: noteString,
                ingredientesQuitados: quitados || [],
                ingredientesExtras: extras || []
              }];
            });
            setCustomizingItem(null);
          }}
        />
      )}

      {/* CART & ORDER MODAL */}
      {isCartOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsCartOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <ShoppingBag style={{ color: 'var(--primary)' }} />
                Confirmar Pedido a la Caja
              </h3>
              <button onClick={() => setIsCartOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            {/* Cart Items */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '20px' }}>
              {cart.map((item, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-main)', padding: '10px 14px', borderRadius: 'var(--radius-md)' }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>{item.title}</div>
                    {item.notes && <div style={{ fontSize: '0.75rem', color: 'var(--primary)' }}>Nota: {item.notes}</div>}
                    <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>${item.price.toLocaleString('es-AR')} c/u</div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <button onClick={() => updateCartQuantity(idx, -1)} style={{ background: 'var(--bg-card-hover)', border: 'none', color: '#fff', padding: '4px 8px', borderRadius: '4px', cursor: 'pointer' }}>-</button>
                    <span style={{ fontWeight: 700 }}>{item.quantity}</span>
                    <button onClick={() => updateCartQuantity(idx, 1)} style={{ background: 'var(--bg-card-hover)', border: 'none', color: '#fff', padding: '4px 8px', borderRadius: '4px', cursor: 'pointer' }}>+</button>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '16px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.2rem', fontWeight: 800 }}>
                <span>Subtotal Ronda:</span>
                <span style={{ color: 'var(--primary)' }}>${cartTotal.toLocaleString('es-AR')}</span>
              </div>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                * Este pedido se sumará a la cuenta abierta de la Mesa #{tableId}. Podrás pagar todo o dividir al solicitar la cuenta final.
              </p>
            </div>

            <button
              onClick={handleSendOrder}
              className="btn btn-primary"
              style={{ width: '100%', padding: '16px', fontSize: '1.05rem' }}
            >
              🚀 Marchar Pedido a Cocina / Caja
            </button>
          </div>
        </div>
      )}

      {/* CHECKOUT / SOLICITAR CUENTA & PAGO INDIVIDUAL MODAL */}
      {isCheckoutOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsCheckoutOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '600px' }}>
            
            {!paymentCompleted ? (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                  <div>
                    <h3 style={{ fontSize: '1.3rem', fontWeight: 800 }}>Pagar Cuenta · Mesa #{tableId}</h3>
                    <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--primary)' }}>Nexora One SmartPOS</span>
                  </div>
                  <button onClick={() => setIsCheckoutOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                    <X size={24} />
                  </button>
                </div>

                {/* Switch Pago Total vs Pago Individual */}
                <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', background: 'var(--bg-main)', padding: '4px', borderRadius: 'var(--radius-md)' }}>
                  <button
                    onClick={() => setPaymentType('total')}
                    className={`btn ${paymentType === 'total' ? 'btn-primary' : 'btn-secondary'}`}
                    style={{ flex: 1, padding: '10px', fontSize: '0.85rem' }}
                  >
                    💳 Pagar Cuenta Total Mesa
                  </button>
                  <button
                    onClick={() => setPaymentType('individual')}
                    className={`btn ${paymentType === 'individual' ? 'btn-primary' : 'btn-secondary'}`}
                    style={{ flex: 1, padding: '10px', fontSize: '0.85rem' }}
                  >
                    👤 Pago Individual / Mi Consumo
                  </button>
                </div>

                {/* Item selection for Individual Payment */}
                {paymentType === 'individual' && (
                  <div style={{ marginBottom: '16px' }}>
                    <h4 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                      Selecciona los productos que vas a abonar:
                    </h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', maxHeight: '200px', overflowY: 'auto' }}>
                      {allUnpaidItems.map(item => (
                        <div 
                          key={item.id}
                          onClick={() => toggleItemForPayment(item.id)}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            padding: '10px 12px',
                            borderRadius: 'var(--radius-sm)',
                            background: selectedItemsToPay.includes(item.id) ? 'var(--primary-light)' : 'var(--bg-main)',
                            border: selectedItemsToPay.includes(item.id) ? '1px solid var(--primary)' : '1px solid var(--border-color)',
                            cursor: 'pointer'
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <div style={{
                              width: '20px',
                              height: '20px',
                              borderRadius: '4px',
                              border: '2px solid var(--primary)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              background: selectedItemsToPay.includes(item.id) ? 'var(--primary)' : 'transparent'
                            }}>
                              {selectedItemsToPay.includes(item.id) && <Check size={14} color="#000" />}
                            </div>
                            <div>
                              <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{item.title}</div>
                              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{item.dinerName}</div>
                            </div>
                          </div>

                          <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>
                            ${item.subtotal.toLocaleString('es-AR')}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TIP SELECTOR (PROPINA PARA EL MESERO) */}
                <div style={{ background: 'var(--bg-main)', padding: '14px', borderRadius: 'var(--radius-md)', marginBottom: '16px' }}>
                  <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)', display: 'block', marginBottom: '8px' }}>
                    ❤️ Propina para el Mozo (Opcional):
                  </label>
                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                    {[0, 5, 10, 15, 20].map(pct => (
                      <button
                        key={pct}
                        onClick={() => { setTipPercentage(pct); setCustomTip(''); }}
                        style={{
                          padding: '8px 12px',
                          borderRadius: 'var(--radius-sm)',
                          border: tipPercentage === pct && customTip === '' ? '1px solid var(--primary)' : '1px solid var(--border-color)',
                          background: tipPercentage === pct && customTip === '' ? 'var(--primary)' : 'var(--bg-card)',
                          color: tipPercentage === pct && customTip === '' ? '#000' : 'var(--text-main)',
                          fontWeight: 700,
                          cursor: 'pointer'
                        }}
                      >
                        {pct}%
                      </button>
                    ))}
                  </div>
                </div>

                {/* PAYMENT METHOD SELECTOR */}
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '8px' }}>
                    Selecciona tu Medio de Pago:
                  </label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                    <button
                      onClick={() => {
                        setPaymentMethod('mercado_pago');
                        if (selectedItemsToPay.length === 0 && allUnpaidItems.length > 0) {
                          setSelectedItemsToPay(allUnpaidItems.map(i => i.id));
                        }
                      }}
                      className={`btn ${paymentMethod === 'mercado_pago' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '10px', fontSize: '0.8rem' }}
                    >
                      <QrCode size={16} /> Mercado Pago / QR
                    </button>
                    <button
                      onClick={() => {
                        setPaymentMethod('transferencia');
                        if (selectedItemsToPay.length === 0 && allUnpaidItems.length > 0) {
                          setSelectedItemsToPay(allUnpaidItems.map(i => i.id));
                        }
                      }}
                      className={`btn ${paymentMethod === 'transferencia' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '10px', fontSize: '0.8rem' }}
                    >
                      <CreditCard size={16} /> Transferencia CBU
                    </button>
                    <button
                      onClick={() => {
                        setPaymentMethod('tarjeta');
                        if (selectedItemsToPay.length === 0 && allUnpaidItems.length > 0) {
                          setSelectedItemsToPay(allUnpaidItems.map(i => i.id));
                        }
                      }}
                      className={`btn ${paymentMethod === 'tarjeta' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '10px', fontSize: '0.8rem' }}
                    >
                      <CreditCard size={16} /> Tarjeta Débito/Crédito
                    </button>
                    <button
                      onClick={() => {
                        setPaymentMethod('efectivo');
                        if (selectedItemsToPay.length === 0 && allUnpaidItems.length > 0) {
                          setSelectedItemsToPay(allUnpaidItems.map(i => i.id));
                        }
                      }}
                      className={`btn ${paymentMethod === 'efectivo' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '10px', fontSize: '0.8rem' }}
                    >
                      <DollarSign size={16} /> Efectivo en Caja
                    </button>
                  </div>
                </div>

                {/* MERCADO PAGO QR DISPLAY */}
                {paymentMethod === 'mercado_pago' && (
                  <div className="glass-accent animate-fade-in" style={{ padding: '16px', borderRadius: 'var(--radius-md)', marginBottom: '16px', textAlign: 'center', border: '1px solid #009ee3' }}>
                    <div style={{ fontWeight: 800, fontSize: '0.95rem', color: '#009ee3', marginBottom: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                      <QrCode size={18} /> ESCANEA Y PAGA CON MERCADO PAGO
                    </div>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                      Abre la App de Mercado Pago o Mercado Libre desde tu celular para escanear:
                    </p>
                    <div style={{ background: '#ffffff', padding: '12px', display: 'inline-block', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)' }}>
                      <QRCodeSVG 
                        value={`https://mpago.la/pos/qr?amount=${grandTotalToPay > 0 ? grandTotalToPay : 1000}&table=${tableId}&ref=MYJNEXORA`} 
                        size={160} 
                        includeMargin={true}
                      />
                    </div>
                    <div style={{ fontSize: '0.75rem', marginTop: '10px', color: '#009ee3', fontWeight: 800 }}>
                      Monto a Transferir: ${grandTotalToPay.toLocaleString('es-AR')}
                    </div>
                  </div>
                )}

                {/* Transfer CBU Info if selected */}
                {paymentMethod === 'transferencia' && (
                  <div className="glass-accent animate-fade-in" style={{ padding: '16px', borderRadius: 'var(--radius-md)', marginBottom: '16px', textAlign: 'center', border: '1px solid #f59e0b' }}>
                    <div style={{ fontWeight: 800, fontSize: '0.95rem', color: '#f59e0b', marginBottom: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                      <CreditCard size={18} /> DATOS Y QR TRANSFERENCIA CBU / ALIAS
                    </div>
                    <div style={{ background: '#ffffff', padding: '10px', display: 'inline-block', borderRadius: '12px', marginBottom: '12px' }}>
                      <QRCodeSVG 
                        value={`cbu:0000003100045892147582?amount=${grandTotalToPay}&alias=bares2026.necora.mp`} 
                        size={150} 
                        includeMargin={true}
                      />
                    </div>
                    <div style={{ fontSize: '0.85rem', textAlign: 'left', background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-sm)', marginBottom: '10px' }}>
                      <div>• Alias: <strong style={{ color: 'var(--primary)', fontFamily: 'monospace' }}>nexora.one.pos</strong></div>
                      <div>• CBU: <strong style={{ color: 'var(--text-main)', fontFamily: 'monospace' }}>0000003100045892147582</strong></div>
                      <div>• Titular: <strong>Gastronomía Nexora One</strong></div>
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText('bares2026.necora.mp');
                        alert('📋 ¡Alias "bares2026.necora.mp" copiado al portapapeles!');
                      }}
                      className="btn btn-secondary"
                      style={{ padding: '6px 14px', fontSize: '0.8rem', fontWeight: 800 }}
                    >
                      <Copy size={14} /> Copiar Alias para Transferir
                    </button>
                  </div>
                )}

                {/* TOTAL SUMMARY */}
                <div style={{ background: 'var(--bg-card)', padding: '14px', borderRadius: 'var(--radius-md)', marginBottom: '16px', border: '1px solid var(--border-accent)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', marginBottom: '4px' }}>
                    <span>Subtotal Consumo:</span>
                    <span>${subtotalToPay.toLocaleString('es-AR')}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: 'var(--primary)', marginBottom: '8px' }}>
                    <span>Propina Mozo ({activeTipPercent}%):</span>
                    <span>+${tipAmount.toLocaleString('es-AR')}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.3rem', fontWeight: 800, borderTop: '1px solid var(--border-color)', paddingTop: '8px' }}>
                    <span>TOTAL A PAGAR:</span>
                    <span style={{ color: 'var(--primary)' }}>${grandTotalToPay.toLocaleString('es-AR')}</span>
                  </div>
                </div>

                <button
                  onClick={handleProcessPayment}
                  className="btn btn-primary"
                  style={{ width: '100%', padding: '16px', fontSize: '1.1rem' }}
                >
                  <ShieldCheck size={20} /> Confirmar & Pagar ${grandTotalToPay.toLocaleString('es-AR')}
                </button>
              </>
            ) : (
              /* PAYMENT CONFIRMED / TICKET RECEIPT DISPLAY */
              <div style={{ textAlign: 'center', padding: '10px 0' }}>
                <div style={{ width: '60px', height: '60px', borderRadius: '99px', background: 'rgba(16,185,129,0.2)', border: '2px solid #10b981', color: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px auto' }}>
                  <Check size={32} />
                </div>
                <h3 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#10b981' }}>¡Pago Realizado con Éxito!</h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '4px', marginBottom: '20px' }}>
                  Comprobante emitido automáticamente para la Caja (Firma: <strong>Nexora One</strong>)
                </p>

                {completedPaymentData && (
                  <div className="thermal-ticket" style={{ textStyle: 'left', marginBottom: '20px' }}>
                    <div className="thermal-ticket-header">
                      <h3>COMPROBANTE MESA #{tableId}</h3>
                      <p>Cliente: {completedPaymentData.dinerName}</p>
                    </div>
                    <div className="thermal-ticket-body">
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Subtotal:</span>
                        <span>${completedPaymentData.subtotal?.toLocaleString('es-AR')}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', color: '#d97706' }}>
                        <span>Propina ({completedPaymentData.tipPercentage}%):</span>
                        <span>+${completedPaymentData.tipAmount?.toLocaleString('es-AR')}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, marginTop: '8px', fontSize: '1.1rem' }}>
                        <span>TOTAL:</span>
                        <span>${completedPaymentData.totalAmount?.toLocaleString('es-AR')}</span>
                      </div>
                    </div>
                    <div className="thermal-ticket-footer">
                      <p>Gracias por tu visita · Nexora One</p>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => { setPaymentCompleted(false); setIsCheckoutOpen(false); }}
                  className="btn btn-primary"
                  style={{ width: '100%', padding: '12px' }}
                >
                  Volver al Menú
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}

function ItemCustomizerModal({ item, onClose, onAddToCart }) {
  // Helper to derive standard ingredients for any dish
  const defaultIngredients = React.useMemo(() => {
    if (Array.isArray(item.ingredients) && item.ingredients.length > 0) {
      return item.ingredients;
    }
    const map = {
      'm1': [
        { id: 'i1', nombre: 'Papas rústicas al romero', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i2', nombre: 'Chimichurri artesanal', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i3', nombre: 'Huevo frito a la chapa', tipo: 'extra', precioExtra: 500, seleccionado: false },
        { id: 'i4', nombre: 'Panceta crocante extra', tipo: 'extra', precioExtra: 800, seleccionado: false }
      ],
      'm2': [
        { id: 'i1', nombre: 'Salsa mixta fileto y crema', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i2', nombre: 'Queso parmesano gratinado', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i3', nombre: 'Extra queso parmesano', tipo: 'extra', precioExtra: 400, seleccionado: false }
      ],
      'm3': [
        { id: 'i1', nombre: 'Hongos silvestres', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i2', nombre: 'Manteca trufada', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i3', nombre: 'Queso sardo estacionado', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i4', nombre: 'Extra queso sardo', tipo: 'extra', precioExtra: 400, seleccionado: false }
      ],
      'm4': [
        { id: 'i1', nombre: 'Doble medalla carne smash', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i2', nombre: 'Queso cheddar inglés', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i3', nombre: 'Panceta crocante', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i4', nombre: 'Cebolla', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i5', nombre: 'Pepinillos agridulces', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i6', nombre: 'Salsa secreta MyJ', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i7', nombre: 'Doble Queso Extra', tipo: 'extra', precioExtra: 800, seleccionado: false },
        { id: 'i8', nombre: 'Huevo frito a la chapa', tipo: 'extra', precioExtra: 500, seleccionado: false }
      ],
      'm5': [
        { id: 'i1', nombre: 'Salsa de tomate italiano', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i2', nombre: 'Mozzarella fior di latte', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i3', nombre: 'Albahaca fresca', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i4', nombre: 'Borde relleno de mozzarella', tipo: 'extra', precioExtra: 1200, seleccionado: false },
        { id: 'i5', nombre: 'Aceitunas negras marinadas', tipo: 'extra', precioExtra: 400, seleccionado: false }
      ],
      'm6': [
        { id: 'i1', nombre: 'Milanesa de lomo', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i2', nombre: 'Jamón cocido', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i3', nombre: 'Queso mozzarella', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i4', nombre: '2 Huevos fritos', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i5', nombre: 'Papas fritas doradas', tipo: 'removible', precioExtra: 0, seleccionado: true },
        { id: 'i6', nombre: 'Salsa Filetto Napolitana', tipo: 'extra', precioExtra: 800, seleccionado: false }
      ]
    };
    if (map[item.id]) return map[item.id];
    
    // Generic fallback for any other dish
    const desc = item.description || '';
    const parts = desc.split(/[,y]/).map(p => p.trim()).filter(p => p.length > 2);
    const result = parts.map((p, idx) => ({
      id: `ing_${idx}`,
      nombre: p.charAt(0).toUpperCase() + p.slice(1),
      tipo: 'removible',
      precioExtra: 0,
      seleccionado: true
    }));

    result.push(
      { id: 'ext_1', nombre: 'Extra Queso Gratinado', tipo: 'extra', precioExtra: 500, seleccionado: false },
      { id: 'ext_2', nombre: 'Panceta Crocante Extra', tipo: 'extra', precioExtra: 800, seleccionado: false }
    );
    return result;
  }, [item]);

  // Ingredients checkbox state: id -> boolean (selected/checked)
  const [ingredientsState, setIngredientsState] = useState(() => {
    const initial = {};
    defaultIngredients.forEach(ing => {
      initial[ing.id] = ing.seleccionado;
    });
    return initial;
  });

  // Single / Multiple optionGroups choice state
  const [selectedChoices, setSelectedChoices] = useState(() => {
    const initial = {};
    (item.optionGroups || []).forEach(group => {
      if (group.type === 'single' && group.options && group.options.length > 0) {
        initial[group.id] = group.options[0].id;
      } else if (group.type === 'multiple') {
        initial[group.id] = [];
      }
    });
    return initial;
  });

  const [itemNote, setItemNote] = useState('');

  const toggleIngredient = (id) => {
    setIngredientsState(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleSingleChoice = (groupId, optionId) => {
    setSelectedChoices(prev => ({ ...prev, [groupId]: optionId }));
  };

  const toggleMultipleChoice = (groupId, optionId) => {
    setSelectedChoices(prev => {
      const currentList = prev[groupId] || [];
      const updated = currentList.includes(optionId)
        ? currentList.filter(id => id !== optionId)
        : [...currentList, optionId];
      return { ...prev, [groupId]: updated };
    });
  };

  // Calculate dynamic price & lists
  let optionsTotalPrice = 0;
  const choiceSummaryParts = [];

  (item.optionGroups || []).forEach(group => {
    if (group.type === 'single') {
      const selectedId = selectedChoices[group.id];
      const foundOpt = group.options.find(o => o.id === selectedId);
      if (foundOpt) {
        optionsTotalPrice += foundOpt.price || 0;
        choiceSummaryParts.push(foundOpt.name);
      }
    } else if (group.type === 'multiple') {
      const selectedIds = selectedChoices[group.id] || [];
      const chosenNames = [];
      selectedIds.forEach(id => {
        const foundOpt = group.options.find(o => o.id === id);
        if (foundOpt) {
          optionsTotalPrice += foundOpt.price || 0;
          chosenNames.push(foundOpt.name);
        }
      });
      if (chosenNames.length > 0) {
        choiceSummaryParts.push(`[${chosenNames.join(', ')}]`);
      }
    }
  });

  // Calculate ingredients extras and removed
  let ingredientsExtraPrice = 0;
  const quitados = [];
  const extras = [];

  defaultIngredients.forEach(ing => {
    const isChecked = ingredientsState[ing.id];
    if (ing.tipo === 'removible' && !isChecked) {
      quitados.push(ing.nombre);
    } else if (ing.tipo === 'extra' && isChecked) {
      extras.push(ing.nombre);
      ingredientsExtraPrice += (ing.precioExtra || 0);
    }
  });

  const finalUnitPrice = item.price + optionsTotalPrice + ingredientsExtraPrice;

  const isValid = (item.optionGroups || []).every(group => {
    if (group.required && group.type === 'single') {
      return Boolean(selectedChoices[group.id]);
    }
    return true;
  });

  const handleAdd = () => {
    const noteParts = [];
    if (quitados.length > 0) noteParts.push(`SIN: ${quitados.join(', ')}`);
    if (extras.length > 0) noteParts.push(`EXTRA: ${extras.join(', ')}`);
    if (choiceSummaryParts.length > 0) noteParts.push(choiceSummaryParts.join(' · '));
    if (itemNote.trim()) noteParts.push(`Nota: ${itemNote.trim()}`);

    const finalNoteString = noteParts.join(' | ');

    onAddToCart(item, finalUnitPrice, finalNoteString, quitados, extras);
  };

  const removiblesList = defaultIngredients.filter(i => i.tipo === 'removible');
  const extrasList = defaultIngredients.filter(i => i.tipo === 'extra');

  return (
    <div className="bottom-sheet-overlay" onClick={onClose}>
      <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '600px', maxHeight: '90vh', overflowY: 'auto' }}>
        
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
          <div>
            <h3 style={{ fontSize: '1.3rem', fontWeight: 800 }}>{item.title}</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '2px' }}>{item.description}</p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={24} />
          </button>
        </div>

        {/* Live Summary Badges */}
        {(quitados.length > 0 || extras.length > 0) && (
          <div style={{ background: 'var(--bg-main)', padding: '10px 14px', borderRadius: 'var(--radius-md)', marginBottom: '16px', border: '1px solid var(--border-color)', display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {quitados.map((q, idx) => (
              <span key={idx} style={{ fontSize: '0.78rem', color: '#ef4444', fontWeight: 800, background: 'rgba(239,68,68,0.15)', padding: '4px 8px', borderRadius: '6px' }}>
                ❌ SIN {q.toUpperCase()}
              </span>
            ))}
            {extras.map((e, idx) => (
              <span key={idx} style={{ fontSize: '0.78rem', color: '#10b981', fontWeight: 800, background: 'rgba(16,185,129,0.15)', padding: '4px 8px', borderRadius: '6px' }}>
                ➕ EXTRA {e.toUpperCase()}
              </span>
            ))}
          </div>
        )}

        {/* SECTION 1: INGREDIENTES BASE (TILDAR / DESTILDAR PARA QUITAR) */}
        {removiblesList.length > 0 && (
          <div style={{ marginBottom: '20px', background: 'var(--bg-card)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
              <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--primary)' }}>
                🥗 Ingredientes de la Receta (Destildar para quitar)
              </h4>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Desmarcá lo que no quieras</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '8px' }}>
              {removiblesList.map(ing => {
                const isChecked = Boolean(ingredientsState[ing.id]);
                return (
                  <label
                    key={ing.id}
                    onClick={() => toggleIngredient(ing.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      padding: '8px 12px',
                      borderRadius: 'var(--radius-sm)',
                      background: isChecked ? 'rgba(16,185,129,0.08)' : 'rgba(239,68,68,0.12)',
                      border: isChecked ? '1px solid #10b981' : '1px solid #ef4444',
                      cursor: 'pointer',
                      userSelect: 'none',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}}
                      style={{ width: '16px', height: '16px', accentColor: '#10b981', cursor: 'pointer' }}
                    />
                    <span style={{ fontSize: '0.85rem', fontWeight: 600, color: isChecked ? 'var(--text-main)' : '#ef4444', textDecoration: isChecked ? 'none' : 'line-through' }}>
                      {ing.nombre}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {/* SECTION 2: INGREDIENTES EXTRA (MARCAR PARA AGREGAR CON PRECIO) */}
        {extrasList.length > 0 && (
          <div style={{ marginBottom: '20px', background: 'var(--bg-card)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
              <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#10b981' }}>
                ➕ Ingredientes Adicionales / Extras (Tildar para agregar)
              </h4>
              <span style={{ fontSize: '0.7rem', color: '#10b981', fontWeight: 700 }}>Agregá más sabor</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '8px' }}>
              {extrasList.map(ing => {
                const isChecked = Boolean(ingredientsState[ing.id]);
                return (
                  <label
                    key={ing.id}
                    onClick={() => toggleIngredient(ing.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '8px 12px',
                      borderRadius: 'var(--radius-sm)',
                      background: isChecked ? 'rgba(16,185,129,0.15)' : 'var(--bg-main)',
                      border: isChecked ? '1px solid #10b981' : '1px solid var(--border-color)',
                      cursor: 'pointer',
                      userSelect: 'none',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        style={{ width: '16px', height: '16px', accentColor: '#10b981', cursor: 'pointer' }}
                      />
                      <span style={{ fontSize: '0.85rem', fontWeight: isChecked ? 700 : 500, color: isChecked ? '#10b981' : 'var(--text-main)' }}>
                        {ing.nombre}
                      </span>
                    </div>
                    {ing.precioExtra > 0 && (
                      <span style={{ fontSize: '0.8rem', fontWeight: 800, color: '#10b981' }}>
                        +${ing.precioExtra.toLocaleString('es-AR')}
                      </span>
                    )}
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {/* SECTION 3: OPCIONES MANDATORIAS (Punto de la Carne, Guarnición, etc.) */}
        {(item.optionGroups && item.optionGroups.length > 0) && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginBottom: '20px' }}>
            {item.optionGroups.map(group => (
              <div key={group.id} style={{ background: 'var(--bg-card)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                  <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--primary)' }}>
                    {group.name}
                  </h4>
                  <span className={`badge ${group.required ? 'badge-warning' : 'badge-info'}`}>
                    {group.required ? 'Obligatorio' : 'Opcional'}
                  </span>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {group.options.map(opt => {
                    const isSelected = group.type === 'single'
                      ? selectedChoices[group.id] === opt.id
                      : (selectedChoices[group.id] || []).includes(opt.id);

                    return (
                      <div
                        key={opt.id}
                        onClick={() => group.type === 'single' ? toggleSingleChoice(group.id, opt.id) : toggleMultipleChoice(group.id, opt.id)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '10px 12px',
                          borderRadius: 'var(--radius-sm)',
                          background: isSelected ? 'var(--primary-light)' : 'var(--bg-main)',
                          border: isSelected ? '1px solid var(--primary)' : '1px solid var(--border-color)',
                          cursor: 'pointer'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{
                            width: '18px',
                            height: '18px',
                            borderRadius: group.type === 'single' ? '99px' : '4px',
                            border: '2px solid var(--primary)',
                            background: isSelected ? 'var(--primary)' : 'transparent',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>
                            {isSelected && <Check size={12} color="#000" />}
                          </div>
                          <span style={{ fontSize: '0.9rem', fontWeight: isSelected ? 700 : 400 }}>
                            {opt.name}
                          </span>
                        </div>

                        {opt.price > 0 && (
                          <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)' }}>
                            +${opt.price.toLocaleString('es-AR')}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Custom Text Note */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
            Aclaración adicional para la cocina o barra (Opcional):
          </label>
          <input
            type="text"
            value={itemNote}
            onChange={e => setItemNote(e.target.value)}
            placeholder="Ej: Servir sin sal, aderezo al costado, hielo extra..."
            style={{
              width: '100%',
              background: 'var(--bg-main)',
              border: '1px solid var(--border-color)',
              color: 'var(--text-main)',
              padding: '10px 14px',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.9rem'
            }}
          />
        </div>

        {/* Add to Cart Button */}
        <button
          disabled={!isValid}
          onClick={handleAdd}
          className="btn btn-primary"
          style={{ width: '100%', padding: '16px', fontSize: '1.05rem', opacity: isValid ? 1 : 0.5 }}
        >
          Agregar al Pedido (${finalUnitPrice.toLocaleString('es-AR')})
        </button>

      </div>
    </div>
  );
}

