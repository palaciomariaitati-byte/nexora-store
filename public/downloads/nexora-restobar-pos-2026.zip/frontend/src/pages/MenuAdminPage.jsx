import React, { useState, useEffect } from 'react';
import { Utensils, Plus, Edit2, Trash2, Check, Sparkles, X, Save, Layers } from 'lucide-react';
import { api, socket } from '../services/api';

export default function MenuAdminPage() {
  const [menu, setMenu] = useState([]);
  const [categories, setCategories] = useState([]);
  const [inventoryList, setInventoryList] = useState([]);
  const [editingItem, setEditingItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Receta / Ficha Técnica Modal State
  const [isRecipeModalOpen, setIsRecipeModalOpen] = useState(false);
  const [selectedProductForRecipe, setSelectedProductForRecipe] = useState(null);
  const [recipeIngredients, setRecipeIngredients] = useState([]);

  // Form State
  const [formData, setFormData] = useState({
    title: '',
    category: 'a-la-carta',
    price: '',
    description: '',
    tag: '',
    image: '',
    isDailySpecial: false,
    optionGroups: []
  });

  useEffect(() => {
    fetchMenu();
    fetchInventory();

    const handleMenuUpdated = (data) => {
      if (data.menu) setMenu(data.menu);
    };

    socket.on('menu_updated', handleMenuUpdated);
    return () => socket.off('menu_updated', handleMenuUpdated);
  }, []);

  const fetchInventory = async () => {
    try {
      const res = await api.getInventory();
      setInventoryList(res.inventory || []);
    } catch (e) {}
  };

  const fetchMenu = async () => {
    try {
      const res = await api.getMenu();
      setMenu(res.menu || []);
      setCategories(res.categories || []);
    } catch (err) {
      console.error('Error fetching menu:', err);
    }
  };

  const openRecipeModal = async (product) => {
    setSelectedProductForRecipe(product);
    try {
      const res = await api.getReceta(product.id);
      if (res.receta && res.receta.length > 0) {
        setRecipeIngredients(res.receta.map(r => ({
          inventoryId: r.inventory_id,
          quantity: r.quantity,
          unit: r.unit || 'Kg'
        })));
      } else {
        // Inicializar con una fila vacía para que el usuario pueda agregar
        setRecipeIngredients([{ inventoryId: inventoryList[0]?.id || '', quantity: 0.25, unit: inventoryList[0]?.unit || 'Kg' }]);
      }
    } catch (e) {
      setRecipeIngredients([]);
    }
    setIsRecipeModalOpen(true);
  };

  const handleSaveRecipe = async (e) => {
    e.preventDefault();
    if (!selectedProductForRecipe) return;
    try {
      await api.saveReceta(selectedProductForRecipe.id, recipeIngredients);
      alert(`✅ Ficha técnica de "${selectedProductForRecipe.title}" actualizada con éxito! Nora descontará exactamente estos insumos.`);
      setIsRecipeModalOpen(false);
    } catch (err) {
      alert('Error guardando receta: ' + err.message);
    }
  };

  const openCreateModal = () => {
    setEditingItem(null);
    setFormData({
      title: '',
      category: 'a-la-carta',
      price: '',
      description: '',
      tag: '',
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
      isDailySpecial: false,
      optionGroups: [
        {
          id: `og_${Date.now()}`,
          name: 'Opciones de Preparación / Ingredientes',
          required: false,
          type: 'multiple',
          options: [
            { id: `opt_1`, name: 'Ingrediente Clásico', price: 0 }
          ]
        }
      ]
    });
    setIsModalOpen(true);
  };

  const openEditModal = (item) => {
    setEditingItem(item);
    setFormData({
      title: item.title,
      category: item.category,
      price: item.price,
      description: item.description || '',
      tag: item.tag || '',
      image: item.image || '',
      isDailySpecial: item.isDailySpecial || false,
      optionGroups: item.optionGroups || []
    });
    setIsModalOpen(true);
  };

  const handleToggleDailySpecial = async (item) => {
    try {
      await api.updateMenuItem(item.id, { isDailySpecial: !item.isDailySpecial });
      fetchMenu();
    } catch (err) {
      alert('Error actualizando plato del día: ' + err.message);
    }
  };

  const handleDeleteItem = async (id) => {
    if (!confirm('¿Seguro que deseas eliminar este plato/bebida?')) return;
    try {
      await api.deleteMenuItem(id);
      fetchMenu();
    } catch (err) {
      alert('Error eliminando plato: ' + err.message);
    }
  };

  const handleSaveItem = async (e) => {
    e.preventDefault();
    if (!formData.title || !formData.price) {
      alert('Ingresa el título y el precio');
      return;
    }

    try {
      if (editingItem) {
        await api.updateMenuItem(editingItem.id, formData);
      } else {
        await api.createMenuItem(formData);
      }
      setIsModalOpen(false);
      fetchMenu();
    } catch (err) {
      alert('Error guardando plato: ' + err.message);
    }
  };

  // Option Groups Builder Handlers
  const addOptionGroup = () => {
    setFormData(prev => ({
      ...prev,
      optionGroups: [
        ...prev.optionGroups,
        {
          id: `og_${Date.now()}_${Math.floor(Math.random()*100)}`,
          name: 'Nuevo Grupo de Opciones',
          required: false,
          type: 'multiple',
          options: [{ id: `opt_${Date.now()}`, name: 'Opción 1', price: 0 }]
        }
      ]
    }));
  };

  const removeOptionGroup = (gIdx) => {
    setFormData(prev => {
      const groups = [...prev.optionGroups];
      groups.splice(gIdx, 1);
      return { ...prev, optionGroups: groups };
    });
  };

  const updateOptionGroupHeader = (gIdx, field, val) => {
    setFormData(prev => {
      const groups = [...prev.optionGroups];
      groups[gIdx] = { ...groups[gIdx], [field]: val };
      return { ...prev, optionGroups: groups };
    });
  };

  const addOptionToGroup = (gIdx) => {
    setFormData(prev => {
      const groups = [...prev.optionGroups];
      groups[gIdx].options.push({
        id: `opt_${Date.now()}_${Math.floor(Math.random()*100)}`,
        name: 'Nueva Opción',
        price: 0
      });
      return { ...prev, optionGroups: groups };
    });
  };

  const removeOptionFromGroup = (gIdx, oIdx) => {
    setFormData(prev => {
      const groups = [...prev.optionGroups];
      groups[gIdx].options.splice(oIdx, 1);
      return { ...prev, optionGroups: groups };
    });
  };

  const updateOptionField = (gIdx, oIdx, field, val) => {
    setFormData(prev => {
      const groups = [...prev.optionGroups];
      groups[gIdx].options[oIdx] = {
        ...groups[gIdx].options[oIdx],
        [field]: field === 'price' ? Number(val) || 0 : val
      };
      return { ...prev, optionGroups: groups };
    });
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '20px auto', padding: '0 20px 60px 20px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Utensils style={{ color: 'var(--primary)' }} />
            Gestión de Carta, Recetas & Opciones de Ingredientes
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginTop: '4px' }}>
            Configura tus platos, bebidas, recetas y combinaciones a medida · Firma: <strong>Nexora One</strong>
          </p>
        </div>

        <button onClick={openCreateModal} className="btn btn-primary" style={{ padding: '10px 18px', fontSize: '0.95rem' }}>
          <Plus size={18} /> Cargar Nuevo Plato / Bebida
        </button>
      </div>

      {/* Menu Items Table / Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '20px' }}>
        {menu.map(item => (
          <div key={item.id} className="glass" style={{ borderRadius: 'var(--radius-lg)', padding: '16px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '12px' }}>
                <img src={item.image} alt={item.title} style={{ width: '70px', height: '70px', borderRadius: 'var(--radius-md)', objectFit: 'cover' }} />
                <div>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 800 }}>{item.title}</h3>
                  <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--primary)', marginTop: '2px' }}>
                    ${item.price.toLocaleString('es-AR')}
                  </div>
                  <span className="badge badge-info" style={{ fontSize: '0.7rem', marginTop: '4px' }}>
                    {item.category.toUpperCase()}
                  </span>
                </div>
              </div>

              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                {item.description}
              </p>

              {/* Recipe / Option Groups Summary */}
              {item.optionGroups && item.optionGroups.length > 0 ? (
                <div style={{ background: 'var(--bg-main)', padding: '10px', borderRadius: 'var(--radius-sm)', marginBottom: '12px', fontSize: '0.75rem' }}>
                  <strong style={{ color: 'var(--primary)', display: 'block', marginBottom: '4px' }}>
                    Grupos de Ingredientes ({item.optionGroups.length}):
                  </strong>
                  {item.optionGroups.map((g, idx) => (
                    <div key={idx} style={{ color: 'var(--text-muted)' }}>
                      • <strong>{g.name}</strong> ({g.options.length} opciones)
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '12px', italic: 'true' }}>
                  Sin grupos de opciones (Receta estándar)
                </div>
              )}
            </div>

            {/* Actions Footer */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-color)', paddingTop: '12px' }}>
              <button
                onClick={() => handleToggleDailySpecial(item)}
                className={`btn ${item.isDailySpecial ? 'btn-primary' : 'btn-secondary'}`}
                style={{ padding: '6px 10px', fontSize: '0.75rem' }}
              >
                <Sparkles size={12} /> {item.isDailySpecial ? 'Plato del Día 🌟' : 'Marcar del Día'}
              </button>

              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  type="button"
                  onClick={() => openRecipeModal(item)}
                  className="btn btn-secondary"
                  title="Configurar Ficha Técnica / Receta para descuento automático de stock"
                  style={{ padding: '6px 10px', fontSize: '0.75rem', background: 'rgba(56, 189, 248, 0.15)', borderColor: 'rgba(56, 189, 248, 0.4)', color: '#38bdf8', fontWeight: 800 }}
                >
                  📋 Receta
                </button>
                <button onClick={() => openEditModal(item)} className="btn btn-secondary" style={{ padding: '6px 10px', fontSize: '0.75rem' }} title="Editar Datos / Precio / Foto">
                  <Edit2 size={14} />
                </button>
                <button onClick={() => handleDeleteItem(item.id)} className="btn btn-danger" style={{ padding: '6px 10px', fontSize: '0.75rem' }} title="Eliminar Plato">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* CREATE / EDIT DISH & RECIPE MODAL */}
      {isModalOpen && (
        <div className="bottom-sheet-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '750px', maxHeight: '85vh', overflowY: 'auto' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h3 style={{ fontSize: '1.4rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Layers style={{ color: 'var(--primary)' }} />
                {editingItem ? 'Editar Plato / Receta' : 'Cargar Nuevo Plato / Receta'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSaveItem}>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Título del Plato / Bebida *</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Ej: Hamburguesa Doble Smash"
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Precio ($) *</label>
                  <input
                    type="number"
                    required
                    value={formData.price}
                    onChange={e => setFormData({ ...formData, price: e.target.value })}
                    placeholder="9800"
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Categoría de la Carta</label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value })}
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  >
                    <option value="del-dia">Platos del Día 🌟</option>
                    <option value="a-la-carta">A la Carta 🍔</option>
                    <option value="bebidas">Bebidas & Coctelería 🍹</option>
                    <option value="postres">Postres & Dulces 🍰</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Etiqueta de Variedad (Ej: Carne a la Cuchilla)</label>
                  <input
                    type="text"
                    value={formData.tag}
                    onChange={e => setFormData({ ...formData, tag: e.target.value })}
                    placeholder="Ej: Empanada Carne / Pollo / J&Q"
                    style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                  />
                </div>
              </div>

              {/* Image Input & Presets Gallery */}
              <div style={{ marginBottom: '14px', background: 'var(--bg-main)', padding: '12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                <label style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)', display: 'block', marginBottom: '6px' }}>
                  🖼️ Imagen Individual del Producto / Variedad:
                </label>
                
                <input
                  type="text"
                  value={formData.image}
                  onChange={e => setFormData({ ...formData, image: e.target.value })}
                  placeholder="Pega la URL de imagen o selecciona una de abajo..."
                  style={{ width: '100%', background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)', marginBottom: '8px', fontSize: '0.85rem' }}
                />

                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
                  Atajos rápidos de fotos predefinidas por tipo:
                </div>

                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                  {[
                    { name: '🥩 Emp. Carne', url: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=600&auto=format&fit=crop&q=80' },
                    { name: '🍗 Emp. Pollo', url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80' },
                    { name: '🧀 Emp. J&Q', url: 'https://images.unsplash.com/photo-1541745537411-b8046dc6d66c?w=600&auto=format&fit=crop&q=80' },
                    { name: '🍔 Hamburguesa', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80' },
                    { name: '🍕 Pizza', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80' },
                    { name: '🥩 Milanesa', url: 'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=600&auto=format&fit=crop&q=80' },
                    { name: '🍺 Cerveza IPA', url: 'https://images.unsplash.com/photo-1608270586620-248524c67de9?w=600&auto=format&fit=crop&q=80' },
                    { name: '🍹 Fernet/Trago', url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600&auto=format&fit=crop&q=80' },
                    { name: '🍰 Postre', url: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&auto=format&fit=crop&q=80' }
                  ].map((preset, pIdx) => (
                    <button
                      key={pIdx}
                      type="button"
                      onClick={() => setFormData({ ...formData, image: preset.url })}
                      style={{
                        padding: '4px 8px',
                        borderRadius: '4px',
                        background: formData.image === preset.url ? 'var(--primary)' : 'var(--bg-card)',
                        color: formData.image === preset.url ? '#000' : 'var(--text-main)',
                        border: '1px solid var(--border-color)',
                        fontSize: '0.75rem',
                        fontWeight: 600,
                        cursor: 'pointer'
                      }}
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Descripción de la Receta</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descripción detallada para el cliente..."
                  style={{ width: '100%', background: 'var(--bg-main)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px 12px', borderRadius: 'var(--radius-sm)' }}
                />
              </div>

              {/* RECIPE OPTION GROUPS BUILDER (OPCIONES DE INGREDIENTES) */}
              <div style={{ borderTop: '2px dashed var(--border-color)', paddingTop: '16px', marginBottom: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                  <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Layers size={16} /> Configurar Opciones de Ingredientes & Receta
                  </h4>
                  <button type="button" onClick={addOptionGroup} className="btn btn-secondary" style={{ padding: '6px 12px', fontSize: '0.8rem' }}>
                    + Agregar Grupo
                  </button>
                </div>

                {formData.optionGroups.length === 0 ? (
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', italic: 'true' }}>
                    Sin grupos. Haz clic en "+ Agregar Grupo" para configurar elecciones (ej: Punto de la carne, Aderezos, Toppings).
                  </p>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {formData.optionGroups.map((group, gIdx) => (
                      <div key={group.id || gIdx} style={{ background: 'var(--bg-main)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-accent)' }}>
                        
                        {/* Group Header Controls */}
                        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr auto', gap: '8px', alignItems: 'center', marginBottom: '10px' }}>
                          <input
                            type="text"
                            value={group.name}
                            onChange={e => updateOptionGroupHeader(gIdx, 'name', e.target.value)}
                            placeholder="Nombre Grupo (Ej: Punto de Carne)"
                            style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px 10px', borderRadius: '4px', fontSize: '0.85rem' }}
                          />

                          <select
                            value={group.type}
                            onChange={e => updateOptionGroupHeader(gIdx, 'type', e.target.value)}
                            style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px 8px', borderRadius: '4px', fontSize: '0.8rem' }}
                          >
                            <option value="single">Selección Única (Radio)</option>
                            <option value="multiple">Selección Múltiple (Checkbox)</option>
                          </select>

                          <select
                            value={group.required ? 'true' : 'false'}
                            onChange={e => updateOptionGroupHeader(gIdx, 'required', e.target.value === 'true')}
                            style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '6px 8px', borderRadius: '4px', fontSize: '0.8rem' }}
                          >
                            <option value="false">Opcional</option>
                            <option value="true">Obligatorio</option>
                          </select>

                          <button type="button" onClick={() => removeOptionGroup(gIdx)} style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer' }}>
                            <Trash2 size={16} />
                          </button>
                        </div>

                        {/* Ingredients Options List */}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginLeft: '12px', borderLeft: '2px solid var(--border-color)', paddingLeft: '10px' }}>
                          {group.options.map((opt, oIdx) => (
                            <div key={opt.id || oIdx} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: '8px', alignItems: 'center' }}>
                              <input
                                type="text"
                                value={opt.name}
                                onChange={e => updateOptionField(gIdx, oIdx, 'name', e.target.value)}
                                placeholder="Nombre de ingrediente/opción"
                                style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '4px 8px', borderRadius: '4px', fontSize: '0.8rem' }}
                              />
                              <input
                                type="number"
                                value={opt.price}
                                onChange={e => updateOptionField(gIdx, oIdx, 'price', e.target.value)}
                                placeholder="+$ Modificador"
                                style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '4px 8px', borderRadius: '4px', fontSize: '0.8rem' }}
                              />
                              <button type="button" onClick={() => removeOptionFromGroup(gIdx, oIdx)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                                <X size={14} />
                              </button>
                            </div>
                          ))}

                          <button type="button" onClick={() => addOptionToGroup(gIdx)} style={{ background: 'none', border: 'none', color: 'var(--primary)', fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer', textAlign: 'left', marginTop: '4px' }}>
                            + Agregar Opción al Grupo
                          </button>
                        </div>

                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Save Button */}
              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '14px', fontSize: '1rem' }}>
                <Save size={18} /> Guardar Plato & Configuración
              </button>
            </form>

          </div>
        </div>
      )}

      {/* MODAL DE FICHA TÉCNICA / RECETA DINÁMICA (DESCUENTO DE INVENTARIO) */}
      {isRecipeModalOpen && selectedProductForRecipe && (
        <div className="bottom-sheet-overlay" onClick={() => setIsRecipeModalOpen(false)}>
          <div className="bottom-sheet-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '720px', maxHeight: '85vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '1.3rem', fontWeight: 900, color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>📋 Ficha Técnica & Receta de Depósito</span>
                </h3>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', margin: '4px 0 0 0' }}>
                  Plato: <strong>{selectedProductForRecipe.title}</strong> · Define qué materias primas descuenta Nora automáticamente de pañol cada vez que se vende una unidad.
                </p>
              </div>
              <button onClick={() => setIsRecipeModalOpen(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSaveRecipe}>
              <div style={{ background: 'var(--bg-main)', borderRadius: '8px', padding: '14px', border: '1px solid var(--border-color)', marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: '#38bdf8' }}>
                    🥗 Insumos & Gramajes que Componen el Plato:
                  </span>
                  <button
                    type="button"
                    onClick={() => setRecipeIngredients(prev => [...prev, { inventoryId: inventoryList[0]?.id || '', quantity: 0.1, unit: inventoryList[0]?.unit || 'Kg' }])}
                    className="btn btn-secondary"
                    style={{ fontSize: '0.75rem', padding: '4px 10px' }}
                  >
                    <Plus size={14} /> Agregar Insumo
                  </button>
                </div>

                {recipeIngredients.length === 0 ? (
                  <div style={{ padding: '16px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    Este plato no tiene insumos configurados aún. Haz clic en "Agregar Insumo" para vincularlo a tu stock de depósito.
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    {recipeIngredients.map((ing, idx) => (
                      <div key={idx} style={{ display: 'grid', gridTemplateColumns: '3fr 1.5fr 1fr 40px', gap: '8px', alignItems: 'center' }}>
                        <select
                          value={ing.inventoryId}
                          onChange={e => {
                            const copy = [...recipeIngredients];
                            const selectedInv = inventoryList.find(i => i.id === e.target.value);
                            copy[idx].inventoryId = e.target.value;
                            if (selectedInv) copy[idx].unit = selectedInv.unit;
                            setRecipeIngredients(copy);
                          }}
                          style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: '4px', fontSize: '0.85rem' }}
                        >
                          {inventoryList.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.name} ({item.unit}) - Stock: {item.currentStock}
                            </option>
                          ))}
                        </select>

                        <input
                          type="number"
                          step="0.001"
                          value={ing.quantity}
                          onChange={e => {
                            const copy = [...recipeIngredients];
                            copy[idx].quantity = Number(e.target.value) || 0;
                            setRecipeIngredients(copy);
                          }}
                          placeholder="Cantidad"
                          style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: '4px', fontSize: '0.85rem' }}
                        />

                        <input
                          type="text"
                          value={ing.unit}
                          onChange={e => {
                            const copy = [...recipeIngredients];
                            copy[idx].unit = e.target.value;
                            setRecipeIngredients(copy);
                          }}
                          placeholder="Unidad"
                          style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', color: '#fff', padding: '8px', borderRadius: '4px', fontSize: '0.85rem' }}
                        />

                        <button
                          type="button"
                          onClick={() => setRecipeIngredients(prev => prev.filter((_, i) => i !== idx))}
                          style={{ background: 'rgba(239, 68, 68, 0.2)', border: 'none', color: '#ef4444', borderRadius: '4px', height: '34px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                          title="Quitar de la receta"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  type="button"
                  onClick={() => setIsRecipeModalOpen(false)}
                  className="btn btn-secondary"
                  style={{ flex: 1, padding: '12px' }}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ flex: 2, padding: '12px', fontWeight: 900 }}
                >
                  💾 Guardar Ficha Técnica & Enlazar a Nora
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
