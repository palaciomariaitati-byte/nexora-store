import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import ClientApp from './pages/ClientApp';
import KitchenDisplay from './pages/KitchenDisplay';
import CajaCentral from './pages/CajaCentral';
import CashierDashboard from './pages/CashierDashboard';
import ErpAdminPage from './pages/ErpAdminPage';
import DeliveryDashboard from './pages/DeliveryDashboard';
import DriverApp from './pages/DriverApp';
import CartaDigitalQR from './pages/CartaDigitalQR';
import InternalChatModal from './components/InternalChatModal';
import ErrorBoundary from './components/ErrorBoundary';

/**
 * App.jsx: Orquestador Modular de Vistas para Nexora One
 * 
 * Vistas Principales:
 *  - /caja-central (Terminal Única de Salón + Nora AI Widget) -> Vista predeterminada en PC
 *  - /mozo (POS de Salón para teléfonos / tablets de mozos)
 *  - /cocina (KDS Pantalla de Cocina / Barra)
 *  - /carta (Carta Digital QR para mesas de comensales)
 */
export default function App() {
  const [isInternalChatOpen, setIsInternalChatOpen] = useState(false);

  // Detección de ruta inicial por Pathname o Hash
  const getInitialRoute = () => {
    try {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();

      if (path.includes('carta') || hash.includes('carta') || path.includes('qr') || hash.includes('qr')) return 'carta';
      if (path.includes('cocina') || hash.includes('cocina') || hash.includes('kds')) return 'cocina';
      if (path.includes('mozo') || hash.includes('mozo') || hash.includes('salon')) return 'mozo';
      if (path.includes('driver') || hash.includes('driver') || hash.includes('cadete')) return 'driver';
      if (path.includes('deposito') || hash.includes('deposito') || hash.includes('stock')) return 'deposito';
      if (path.includes('manager') || hash.includes('manager') || hash.includes('admin')) return 'manager';
      if (path.includes('caja') || hash.includes('caja')) return 'caja-central';
    } catch (e) {
      console.error(e);
    }
    // Por defecto en PC: Terminal Única con Nora AI
    return 'caja-central';
  };

  const [activeView, setActiveView] = useState(getInitialRoute);
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('nexora_theme') || 'dark';
    } catch (e) {
      return 'dark';
    }
  });

  // Aplicar tema en data-theme
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    try {
      localStorage.setItem('nexora_theme', theme);
    } catch (e) {}
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Escuchar cambios de hash para navegación limpia sin recargar
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash.includes('carta') || hash.includes('qr')) setActiveView('carta');
      else if (hash.includes('cocina')) setActiveView('cocina');
      else if (hash.includes('mozo')) setActiveView('mozo');
      else if (hash.includes('driver')) setActiveView('driver');
      else if (hash.includes('deposito') || hash.includes('stock')) setActiveView('deposito');
      else if (hash.includes('manager')) setActiveView('manager');
      else if (hash.includes('caja')) setActiveView('caja-central');
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const isLight = theme === 'light';

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg-main)',
      color: 'var(--text-main)',
      transition: 'background 0.3s ease, color 0.3s ease'
    }}>
      {/* BARRA SUPERIOR DE ACCESO RÁPIDO ENTRE TERMINALES */}
      <header style={{
        background: isLight ? 'rgba(255, 255, 255, 0.95)' : 'linear-gradient(135deg, #083344 0%, #0f172a 100%)',
        borderBottom: '1px solid var(--border-color)',
        padding: '10px 18px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px',
        boxShadow: isLight ? '0 2px 10px rgba(0,0,0,0.06)' : 'none'
      }}>
        {/* LOGO & BRANDING NEXORA ONE */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #f59e0b, #d97706)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#083344',
            fontWeight: 900,
            fontSize: '1rem',
            boxShadow: '0 2px 8px rgba(245,158,11,0.3)'
          }}>
            N
          </div>
          <div>
            <span style={{ fontSize: '1.2rem', fontWeight: 900, color: 'var(--primary)', letterSpacing: '1px' }}>
              NEXORA ONE
            </span>
            <span style={{
              marginLeft: '8px',
              fontSize: '0.72rem',
              color: isLight ? '#475569' : '#94a3b8',
              background: isLight ? '#e2e8f0' : 'rgba(255,255,255,0.06)',
              padding: '2px 8px',
              borderRadius: '4px',
              fontWeight: 700
            }}>
              POS & Manager
            </span>
          </div>
        </div>

        {/* SELECTOR DE MODO DE TERMINAL Y TEMA */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
          {/* BOTÓN TOGGLE DE TEMA ☀️ / 🌙 */}
          <button
            onClick={toggleTheme}
            title={isLight ? 'Cambiar a modo oscuro' : 'Cambiar a modo claro'}
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border-color)',
              color: 'var(--text-main)',
              padding: '7px 13px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.85rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              boxShadow: 'var(--shadow-sm)',
              transition: 'all 0.2s ease'
            }}
          >
            <span>{isLight ? '🌙' : '☀️'}</span>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-main)', fontWeight: 700 }}>
              {isLight ? 'Modo Oscuro' : 'Modo Claro'}
            </span>
          </button>

          <button
            onClick={() => { setActiveView('caja-central'); window.location.hash = 'caja'; }}
            style={{
              background: activeView === 'caja-central' ? 'linear-gradient(135deg, #ea580c, #c2410c)' : 'var(--bg-card)',
              color: activeView === 'caja-central' ? '#ffffff' : 'var(--text-main)',
              border: activeView === 'caja-central' ? 'none' : '1px solid var(--border-color)',
              padding: '7px 14px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer',
              boxShadow: activeView === 'caja-central' ? '0 4px 12px rgba(234, 88, 12, 0.35)' : 'var(--shadow-sm)',
              transition: 'all 0.15s ease'
            }}
          >
            🖥️ Caja Central (Nora AI)
          </button>

          <button
            onClick={() => { setActiveView('mozo'); window.location.hash = 'mozo'; }}
            style={{
              background: activeView === 'mozo' ? '#0284c7' : 'var(--bg-card)',
              color: activeView === 'mozo' ? '#ffffff' : 'var(--text-main)',
              border: activeView === 'mozo' ? 'none' : '1px solid var(--border-color)',
              padding: '7px 14px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer',
              boxShadow: activeView === 'mozo' ? '0 4px 12px rgba(2, 132, 199, 0.35)' : 'var(--shadow-sm)',
              transition: 'all 0.15s ease'
            }}
          >
            📱 Mozo / Salón
          </button>

          <button
            onClick={() => { setActiveView('cocina'); window.location.hash = 'cocina'; }}
            style={{
              background: activeView === 'cocina' ? '#e11d48' : 'var(--bg-card)',
              color: activeView === 'cocina' ? '#ffffff' : 'var(--text-main)',
              border: activeView === 'cocina' ? 'none' : '1px solid var(--border-color)',
              padding: '7px 14px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer',
              boxShadow: activeView === 'cocina' ? '0 4px 12px rgba(225, 29, 72, 0.35)' : 'var(--shadow-sm)',
              transition: 'all 0.15s ease'
            }}
          >
            🍳 Cocina / KDS
          </button>

          <button
            onClick={() => { setActiveView('carta'); window.location.hash = 'carta'; }}
            style={{
              background: activeView === 'carta' ? '#059669' : 'var(--bg-card)',
              color: activeView === 'carta' ? '#ffffff' : 'var(--text-main)',
              border: activeView === 'carta' ? 'none' : '1px solid var(--border-color)',
              padding: '7px 14px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer',
              boxShadow: activeView === 'carta' ? '0 4px 12px rgba(5, 150, 105, 0.35)' : 'var(--shadow-sm)',
              transition: 'all 0.15s ease'
            }}
          >
            📱 Carta QR Mesa
          </button>

          <button
            onClick={() => { setActiveView('deposito'); window.location.hash = 'deposito'; }}
            style={{
              background: activeView === 'deposito' ? 'linear-gradient(135deg, #0284c7, #0369a1)' : 'var(--bg-card)',
              color: activeView === 'deposito' ? '#ffffff' : 'var(--text-main)',
              border: activeView === 'deposito' ? 'none' : '1px solid var(--border-color)',
              padding: '7px 14px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer',
              boxShadow: activeView === 'deposito' ? '0 4px 12px rgba(2, 132, 199, 0.35)' : 'var(--shadow-sm)',
              transition: 'all 0.15s ease'
            }}
          >
            📦 Depósito & Remitos (Nora)
          </button>

          <button
            onClick={() => { setActiveView('manager'); window.location.hash = 'manager'; }}
            style={{
              background: activeView === 'manager' ? '#7c3aed' : 'var(--bg-card)',
              color: activeView === 'manager' ? '#ffffff' : 'var(--text-main)',
              border: activeView === 'manager' ? 'none' : '1px solid var(--border-color)',
              padding: '7px 14px',
              borderRadius: '8px',
              fontWeight: 800,
              fontSize: '0.82rem',
              cursor: 'pointer',
              boxShadow: activeView === 'manager' ? '0 4px 12px rgba(124, 58, 237, 0.35)' : 'var(--shadow-sm)',
              transition: 'all 0.15s ease'
            }}
          >
            📊 Gerencia / ERP
          </button>

          {/* BOTÓN EXCLUSIVO DE PERSONAL: INTERCOMUNICADOR / CHAT INTERNO */}
          {activeView !== 'carta' && (
            <button
              onClick={() => setIsInternalChatOpen(true)}
              style={{
                background: 'linear-gradient(135deg, #10b981, #059669)',
                color: '#ffffff',
                border: 'none',
                padding: '7px 14px',
                borderRadius: '8px',
                fontWeight: 800,
                fontSize: '0.82rem',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                boxShadow: '0 4px 14px rgba(16, 185, 129, 0.4)'
              }}
            >
              💬 Chat Personal & Faltantes
            </button>
          )}
        </nav>
      </header>

      {/* RENDERIZADO MODULAR DE LA VISTA ACTIVA */}
      <main style={{ minHeight: 'calc(100vh - 105px)' }}>
        <ErrorBoundary>
          {activeView === 'caja-central' && <CajaCentral />}
          {activeView === 'mozo' && <ClientApp tableId={1} />}
          {activeView === 'cocina' && <KitchenDisplay />}
          {activeView === 'carta' && <CartaDigitalQR />}
          {activeView === 'deposito' && <ErpAdminPage defaultTab="inventory" />}
          {activeView === 'manager' && <ErpAdminPage defaultTab="accounting" />}
          {activeView === 'salon' && <CashierDashboard />}
          {activeView === 'driver' && <DriverApp />}
        </ErrorBoundary>
      </main>

      {/* MODAL DE CHAT INTERNO EXCLUSIVO DE PERSONAL (NO VISIBLE PARA CLIENTES) */}
      <InternalChatModal
        isOpen={isInternalChatOpen}
        onClose={() => setIsInternalChatOpen(false)}
        currentRoleName="Personal Operativo"
      />

      {/* FOOTER CORPORATIVO OFICIAL: FIRMA NEXORA ONE */}
      <footer style={{
        padding: '10px 20px',
        background: isLight ? '#f1f5f9' : 'rgba(11, 15, 23, 0.95)',
        borderTop: '1px solid var(--border-color)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px',
        fontSize: '0.78rem',
        color: 'var(--text-muted)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <strong style={{ color: 'var(--primary)', letterSpacing: '0.5px' }}>NEXORA ONE</strong>
          <span>· Suite Gastronómica & POS Inteligente</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
          <span>📞 Contacto Oficial: <strong style={{ color: 'var(--text-main)', fontFamily: 'var(--font-mono)' }}>3786414533</strong></span>
          <span>✉️ Soporte: <strong style={{ color: 'var(--text-main)' }}>mjnexora.visual@gmail.com</strong></span>
        </div>
      </footer>
    </div>
  );
}
