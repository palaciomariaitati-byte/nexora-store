import { io } from 'socket.io-client';
import { setGlobalLocalIp } from '../utils/networkHelper';

const API_BASE = '/api';

export const socket = io(window.location.origin, {
  transports: ['websocket', 'polling'],
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 5000,
  timeout: 20000
});

export const api = {
  // Tables
  getTables: async () => {
    const res = await fetch(`${API_BASE}/tables`);
    return res.json();
  },
  getTable: async (id) => {
    const res = await fetch(`${API_BASE}/tables/${id}`);
    return res.json();
  },
  startSession: async (tableId, comensales) => {
    const res = await fetch(`${API_BASE}/tables/${tableId}/session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ comensales })
    });
    return res.json();
  },

  // Menu
  getMenu: async () => {
    const res = await fetch(`${API_BASE}/menu`);
    return res.json();
  },
  createMenuItem: async (itemData) => {
    const res = await fetch(`${API_BASE}/menu`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(itemData)
    });
    return res.json();
  },
  updateMenuItem: async (id, itemData) => {
    const res = await fetch(`${API_BASE}/menu/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(itemData)
    });
    return res.json();
  },
  deleteMenuItem: async (id) => {
    const res = await fetch(`${API_BASE}/menu/${id}`, {
      method: 'DELETE'
    });
    return res.json();
  },
  getReceta: async (productoId) => {
    const res = await fetch(`${API_BASE}/menu/${productoId}/receta`);
    return res.json();
  },
  saveReceta: async (productoId, ingredientes) => {
    const res = await fetch(`${API_BASE}/menu/${productoId}/receta`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ingredientes })
    });
    return res.json();
  },

  // Orders
  getOrders: async () => {
    const res = await fetch(`${API_BASE}/orders`);
    return res.json();
  },
  createOrder: async (orderData) => {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });
    return res.json();
  },
  updateOrderStatus: async (orderId, status) => {
    const res = await fetch(`${API_BASE}/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    return res.json();
  },
  cancelOrder: async (orderId) => {
    const res = await fetch(`${API_BASE}/orders/${orderId}/cancel`, {
      method: 'POST'
    });
    return res.json();
  },
  updateOrderItemStatus: async (orderId, itemId, status) => {
    const res = await fetch(`${API_BASE}/orders/${orderId}/items/${itemId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    return res.json();
  },

  // Payments
  processPayment: async (paymentData) => {
    const res = await fetch(`${API_BASE}/payments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(paymentData)
    });
    return res.json();
  },

  // Table Closure
  closeTable: async (tableId) => {
    const res = await fetch(`${API_BASE}/tables/${tableId}/close`, {
      method: 'POST'
    });
    return res.json();
  },

  // Reports
  getReportsSummary: async () => {
    const res = await fetch(`${API_BASE}/reports/summary`);
    return res.json();
  },

  // CRM & RPM
  getCustomers: async () => {
    const res = await fetch(`${API_BASE}/crm/customers`);
    return res.json();
  },
  createCustomer: async (customerData) => {
    const res = await fetch(`${API_BASE}/crm/customers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(customerData)
    });
    return res.json();
  },
  getRpmMetrics: async () => {
    const res = await fetch(`${API_BASE}/rpm/metrics`);
    return res.json();
  },

  // Delivery & Takeaway
  getDeliveries: async () => {
    const res = await fetch(`${API_BASE}/deliveries`);
    return res.json();
  },
  createDeliveryOrder: async (deliveryData) => {
    const res = await fetch(`${API_BASE}/deliveries`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(deliveryData)
    });
    return res.json();
  },
  updateDeliveryStatus: async (id, status, driverName) => {
    const res = await fetch(`${API_BASE}/deliveries/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, driverName })
    });
    return res.json();
  },

  // Driver App (Uber-Style)
  getDriverStats: async () => {
    const res = await fetch(`${API_BASE}/driver/stats`);
    return res.json();
  },
  claimDeliveryOrder: async (deliveryId, driverName) => {
    const res = await fetch(`${API_BASE}/driver/claim/${deliveryId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ driverName })
    });
    return res.json();
  },
  rejectDeliveryOrder: async (deliveryId, driverName) => {
    const res = await fetch(`${API_BASE}/driver/reject/${deliveryId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ driverName })
    });
    return res.json();
  },

  // ERP Methods
  getInventory: async () => {
    const res = await fetch(`${API_BASE}/erp/inventory`);
    return res.json();
  },
  getLowStockAlerts: async () => {
    const res = await fetch(`${API_BASE}/erp/inventory/alerts`);
    return res.json();
  },
  getStockMovements: async (limit = 100) => {
    const res = await fetch(`${API_BASE}/erp/inventory/movements?limit=${limit}`);
    return res.json();
  },
  updateInventoryStock: async (id, stock, usuario = 'Gerencia', motivo = 'ajuste_manual') => {
    const res = await fetch(`${API_BASE}/erp/inventory/${id}/stock`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stock, usuario, motivo })
    });
    return res.json();
  },
  addInventoryItem: async (data) => {
    const res = await fetch(`${API_BASE}/erp/inventory`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  // Bandeja de Remitos y Facturas Pendientes (Depósito / Caja ➔ Gerencia)
  getRemitosPendientes: async (status = null) => {
    const query = status ? `?status=${status}` : '';
    const res = await fetch(`${API_BASE}/erp/remitos-pendientes${query}`);
    return res.json();
  },
  createRemitoPendiente: async (data) => {
    const res = await fetch(`${API_BASE}/erp/remitos-pendientes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  approveRemito: async (id, reviewerUser = 'Gerente General', itemsOverride = null) => {
    const res = await fetch(`${API_BASE}/erp/remitos-pendientes/${id}/aprobar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reviewerUser, itemsOverride })
    });
    return res.json();
  },
  rejectRemito: async (id, reviewerUser = 'Gerente General', motivo = '') => {
    const res = await fetch(`${API_BASE}/erp/remitos-pendientes/${id}/rechazar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reviewerUser, motivo })
    });
    return res.json();
  },
  getStaff: async () => {
    const res = await fetch(`${API_BASE}/erp/staff`);
    return res.json();
  },
  addStaffMember: async (data) => {
    const res = await fetch(`${API_BASE}/erp/staff`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  updateStaffMember: async (id, data) => {
    const res = await fetch(`${API_BASE}/erp/staff/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  deleteStaffMember: async (id) => {
    const res = await fetch(`${API_BASE}/erp/staff/${id}`, {
      method: 'DELETE'
    });
    return res.json();
  },
  getSuppliers: async () => {
    const res = await fetch(`${API_BASE}/erp/suppliers`);
    return res.json();
  },
  addSupplier: async (data) => {
    const res = await fetch(`${API_BASE}/erp/suppliers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  getAccountingSummary: async () => {
    const res = await fetch(`${API_BASE}/erp/accounting`);
    return res.json();
  },
  getJournalEntries: async () => {
    const res = await fetch(`${API_BASE}/erp/journal-entries`);
    return res.json();
  },
  getPurchaseOrders: async () => {
    const res = await fetch(`${API_BASE}/erp/purchase-orders`);
    return res.json();
  },
  createPurchaseOrder: async (data) => {
    const res = await fetch(`${API_BASE}/erp/purchase-orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  receivePurchaseOrder: async (id) => {
    const res = await fetch(`${API_BASE}/erp/purchase-orders/${id}/receive`, {
      method: 'POST'
    });
    return res.json();
  },
  addExpense: async (data) => {
    const res = await fetch(`${API_BASE}/erp/expenses`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },
  getCajaInicial: async () => {
    const res = await fetch(`${API_BASE}/erp/caja-inicial`);
    return res.json();
  },
  setCajaInicial: async (amount) => {
    const res = await fetch(`${API_BASE}/erp/caja-inicial`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount })
    });
    return res.json();
  },
  getPaymentGateways: async () => {
    const res = await fetch(`${API_BASE}/erp/payment-gateways`);
    return res.json();
  },
  savePaymentGateways: async (data) => {
    const res = await fetch(`${API_BASE}/erp/payment-gateways`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  // AI Agent Invoice OCR Reader
  parseInvoiceWithAI: async (invoiceText) => {
    const res = await fetch(`${API_BASE}/ai/parse-invoice`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoiceText })
    });
    return res.json();
  },

  // Intercomunicador & Mensajería Interna
  getInternalMessages: async () => {
    const res = await fetch(`${API_BASE}/internal-messages`);
    return res.json();
  },
  sendInternalMessage: async (data) => {
    const res = await fetch(`${API_BASE}/internal-messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  // Sector Login PIN Check
  verifySectorPin: async (pin) => {
    const res = await fetch(`${API_BASE}/auth/sector-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin })
    });
    return res.json();
  },

  // Auto-descubrimiento Adaptativo de Red Wi-Fi
  getNetworkInfo: async () => {
    try {
      const res = await fetch(`${API_BASE}/system/network-info`);
      const data = await res.json();
      if (data?.localIp) setGlobalLocalIp(data.localIp);
      return data;
    } catch (e) {
      return { localIp: window.location.hostname };
    }
  }
};
