import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3036,
    host: true,
    proxy: {
      '/api': {
        target: 'http://localhost:3035',
        changeOrigin: true
      },
      '/socket.io': {
        target: 'http://localhost:3035',
        ws: true
      }
    }
  }
});
