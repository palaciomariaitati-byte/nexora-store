@echo off
title Restobar POS 2026 - Terminal Soberana (Nexora One)
color 0B

echo ======================================================================
echo          RESTOBAR POS 2026 - SISTEMA GASTRONOMICO SOBERANO
echo                        Powered by Nexora One
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: 1. Verificacion de red y actualizacion silenciosa (sin bloquear apertura si no hay internet)
echo  [1/4] Comprobando parches y mejoras del sistema...
ping -n 1 -w 1000 8.8.8.8 >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    if exist "%ROOT_DIR%\.git" (
        git fetch origin main --quiet 2>nul
        git pull --ff-only origin main --quiet 2>nul
        echo        Sincronizacion completada sin alterar datos locales de clientes.
    ) else (
        echo        Terminal local lista (modo autonomo).
    )
) else (
    echo        Sin conexion externa. Operando en modo Perimetral 100%% Offline.
)

:: 2. Verificacion preventiva de la interfaz compilada
if not exist "%ROOT_DIR%frontend\dist" (
    echo.
    echo  [2/4] Generando compilacion inicial optimizada...
    call npm --prefix "%ROOT_DIR%frontend" run build
) else (
    echo  [2/4] Interfaz operativa validada.
)

:: 3. Limpieza de puertos para evitar bloqueos
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3035" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3036" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

:: 4. Iniciar Servidor Backend (Node/Express + SQLite WAL en puerto 3035)
echo.
echo  [3/4] Iniciando Base de Datos Local y Servidor...
start /min "Restobar POS - Backend" cmd /c "cd /d "%ROOT_DIR%backend" && node server.js"

:: 5. Iniciar Servidor Frontend (Puerto 3036)
echo  [4/4] Levantando terminal de salon y comanderas...
start /min "Restobar POS - Frontend" cmd /c "cd /d "%ROOT_DIR%frontend" && npx vite --port 3036 --host"

:: 6. Espera de 2 segundos para inicializar WebSockets
timeout /t 2 /nobreak >nul

:: 7. Apertura de la aplicacion en ventana limpia / modo app (sin barra de navegador)
echo.
echo  ======================================================================
echo   TERMINAL RESTOBAR 2026 ACTIVA
echo   - Salon / Caja: http://localhost:3036/
echo   - Base SQLite:  %ROOT_DIR%backend\data\restobar.sqlite (Protegida)
echo  ======================================================================
echo.

:: Detectar Chrome, Edge o navegador por defecto para modo aplicacion dedicada
set "BROWSER_FOUND=0"
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3036/
    set "BROWSER_FOUND=1"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3036/
    set "BROWSER_FOUND=1"
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3036/
    set "BROWSER_FOUND=1"
) else (
    start http://localhost:3036/
)

echo La terminal se encuentra ejecutandose en segundo plano.
echo Presione cualquier tecla si desea cerrar esta consola auxiliar.
pause >nul
