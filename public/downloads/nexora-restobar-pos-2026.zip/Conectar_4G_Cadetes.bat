@echo off
title MyJNexoraVisual - Tunel 4G/5G para Cadetes en la Calle
color 0B

echo ======================================================================
echo           MYJNEXORAVISUAL - CONECTOR 4G/5G PARA CADETES
echo ======================================================================
echo.
echo  Creando tunel publico seguro HTTPS con reconexion automatica infinita...
echo.

:loop
echo [%time%] Conectando tunel para repartidores en calle (4G/5G)...
npx localtunnel --port 3036
echo.
echo ⚠️ Tunel desconectado. Reintentando en 5 segundos...
timeout /t 5 /nobreak >nul
goto loop
