@echo off
title MyJNecoraVisual - Sistema Inteligente para Bares y Restaurantes
color 0A

echo ======================================================================
echo           MYJNECORAVISUAL - SMART RESTAURANT & BAR SYSTEM
echo ======================================================================
echo.
echo  [1/3] Iniciando Servidor Backend (Puerto 3035 - RAM ~11MB)...
start /min "MyJNecoraVisual Backend" cmd /c "cd /d "%~dp0backend" && node server.js"

echo  [2/3] Iniciando Servidor Frontend (Puerto 3036)...
start /min "MyJNecoraVisual Frontend" cmd /c "cd /d "%~dp0frontend" && npx vite --port 3036 --host"

echo  [3/3] Esperando arranque del sistema (3 segundos)...
timeout /t 3 /nobreak >nul

echo.
echo  ======================================================================
echo   SISTEMA EN LINEA Y LISTO PARA OPERAR!
echo  ======================================================================
echo   - App Local: http://localhost:3036/
echo   - PIN Personal del Bar por defecto: 1234
echo   - Firma: MyJNecoraVisual
echo  ======================================================================
echo.

start http://localhost:3036/

echo Presiona cualquier tecla para cerrar esta ventana (los servidores seguiran activos).
pause >nul
