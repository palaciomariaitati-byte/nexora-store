# 🚀 DIRECTIVA MAESTRA DE DESARROLLO: ECOSISTEMA Y TIENDA NEXORA SAAS

Hola Agente de Desarrollo. Este documento define la arquitectura, la esencia comercial, el modelo de seguridad y la metodología de trabajo con la que empaquetaremos y distribuiremos todos nuestros sistemas de software (Suite Restobar POS, Nexativa News, MyNex TV, Nexora Ads, NORA AI, etc.).

Debes leer cuidadosamente estas directivas y aplicarlas estrictamente en la construcción de cualquier nuevo módulo o sistema.

---

## 🏛️ 1. ESENCIA Y PROPÓSITO DEL SISTEMA
El propósito del ecosistema Nexora es la distribución masiva y automatizada de licencias de software comercial mediante un modelo de suscripción SaaS (Software as a Service), con la máxima seguridad del código fuente y cero fricción para el cliente.

El ecosistema consta de dos componentes principales:
1. Tienda Web Pública (Nexora Store): Desplegada en Vercel Production (https://nexora-store-xi.vercel.app), desarrollada en Next.js 16 App Router. Es la vitrina comercial donde los clientes ven las apps, prueban versiones Beta/Comerciales y descargan el paquete en 1 clic.
2. Dashboard Maestro de Control (Nexora SaaS Master Control): Operando 100% de forma remota en la nube conectada a Supabase Central (https://aajgmgpcvbwqwrabuolj.supabase.co). Es el centro de mando comercial donde se gestionan los clientes CRM, cobros, abonos en dólares/pesos, dispositivos extra y el Alta Exprés de proyectos.

---

## 🔒 2. MODELO DE SEGURIDAD Y PRIVACIDAD (TIPO APP STORE / PLAY STORE)
Para proteger nuestro trabajo y estructuras, se aplica el siguiente protocolo de seguridad estricta:

* Secreto Absoluto del Código Fuente: El cliente final NUNCA accede a nuestro código fuente, ni a la base de datos Supabase, ni a credenciales maestras.
* Empaquetado Compilado (.ZIP / .EXE): Al cliente solo se le entrega el paquete cerrado ejecutable para Windows PC.
* Tokenización de Licencias: Cada registro genera automáticamente un ID_CLIENTE (ej: NEX-RESTOBAR-4EC5A8) y un TOKEN_SEGURIDAD alfanumérico de 16 caracteres.
* Inyección y Autodespliegue Pragmático (Cero Vueltas): La app instalada en la PC del cliente debe validar automáticamente el archivo licencia_activacion.txt pre-inyectado en el paquete o requerir el Token al iniciar por primera vez para activar sus 15 días de prueba.

---

## 💰 3. FORMATO DE PRECIOS Y LICENCIAMIENTO DUAL
Todos los sistemas comercializados bajo el sello Nexora se estructuran bajo las siguientes reglas financieras:

* Moneda Base: Precio en Dólares ($ USD) mensual + Conversión automática a Pesos Argentinos ($ ARS) según la cotización en tiempo real.
* Cobro por Dispositivos Extra: El cobro adicional por cajas o pantallas POS extra utiliza exactamente el mismo formato dual ($ USD / $ ARS).
* Modos de Publicación en el Cargador Exprés:
  * 🟢 Comercial (De Pago): Sistemas oficiales con abono mensual (ej: Suite Restobar a $65 USD/mes, Nexativa News a $35 USD/mes).
  * 🧪 Versión Beta / Prueba ($0 USD): Sistemas en fase de pruebas o evaluación totalmente gratuitos ($0 USD) para captar usuarios tester.
  * ⏳ Próximamente: Teasers de sistemas en desarrollo.

---

## 📦 4. PROCEDIMIENTO DE INTEGRACIÓN PARA NUEVOS SISTEMAS
Cuando construyas un nuevo sistema o módulo para la plataforma, debes cumplir con esta entrega:

1. Generación de Paquete Instalador: Compilar el proyecto localmente y empaquetar en un archivo comprimido .zip preparado para ejecutar en Windows PC (ej: MyProyecto_Setup.zip).
2. Registro de Ruta Local: Registrar el proyecto en el Cargador Exprés de Sistemas indicando la ruta local de tu PC (ej: D:\BARES 2026\MiProyecto.zip), categoría, tipo de versión (Comercial/Beta) y precio ($ USD).
3. Mapeo de Licencias en Supabase: El sistema consultará la tabla central nexora_clientes_SaaS en Supabase Cloud para verificar vencimientos, estado (activo / suspendido) y número de dispositivos autorizados.
4. Módulo de Feedback de Usuarios: El sistema puede recibir valoraciones (⭐ 1 a 5) y reseñas de experiencia que el administrador puede moderar (Hacer Público / Privado) desde el Dashboard Maestro.

---

## 🎯 RESUMEN DE LA DIRECTIVA
* Pragmatismo Total: El cliente no quiere vueltas. Hace 1 clic, descarga el .zip, abre la app en su PC y la app inicia activada.
* Seguridad Absoluta: Código fuente aislado en la nube.
* Control Centralizado: Todo el control comercial se maneja desde la nube de Supabase Central.

Entendido. Procederemos a trabajar bajo estas reglas para el desarrollo e integración de los siguientes sistemas.
