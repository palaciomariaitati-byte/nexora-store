import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://aajgmgpcvbwqwrabuolj.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFhamdtZ3BjdmJ3cXdyYWJ1b2xqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU0NDYyMDUsImV4cCI6MjEwMTAyMjIwNX0.s81meZHaOto-KYdMf5-72scDUb8Cyl2ONWXCthZlVcU';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || supabaseAnonKey;

// Cliente seguro para cliente y servidor
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Cliente Admin para API Routes (Serverless)
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

export const SUPABASE_STORAGE_URL = 'https://nexora-store-xi.vercel.app/downloads';
