'use client';

import React from 'react';
import Link from 'next/link';
import { ShoppingBag, ShieldCheck, Sparkles } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-xl border-b border-[#1b4353]/40 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Marca Nexora */}
          <Link href="/" className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#1b4353] via-[#3a6073] to-[#e4a834] p-[2px] shadow-lg shadow-[#1b4353]/50">
              <div className="w-full h-full bg-[#0e2430] rounded-[10px] flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-[#e4a834]" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-black tracking-tight text-white uppercase">
                  NEXORA <span className="bg-gradient-to-r from-[#e4a834] to-[#cf9323] bg-clip-text text-transparent">STORE</span>
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#1b4353]/60 text-[#e4a834] border border-[#e4a834]/30 uppercase">
                  App Store SaaS
                </span>
              </div>
              <p className="text-xs text-gray-400 font-medium">Centro Oficial de Software & Licencias Corporativas</p>
            </div>
          </Link>

          {/* Badges de Garantía Corporativa (Público Limpio) */}
          <div className="flex items-center space-x-4 sm:space-x-6">
            <div className="flex items-center space-x-2 text-xs font-semibold text-gray-300 bg-[#0e2430]/70 px-3.5 py-2 rounded-xl border border-[#1b4353]/30">
              <ShieldCheck className="w-4 h-4 text-[#e4a834]" />
              <span>Garantía Bancaria SaaS</span>
            </div>
            <div className="hidden sm:flex items-center space-x-2 text-xs font-semibold text-gray-300 bg-[#0e2430]/70 px-3.5 py-2 rounded-xl border border-[#1b4353]/30">
              <Sparkles className="w-4 h-4 text-[#e4a834]" />
              <span>15 Días de Prueba</span>
            </div>
          </div>

        </div>
      </div>
    </header>
  );
}
