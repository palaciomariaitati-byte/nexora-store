'use client';

import React from 'react';
import { Download, ShieldCheck, CheckCircle, Sparkles, Globe, ExternalLink } from 'lucide-react';

export interface Software {
  id: string;
  nombre: string;
  subtitulo: string;
  descripcion: string;
  categoria: string;
  icono: string;
  version: string;
  caracteristicas: string[];
  precioUsd?: number;
  destacado?: boolean;
  tipoEntrega?: 'web' | 'descarga';
  urlAcceso?: string;
  tipoVersion?: 'comercial' | 'beta' | 'prueba' | 'proximamente';
  visible?: boolean;
}

interface AppCardProps {
  software: Software;
  onSelect: (software: Software) => void;
  dolarRate?: number;
}

export default function AppCard({ software, onSelect, dolarRate = 1550 }: AppCardProps) {
  const precioUsd = software.precioUsd !== undefined ? software.precioUsd : 0;
  const precioArs = Math.round(precioUsd * dolarRate);
  const isWeb = software.tipoEntrega === 'web';

  return (
    <div className="relative group bg-[#0e2430]/90 border border-[#1b4353]/30 backdrop-blur-md rounded-2xl p-6 shadow-2xl hover:border-[#e4a834]/50 transition-all duration-300 flex flex-col justify-between overflow-hidden">
      
      {/* Destacado / Badge corporativo */}
      {software.destacado && (
        <div className="absolute top-0 right-0 bg-gradient-to-l from-[#e4a834] to-[#3a6073] text-[#083344] text-[10px] font-black uppercase px-3 py-1 rounded-bl-xl shadow-md flex items-center space-x-1">
          <Sparkles className="w-3 h-3 text-[#083344]" />
          <span>SISTEMA OFICIAL</span>
        </div>
      )}

      <div>
        {/* Cabecera del Software */}
        <div className="flex items-start space-x-4 mb-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#1b4353] via-[#3a6073] to-[#e4a834] p-[2px] shrink-0 shadow-lg group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-black rounded-[14px] flex items-center justify-center text-3xl">
              {software.icono}
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-xl font-black text-white tracking-tight group-hover:text-[#e4a834] transition-colors truncate">
              {software.nombre}
            </h3>
            <p className="text-xs font-semibold text-[#e4a834] line-clamp-1">{software.subtitulo}</p>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#1b4353]/50 text-gray-300 border border-[#1b4353]">
                v{software.version} • {software.categoria}
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${isWeb ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-700/50' : 'bg-emerald-950/60 text-emerald-300 border border-emerald-700/50'}`}>
                {isWeb ? '🌐 Portal / Web Online' : '📥 Instalador PC'}
              </span>
            </div>
          </div>
        </div>

        {/* Tarjeta de Precio USD & Pesos Argentinos (Soporta $0 Gratis) */}
        <div className="mb-4 p-3 rounded-xl bg-black/60 border border-[#e4a834]/30 flex justify-between items-center">
          {precioUsd === 0 ? (
            <div className="w-full flex justify-between items-center">
              <div>
                <span className="block text-[10px] font-bold text-gray-400 uppercase">Modalidad:</span>
                <span className="text-xl font-black text-emerald-400">100% GRATIS</span>
              </div>
              <div className="text-right">
                <span className="text-xs font-black text-[#e4a834] bg-[#0e2430] px-2.5 py-1 rounded-lg border border-[#e4a834]/40">
                  🎁 Acceso Oficial Libre
                </span>
              </div>
            </div>
          ) : (
            <>
              <div>
                <span className="block text-[10px] font-bold text-gray-400 uppercase">Abono Mensual:</span>
                <span className="text-xl font-black text-[#e4a834]">${precioUsd} USD <span className="text-[10px] text-gray-400 font-normal">/mes</span></span>
              </div>
              <div className="text-right">
                <span className="block text-[10px] font-bold text-gray-400 uppercase">Equivalente ARS:</span>
                <span className="text-sm font-bold text-emerald-400">~ ${precioArs.toLocaleString('es-AR')} ARS</span>
              </div>
            </>
          )}
        </div>

        {/* Descripción */}
        <p className="text-xs text-gray-300 leading-relaxed mb-4 line-clamp-3">
          {software.descripcion}
        </p>

        {/* Lista de características clave */}
        <div className="space-y-1.5 mb-6">
          {(software.caracteristicas || []).map((item, idx) => (
            <div key={idx} className="flex items-center space-x-2 text-xs text-gray-300">
              <CheckCircle className="w-3.5 h-3.5 text-[#e4a834] shrink-0" />
              <span className="truncate">{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Pie y Botón de Acción */}
      <div className="pt-4 border-t border-[#1b4353]/40 flex flex-col space-y-3">
        <div className="flex justify-between items-center text-[11px] text-gray-400 font-medium">
          <span className="flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isWeb ? 'Acceso Seguro Directo' : 'Licencia 15 Días Incluida'}</span>
          </span>
          <span className="text-[#e4a834] font-bold uppercase">{isWeb ? 'SaaS Web' : 'SaaS Desktop'}</span>
        </div>

        <button
          onClick={() => onSelect(software)}
          className={`w-full py-3.5 px-4 font-black uppercase rounded-xl transition-all duration-200 shadow-lg flex items-center justify-center space-x-2 text-xs tracking-wider cursor-pointer ${
            isWeb 
              ? 'text-white bg-gradient-to-r from-[#1b4353] to-[#3a6073] hover:from-[#235569] hover:to-[#4a7a92] border border-[#e4a834]/40 hover:border-[#e4a834]' 
              : 'text-[#083344] bg-[#e4a834] hover:bg-[#cf9323] hover:shadow-[#e4a834]/20'
          }`}
        >
          {isWeb ? <Globe className="w-4 h-4 text-[#e4a834]" /> : <Download className="w-4 h-4" />}
          <span>{isWeb ? '🌐 ACCEDER AL SISTEMA' : '📥 DESCARGAR E INSTALAR'}</span>
        </button>
      </div>

    </div>
  );
}
