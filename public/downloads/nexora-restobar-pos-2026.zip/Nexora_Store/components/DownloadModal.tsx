'use client';

import React, { useState } from 'react';
import { X, Download, CheckCircle2, Copy, AlertCircle, Loader2, Sparkles, Building2, Mail, Phone, Globe, ExternalLink, Smartphone, Laptop } from 'lucide-react';
import { Software } from './AppCard';

interface DownloadModalProps {
  software: Software | null;
  onClose: () => void;
}

interface LicenseData {
  id_cliente: string;
  sistema_id: string;
  nombre_comercio: string;
  email_propietario: string;
  token_seguridad: string;
  licencia_vencimiento: string;
  estado_licencia: string;
  enlace_descarga: string;
}

export default function DownloadModal({ software, onClose }: DownloadModalProps) {
  const [activeTab, setActiveTab] = useState<'descarga' | 'feedback'>('descarga');

  // Estado Formulario Descarga / Activación
  const [nombreComercio, setNombreComercio] = useState('');
  const [emailPropietario, setEmailPropietario] = useState('');
  const [telefonoWhatsapp, setTelefonoWhatsapp] = useState('');

  // Estado Formulario Feedback / Experiencia
  const [fbUsuario, setFbUsuario] = useState('');
  const [fbEstrellas, setFbEstrellas] = useState(5);
  const [fbComentario, setFbComentario] = useState('');
  const [fbEnviado, setFbEnviado] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [licenseResponse, setLicenseResponse] = useState<LicenseData | null>(null);
  const [isExisting, setIsExisting] = useState(false);

  if (!software) return null;
  const isWeb = software.tipoEntrega === 'web';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/registro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre_comercio: nombreComercio,
          email_propietario: emailPropietario,
          telefono_whatsapp: telefonoWhatsapp,
          sistema_id: software.id,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'No se pudo procesar la solicitud.');
      }

      setLicenseResponse(data.data);
      setIsExisting(data.isExisting || false);
    } catch (err: any) {
      setError(err.message || 'Error de conexión con el servidor.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyCredentials = () => {
    if (!licenseResponse) return;
    const textToCopy = `=== 🔑 CREDENCIALES & ACCESO NEXORA STORE ===
Sistema: ${software.nombre}
ID Cliente: ${licenseResponse.id_cliente}
Token de Seguridad: ${licenseResponse.token_seguridad}
Vencimiento: ${new Date(licenseResponse.licencia_vencimiento).toLocaleDateString('es-AR')}
Estado: ${licenseResponse.estado_licencia.toUpperCase()}
==============================================`;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fbComentario.trim()) return;

    const newFeedback = {
      id: 'fb_' + Date.now(),
      appNombre: software.nombre,
      usuario: fbUsuario.trim() || 'Usuario Anónimo',
      estrellas: fbEstrellas,
      comentario: fbComentario.trim(),
      esPublico: false,
      fecha: new Date().toISOString().split('T')[0],
    };

    try {
      const existing = localStorage.getItem('NEXORA_FEEDBACK_DATA_V1');
      const list = existing ? JSON.parse(existing) : [];
      list.unshift(newFeedback);
      localStorage.setItem('NEXORA_FEEDBACK_DATA_V1', JSON.stringify(list));
    } catch (err) {}

    setFbEnviado(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#0e2430]/95 border border-[#1b4353]/50 backdrop-blur-xl rounded-2xl shadow-2xl p-6 sm:p-8 text-white overflow-hidden">
        
        {/* Glow de Gradiente Corporativo superior */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-[#1b4353] via-[#3a6073] to-[#e4a834]" />

        {/* Botón Cerrar */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white p-2 rounded-xl bg-black/30 hover:bg-[#1b4353]/50 transition-all z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* PESTAÑAS */}
        <div className="flex border-b border-[#1b4353]/50 mb-6 font-bold text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('descarga')}
            className={`pb-3 px-4 transition-all border-b-2 ${activeTab === 'descarga' ? 'border-[#e4a834] text-[#e4a834]' : 'border-transparent text-gray-400 hover:text-white'}`}
          >
            {isWeb ? '🌐 Acceso & Activación' : '📥 Descarga & Licencia'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('feedback')}
            className={`pb-3 px-4 transition-all border-b-2 ${activeTab === 'feedback' ? 'border-[#e4a834] text-[#e4a834]' : 'border-transparent text-gray-400 hover:text-white'}`}
          >
            💬 Dejar Opinión
          </button>
        </div>

        {activeTab === 'feedback' ? (
          /* FEEDBACK */
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <span className="text-3xl">💬</span>
              <div>
                <h3 className="text-xl font-bold text-white uppercase tracking-tight">Feedback de Experiencia</h3>
                <p className="text-xs text-[#e4a834] font-semibold">{software.nombre}</p>
              </div>
            </div>

            {fbEnviado ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto text-2xl">
                  ✓
                </div>
                <h4 className="text-lg font-bold text-white uppercase">¡Gracias por tu opinión!</h4>
                <p className="text-xs text-gray-300">
                  Tu valoración fue recibida correctamente por el equipo de administración.
                </p>
                <button
                  onClick={() => { setFbEnviado(false); setActiveTab('descarga'); }}
                  className="py-2.5 px-5 bg-[#e4a834] text-[#083344] font-bold text-xs uppercase rounded-xl"
                >
                  Volver al Sistema
                </button>
              </div>
            ) : (
              <form onSubmit={handleFeedbackSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-300 mb-1">
                    Tu Nombre o Empresa (Opcional):
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: Juan Pérez / Estudio Musical"
                    value={fbUsuario}
                    onChange={(e) => setFbUsuario(e.target.value)}
                    className="w-full bg-black/60 border border-[#1b4353]/60 rounded-xl py-2.5 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#e4a834]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-gray-300 mb-1">
                    Valoración:
                  </label>
                  <div className="flex space-x-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setFbEstrellas(star)}
                        className={`text-2xl transition-transform ${star <= fbEstrellas ? 'scale-110' : 'opacity-40 hover:opacity-100'}`}
                      >
                        ⭐
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-gray-300 mb-1">
                    Comentario o Sugerencia *
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Escribe aquí tu opinión sobre este sistema..."
                    value={fbComentario}
                    onChange={(e) => setFbComentario(e.target.value)}
                    className="w-full bg-black/60 border border-[#1b4353]/60 rounded-xl p-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#e4a834]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 px-6 text-[#083344] bg-[#e4a834] hover:bg-[#cf9323] font-black uppercase rounded-xl transition-all shadow-xl text-xs"
                >
                  🚀 Enviar Feedback
                </button>
              </form>
            )}
          </div>
        ) : !licenseResponse ? (
          /* FORMULARIO DE REGISTRO */
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <span className="text-3xl">{software.icono}</span>
              <div>
                <h3 className="text-xl font-bold text-white uppercase tracking-tight">{software.nombre}</h3>
                <p className="text-xs text-[#e4a834] font-semibold">{software.subtitulo} (v{software.version})</p>
              </div>
            </div>

            <div className="p-3.5 mb-6 rounded-xl bg-[#1b4353]/30 border border-[#1b4353]/50 text-xs text-gray-300 flex items-start space-x-2">
              <Sparkles className="w-4 h-4 text-[#e4a834] shrink-0 mt-0.5" />
              <span>
                {isWeb 
                  ? 'Completa tus datos para ingresar directamente al portal oficial y generar tu ID de acceso.' 
                  : 'Obtén tu **licencia oficial gratuita por 15 días**. El sistema inyectará automáticamente tus credenciales en el instalador.'}
              </span>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-800/50 text-red-200 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-300 mb-1">
                  Nombre de tu Negocio, Banda o Persona *
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    placeholder="Ej: Auténtico Tributo Fan / Restobar Centro"
                    value={nombreComercio}
                    onChange={(e) => setNombreComercio(e.target.value)}
                    className="w-full bg-black/60 border border-[#1b4353]/60 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#e4a834] transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-300 mb-1">
                  Email de Contacto *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                  <input
                    type="email"
                    required
                    placeholder="tu-correo@ejemplo.com"
                    value={emailPropietario}
                    onChange={(e) => setEmailPropietario(e.target.value)}
                    className="w-full bg-black/60 border border-[#1b4353]/60 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#e4a834] transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-300 mb-1">
                  Teléfono / WhatsApp (Opcional)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                  <input
                    type="tel"
                    placeholder="+54 9 11 1234-5678"
                    value={telefonoWhatsapp}
                    onChange={(e) => setTelefonoWhatsapp(e.target.value)}
                    className="w-full bg-black/60 border border-[#1b4353]/60 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#e4a834] transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-6 py-3.5 px-6 text-[#083344] bg-[#e4a834] hover:bg-[#cf9323] font-black uppercase rounded-xl transition-all duration-200 shadow-xl shadow-[#e4a834]/10 flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Conectando con el Servidor...</span>
                  </>
                ) : (
                  <>
                    {isWeb ? <Globe className="w-5 h-5" /> : <Download className="w-5 h-5" />}
                    <span>{isWeb ? 'Generar Acceso & Abrir Sitio' : 'Generar Licencia de 15 Días & Descargar'}</span>
                  </>
                )}
              </button>
            </form>
          </div>
        ) : (
          /* PANTALLA DE ÉXITO */
          <div className="text-center py-2 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-2xl font-black uppercase text-white tracking-tight">
                {isWeb ? '¡Acceso Habilitado!' : '¡Licencia Activada!'}
              </h3>
              <p className="text-xs text-emerald-400 font-semibold mt-1">
                {isWeb ? '⚡ Tu usuario y credenciales fueron registradas con éxito' : '⚡ Tu licencia de 15 días ya está activa'}
              </p>
            </div>

            {/* CASO SISTEMA WEB (AUTÉNTICO TRIBUTO, NEXATIVA NEWS, PORTALES) */}
            {isWeb ? (
              <div className="space-y-4 pt-2 text-left">
                <div className="p-4 rounded-xl bg-gradient-to-br from-[#0e2430] to-black border border-[#e4a834]/50">
                  <div className="flex items-center space-x-2 mb-2">
                    <Globe className="w-5 h-5 text-[#e4a834]" />
                    <h4 className="text-sm font-bold text-white uppercase">{software.nombre}</h4>
                  </div>
                  <p className="text-xs text-gray-300 mb-4 leading-relaxed">
                    Este sistema está disponible en la nube para acceso directo desde cualquier navegador en celular o PC, sin necesidad de descargar archivos.
                  </p>
                  
                  <a
                    href={software.urlAcceso || licenseResponse.enlace_descarga || 'https://nexora-store-xi.vercel.app'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3.5 px-4 text-[#083344] bg-[#e4a834] hover:bg-[#cf9323] font-black uppercase rounded-xl transition-all flex items-center justify-center space-x-2 text-xs cursor-pointer shadow-lg shadow-[#e4a834]/20"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>🌐 ABRIR SISTEMA / SITIO OFICIAL AHORA</span>
                  </a>
                </div>

                <button
                  onClick={handleCopyCredentials}
                  className="w-full py-2.5 px-4 bg-black/40 hover:bg-[#1b4353]/40 text-gray-300 hover:text-white font-semibold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 border border-white/10 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-[#e4a834]" />
                  <span>{copied ? '✓ ¡Credenciales Copiadas!' : 'Copiar Credenciales de Acceso (Opcional)'}</span>
                </button>
              </div>
            ) : (
              /* CASO INSTALADOR DESCARGABLE PC (RESTOBAR, NORA PERIODISTA) */
              <div className="space-y-3 pt-2">
                <a
                  href={licenseResponse?.enlace_descarga || '/downloads/Suite_Restobar_2026_Setup.zip'}
                  download
                  className="w-full py-4 px-6 text-[#083344] bg-[#e4a834] hover:bg-[#cf9323] font-black uppercase rounded-xl transition-all duration-200 shadow-xl shadow-[#e4a834]/20 flex items-center justify-center space-x-2 cursor-pointer text-sm"
                >
                  <Download className="w-6 h-6" />
                  <span>🚀 DESCARGAR E INSTALAR SISTEMA (.ZIP)</span>
                </a>

                <button
                  onClick={handleCopyCredentials}
                  className="w-full py-2.5 px-4 bg-black/40 hover:bg-[#1b4353]/40 text-gray-300 hover:text-white font-semibold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 border border-white/10 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-[#e4a834]" />
                  <span>{copied ? '✓ ¡Credenciales Copiadas!' : 'Copiar copia de resguardo de claves'}</span>
                </button>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
