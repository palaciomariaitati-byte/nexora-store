-- ====================================================================
-- ESQUEMA DDL OFICIAL: MAESTRO DE LICENCIAS SAAS DE NEXORA STORE
-- Instancia Cloud de Supabase
-- ====================================================================

CREATE TABLE IF NOT EXISTS nexora_clientes_SaaS (
    id_registro UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    id_cliente VARCHAR(100) NOT NULL,
    sistema_id VARCHAR(100) NOT NULL, -- 'restobar' | 'nora_itu' | 'periodismo' | 'nexativa_news'
    nombre_comercio VARCHAR(255) NOT NULL,
    email_propietario VARCHAR(255) NOT NULL,
    telefono_whatsapp VARCHAR(50),
    fecha_alta TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    licencia_vencimiento TIMESTAMP WITH TIME ZONE NOT NULL, -- Calculado automáticamente a +15 días
    estado_licencia VARCHAR(50) DEFAULT 'activo', -- 'activo' | 'alerta' | 'suspendido'
    token_seguridad VARCHAR(255) NOT NULL,
    creado_en TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT unica_suscripcion_por_sistema UNIQUE (email_propietario, sistema_id)
);

-- Índice de búsqueda rápida por cliente y sistema
CREATE INDEX IF NOT EXISTS idx_nexora_clientes_lookup 
ON nexora_clientes_SaaS(id_cliente, sistema_id);

-- Comentarios documentales
COMMENT ON TABLE nexora_clientes_SaaS IS 'Tabla centralizada de gestión de clientes y licencias SaaS de Nexora Store';
COMMENT ON COLUMN nexora_clientes_SaaS.licencia_vencimiento IS 'Fecha de expiración (+15 días de prueba inicial o extensión de pago)';
