import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';

export interface SoftwareItem {
  id: string;
  nombre: string;
  subtitulo: string;
  descripcion: string;
  categoria: string;
  icono: string;
  version: string;
  precioUsd: number;
  destacado?: boolean;
  caracteristicas: string[];
  tipoEntrega?: 'web' | 'descarga';
  urlAcceso?: string;
  tipoVersion?: 'comercial' | 'beta' | 'prueba' | 'proximamente';
  visible?: boolean;
}

// Catálogo maestro oficial de sistemas Nexora
const DEFAULT_CATALOG: SoftwareItem[] = [
  {
    id: 'autentico_tributo',
    nombre: 'Auténtico Tributo (Portal & Sistema Oficial)',
    subtitulo: '🎯 Sistema Integral para Bandas, Conciertos & Shows en Vivo',
    descripcion: 'Plataforma oficial desarrollada para la banda Auténtico Tributo. Incluye portal interactivo para fans, pantalla gigante para shows en vivo, administración de repertorio, canciones y módulo móvil.',
    categoria: '🎵 Música & Eventos',
    icono: '🎸',
    version: '2.0.0 (Web Oficial)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexora-store-xi.vercel.app',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🌐 Acceso 100% Online y Directo (Sin necesidad de descargas)',
      '🎤 Módulo de Pantalla Gigante e interactividad con el público',
      '📱 App Móvil para fans y pedidos de canciones en vivo',
      '⚡ Panel de control y repertorio de la banda',
    ],
  },
  {
    id: 'restobar',
    nombre: 'Restobar 2026 (Suite Gastronómica)',
    subtitulo: 'Sistema de Gestión Gastronómica & Bares',
    descripcion: 'Plataforma integral para restaurantes, bares y pubs. Control en tiempo real de mesas, comandas digitales, stock de insumos y facturación rápida.',
    categoria: 'Gastronomía & Bares',
    icono: '🍹',
    version: '4.8.2 (Compilado)',
    precioUsd: 65,
    destacado: true,
    tipoEntrega: 'descarga',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      'Mapa interactivo de salón y comandas digitales',
      'Facturación e integración con impresoras térmicas',
      'Control estricto de caja e inventario de stock',
      'Licencia autónoma de 15 días con instalador compilado',
    ],
  },
  {
    id: 'nexora_clasificados',
    nombre: 'Nexora Clasificados Móvil',
    subtitulo: '🎯 Compra-Venta Directa de Autos, Motos y Segunda Mano',
    descripcion: 'App ciudadana gratuita para comprar y vender autos, motos, herramientas y artículos usados en Ituzaingó y la región. Carga de hasta 10 fotos con compresión WebP y contacto directo por WhatsApp.',
    categoria: '🚗 Clasificados & Autos (Gratis)',
    icono: '🚗',
    version: '1.0.0 (PWA Oficial)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/clasificados',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🚗 Publicación gratuita de autos, motos y artículos usados',
      '📸 Carga de hasta 10 fotos en alta resolución WebP',
      '🤖 Asistente NORA IA para redactar avisos que venden',
      '📲 Contacto directo con el comprador por WhatsApp',
    ],
  },
  {
    id: 'inmuebles_verificados',
    nombre: 'Inmuebles Verificados',
    subtitulo: '🎯 Portal Regional de Alquileres, Casas y Propiedades',
    descripcion: 'Plataforma oficial de búsqueda y publicación de propiedades, casas, departamentos y alquileres temporarios y anuales verificados en Ituzaingó y la región.',
    categoria: '🏠 Inmuebles & Vivienda (Gratis)',
    icono: '🏠',
    version: '2.4.0 (Web & PWA)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/guia/inmuebles',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🏠 Directorio de propiedades y alquileres verificados',
      '📍 Fotos en alta definición, mapa y datos precisos',
      '📱 Sistema 100% gratuito e instalable en celulares',
      '🤝 Trato directo con dueños e inmobiliarias de confianza',
    ],
  },
  {
    id: 'empleos_oficios',
    nombre: 'Empleos & Oficios Regionales',
    subtitulo: '🎯 Bolsa de Trabajo y Directorio de Prestadores de Oficios',
    descripcion: 'Bolsa de trabajo regional para buscar empleo y contratar prestadores calificados (electricistas, plomeros, albañiles, técnicos) en Ituzaingó y localidades vecinas.',
    categoria: '💼 Empleos & Trabajo (Gratis)',
    icono: '💼',
    version: '2.1.0 (Web & PWA)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/empleos',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '💼 Bolsa de trabajo con postulaciones inmediatas',
      '🛠️ Catálogo de prestadores de oficios de confianza',
      '📱 Instalación PWA rápida para Android y iPhone',
      '🤝 Conexión directa empleador - trabajador vía WhatsApp',
    ],
  },
  {
    id: 'nora_itu_soberano',
    nombre: 'NORA ITU — Asistente de Voz y Accesibilidad DUA',
    subtitulo: '🎯 Inteligencia Artificial Soberana, Educativa y 100% Accesible',
    descripcion: 'Asistente de voz multimodal soberana ($0 costo comercial). Diseñada bajo principios DUA con soporte nativo para TalkBack y VoiceOver para personas con discapacidad visual y alumnos.',
    categoria: '🎙️ Nora IA & Accesibilidad (Gratis)',
    icono: '🎙️',
    version: '5.0.0 (Soberana DUA)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/noraitu',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🎙️ Llamada y conversación de voz natural en tiempo real',
      '♿ Coexistencia con lectores de pantalla TalkBack y VoiceOver',
      '🧠 Inferencia abierta y soberana con 0 caídas',
      '📚 Respuestas educativas y noticias locales al instante',
    ],
  },
  {
    id: 'nexativa_news',
    nombre: 'NexativaNews (Panel Principal)',
    subtitulo: 'Portal de Prensa & Redacción Periodística',
    descripcion: 'Panel principal de redacción periodística de alto rendimiento. Editor de notas, gestión de portales y distribución de medios digitales.',
    categoria: 'Prensa & Medios',
    icono: '📰',
    version: '1.9.5 (Panel)',
    precioUsd: 35,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexativa-news.vercel.app',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      'Acceso directo al Panel Principal de Prensa',
      'Edición y distribución de noticias multicanal',
      'Módulos de redacción y analítica de lectores',
      'Sincronización de artículos y contenidos',
    ],
  },
  {
    id: 'nora_ciudadano_free',
    nombre: 'NORA AI (Reportero Ciudadano)',
    subtitulo: '🎯 Orientado a: Uso Aficionado & Prensa Ciudadana Colaborativa',
    descripcion: 'App móvil gratuita para vecinos, testigos y cronistas aficionados. Graba testimonios de voz y fotos en la calle con asistencia de NORA AI. Tus reportes se envían a la redacción central de NexativaNews para su análisis, verificación y cobertura periodística.',
    categoria: 'Prensa Ciudadana (Gratis)',
    icono: '📱',
    version: '1.2.0 (Edición Ciudadana)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexativa-news.vercel.app?modo=ciudadano',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '📱 App Móvil de Campo para Celulares (Android / iOS PWA)',
      '🎙️ Graba audios y notas de voz con transcripción NORA AI',
      '📷 Envío directo de fotos y testimonios de la calle',
      '🤝 Envía tus noticias a la red central de NexativaNews',
    ],
  },
  {
    id: 'nora_periodista_exterior',
    nombre: 'NORA AI (Periodismo Profesional & Exteriores)',
    subtitulo: '🎯 Orientado a: Medios de Prensa, Radios & Portales Profesionales',
    descripcion: 'Suite multimodal completa y privada para medios de comunicación. Incluye Panel de Redacción Central para PC, App Móvil para tu equipo de cronistas, soberanía 100% privada de tus noticias y difusión simultánea a tus propias Redes Sociales en 1 clic.',
    categoria: 'Prensa Profesional & IA',
    icono: '🎙️',
    version: '2.1.0 (Suite Comercial)',
    precioUsd: 35,
    destacado: true,
    tipoEntrega: 'descarga',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      '💻 Panel de Redacción & Edición en PC (Mesa Central)',
      '📱 App Móvil de Campo para tus Cronistas (PWA Celular)',
      '🔒 Canal Privado e Independiente (Tus noticias son 100% tuyas)',
      '📲 Difusión simultánea a tus Redes (Facebook, X, WhatsApp)',
    ],
  },
  {
    id: 'nexora_store_app',
    nombre: 'Nexora Store (App Oficial PWA)',
    subtitulo: '🎯 Orientado a: Clientes, Comercios & Desarrolladores',
    descripcion: 'Instala la tienda oficial de Nexora en tu teléfono celular o PC en modo 100% Gratis. Accede a todo el catálogo de sistemas SaaS, activa licencias de prueba en 1 clic y recibe notificaciones de nuevas actualizaciones.',
    categoria: 'App Store & Hub SaaS (Gratis)',
    icono: '🛍️',
    version: '3.0.0 (PWA Oficial)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexora-store-xi.vercel.app',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '📱 Instalación instantánea en Celulares (Android & iPhone)',
      '💻 Acceso directo como App de Escritorio en PC Windows',
      '⚡ Catálogo completo de sistemas y licencias gratuitas',
      '🔔 Alertas de nuevas versiones, módulos y soporte oficial',
    ],
  },
  {
    id: 'nexora_ads',
    nombre: 'Nexora Ads & Marketing',
    subtitulo: 'Gestor Automatizado de Campañas Meta & Google',
    descripcion: 'Plataforma de generación automática de anuncios, difusión de ofertas y marketing digital.',
    categoria: 'Publicidad & Ads',
    icono: '📣',
    version: 'Próximamente',
    precioUsd: 60,
    tipoEntrega: 'web',
    tipoVersion: 'proximamente',
    visible: true,
    caracteristicas: [
      'Integración con API Meta Ads & Google Marketing',
      'Próximamente disponible para suscripción',
    ],
  },
];

// Almacén en memoria del servidor
let catalogMemory: SoftwareItem[] = [...DEFAULT_CATALOG];

export async function GET() {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };

  try {
    // 1. Intentar consultar catálogo dinámico desde Supabase
    const { data, error } = await supabaseAdmin
      .from('nexora_catalogo_sistemas')
      .select('*')
      .order('destacado', { ascending: false });

    if (!error && data && data.length > 0) {
      // Mapear campos de base de datos a formato de SoftwareItem
      const dbCatalog: SoftwareItem[] = data.map((row: any) => ({
        id: row.id_sistema || row.id,
        nombre: row.nombre,
        subtitulo: row.subtitulo || '',
        descripcion: row.descripcion || '',
        categoria: row.categoria || 'Software SaaS',
        icono: row.icono || '📦',
        version: row.version || '1.0.0',
        precioUsd: row.precio_usd !== undefined ? Number(row.precio_usd) : 0,
        destacado: Boolean(row.destacado),
        tipoEntrega: row.tipo_entrega || 'descarga',
        urlAcceso: row.url_acceso || '',
        tipoVersion: row.tipo_version || (row.precio_usd === 0 ? 'prueba' : 'comercial'),
        visible: row.visible !== false,
        caracteristicas: Array.isArray(row.caracteristicas) ? row.caracteristicas : (row.caracteristicas ? JSON.parse(row.caracteristicas) : []),
      }));

      // Filtrar solo los visibles
      const activeList = dbCatalog.filter(item => item.visible !== false);
      return NextResponse.json({ success: true, catalog: activeList }, { headers: corsHeaders });
    }
  } catch (e) {
    // Fallback a memoria
  }

  // Filtrar solo visibles de memoria
  const visibleCatalog = catalogMemory.filter(item => item.visible !== false);
  return NextResponse.json({ success: true, catalog: visibleCatalog }, { headers: corsHeaders });
}

export async function POST(req: Request) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };

  try {
    const body = await req.json();
    const {
      id,
      nombre,
      subtitulo,
      descripcion,
      categoria,
      icono,
      version,
      precioUsd,
      destacado,
      caracteristicas,
      tipoEntrega,
      urlAcceso,
      tipoVersion,
      visible,
    } = body;

    if (!nombre) {
      return NextResponse.json({ success: false, error: 'El nombre del sistema es obligatorio' }, { status: 400, headers: corsHeaders });
    }

    const itemKey = id || nombre.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 30);
    const existingIndex = catalogMemory.findIndex(a => a.id === itemKey);

    const updatedItem: SoftwareItem = {
      id: itemKey,
      nombre: nombre || (existingIndex > -1 ? catalogMemory[existingIndex].nombre : 'Nuevo Sistema'),
      subtitulo: subtitulo || (existingIndex > -1 ? catalogMemory[existingIndex].subtitulo : ''),
      descripcion: descripcion || (existingIndex > -1 ? catalogMemory[existingIndex].descripcion : ''),
      categoria: categoria || (existingIndex > -1 ? catalogMemory[existingIndex].categoria : 'General'),
      icono: icono || (existingIndex > -1 ? catalogMemory[existingIndex].icono : '📦'),
      version: version || (existingIndex > -1 ? catalogMemory[existingIndex].version : '1.0.0'),
      precioUsd: precioUsd !== undefined ? Number(precioUsd) : (existingIndex > -1 ? catalogMemory[existingIndex].precioUsd : 0),
      destacado: destacado !== undefined ? Boolean(destacado) : (existingIndex > -1 ? catalogMemory[existingIndex].destacado : false),
      caracteristicas: Array.isArray(caracteristicas) ? caracteristicas : (existingIndex > -1 ? catalogMemory[existingIndex].caracteristicas : ['Acceso oficial', 'Garantía Nexora']),
      tipoEntrega: tipoEntrega || (existingIndex > -1 ? catalogMemory[existingIndex].tipoEntrega : 'descarga'),
      urlAcceso: urlAcceso || (existingIndex > -1 ? catalogMemory[existingIndex].urlAcceso : ''),
      tipoVersion: tipoVersion || (precioUsd === 0 ? 'prueba' : 'comercial'),
      visible: visible !== undefined ? Boolean(visible) : true,
    };

    if (existingIndex > -1) {
      catalogMemory[existingIndex] = updatedItem;
    } else {
      catalogMemory.unshift(updatedItem);
    }

    // Intentar guardar en Supabase si la tabla existe
    try {
      await supabaseAdmin.from('nexora_catalogo_sistemas').upsert({
        id_sistema: itemKey,
        nombre: updatedItem.nombre,
        subtitulo: updatedItem.subtitulo,
        descripcion: updatedItem.descripcion,
        categoria: updatedItem.categoria,
        icono: updatedItem.icono,
        version: updatedItem.version,
        precio_usd: updatedItem.precioUsd,
        destacado: updatedItem.destacado,
        caracteristicas: updatedItem.caracteristicas,
        tipo_entrega: updatedItem.tipoEntrega,
        url_acceso: updatedItem.urlAcceso,
        tipo_version: updatedItem.tipoVersion,
        visible: updatedItem.visible,
        updated_at: new Date().toISOString(),
      });
    } catch (dbErr) {
      // Ignorar si la tabla no está creada aún
    }

    return NextResponse.json({ success: true, item: updatedItem, catalog: catalogMemory.filter(i => i.visible !== false) }, { headers: corsHeaders });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Error al procesar solicitud' }, { status: 500, headers: corsHeaders });
  }
}

export async function DELETE(req: Request) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ success: false, error: 'Falta el id del sistema a eliminar' }, { status: 400, headers: corsHeaders });
    }

    catalogMemory = catalogMemory.filter(item => item.id !== id);

    try {
      await supabaseAdmin.from('nexora_catalogo_sistemas').delete().eq('id_sistema', id);
    } catch (e) {}

    return NextResponse.json({ success: true, message: `Sistema ${id} eliminado`, catalog: catalogMemory.filter(i => i.visible !== false) }, { headers: corsHeaders });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500, headers: corsHeaders });
  }
}

export async function OPTIONS() {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}
