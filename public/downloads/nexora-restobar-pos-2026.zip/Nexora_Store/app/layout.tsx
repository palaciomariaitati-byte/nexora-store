import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';

export const metadata: Metadata = {
  title: 'Nexora Store | Shopping Digital de Software SaaS',
  description: 'Descarga e instalación de sistemas corporativos oficiales: Restobar, Nora ITU IA, Central de Periodismo y NexativaNews.',
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className="dark">
      <body className="bg-black text-white antialiased min-h-screen flex flex-col selection:bg-[#e4a834] selection:text-[#083344]">
        <Header />
        <main className="flex-grow">{children}</main>
        
        {/* Footer Institucional */}
        <footer className="bg-black border-t border-[#1b4353]/30 py-8 text-center text-xs text-gray-500">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-gray-300">NEXORA STORE SaaS © 2026</span>
              <span>• Todos los derechos reservados.</span>
            </div>
            <div className="flex items-center space-x-4 text-gray-400">
              <span className="hover:text-[#e4a834] cursor-pointer">Soporte Técnico</span>
              <span>•</span>
              <span className="hover:text-[#e4a834] cursor-pointer">Validación de Licencias</span>
              <span>•</span>
              <span className="hover:text-[#e4a834] cursor-pointer">Nexora Pay Bridge</span>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
