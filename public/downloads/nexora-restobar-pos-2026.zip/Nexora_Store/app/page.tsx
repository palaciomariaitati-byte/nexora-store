'use client';

import React, { useState, useEffect } from 'react';
import AppCard, { Software } from '@/components/AppCard';
import DownloadModal from '@/components/DownloadModal';
import { Sparkles, Terminal, Database, Server, Shield, Layers, Search, Filter } from 'lucide-react';

const INITIAL_SOFTWARE_CATALOG: Software[] = [
  {
    id: 'nexora_club_pay',
    nombre: 'Nexora Club & Carribar Pass (Closed-Loop)',
    subtitulo: '👑 Ecosistema Fintech Cerrado para Boliches, Barras & Carribares',
    descripcion: 'Sistema cerrado de cobros rápidos por QR, billetera digital prepaga para clientes, punto de venta táctil 1-clic para barras y carribares exteriores, control de stock por voz asistido por Nora IA y panel de gamificación en vivo para DJs.',
    categoria: 'Discotecas, Bares & Foodtrucks',
    icono: '🍸',
    version: '1.0.0 (Suite Oficial)',
    precioUsd: 150,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexora-club-pay.vercel.app',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      '💰 Alcancía digital prepaga: recarga de saldo antes de entrar o en caja',
      '⚡ Débito atómico instantáneo (<1 segundo) con confirmación por Beep sonoro',
      '🔐 Separación de roles con PINs: Barra (1111), Carribar (2222), DJ Master (2026)',
      '📷 Doble vía de escaneo: el cliente escanea el cartel o el bartender escanea al cliente',
      '🎉 Premios y sorteos DJ en vivo acreditados al celular en tiempo real',
      '🎙️ Carga de mercadería por voz con Nora IA (cajones, botellas, medallones, panes)',
      '📊 Auditoría y arqueo ciego diario sin fugas de dinero ni comisiones por trago'
    ],
  },
  {
    id: 'autentico_tributo',
    nombre: 'Auténtico Tributo (Portal & Sistema Oficial)',
    subtitulo: '🎯 Sistema Integral para Bandas, Conciertos & Shows en Vivo',
    descripcion: 'Plataforma oficial desarrollada para la banda Auténtico Tributo. Incluye portal interactivo para fans, pantalla gigante para shows en vivo, administración de repertorio, canciones y módulo móvil.',
    categoria: '🎵 Música & Eventos',
    icono: '🎸',
    version: '2.0.0 (Web Oficial)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexora-store-xi.vercel.app',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🌐 Acceso 100% Online y Directo (Sin necesidad de descargas)',
      '🎤 Módulo de Pantalla Gigante e interactividad con el público',
      '📱 App Móvil para fans y pedidos de canciones en vivo',
      '⚡ Panel de control y repertorio de la banda',
    ],
  },
  {
    id: 'restobar',
    nombre: 'Restobar 2026 (Suite Gastronómica)',
    subtitulo: 'Sistema de Gestión Gastronómica & Bares',
    descripcion: 'Plataforma integral para restaurantes, bares y pubs. Control en tiempo real de mesas, comandas digitales, stock de insumos y facturación rápida.',
    categoria: 'Gastronomía & Bares',
    icono: '🍹',
    version: '4.8.2 (Compilado)',
    precioUsd: 65,
    destacado: true,
    tipoEntrega: 'descarga',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      'Mapa interactivo de salón y comandas digitales',
      'Facturación e integración con impresoras térmicas',
      'Control estricto de caja e inventario de stock',
      'Licencia autónoma de 15 días con instalador compilado',
    ],
  },
  {
    id: 'nexora_clasificados',
    nombre: 'Nexora Clasificados Móvil',
    subtitulo: '🎯 Compra-Venta Directa de Autos, Motos y Segunda Mano',
    descripcion: 'App ciudadana gratuita para comprar y vender autos, motos, herramientas y artículos usados en Ituzaingó y la región. Carga de hasta 10 fotos con compresión WebP y contacto directo por WhatsApp.',
    categoria: '🚗 Clasificados & Autos (Gratis)',
    icono: '🚗',
    version: '1.0.0 (PWA Oficial)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/clasificados',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🚗 Publicación gratuita de autos, motos y artículos usados',
      '📸 Carga de hasta 10 fotos en alta resolución WebP',
      '🤖 Asistente NORA IA para redactar avisos que venden',
      '📲 Contacto directo con el comprador por WhatsApp',
    ],
  },
  {
    id: 'inmuebles_verificados',
    nombre: 'Inmuebles Verificados',
    subtitulo: '🎯 Portal Regional de Alquileres, Casas y Propiedades',
    descripcion: 'Plataforma oficial de búsqueda y publicación de propiedades, casas, departamentos y alquileres temporarios y anuales verificados en Ituzaingó y la región.',
    categoria: '🏠 Inmuebles & Vivienda (Gratis)',
    icono: '🏠',
    version: '2.4.0 (Web & PWA)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/guia/inmuebles',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🏠 Directorio de propiedades y alquileres verificados',
      '📍 Fotos en alta definición, mapa y datos precisos',
      '📱 Sistema 100% gratuito e instalable en celulares',
      '🤝 Trato directo con dueños e inmobiliarias de confianza',
    ],
  },
  {
    id: 'empleos_oficios',
    nombre: 'Empleos & Oficios Regionales',
    subtitulo: '🎯 Bolsa de Trabajo y Directorio de Prestadores de Oficios',
    descripcion: 'Bolsa de trabajo regional para buscar empleo y contratar prestadores calificados (electricistas, plomeros, albañiles, técnicos) en Ituzaingó y localidades vecinas.',
    categoria: '💼 Empleos & Trabajo (Gratis)',
    icono: '💼',
    version: '2.1.0 (Web & PWA)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/empleos',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '💼 Bolsa de trabajo con postulaciones inmediatas',
      '🛠️ Catálogo de prestadores de oficios de confianza',
      '📱 Instalación PWA rápida para Android y iPhone',
      '🤝 Conexión directa empleador - trabajador vía WhatsApp',
    ],
  },
  {
    id: 'nora_itu_soberano',
    nombre: 'NORA ITU — Asistente de Voz y Accesibilidad DUA',
    subtitulo: '🎯 Inteligencia Artificial Soberana, Educativa y 100% Accesible',
    descripcion: 'Asistente de voz multimodal soberana ($0 costo comercial). Diseñada bajo principios DUA con soporte nativo para TalkBack y VoiceOver para personas con discapacidad visual y alumnos.',
    categoria: '🎙️ Nora IA & Accesibilidad (Gratis)',
    icono: '🎙️',
    version: '5.0.0 (Soberana DUA)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://www.nexativanews.com.ar/noraitu',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '🎙️ Llamada y conversación de voz natural en tiempo real',
      '♿ Coexistencia con lectores de pantalla TalkBack y VoiceOver',
      '🧠 Inferencia abierta y soberana con 0 caídas',
      '📚 Respuestas educativas y noticias locales al instante',
    ],
  },
  {
    id: 'nexativa_news',
    nombre: 'NexativaNews (Panel Principal)',
    subtitulo: 'Portal de Prensa & Redacción Periodística',
    descripcion: 'Panel principal de redacción periodística de alto rendimiento. Editor de notas, gestión de portales y distribución de medios digitales.',
    categoria: 'Prensa & Medios',
    icono: '📰',
    version: '1.9.5 (Panel)',
    precioUsd: 35,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexativa-news.vercel.app',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      'Acceso directo al Panel Principal de Prensa',
      'Edición y distribución de noticias multicanal',
      'Módulos de redacción y analítica de lectores',
      'Sincronización de artículos y contenidos',
    ],
  },
  {
    id: 'nora_ciudadano_free',
    nombre: 'NORA AI (Reportero Ciudadano)',
    subtitulo: '🎯 Orientado a: Uso Aficionado & Prensa Ciudadana Colaborativa',
    descripcion: 'App móvil gratuita para vecinos, testigos y cronistas aficionados. Graba testimonios de voz y fotos en la calle con asistencia de NORA AI. Tus reportes se envían a la redacción central de NexativaNews para su análisis, verificación y cobertura periodística.',
    categoria: 'Prensa Ciudadana (Gratis)',
    icono: '📱',
    version: '1.2.0 (Edición Ciudadana)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexativa-news.vercel.app?modo=ciudadano',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '📱 App Móvil de Campo para Celulares (Android / iOS PWA)',
      '🎙️ Graba audios y notas de voz con transcripción NORA AI',
      '📷 Envío directo de fotos y testimonios de la calle',
      '🤝 Envía tus noticias a la red central de NexativaNews',
    ],
  },
  {
    id: 'nora_periodista_exterior',
    nombre: 'NORA AI (Periodismo Profesional & Exteriores)',
    subtitulo: '🎯 Orientado a: Medios de Prensa, Radios & Portales Profesionales',
    descripcion: 'Suite multimodal completa y privada para medios de comunicación. Incluye Panel de Redacción Central para PC, App Móvil para tu equipo de cronistas, soberanía 100% privada de tus noticias y difusión simultánea a tus propias Redes Sociales en 1 clic.',
    categoria: 'Prensa Profesional & IA',
    icono: '🎙️',
    version: '2.1.0 (Suite Comercial)',
    precioUsd: 35,
    destacado: true,
    tipoEntrega: 'descarga',
    tipoVersion: 'comercial',
    visible: true,
    caracteristicas: [
      '💻 Panel de Redacción & Edición en PC (Mesa Central)',
      '📱 App Móvil de Campo para tus Cronistas (PWA Celular)',
      '🔒 Canal Privado e Independiente (Tus noticias son 100% tuyas)',
      '📲 Difusión simultánea a tus Redes (Facebook, X, WhatsApp)',
    ],
  },
  {
    id: 'nexora_store_app',
    nombre: 'Nexora Store (App Oficial PWA)',
    subtitulo: '🎯 Orientado a: Clientes, Comercios & Desarrolladores',
    descripcion: 'Instala la tienda oficial de Nexora en tu teléfono celular o PC en modo 100% Gratis. Accede a todo el catálogo de sistemas SaaS, activa licencias de prueba en 1 clic y recibe notificaciones de nuevas actualizaciones.',
    categoria: 'App Store & Hub SaaS (Gratis)',
    icono: '🛍️',
    version: '3.0.0 (PWA Oficial)',
    precioUsd: 0,
    destacado: true,
    tipoEntrega: 'web',
    urlAcceso: 'https://nexora-store-xi.vercel.app',
    tipoVersion: 'prueba',
    visible: true,
    caracteristicas: [
      '📱 Instalación instantánea en Celulares (Android & iPhone)',
      '💻 Acceso directo como App de Escritorio en PC Windows',
      '⚡ Catálogo completo de sistemas y licencias gratuitas',
      '🔔 Alertas de nuevas versiones, módulos y soporte oficial',
    ],
  },
  {
    id: 'nexora_ads',
    nombre: 'Nexora Ads & Marketing',
    subtitulo: 'Gestor Automatizado de Campañas Meta & Google',
    descripcion: 'Plataforma de generación automática de anuncios, difusión de ofertas y marketing digital.',
    categoria: 'Publicidad & Ads',
    icono: '📣',
    version: 'Próximamente',
    precioUsd: 60,
    tipoEntrega: 'web',
    tipoVersion: 'proximamente',
    visible: true,
    caracteristicas: [
      'Integración con API Meta Ads & Google Marketing',
      'Próximamente disponible para suscripción',
    ],
  },
];

export default function Home() {
  const [catalog, setCatalog] = useState<Software[]>(INITIAL_SOFTWARE_CATALOG);
  const [selectedSoftware, setSelectedSoftware] = useState<Software | null>(null);
  const [dolarRate, setDolarRate] = useState<number>(1550);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    async function fetchRate() {
      try {
        const res = await fetch('https://dolarapi.com/v1/dolares/blue');
        if (res.ok) {
          const data = await res.json();
          if (data.venta) setDolarRate(data.venta);
        }
      } catch (err) {
        console.warn('Usando cotización de dólar por defecto:', err);
      }
    }

    async function fetchCatalog() {
      try {
        const res = await fetch('/api/catalogo');
        if (res.ok) {
          const data = await res.json();
          if (data.catalog && Array.isArray(data.catalog) && data.catalog.length > 0) {
            setCatalog(data.catalog);
          }
        }
      } catch (err) {
        console.warn('Usando catálogo inicial:', err);
      }
    }

    fetchRate();
    fetchCatalog();
  }, []);

  // Extraer categorías únicas
  const categories = ['all', ...Array.from(new Set(catalog.map((item) => item.categoria)))];

  // Filtrado de sistemas
  const filteredCatalog = catalog.filter((item) => {
    const matchesSearch =
      item.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.descripcion.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.categoria.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.categoria === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      
      {/* Fondo con resplandor */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-[#1b4353]/30 via-[#3a6073]/20 to-[#e4a834]/15 blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* BANNER HERO */}
        <div className="relative rounded-3xl p-8 sm:p-12 mb-12 bg-gradient-to-tr from-[#1b4353] via-[#3a6073] to-[#e4a834] overflow-hidden shadow-2xl border border-[#1b4353]/50">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />

          <div className="relative z-10 max-w-3xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-black/60 border border-[#e4a834]/40 text-[#e4a834] text-xs font-bold uppercase mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SHOPPING DIGITAL DE SISTEMAS NEXORA</span>
            </div>

            <h1 className="text-4xl sm:text-5xl font-black text-white uppercase tracking-tight leading-none mb-4">
              PORTAL Y TIENDA DE <span className="text-[#e4a834]">SOFTWARE SAAS</span>
            </h1>

            <p className="text-base sm:text-lg text-gray-200 font-medium leading-relaxed mb-8">
              Catálogo oficial de sistemas, portales web e instaladores desarrollados por Nexora. 
              Accede a portales oficiales en vivo o descarga instaladores con 15 días de prueba en 1 clic.
            </p>

            <div className="flex flex-wrap gap-4 text-xs font-semibold text-gray-300">
              <div className="flex items-center space-x-2 bg-black/60 px-4 py-2 rounded-xl border border-[#1b4353]">
                <Database className="w-4 h-4 text-[#e4a834]" />
                <span>Supabase Cloud Sync</span>
              </div>
              <div className="flex items-center space-x-2 bg-black/60 px-4 py-2 rounded-xl border border-[#1b4353]">
                <Server className="w-4 h-4 text-[#e4a834]" />
                <span>Serverless Vercel Engine</span>
              </div>
              <div className="flex items-center space-x-2 bg-black/60 px-4 py-2 rounded-xl border border-[#1b4353]">
                <Shield className="w-4 h-4 text-[#e4a834]" />
                <span>Acceso Seguro & Token</span>
              </div>
            </div>
          </div>
        </div>

        {/* BARRA DE BÚSQUEDA Y FILTROS */}
        <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4 mb-8">
          {/* Buscador */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Buscar sistema por nombre o rubro..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0e2430]/90 border border-[#1b4353]/50 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-400 focus:outline-none focus:border-[#e4a834]"
            />
          </div>

          {/* Filtros de Categorías */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  selectedCategory === cat
                    ? 'bg-[#e4a834] text-[#083344]'
                    : 'bg-[#0e2430] text-gray-300 border border-[#1b4353]/40 hover:text-white'
                }`}
              >
                {cat === 'all' ? '🌟 Todos los Sistemas' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* TÍTULO DE SECCIÓN */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-[#1b4353]/30">
          <div>
            <h2 className="text-2xl font-black uppercase text-white tracking-tight flex items-center space-x-3">
              <span>CATÁLOGO OFICIAL DISPONIBLE</span>
            </h2>
            <p className="text-xs text-gray-400 mt-1">Valores fijados en USD con equivalencia en Pesos Argentinos (~${dolarRate} ARS)</p>
          </div>
          <span className="text-xs font-bold text-[#e4a834] bg-[#0e2430] px-3 py-1.5 rounded-xl border border-[#1b4353]/40">
            {filteredCatalog.length} Sistemas Visibles
          </span>
        </div>

        {/* GRID DE SOFTWARES */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 mb-16">
          {filteredCatalog.map((item) => (
            <AppCard
              key={item.id}
              software={item}
              dolarRate={dolarRate}
              onSelect={(software) => setSelectedSoftware(software)}
            />
          ))}
        </div>

        {/* GUÍA DE FUNCIONAMIENTO */}
        <div className="bg-[#0e2430]/90 border border-[#1b4353]/40 rounded-2xl p-8 backdrop-blur-md shadow-2xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-3 rounded-xl bg-[#1b4353]/50 text-[#e4a834]">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white uppercase">¿Cómo funciona el acceso y activación en Nexora Store?</h3>
              <p className="text-xs text-gray-400">Proceso unificado y transparente en 3 pasos</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-gray-300">
            <div className="p-4 rounded-xl bg-black/50 border border-[#1b4353]/40 space-y-2">
              <div className="w-7 h-7 rounded-lg bg-[#e4a834] text-[#083344] font-black flex items-center justify-center text-sm">
                1
              </div>
              <h4 className="font-bold text-white uppercase">Identificación</h4>
              <p className="text-gray-400">Ingresas el nombre de tu comercio o negocio. Se genera tu ID de Cliente único en la nube.</p>
            </div>

            <div className="p-4 rounded-xl bg-black/50 border border-[#1b4353]/40 space-y-2">
              <div className="w-7 h-7 rounded-lg bg-[#e4a834] text-[#083344] font-black flex items-center justify-center text-sm">
                2
              </div>
              <h4 className="font-bold text-white uppercase">Generación de Token</h4>
              <p className="text-gray-400">El servidor genera tu Token de Seguridad con firma digital registrado en Supabase Cloud.</p>
            </div>

            <div className="p-4 rounded-xl bg-black/50 border border-[#1b4353]/40 space-y-2">
              <div className="w-7 h-7 rounded-lg bg-[#e4a834] text-[#083344] font-black flex items-center justify-center text-sm">
                3
              </div>
              <h4 className="font-bold text-white uppercase">Acceso Inmediato</h4>
              <p className="text-gray-400">Ingresas directamente al portal web oficial o descargas el instalador en tu PC según corresponda.</p>
            </div>
          </div>
        </div>

      </div>

      {/* MODAL */}
      <DownloadModal
        software={selectedSoftware}
        onClose={() => setSelectedSoftware(null)}
      />

    </div>
  );
}
