import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        nexora: {
          dark: "#000000",
          petroleum: "#1b4353",
          steel: "#3a6073",
          gold: "#e4a834",
          goldHover: "#cf9323",
          cardBg: "#0e2430",
          cardText: "#083344",
        },
      },
      backgroundImage: {
        'nexora-gradient': "linear-gradient(to top right, #1b4353, #3a6073, #e4a834)",
      },
    },
  },
  plugins: [],
};

export default config;
