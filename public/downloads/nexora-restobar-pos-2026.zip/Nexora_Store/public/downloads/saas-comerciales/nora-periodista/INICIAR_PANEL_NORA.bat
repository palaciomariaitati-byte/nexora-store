@echo off
start "" "Nora_Periodista_Panel_Cliente.html"
exit
