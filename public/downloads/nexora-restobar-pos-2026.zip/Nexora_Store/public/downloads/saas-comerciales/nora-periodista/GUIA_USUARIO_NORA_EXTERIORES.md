# 🎙️ Manual de Usuario Oficial: NORA AI Periodismo de Exteriores & Prensa Ciudadana

Bienvenido a la **Suite Multimodal de Periodismo NORA AI**. Este sistema fue diseñado para medios de comunicación independientes, radios, portales de noticias y cronistas de campo que necesitan **cubrir la calle con velocidad, redactar con Inteligencia Artificial y difundir a todas sus redes sociales en 1 solo clic**.

---

## 🎁 1. Período de Prueba Oficial de 15 Días (Sin Tarjeta Previa)

* **Activación Automática e Inmediata:** Al instalar o abrir este panel, tu medio cuenta con **15 días de prueba completa y 100% gratuita** con acceso a todas las herramientas de IA, transcripciones y difusión omnicanal.
* **Sin Tarjeta de Entrada:** No requieres ingresar tarjetas bancarias para comenzar a probarlo.
* **Continuidad cada 30 Días:** Al término de los 15 días, el sistema te solicitará ingresar tu tarjeta o clave de suscripción para continuar disfrutando del servicio en abonos mensuales de 30 días (USD $35 / mes).

---

## 🏗️ 2. Arquitectura de la Suite (2 Puestos de Trabajo)

Tu sistema opera con **dos interfaces conectadas en tiempo real**:

1. **📱 App Móvil de Exteriores (Para los Cronistas en la Calle):**
   * Se abre en cualquier celular (Android o iPhone).
   * Permite grabar notas de voz de entrevistas, tomar fotografías del hecho y enviar el reporte a la redacción en segundos.
2. **💻 Mesa de Redacción Central (Panel en PC de Escritorio):**
   * Panel para el director o editor de noticias.
   * Recibe los audios ya transcriptos por NORA AI, permite revisar o pulir la crónica y difundirla a todas las plataformas.

---

## 🚀 3. Flujo de Trabajo en 4 Pasos

### Paso 1: Cobertura en la Calle (Desde el Celular)
1. El cronista abre la App NORA en su teléfono móvil.
2. Toca el botón **🎙️ Grabar Nota de Voz** mientras entrevista a un testigo o funcionario.
3. Toma una o varias fotografías del lugar con la cámara del celular.
4. Toca **"🚀 Enviar a Redacción"**.
5. **NORA AI** se encarga de transcribir el audio, extraer los puntos clave y redactar un borrador periodístico automático.

---

### Paso 2: Recepción en la Mesa Central (En la PC)
1. Abre tu panel `Nora_Periodista_Panel_Cliente.html` o ejecuta `INICIAR_PANEL_NORA.bat`.
2. En la columna izquierda (**Inbox de Reportes de Calle**) verás aparecer la noticia entrante con la etiqueta `Audio IA` o `Fotos`.
3. Haz clic sobre el reporte para que el **Titular**, **Copete**, **Cuerpo** y **Fotos** se carguen automáticamente en el editor.

---

### Paso 3: Asistencia Editorial con NORA AI
* Si deseas mejorar el título para captar más clics y lectores, haz clic en el botón dorado **`✨ NORA: Titular & Copete IA`**.
* NORA reformulará el titular con un formato de alto impacto y redactará el resumen gancho ideal para redes sociales.

---

### Paso 4: Publicación y Difusión Simultánea a Redes Sociales (1 Clic)
En la sección inferior **"Difusión Simultánea a Redes Sociales"**:
1. Marca las casillas de las plataformas donde deseas enviar la primicia:
   * ☑️ **🌐 Mi Portal Web Oficial**
   * ☑️ **📘 Página de Facebook**
   * ☑️ **🐦 X (Twitter)**
   * ☑️ **📱 Canales de WhatsApp & Telegram**
   * ☑️ **⚡ Webhook Global (Make / Zapier / n8n)**
2. Haz clic en el botón verde gigante: **`🚀 PUBLICAR EN PORTAL Y DIFUNDIR A TODAS LAS REDES ACTIVAS`**.

---

## ⚙️ 4. Cómo Vincular tus Redes Sociales (Fácil y sin Complicaciones)

Para configurar la difusión automática solo tienes que pegar tus accesos **una sola vez**:

| Red Social | ¿Qué necesitas pegar? | ¿Cómo se obtiene? |
| :--- | :--- | :--- |
| **📘 Facebook** | `Page Access Token` | En el panel de Meta for Developers o mediante Make/Zapier en 2 clics. |
| **🐦 X (Twitter)** | `API Key` o `Webhook Bridge` | Conectando tu cuenta de X mediante Make o tu Bearer Token. |
| **📱 WhatsApp / Telegram** | `Token de Bot` / `ID Canal` | En Telegram hablándole a `@BotFather`, o pegando el webhook de tu WhatsApp Business. |
| **⚡ Webhook Universal** | `URL de Webhook` | Puedes usar **Make.com**, **Zapier** o **n8n** para disparar publicaciones automáticas a más de 20 redes simultáneas. |

---

## 🔒 5. Garantía de Privacidad y Soberanía de tus Noticias
* **Tus noticias son 100% tuyas:** Las publicaciones y notas que crees en tu panel de NORA pertenecen a tu medio.
* **Canal Aislado:** No se comparten ni se cruzan con otros portales ni con la red central de NexativaNews.

---

*Desarrollado por el Ecosistema Nexora SaaS © 2026. Todos los derechos reservados.*
