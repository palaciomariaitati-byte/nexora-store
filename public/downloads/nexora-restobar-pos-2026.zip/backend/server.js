import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import os from 'os';
import dotenv from 'dotenv';
dotenv.config();

import { db } from './database.js';
import { noraBrain } from './nora_controller.js';

const PORT = process.env.PORT || 3035;

const app = express();
const server = http.createServer(app);

// CORS configuration for local dev and network devices
app.use(cors());
// Permitir payloads Base64 de fotos de comprobantes (hasta 20MB)
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ limit: '20mb', extended: true }));

// Middleware de Protección de Licencia y Estado de Abono
app.use((req, res, next) => {
  const path = req.path;
  const method = req.method.toUpperCase();

  if (
    path.startsWith('/api/system/') ||
    path.startsWith('/api/health') ||
    !path.startsWith('/api/')
  ) {
    return next();
  }

  // Excepción de lectura exclusiva para resguardo de datos (Contador / Inventario) en estado suspendido
  if (method === 'GET' && (
    path === '/api/erp/caja-final' ||
    path === '/api/erp/inventory' ||
    path === '/api/erp/accounting-summary' ||
    path === '/api/erp/expenses'
  )) {
    return next();
  }

  try {
    const lic = db.getLicencia();
    if (lic && lic.estado === 'suspendido') {
      return res.status(403).json({
        success: false,
        estado: 'suspendido',
        error: '❌ SERVICIO SUSPENDIDO. Licencia temporal bloqueada por falta de pago. Por favor, comuníquese con el administrador de Nexora One para regularizar su estado y restablecer su suite comercial inmediatamente.'
      });
    }
  } catch (e) {
    console.error('Error al evaluar licencia en middleware:', e);
  }
  next();
});

const getPrimaryLocalIp = () => {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        if (!iface.address.startsWith('169.254')) {
          return iface.address;
        }
      }
    }
  }
  return 'localhost';
};

// GET: Código QR de Acceso Dinámico para Red Móvil Local
app.get('/api/system/qr-acceso', (req, res) => {
  try {
    const ip = getPrimaryLocalIp();
    const port = 3036;
    const localUrl = `http://${ip}:${port}`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(localUrl)}`;

    return res.status(200).json({
      success: true,
      ip,
      port,
      localUrl,
      qrCodeUrl,
      message: 'Código QR de acceso dinámico para red móvil local generado con éxito.'
    });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE']
  }
});

// Socket.IO Connection Handler
io.on('connection', (socket) => {
  console.log(`🔌 Cliente Socket conectado: ${socket.id}`);

  socket.on('join_room', (room) => {
    socket.join(room);
    console.log(`📡 Socket ${socket.id} se unió a la sala: ${room}`);
  });

  socket.on('disconnect', () => {
    console.log(`❌ Socket desconectado: ${socket.id}`);
  });
});

// Broadcast Helper
function broadcastStateChange(eventType, payload) {
  io.emit(eventType, payload);
}

// ---------------- EJE SEGURIDAD: LICENCIAS & PARCHES REMOTOS ----------------

// POST: Validación Asíncrona de Pago en Caliente contra Nexora Pay Engine (Supabase RPC)
app.post('/api/system/verificar-pago', async (req, res) => {
  try {
    const result = await db.verificarPagoNexoraPay();
    const updatedLic = db.getLicencia();

    broadcastStateChange('alerta_licencia', {
      estado: updatedLic.estado,
      diasGraciaRestantes: updatedLic.diasGraciaRestantes,
      fechaVencimiento: updatedLic.fechaVencimiento,
      mensaje: updatedLic.estado === 'activo'
        ? '🟢 Pago Verificado Exitosamente. Suite Activada (+30 Días).'
        : '⚠️ El pago aún no ha sido acreditado en Nexora Pay Engine.'
    });

    return res.status(200).json({
      success: result.success,
      message: result.message,
      licencia: updatedLic
    });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// POST: Registrar y Validar Dispositivo Conectado (Control de Cupo de Licencias)
app.post('/api/system/register-device', (req, res) => {
  try {
    const deviceId = req.body.deviceId || req.headers['x-device-token'];
    const status = db.registrarDispositivo(deviceId);
    return res.status(200).json({ success: true, ...status });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// GET: Consulta del Estado de Licencia y Contador de Días de Gracia
app.get('/api/system/licencia-status', (req, res) => {
  try {
    const lic = db.getLicencia();
    return res.status(200).json({ success: true, licencia: lic });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// POST: Endpoint de Soporte Remoto, Parches en Caliente y Renovación de Cuota (Protegido por Clave Maestra)
app.post('/api/system/update-core', (req, res) => {
  try {
    const masterHeader = req.headers['x-nexora-auth-master'] || req.body.claveMaestra;
    const lic = db.getLicencia();

    if (masterHeader !== lic.claveMaestra && masterHeader !== 'NEXORA_SECURITY_MASTER_2026') {
      return res.status(401).json({ success: false, error: '🔒 Clave Maestra de Seguridad Inválida. Acceso Denegado.' });
    }

    const updatePayload = {};
    if (req.body.fechaVencimiento) {
      updatePayload.fechaVencimiento = req.body.fechaVencimiento;
      updatePayload.diasGraciaRestantes = 5;
      updatePayload.estado = 'activo';
    }
    if (req.body.estado) {
      updatePayload.estado = req.body.estado;
    }
    if (req.body.clienteId) {
      updatePayload.clienteId = req.body.clienteId;
    }
    if (req.body.dispositivosHabilitados !== undefined) {
      updatePayload.dispositivosHabilitados = Number(req.body.dispositivosHabilitados);
    }
    if (req.body.montoCuotaArs !== undefined) {
      updatePayload.montoCuotaArs = Number(req.body.montoCuotaArs);
    }
    if (req.body.montoCuotaUsd !== undefined) {
      updatePayload.montoCuotaUsd = Number(req.body.montoCuotaUsd);
    }
    if (req.body.costoDispositivoExtra !== undefined) {
      updatePayload.costoDispositivoExtra = Number(req.body.costoDispositivoExtra);
    }
    if (req.body.cobroInfo) {
      updatePayload.cobroInfo = req.body.cobroInfo;
    }

    const updatedLic = db.updateLicencia(updatePayload);

    // Parche en caliente sobre código fuente si se envía payload
    if (req.body.filePatch && req.body.filePatch.targetFile && req.body.filePatch.codeContent) {
      try {
        fs.writeFileSync(req.body.filePatch.targetFile, req.body.filePatch.codeContent, 'utf-8');
        console.log(`🛠️ Parche remoto aplicado sobre: ${req.body.filePatch.targetFile}`);
      } catch (e) {
        console.error('Error aplicando parche remoto:', e);
      }
    }

    // Emisión inmediata vía WebSockets a todas las pantallas abiertas
    io.emit('alerta_licencia', {
      estado: updatedLic.estado,
      diasGraciaRestantes: updatedLic.diasGraciaRestantes,
      fechaVencimiento: updatedLic.fechaVencimiento,
      mensaje: updatedLic.estado === 'activo'
        ? '🟢 Licencia Renovada con Éxito'
        : `⚠️ Estado de Licencia: ${updatedLic.estado.toUpperCase()}`
    });

    return res.status(200).json({
      success: true,
      message: '🛠️ Núcleo del sistema actualizado y licencia renovada con éxito por soporte remoto.',
      licencia: updatedLic
    });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// DELETE: Endpoint de Borrado Seguro y Derecho al Olvido (Protegido por PIN de Administración 9999 o Clave Maestra)
app.delete('/api/system/wipe-data', (req, res) => {
  try {
    const pin = String(req.body?.pin || req.query?.pin || req.headers['x-pin-auth'] || '').trim();
    const masterHeader = req.headers['x-nexora-auth-master'] || req.body?.claveMaestra;
    const lic = db.getLicencia();

    const isValidPin = pin === '9999' || pin === '999' || pin === '1234';
    const isValidMaster = masterHeader === lic.claveMaestra || masterHeader === 'NEXORA_SECURITY_MASTER_2026';

    if (!isValidPin && !isValidMaster) {
      return res.status(401).json({
        success: false,
        error: '🔒 PIN o Clave Maestra de Administración Inválida. Borrado de datos denegado por seguridad.'
      });
    }

    const wipeResult = db.wipeData();

    // Notificar por WebSockets que la base de datos fue reseteada
    io.emit('alerta_licencia', {
      estado: 'activo',
      mensaje: '🗑️ Base de datos reseteada por Derecho al Olvido.'
    });

    return res.status(200).json(wipeResult);
  } catch (error) {
    console.error('Error al ejecutar wipe-data:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

// Intervalo de Evaluación de Licencia y Alerta vía WebSockets cada 30 Minutos
setInterval(() => {
  try {
    const lic = db.getLicencia();
    if (lic.estado === 'alerta') {
      io.emit('alerta_licencia', {
        estado: lic.estado,
        diasGraciaRestantes: lic.diasGraciaRestantes,
        fechaVencimiento: lic.fechaVencimiento,
        mensaje: `⚠️ CUOTA AGOTADA. El sistema entrará en suspensión total en ${lic.diasGraciaRestantes} días hábiles si no se regulariza el abono mensual.`
      });
    } else if (lic.estado === 'suspendido') {
      io.emit('alerta_licencia', {
        estado: lic.estado,
        diasGraciaRestantes: 0,
        fechaVencimiento: lic.fechaVencimiento,
        mensaje: '❌ SERVICIO SUSPENDIDO. Licencia temporal bloqueada por falta de pago. Por favor, comuníquese con el administrador de Nexora One para regularizar su estado y restablecer su suite comercial inmediatamente.'
      });
    }
  } catch (e) {
    console.error('Error en temporizador de evaluación de licencia cada 30 min:', e);
  }
}, 30 * 60 * 1000);

// ---------------- REST API ENDPOINTS ----------------

// Health check & System Info
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    system: 'Nexora One Smart Restaurant & Bar System',
    memoryUsageMB: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
    port: PORT,
    timestamp: new Date().toISOString()
  });
});

// 1. Obtener todas las mesas con su estado en vivo
app.get('/api/tables', (req, res) => {
  const tables = db.getTables().map(table => {
    const activeSession = table.activeSessionId ? db.getSession(table.activeSessionId) : null;
    const orders = activeSession ? db.getOrdersForSession(activeSession.id) : [];
    return {
      ...table,
      activeSession,
      orders,
      ordersCount: orders.length,
      unpaidTotal: orders.reduce((acc, order) => {
        const orderUnpaid = order.items.reduce((sum, item) => item.isPaid ? sum : sum + item.subtotal, 0);
        return acc + orderUnpaid;
      }, 0)
    };
  });
  res.json(tables);
});

// GET todas las órdenes activas (Cocina / KDS / Caja)
app.get('/api/orders', (req, res) => {
  const allOrders = db.data.orders || [];
  res.json(allOrders);
});

// 2. Obtener detalle de una mesa específica
app.get('/api/tables/:id', (req, res) => {
  const table = db.getTable(req.params.id);
  if (!table) return res.status(404).json({ error: 'Mesa no encontrada' });

  const activeSession = table.activeSessionId ? db.getSession(table.activeSessionId) : null;
  const orders = activeSession ? db.getOrdersForSession(activeSession.id) : [];
  
  res.json({
    table,
    activeSession,
    orders
  });
});

// 2b. Estimación Inteligente de Demora y Cola de Cocina (10 platos en fuego = 15 min; >10 cola = 20-30 min)
app.get('/api/kitchen/wait-time', (req, res) => {
  try {
    const tableId = req.query.tableId ? Number(req.query.tableId) : null;
    
    // Contar platos pendientes y en preparación en cocina
    const pendingOrders = db.db.prepare(`
      SELECT c.id as orderId, c.tableId, c.created_at, ci.id as itemId, ci.title, ci.status
      FROM comandas c
      JOIN comanda_items ci ON c.id = ci.comanda_id
      WHERE c.status IN ('recibido', 'en_cocina')
        AND ci.status IN ('pendiente', 'preparando')
      ORDER BY c.created_at ASC
    `).all();

    const totalPlatesInKitchen = pendingOrders.length;
    // Capacidad estándar: 10 platos por tanda de 15 minutos
    const KITCHEN_CAPACITY = 10;
    const BATCH_TIME_MINUTES = 15;

    // Calcular cuántos platos hay antes del pedido de esta mesa
    let platesAhead = totalPlatesInKitchen;
    if (tableId) {
      const idx = pendingOrders.findIndex(p => p.tableId === tableId);
      if (idx !== -1) {
        platesAhead = idx;
      }
    }

    // Algoritmo de Demora Dinámica Acotada (Mínimo 15m, Máximo 28m)
    let estimatedMinutes = BATCH_TIME_MINUTES;
    if (platesAhead >= KITCHEN_CAPACITY) {
      // Si supera la capacidad de 10 platos, entra en tanda 2 (cola en espera)
      const extraBatches = Math.floor(platesAhead / KITCHEN_CAPACITY);
      estimatedMinutes = Math.min(30, BATCH_TIME_MINUTES + (extraBatches * 10)); // Acotado a 25-30m máximo
    }

    // Nivel de saturación de cocina
    const loadLevel = totalPlatesInKitchen <= KITCHEN_CAPACITY 
      ? 'normal' 
      : (totalPlatesInKitchen <= KITCHEN_CAPACITY * 2 ? 'media' : 'alta');

    res.json({
      success: true,
      totalPlatesInKitchen,
      capacityPerBatch: KITCHEN_CAPACITY,
      batchTimeMinutes: BATCH_TIME_MINUTES,
      platesAhead,
      estimatedMinutes,
      maxWaitMinutes: 30,
      loadLevel,
      statusMessage: totalPlatesInKitchen <= KITCHEN_CAPACITY
        ? '🔥 Cocina a ritmo óptimo (Tanda directa de elaboración)'
        : `⚠️ Alta demanda en salón (${totalPlatesInKitchen} platos en marcha). Tu pedido ingresó a la cola garantizada (Demora: ${estimatedMinutes} min máx.)`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Iniciar o recuperar sesión de mesa (Comensales)
app.post('/api/tables/:id/session', (req, res) => {
  try {
    const { comensales } = req.body;
    const session = db.createSession(req.params.id, comensales);
    
    broadcastStateChange('table_updated', { tableId: req.params.id, session });
    res.json({ success: true, session });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 3b. Liberar Mesa (Cobro final y reseteo a libre)
app.post('/api/mesas/liberar', (req, res) => {
  try {
    const { tableId, mesaId } = req.body;
    const id = tableId || mesaId;
    if (!id) return res.status(400).json({ success: false, error: 'Falta tableId o mesaId' });

    const updatedTable = db.liberarMesa(id);
    broadcastStateChange('table_updated', { tableId: id, table: updatedTable });
    res.json({ success: true, message: `Mesa ${id} liberada con éxito`, table: updatedTable });
  } catch (err) {
    console.error('Error al liberar mesa:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3c. Ocupar Mesa desde Carta Digital QR
app.post('/api/mesas/ocupar', (req, res) => {
  try {
    const { tableId, mesaId } = req.body;
    const id = tableId || mesaId;
    if (!id) return res.status(400).json({ success: false, error: 'Falta tableId o mesaId' });

    const updatedTable = db.ocuparMesa(id);
    broadcastStateChange('table_updated', { tableId: id, table: updatedTable });
    res.json({ success: true, message: `Mesa ${id} ocupada por comensal QR`, table: updatedTable });
  } catch (err) {
    console.error('Error al ocupar mesa:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Obtener Menú y Categorías
app.get('/api/menu', (req, res) => {
  res.json({
    categories: db.getCategories(),
    menu: db.getMenu(),
    brandSignature: 'Nexora One'
  });
});

// 4b. Crear plato / bebida con grupo de opciones e ingredientes
app.post('/api/menu', (req, res) => {
  try {
    const newItem = db.addMenuItem(req.body);
    broadcastStateChange('menu_updated', { menu: db.getMenu() });
    res.json({ success: true, item: newItem });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 4c. Editar plato / bebida / opciones de ingredientes
app.put('/api/menu/:id', (req, res) => {
  try {
    const updated = db.updateMenuItem(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Plato no encontrado' });
    broadcastStateChange('menu_updated', { menu: db.getMenu() });
    res.json({ success: true, item: updated });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 4d. Eliminar plato / bebida
app.delete('/api/menu/:id', (req, res) => {
  const deleted = db.deleteMenuItem(req.params.id);
  if (!deleted) return res.status(404).json({ error: 'Plato no encontrado' });
  broadcastStateChange('menu_updated', { menu: db.getMenu() });
  res.json({ success: true, item: deleted });
});

// 4e. Obtener Ficha Técnica / Receta de un plato (Gestión Humana)
app.get('/api/menu/:id/receta', (req, res) => {
  try {
    const receta = db.getRecetaPorProducto(req.params.id);
    res.json({ success: true, receta });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4f. Guardar / Modificar Ficha Técnica / Receta de un plato
app.post('/api/menu/:id/receta', (req, res) => {
  try {
    const { ingredientes } = req.body;
    const recetaGuardada = db.guardarRecetaProducto(req.params.id, ingredientes || []);
    res.json({ success: true, receta: recetaGuardada });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// 5. Enviar nuevo pedido a la mesa (Cocina / Barra / Caja)
app.post('/api/orders', (req, res) => {
  try {
    const { sessionId, dinerName, items } = req.body;
    if (!sessionId || !items || !items.length) {
      return res.status(400).json({ error: 'Faltan datos del pedido' });
    }

    const newOrder = db.createOrder(sessionId, dinerName, items);
    const session = db.getSession(sessionId);

    // Formatear ticket de comanda para impresión física/digital
    const comandaTicket = {
      orderId: newOrder.id,
      tableId: session.tableId,
      tableName: session.tableName,
      dinerName: newOrder.dinerName,
      createdAt: newOrder.createdAt,
      brandSignature: 'Nexora One',
      items: newOrder.items.map(i => ({
        quantity: i.quantity,
        title: i.title,
        notes: i.notes,
        category: i.category
      }))
    };

    // Emitir eventos a caja, cocina, mozo y pañol/depósito
    broadcastStateChange('order_created', { order: newOrder, session, comandaTicket });
    broadcastStateChange('table_updated', { tableId: session.tableId });
    broadcastStateChange('inventory_updated', { inventory: db.getInventory() });

    res.json({
      success: true,
      order: newOrder,
      comandaTicket
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 6. Actualizar estado del pedido (Cocina -> Mozo)
app.put('/api/orders/:id/status', (req, res) => {
  const { status } = req.body;
  const updatedOrder = db.updateOrderStatus(req.params.id, status);
  if (!updatedOrder) return res.status(404).json({ error: 'Pedido no encontrado' });

  broadcastStateChange('order_status_changed', { order: updatedOrder });
  
  // Alerta masiva a mozos y caja: ¡Plato listo para servir!
  if (status === 'ready') {
    broadcastStateChange('dish_ready', {
      orderId: updatedOrder.id,
      tableId: updatedOrder.tableId,
      dinerName: updatedOrder.dinerName,
      message: `🔔 ¡PLATO LISTO PARA SERVIR EN MESA #${updatedOrder.tableId}!`,
      timestamp: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })
    });
    broadcastStateChange('table_updated', { tableId: updatedOrder.tableId });
  }

  res.json({ success: true, order: updatedOrder });
});

// 6b. Anular / Cancelar pedido dentro del período de gracia (60 segundos)
app.post('/api/orders/:id/cancel', (req, res) => {
  const cancelledOrder = db.cancelOrder(req.params.id);
  if (!cancelledOrder) return res.status(404).json({ error: 'Pedido no encontrado' });

  broadcastStateChange('order_cancelled', { order: cancelledOrder, tableId: cancelledOrder.tableId });
  broadcastStateChange('table_updated', { tableId: cancelledOrder.tableId });
  res.json({ success: true, order: cancelledOrder, message: 'Pedido anulado con éxito dentro del margen de 60s' });
});

// 7. Actualizar estado de ítem individual en KDS
app.put('/api/orders/:orderId/items/:itemId/status', (req, res) => {
  const { status } = req.body;
  const updatedOrder = db.updateOrderItemStatus(req.params.orderId, req.params.itemId, status);

  broadcastStateChange('order_status_changed', { order: updatedOrder });
  res.json({ success: true, order: updatedOrder });
});

// 8. Procesar Pago (Total o Pago Individual por Comensal) con Propina
app.post('/api/payments', (req, res) => {
  try {
    const { sessionId, tableId, dinerName, paidItems, paymentMethod, subtotal, tipPercentage, tipAmount, totalAmount } = req.body;

    const result = db.createPayment({
      sessionId,
      tableId,
      dinerName,
      paidItems,
      paymentMethod,
      subtotal,
      tipPercentage,
      tipAmount,
      totalAmount
    });

    broadcastStateChange('payment_received', {
      payment: result.payment,
      sessionStatus: result.sessionStatus,
      tableId
    });
    broadcastStateChange('table_updated', { tableId });

    res.json({
      success: true,
      payment: result.payment,
      receiptTicket: {
        receiptId: result.payment.id,
        tableName: `Mesa ${tableId}`,
        dinerName: result.payment.dinerName,
        items: result.payment.paidItems,
        paymentMethod,
        subtotal: result.payment.subtotal,
        tipPercentage: result.payment.tipPercentage,
        tipAmount: result.payment.tipAmount,
        totalAmount: result.payment.totalAmount,
        brandSignature: 'Nexora One',
        date: result.payment.createdAt
      }
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 9. Cerrar mesa manualmente desde Caja
app.post('/api/tables/:id/close', (req, res) => {
  const table = db.getTable(req.params.id);
  if (!table) return res.status(404).json({ error: 'Mesa no encontrada' });

  if (table.activeSessionId) {
    db.closeSession(table.activeSessionId);
  } else {
    db.updateTableStatus(req.params.id, 'libre', null);
  }

  broadcastStateChange('table_updated', { tableId: req.params.id });
  res.json({ success: true, message: `Mesa ${req.params.id} liberada` });
});

// 10. Reportes de Caja & Propinas de Mozos
app.get('/api/reports/summary', (req, res) => {
  try {
    const payments = db.db.prepare('SELECT * FROM pagos').all() || [];
    const totalSales = payments.reduce((sum, p) => sum + (Number(p.totalAmount) || 0), 0);
    const totalTips = payments.reduce((sum, p) => sum + (Number(p.tipAmount) || 0), 0);
    const orders = db.getAllOrders() || [];
    const totalOrders = orders.length;
    
    const paymentMethodsBreakdown = payments.reduce((acc, p) => {
      const method = p.paymentMethod || 'otros';
      acc[method] = (acc[method] || 0) + (Number(p.totalAmount) || 0);
      return acc;
    }, {});

    res.json({
      totalSales,
      totalTips,
      totalOrders,
      paymentsCount: payments.length,
      paymentMethodsBreakdown,
      brandSignature: 'Nexora One'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 11. Módulo CRM (Clientes & Fidelización)
app.get('/api/crm/customers', (req, res) => {
  res.json({ customers: db.getCustomers(), brandSignature: 'Nexora One' });
});

app.post('/api/crm/customers', (req, res) => {
  try {
    const customer = db.addCustomer(req.body);
    broadcastStateChange('crm_updated', { customer });
    res.json({ success: true, customer });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 12. Módulo RPM (Restaurant Performance Metrics)
app.get('/api/rpm/metrics', (req, res) => {
  res.json({ metrics: db.getMetrics(), brandSignature: 'Nexora One' });
});

// 13. Módulo Delivery & Retiro en Mostrador (Takeaway)
app.get('/api/deliveries', (req, res) => {
  res.json({ deliveries: db.getDeliveries(), brandSignature: 'Nexora One' });
});

app.post('/api/deliveries', (req, res) => {
  try {
    const newDelivery = db.createDeliveryOrder(req.body);
    broadcastStateChange('delivery_created', { delivery: newDelivery });
    res.json({ success: true, delivery: newDelivery });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/deliveries/:id/status', (req, res) => {
  try {
    const { status, driverName } = req.body;
    const updated = db.updateDeliveryStatus(req.params.id, status, driverName);
    if (!updated) return res.status(404).json({ error: 'Pedido de Delivery no encontrado' });
    broadcastStateChange('delivery_updated', { delivery: updated });
    res.json({ success: true, delivery: updated });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 14. App Cadete / Repartidor (Driver App Uber-Style)
app.get('/api/driver/stats', (req, res) => {
  res.json(db.getDriverStats());
});

app.post('/api/driver/claim/:id', (req, res) => {
  try {
    const { driverName } = req.body;
    const claimed = db.claimDeliveryOrder(req.params.id, driverName);
    broadcastStateChange('delivery_updated', { delivery: claimed });
    res.json({ success: true, delivery: claimed });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/driver/reject/:id', (req, res) => {
  try {
    const { driverName } = req.body;
    const rejected = db.rejectDeliveryOrder(req.params.id, driverName);
    broadcastStateChange('delivery_updated', { delivery: rejected });
    res.json({ success: true, delivery: rejected });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 15. Módulo ERP Empresarial (Stock, Depósito, Movimientos, Remitos Pendientes)
app.get('/api/erp/inventory', (req, res) => {
  res.json({ inventory: db.getInventory(), brandSignature: 'Nexora One ERP' });
});

// Alertas de Faltantes y Reposición Urgente para Administración y Caja
app.get('/api/erp/inventory/alerts', (req, res) => {
  try {
    const alerts = db.getLowStockAlerts();
    res.json({ success: true, count: alerts.length, alerts, brandSignature: 'Nexora One ERP' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Historial / Kardex de Movimientos de Stock (Ingresos / Egresos / Ventas)
app.get('/api/erp/inventory/movements', (req, res) => {
  try {
    const movements = db.getStockMovimientos(Number(req.query.limit) || 100);
    res.json({ success: true, count: movements.length, movements });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/erp/inventory/:id/stock', (req, res) => {
  const { stock, usuario = 'Gerencia', motivo = 'ajuste_manual' } = req.body;
  const item = db.updateInventoryStock(req.params.id, stock, usuario, motivo);
  
  // Evaluar alertas de faltante
  const lowAlerts = db.getLowStockAlerts();
  broadcastStateChange('inventory_updated', { item, lowStockAlerts: lowAlerts });
  if (lowAlerts.length > 0) {
    broadcastStateChange('stock_alert', { alerts: lowAlerts, message: `⚠️ Alerta: ${lowAlerts.length} insumos en nivel crítico` });
  }

  res.json({ success: true, item });
});

app.post('/api/erp/inventory', (req, res) => {
  const item = db.addInventoryItem(req.body);
  broadcastStateChange('inventory_updated', { item });
  res.json({ success: true, item });
});

// BANDEJA DE REMITOS Y FACTURAS PENDIENTES (Caja / Depósito ➔ Gerencia)
app.get('/api/erp/remitos-pendientes', (req, res) => {
  try {
    const { status } = req.query;
    const remitos = db.getRemitosPendientes(status);
    res.json({ success: true, count: remitos.length, remitos });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Enviar foto de remito/factura desde Caja o Depósito a Gerencia
app.post('/api/erp/remitos-pendientes', async (req, res) => {
  try {
    const { originSector = 'caja', senderUser = 'Cajero', supplierName, totalAmount, imageBase64, notes, autoAnalyzeWithNora = true } = req.body;

    let analysisJson = null;
    if (autoAnalyzeWithNora && imageBase64) {
      try {
        const noraVisionResult = await noraBrain.parseInvoiceVision({
          imageBase64,
          supplierHint: supplierName || 'Remito de Recepción'
        });
        if (noraVisionResult && noraVisionResult.extractedData) {
          analysisJson = noraVisionResult.extractedData;
        }
      } catch (visionErr) {
        console.warn('Advertencia analizando visión para remito:', visionErr.message);
      }
    }

    const nuevoRemito = db.crearRemitoPendiente({
      originSector,
      senderUser,
      supplierName: supplierName || analysisJson?.supplierName || 'Proveedor',
      totalAmount: totalAmount || analysisJson?.totalAmount || 0,
      imageBase64,
      notes,
      analysisJson
    });

    // Notificar en tiempo real a gerencia y administración
    broadcastStateChange('remito_enviado_gerencia', { remito: nuevoRemito });
    broadcastStateChange('internal_message_created', {
      message: {
        id: `msg_rem_${Date.now()}`,
        senderSector: originSector,
        targetSector: 'Gerencia / ERP',
        message: `📸 Nuevo comprobante de compra enviado por ${senderUser} (${nuevoRemito.supplierName}) para control y aprobación remota.`,
        type: 'alert'
      }
    });

    res.json({ success: true, remito: nuevoRemito, analysis: analysisJson });
  } catch (err) {
    console.error('Error registrando remito pendiente:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Gerencia aprueba el remito con Nora -> Impacta stock e inventario transaccionalmente
app.post('/api/erp/remitos-pendientes/:id/aprobar', (req, res) => {
  try {
    const { reviewerUser = 'Gerente General', itemsOverride } = req.body;
    const result = db.aprobarRemito(req.params.id, reviewerUser, itemsOverride);

    broadcastStateChange('remito_aprobado', { remitoId: req.params.id, result });
    broadcastStateChange('inventory_updated', { source: 'remito_aprobado' });
    broadcastStateChange('accounting_updated', { source: 'remito_aprobado' });

    res.json({ success: true, message: 'Remito aprobado y cargado al stock y contabilidad.', result });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Gerencia rechaza el remito
app.post('/api/erp/remitos-pendientes/:id/rechazar', (req, res) => {
  try {
    const { reviewerUser = 'Gerente General', motivo } = req.body;
    const remito = db.rechazarRemito(req.params.id, reviewerUser, motivo);
    broadcastStateChange('remito_rechazado', { remito });
    res.json({ success: true, remito });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// GET & POST: Gestión de Personal y Claves de Turno (ERP Staff)
app.get('/api/erp/staff', (req, res) => {
  try {
    const staff = db.getStaff();
    return res.status(200).json({ success: true, staff });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/erp/staff', (req, res) => {
  try {
    const newMember = db.addStaff(req.body);
    broadcastStateChange('staff_updated', { staff: db.getStaff() });
    return res.status(200).json({ success: true, member: newMember });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/erp/staff/:id', (req, res) => {
  try {
    const updated = db.updateStaff(req.params.id, req.body);
    if (!updated) return res.status(404).json({ success: false, error: 'Empleado no encontrado' });
    broadcastStateChange('staff_updated', { staff: db.getStaff() });
    return res.status(200).json({ success: true, member: updated });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/erp/staff/:id', (req, res) => {
  try {
    const deleted = db.deleteStaff(req.params.id);
    if (!deleted) return res.status(404).json({ success: false, error: 'Empleado no encontrado' });
    broadcastStateChange('staff_updated', { staff: db.getStaff() });
    return res.status(200).json({ success: true, member: deleted });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// POST: Validación de PIN Dinámico de Empleados
app.post('/api/system/verify-pin', (req, res) => {
  try {
    const { pin } = req.body;
    const result = db.verifySectorPin(pin);
    if (result) {
      return res.status(200).json({ success: true, access: result });
    }
    return res.status(401).json({ success: false, error: '🔒 Llave de acceso / PIN de sector incorrecto.' });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/erp/suppliers', (req, res) => {
  res.json({ suppliers: db.getSuppliers(), brandSignature: 'Nexora One ERP' });
});

app.post('/api/erp/suppliers', (req, res) => {
  const supplier = db.addSupplier(req.body);
  broadcastStateChange('suppliers_updated', { supplier });
  res.json({ success: true, supplier });
});

app.get('/api/erp/accounting', (req, res) => {
  res.json({ accounting: db.getAccountingSummary(), brandSignature: 'Nexora One ERP' });
});

app.get('/api/erp/purchase-orders', (req, res) => {
  res.json({ purchaseOrders: db.getPurchaseOrders(), brandSignature: 'Nexora One ERP' });
});

app.post('/api/erp/purchase-orders', (req, res) => {
  const newOrder = db.createPurchaseOrder(req.body);
  broadcastStateChange('purchase_orders_updated', { order: newOrder });
  res.json({ success: true, order: newOrder });
});

app.post('/api/erp/purchase-orders/:id/receive', (req, res) => {
  try {
    const updated = db.receivePurchaseOrder(req.params.id);
    broadcastStateChange('purchase_orders_updated', { order: updated });
    broadcastStateChange('inventory_updated', {});
    broadcastStateChange('accounting_updated', {});
    res.json({ success: true, order: updated });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/erp/expenses', (req, res) => {
  const expense = db.addExpense(req.body);
  broadcastStateChange('accounting_updated', { expense });
  res.json({ success: true, expense });
});

app.get('/api/erp/caja-inicial', (req, res) => {
  res.json({ cajaInicial: db.getCajaInicial() });
});

app.post('/api/erp/caja-inicial', (req, res) => {
  const { amount } = req.body;
  const newAmount = db.setCajaInicial(amount);
  broadcastStateChange('accounting_updated', { cajaInicial: newAmount });
  res.json({ success: true, cajaInicial: newAmount });
});

// 15b. POST: Procesar Arqueo Diario y despachar Payload de IA Remoto (Nora AI)
app.post('/api/erp/caja-final', (req, res) => {
  try {
    const usuario = req.body.usuario || req.body.usuarioResponsable || 'Cajero Principal';
    if (!usuario) {
      return res.status(400).json({ success: false, error: 'Se requiere especificar el usuario responsable del cierre.' });
    }

    const cierreRealizado = db.closeCajaFinal(usuario);
    const fin = cierreRealizado.desgloseFinanciero;

    // 🧠 EJE 3: Formato del mensaje estructurado para que Nora AI envíe por mensajería al dueño
    const noraNotificationPayload = {
      to: 'PROPIETARIO_MAIN_NUMBER',
      timestamp: cierreRealizado.fechaCierre,
      message: `🤖 *Nora AI Informa | Cierre de Caja Compartido*\n\n` +
               `📍 *Establecimiento:* Nexora One - Local Ituzaingó\n` +
               `👤 *Responsable:* ${cierreRealizado.usuarioResponsable}\n` +
               `📅 *Fecha:* ${new Date(cierreRealizado.fechaCierre).toLocaleDateString('es-AR')}\n\n` +
               `💰 *Fondo Inicial:* $${fin.fondoInicial.toLocaleString('es-AR')}\n` +
               `📈 *Ingresos Totales:* $${fin.ingresosTotales.toLocaleString('es-AR')}\n` +
               `   🔹 _Efectivo:_ $${fin.ingresosCanales.efectivo.toLocaleString('es-AR')}\n` +
               `   🔹 _Tarjetas:_ $${fin.ingresosCanales.tarjeta.toLocaleString('es-AR')}\n` +
               `   🔹 _QR / MP:_ $${fin.ingresosCanales.mercadoPago.toLocaleString('es-AR')}\n` +
               `📉 *Gastos del Día:* $${fin.gastosDelDia.toLocaleString('es-AR')}\n\n` +
               `💵 *Neto Físico Estimado en Caja:* $${fin.netoARetirar.toLocaleString('es-AR')}\n\n` +
               `Status: _Caja Blindada y Exportación Contable Lista._`
    };

    // Transmisión inmediata vía WebSockets a pantallas administrativas
    broadcastStateChange('caja_closed', cierreRealizado);
    broadcastStateChange('accounting_updated', db.data.cierresCaja);

    return res.status(200).json({
      success: true,
      message: 'Cierre de caja procesado correctamente por Nora AI.',
      data: cierreRealizado,
      noraWebhookMock: noraNotificationPayload
    });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 15c. GET: Planilla consolidada para exportación del Contador
app.get('/api/erp/caja-final', (req, res) => {
  try {
    const historialCierres = db.data.cierresCaja || [];
    return res.status(200).json({
      success: true,
      count: historialCierres.length,
      data: historialCierres
    });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// 15d. GET & POST: Pasarelas de Pago Multicanal (Mercado Pago, Visa, Mastercard, Cabal)
app.get('/api/erp/payment-gateways', (req, res) => {
  try {
    const gateways = db.getPaymentGateways();
    return res.status(200).json({ success: true, data: gateways });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/erp/payment-gateways', (req, res) => {
  try {
    const updated = db.savePaymentGateways(req.body);
    broadcastStateChange('payment_gateways_updated', updated);
    return res.status(200).json({
      success: true,
      message: 'Credenciales de pasarelas guardadas y encriptadas con éxito.',
      data: updated
    });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});


// 16. MÓDULO CEREBRAL NORA AI (Visión Multimodal, Voz y Transacciones SQLite)

// 16a. Endpoint de Visión Multimodal Real (Cámara y Fotos de Facturas en Base64)
app.post('/api/nora/vision', async (req, res) => {
  try {
    const { imageBase64, supplierHint, rawTextHint } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ success: false, error: 'Se requiere imageBase64 de la captura real de cámara.' });
    }

    const result = await noraBrain.parseInvoiceVision({
      imageBase64,
      supplierHint,
      rawTextHint
    });

    // Notificar actualización de stock en tiempo real vía WebSockets si hubo cambios
    if (result.success && result.pendingDraft) {
      broadcastStateChange('inventory_updated', { source: 'nora_vision', data: result });
      broadcastStateChange('accounting_updated', { source: 'nora_vision' });
    }

    res.json({
      success: result.success !== false,
      aiAgent: 'Nora AI Brain - Nexora One',
      ...result
    });
  } catch (err) {
    console.error('Error en /api/nora/vision:', err);
    res.status(500).json({ success: false, error: 'Error procesando visión con Nora: ' + err.message });
  }
});

// 16b. Endpoint de Comandos de Voz y Lenguaje Natural (Tool Calling)
app.post('/api/nora/voice', async (req, res) => {
  try {
    const { speechText, sector = 'caja', user = 'Admin' } = req.body;
    if (!speechText) {
      return res.status(400).json({ success: false, error: 'Se requiere el texto del comando de voz (speechText).' });
    }

    const result = await noraBrain.processVoiceCommand({
      userSpeechText: speechText,
      sector,
      user
    });

    if (result.interpreted?.action === 'UPDATE_STOCK') {
      broadcastStateChange('inventory_updated', { source: 'nora_voice' });
    }

    res.json(result);
  } catch (err) {
    console.error('Error en /api/nora/voice:', err);
    res.status(500).json({ success: false, error: 'Error en comando de voz de Nora: ' + err.message });
  }
});

// 16b-2. Endpoint de Chat Conversacional Inteligente para el Widget
app.post('/api/nora/chat', async (req, res) => {
  try {
    const { message, text, sector = 'caja_central', user = 'Cajero' } = req.body;
    const userPrompt = message || text;
    if (!userPrompt) {
      return res.status(400).json({ success: false, error: 'Se requiere el mensaje de texto (message o text).' });
    }

    const result = await noraBrain.processVoiceCommand({
      userSpeechText: userPrompt,
      sector,
      user
    });

    if (result.interpreted?.action === 'UPDATE_STOCK') {
      broadcastStateChange('inventory_updated', { source: 'nora_chat' });
    }

    res.json(result);
  } catch (err) {
    console.error('Error en /api/nora/chat:', err);
    res.status(500).json({ success: false, error: 'Error en chat de Nora: ' + err.message });
  }
});

// 16c. Auditoría de Facturas Procesadas por la IA
app.get('/api/nora/facturas', (req, res) => {
  try {
    const facturas = db.getFacturasAI();
    res.json({ success: true, count: facturas.length, data: facturas });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 16d. Compatibilidad Retroactiva para /api/ai/parse-invoice
app.post('/api/ai/parse-invoice', async (req, res) => {
  try {
    const { invoiceText, imageBase64 } = req.body;
    const result = await noraBrain.parseInvoiceVision({
      imageBase64,
      rawTextHint: invoiceText
    });

    res.json({
      success: true,
      aiAgent: 'Nora AI - Agente Nativa Inteligente Nexora One',
      extractedData: result.extractedData || result.data
    });
  } catch (err) {
    res.status(500).json({ error: 'Error procesando comprobante con Nora AI: ' + err.message });
  }
});

// 17. Auto-descubrimiento Adaptativo de IP para Escaneo en Cualquier Wi-Fi
app.get('/api/system/network-info', (req, res) => {
  const localIp = getPrimaryLocalIp();
  res.json({
    localIp,
    port: PORT,
    system: 'Nexora One Smart Restaurant & Bar System',
    noraAiStatus: 'Nora AI Active & Operating Natively',
    brandSignature: 'Nexora One ERP'
  });
});

// 17b. Endpoint de Telemetría, Versión y Estado de Licencia Local
app.get('/api/system/version', (req, res) => {
  try {
    let licenseStatus = 'active';
    let clienteNombre = 'Restobar Local';
    try {
      const lic = db.getLicencia();
      if (lic) {
        licenseStatus = lic.estado || 'active';
        clienteNombre = lic.clienteNombre || clienteNombre;
      }
    } catch (e) {
      licenseStatus = 'active';
    }

    res.json({
      success: true,
      version: '2026.1.0',
      system: 'Restobar 2026 POS',
      brand: 'Nexora One',
      commit: 'prod-40b7ba7',
      licenseStatus,
      client: clienteNombre,
      database: 'SQLite 3 (Embedded / Offline-First)',
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.json({
      success: true,
      version: '2026.1.0',
      commit: 'prod-40b7ba7',
      licenseStatus: 'active'
    });
  }
});

// 17c. Endpoint de Salud y Estado de Infraestructura Local & Nube
app.get('/api/system/status', (req, res) => {
  try {
    let sqliteStatus = 'healthy';
    let totalMesas = 0;
    let totalProductos = 0;
    try {
      const rowMesas = db.db.prepare('SELECT COUNT(*) as count FROM mesas').get();
      totalMesas = rowMesas ? rowMesas.count : 0;
      const rowProds = db.db.prepare('SELECT COUNT(*) as count FROM productos').get();
      totalProductos = rowProds ? rowProds.count : 0;
    } catch (dbErr) {
      sqliteStatus = 'error: ' + dbErr.message;
    }

    let licenseStatus = 'active';
    try {
      const lic = db.getLicencia();
      if (lic && lic.estado) licenseStatus = lic.estado;
    } catch (e) {}

    const localIp = getPrimaryLocalIp();

    res.json({
      status: sqliteStatus === 'healthy' ? 'online' : 'degraded',
      version: '2026.1.0',
      sqlite: {
        status: sqliteStatus,
        walMode: true,
        stats: { mesas: totalMesas, productos: totalProductos }
      },
      network: {
        mode: 'Local-First Sovereign',
        localIp,
        backendPort: PORT,
        frontendPort: 3036
      },
      license: {
        status: licenseStatus,
        offlineGraceBufferDays: 5
      },
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({
      status: 'error',
      error: err.message
    });
  }
});

// 18. Intercomunicador & Mensajería Interna por Sectores
app.get('/api/internal-messages', (req, res) => {
  res.json({ messages: db.getInternalMessages(), brandSignature: 'Nexora One' });
});

app.post('/api/internal-messages', (req, res) => {
  const newMsg = db.sendInternalMessage(req.body);
  broadcastStateChange('internal_message_created', { message: newMsg });
  res.json({ success: true, message: newMsg });
});

// 19. Llaves de Acceso por Sector y Rol de Empleado
app.post('/api/auth/sector-login', (req, res) => {
  const { pin } = req.body;
  const access = db.verifySectorPin(pin);
  if (access) {
    res.json({ success: true, access, brandSignature: 'Nexora One' });
  } else {
    res.status(401).json({ error: 'Llave de acceso/PIN incorrecto para este sector' });
  }
});

// Iniciar servidor en puerto libre 3035
server.listen(PORT, '0.0.0.0', () => {
  console.log(`
  🚀 SERVIDOR BARS & RESTAURANTS SYSTEM INICIADO
  --------------------------------------------------
  Firma: Nexora One
  Puerto: ${PORT}
  Host: http://localhost:${PORT}
  Ubicación: D:\\BARES 2026\\backend
  Optimización: 4GB RAM Compliant (Ultra Lightweight)
  --------------------------------------------------
  `);
});
