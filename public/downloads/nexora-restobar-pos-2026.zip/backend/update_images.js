import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database(path.join(__dirname, 'data', 'restobar.sqlite'));

const update = db.prepare('UPDATE productos SET image = ? WHERE id = ?');
update.run('/dishes/bife.jpg', 'm1');
update.run('/dishes/burger.jpg', 'm4');
update.run('/dishes/pizza.jpg', 'm5');
update.run('/dishes/cerveza.jpg', 'm6');
update.run('/dishes/flan.jpg', 'm8');

console.log('✅ Base de datos actualizada con las fotos culinarias HD generadas.');
const prods = db.prepare('SELECT id, title, image FROM productos').all();
console.table(prods);
