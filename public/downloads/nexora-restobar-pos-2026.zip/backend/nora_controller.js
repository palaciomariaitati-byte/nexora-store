/**
 * nora_controller.js - Controlador Cerebral de Inteligencia Artificial para MyJNexoraVisual
 * 
 * Integra los motores multimodales de Nora con el backend gastronómico de BARES 2026.
 * Incluye:
 *  1. Visión y OCR Multimodal con CONCILIACIÓN CONVERSACIONAL (Borrador en memoria).
 *  2. Procesamiento de Voz y Comandos Naturales con ajuste iterativo de mercadería.
 *  3. Inyección transaccional controlada hacia SQLite (better-sqlite3).
 */

import { Groq } from 'groq-sdk';
import { db } from './database.js';
import dotenv from 'dotenv';
dotenv.config();

export class NoraBrainController {
  constructor(options = {}) {
    this.apiKey = options.apiKey || process.env.GROQ_API_KEY || '';
    this.sqliteDb = db;

    // Estado borrador en memoria para conciliación conversacional paso a paso
    this.activeDraftInvoice = null;

    // Modelos Groq LPU de alta velocidad con rotación
    this.visionModels = [
      'llama-3.2-11b-vision-preview',
      'llama-3.2-90b-vision-preview'
    ];
    this.textModels = [
      'llama-3.3-70b-versatile',
      'qwen-2.5-32b',
      'llama-3.1-8b-instant'
    ];
    this.sttModel = 'whisper-large-v3-turbo';

    this.client = this.apiKey ? new Groq({ apiKey: this.apiKey }) : null;
  }

  isReady() {
    return Boolean(this.client);
  }

  /**
   * 1. VISIÓN MULTIMODAL REAL: Inspecciona la imagen real con Groq Vision
   * Prompt estricto: "Lee exactamente los ítems de este comprobante. No inventes datos. Si es de una farmacia u otro rubro, indícalo".
   */
  async parseInvoiceVision({ imageBase64, supplierHint = '', rawTextHint = '' }) {
    let parsedData = null;

    if (!this.client || !this.apiKey) {
      console.warn('[NoraBrain Vision] Motor de visión no disponible: API key de Groq no configurada.');
      return {
        ok: false,
        success: false,
        isLegible: false,
        error: 'Servicio de Visión no configurado (falta GROQ_API_KEY). El resto del sistema opera con normalidad.',
        spokenResponse: 'El módulo de visión por cámara requiere configuración de API key. La facturación y comandas siguen funcionando sin inconvenientes.',
        extractedData: null
      };
    }

    if (!imageBase64) {
      return {
        ok: false,
        success: false,
        isLegible: false,
        error: 'No se recibió imagen para procesar.',
        spokenResponse: 'No recibí ninguna imagen de comprobante para procesar.',
        extractedData: null
      };
    }

    try {
      const systemPrompt = `
Eres Nora AI, el sistema de visión y OCR multimodal para Nexora One.
Tu misión es inspeccionar la imagen real del comprobante con máxima rigurosidad y precisión.

INSTRUCCIONES ESTRICTAS:
1. Lee exactamente los ítems visibles en este comprobante. NO inventes datos. NO inventes ítems de carne, verdura ni frigoríficos si no aparecen en la imagen.
2. Si el comprobante o remito es de una farmacia, ferretería, supermercado u otro rubro no gastronómico, indícalo explícitamente en el nombre del proveedor y notas.
3. Si la imagen está borrosa, ilegible o no contiene ningún comprobante reconocible, devuelve "isLegible": false con un mensaje descriptivo.
4. Devuelve ÚNICAMENTE un objeto JSON válido con la estructura solicitada.

ESTRUCTURA DE RESPUESTA REQUERIDA (JSON):
{
  "isLegible": true,
  "rubro": "Gastronomía | Farmacia | Ferretería | Varios",
  "supplierName": "Nombre real del emisor/proveedor",
  "invoiceType": "Factura / Ticket / Remito",
  "invoiceDate": "YYYY-MM-DD",
  "totalAmount": 0.00,
  "confidenceScore": 0.95,
  "items": [
    {
      "name": "Nombre exacto del ítem leído",
      "quantity": 1.0,
      "unit": "Unidades / Kg / Litros",
      "costPerUnit": 0.0,
      "subtotal": 0.0
    }
  ],
  "notes": "Observaciones adicionales si aplica"
}
`;

      const formattedUrl = imageBase64.startsWith('data:') 
        ? imageBase64 
        : `data:image/jpeg;base64,${imageBase64}`;

      const userContent = [
        {
          type: 'image_url',
          image_url: { url: formattedUrl }
        },
        {
          type: 'text',
          text: 'Lee exactamente los ítems de este comprobante. No inventes datos. Si es de una farmacia u otro rubro, indícalo.'
        }
      ];

      const response = await this.client.chat.completions.create({
        model: 'llama-3.2-11b-vision-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userContent }
        ],
        temperature: 0.1,
        response_format: { type: 'json_object' }
      });

      const rawJson = response.choices[0]?.message?.content || '{}';
      parsedData = JSON.parse(rawJson);
    } catch (err) {
      console.error('[NoraBrain Vision] Error llamando a Groq Vision:', err.message);
      return {
        ok: false,
        success: false,
        isLegible: false,
        error: `Falla en reconocimiento visual de comprobante: ${err.message}`,
        spokenResponse: 'Ocurrió un error al procesar la imagen con el servidor de visión. Por favor intenta nuevamente o carga el remito de forma manual.',
        extractedData: null
      };
    }

    // Si la visión no pudo leer o falló la conexión
    if (!parsedData || parsedData.isLegible === false || !parsedData.items) {
      const spokenMsg = parsedData?.notes || 'No pude distinguir los ítems del comprobante con claridad en la imagen. Por favor, enfócalo con buena luz y vuelve a tomar la foto.';
      return {
        ok: true,
        success: false,
        isLegible: false,
        spokenResponse: spokenMsg,
        extractedData: parsedData || null
      };
    }

    // ⚡ CONCILIACIÓN CONVERSACIONAL: Guardar en BORRADOR si hay ítems legítimos
    this.activeDraftInvoice = {
      ...parsedData,
      status: 'pending_confirmation',
      imageBase64: 'image_attached'
    };

    const rubroInfo = parsedData.rubro && parsedData.rubro.toLowerCase() !== 'gastronomía' 
      ? ` (Rubro detectado: ${parsedData.rubro})` 
      : '';

    const itemsSummary = parsedData.items.length > 0
      ? parsedData.items.map((i) => `${i.quantity} ${i.unit || 'u.'} de ${i.name}`).join(', ')
      : 'sin ítems legibles';

    const spokenResponse = `Leí el comprobante de ${parsedData.supplierName || 'comprobante'}${rubroInfo}: ${itemsSummary}. ¿Deseas confirmar la recepción de estos ítems?`;

    return {
      ok: true,
      success: true,
      pendingDraft: this.activeDraftInvoice,
      spokenResponse,
      extractedData: parsedData
    };
  }

  /**
   * 2. COMANDOS DE VOZ Y CONCILIACIÓN ITERATIVA
   * Interpreta si el usuario confirma ("Sí, todo en orden") o ajusta ("Faltaron 2kg de carne")
   */
  async processVoiceCommand({ userSpeechText, sector = 'caja', user = 'Admin' }) {
    const text = String(userSpeechText).toLowerCase();

    // A. ¿Hay un borrador de remito pendiente de confirmación?
    if (this.activeDraftInvoice && this.activeDraftInvoice.status === 'pending_confirmation') {
      return this.handleDraftInvoiceConciliation(text, userSpeechText);
    }

    // B. Si no hay borrador, procesar comando habitual
    if (this.client) {
      try {
        const currentInventory = this.getAvailableInventoryList();
        const caja = this.sqliteDb.getCajaActual();

        const systemPrompt = `
Eres Nora AI, el cerebro gastronómico de MyJNexoraVisual.
El usuario te habla desde "${sector}". Total caja actual: $${caja.montoTotal}.
Inventario: ${JSON.stringify(currentInventory.slice(0, 10))}

ACCIONES:
- "UPDATE_STOCK": Cargar insumos. { quantity, productName, unit, costPerUnit }
- "QUERY_SALES": Consulta de recaudación o caja.
- "CHAT_GENERAL": Respuestas cordiales o asesoramiento.

Devuelve JSON:
{
  "action": "UPDATE_STOCK" | "QUERY_SALES" | "CHAT_GENERAL",
  "spokenResponse": "Respuesta breve de Nora (máximo 2 oraciones)",
  "payload": {}
}
`;

        const response = await this.client.chat.completions.create({
          model: this.textModels[0],
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userSpeechText }
          ],
          temperature: 0.2,
          response_format: { type: 'json_object' }
        });

        const parsed = JSON.parse(response.choices[0]?.message?.content || '{}');
        const executionResult = await this.executeAction(parsed);

        return {
          success: true,
          interpreted: parsed,
          executionResult
        };
      } catch (e) {
        console.warn('[NoraBrain Voice] Error con LLM, usando fallback local:', e.message);
      }
    }

    return this.fallbackVoiceCommand(userSpeechText);
  }

  /**
   * Conciliación Conversacional de Remitos / Facturas
   */
  async handleDraftInvoiceConciliation(text, originalSpeech) {
    const draft = this.activeDraftInvoice;

    // 1. Confirmación Total: "Todo en orden", "sí", "correcto", "recibí todo", "guardar"
    if (text.includes('si') || text.includes('sí') || text.includes('todo') || text.includes('correcto') || text.includes('orden') || text.includes('confirmar')) {
      // ⚡ AHORA SÍ IMPACTA SQLITE DE FORMA TRANSACCIONAL
      const dbResult = this.sqliteDb.procesarFacturaIA({
        supplierName: draft.supplierName,
        invoiceType: draft.invoiceType,
        invoiceDate: draft.invoiceDate,
        totalAmount: draft.totalAmount,
        items: draft.items,
        rawText: draft.rawText,
        imageBase64: draft.imageBase64
      });

      this.activeDraftInvoice = null; // Borrador liquidado

      const spoken = `Perfecto. Stock y gasto de ${draft.supplierName || 'insumos'} impactados correctamente en el sistema.`;
      return {
        success: true,
        interpreted: { action: 'CONFIRM_DRAFT', spokenResponse: spoken },
        executionResult: { updated: true, dbResult }
      };
    }

    // 2. Modificación de Faltantes: "faltaron X kg", "vino menos", "llegaron solo Y"
    if (text.includes('falto') || text.includes('faltaron') || text.includes('menos') || text.includes('solo')) {
      // Extraer número de faltante si se detecta
      const matchNumber = text.match(/(\d+[\.,]?\d*)/);
      const diffAmount = matchNumber ? parseFloat(matchNumber[1].replace(',', '.')) : 2.0;

      // Restar al primer ítem del borrador o buscar carne/cerveza
      if (draft.items && draft.items.length > 0) {
        draft.items[0].quantity = Math.max(0, draft.items[0].quantity - diffAmount);
        draft.items[0].subtotal = draft.items[0].quantity * (draft.items[0].costPerUnit || 1);
        draft.totalAmount = draft.items.reduce((s, i) => s + (i.subtotal || 0), 0);
      }

      // Impactar en SQLite con las cantidades ajustadas
      const dbResult = this.sqliteDb.procesarFacturaIA({
        supplierName: draft.supplierName,
        invoiceType: draft.invoiceType,
        invoiceDate: draft.invoiceDate,
        totalAmount: draft.totalAmount,
        items: draft.items,
        rawText: `${draft.rawText || ''} | Ajuste por faltante reportado: ${diffAmount}`
      });

      this.activeDraftInvoice = null;

      const spoken = `Entendido. Desconté los ${diffAmount} faltantes y actualicé el inventario real en el sistema.`;
      return {
        success: true,
        interpreted: { action: 'ADJUST_AND_CONFIRM_DRAFT', spokenResponse: spoken },
        executionResult: { updated: true, dbResult }
      };
    }

    // 3. Cancelar borrador
    if (text.includes('cancelar') || text.includes('no') || text.includes('descartar')) {
      this.activeDraftInvoice = null;
      return {
        success: true,
        interpreted: { action: 'CANCEL_DRAFT', spokenResponse: 'Borrador de remito cancelado. No se modificó el inventario.' },
        executionResult: { cancelled: true }
      };
    }

    return {
      success: true,
      pendingDraft: draft,
      interpreted: {
        action: 'AWAITING_CONFIRMATION',
        spokenResponse: '¿Deseas confirmar la recepción de todos los ítems o indicar algún faltante?'
      }
    };
  }

  generateFallbackDraft(rawText = '') {
    return {
      isLegible: false,
      supplierName: 'Comprobante no reconocido',
      invoiceType: 'Desconocido',
      invoiceDate: new Date().toISOString().split('T')[0],
      totalAmount: 0,
      items: [],
      notes: 'No fue posible extraer ítems automáticamente sin una imagen clara.'
    };
  }

  async executeAction(actionIntent) {
    const { action, payload } = actionIntent;
    if (action === 'QUERY_SALES') {
      const caja = this.sqliteDb.getCajaActual();
      return { totalCaja: caja.montoTotal, movimientos: caja.movimientos.length };
    }
    if (action === 'UPDATE_STOCK') {
      const qty = Number(payload.quantity) || 1;
      const name = payload.productName || 'Producto';
      const dbResult = this.sqliteDb.procesarFacturaIA({
        supplierName: 'Comando de Voz Nora',
        totalAmount: 0,
        items: [{ name, quantity: qty, unit: payload.unit || 'Kg', costPerUnit: payload.costPerUnit || 0 }]
      });
      return { updated: true, dbResult };
    }
    return { handled: true };
  }

  getAvailableInventoryList() {
    try {
      return this.sqliteDb.getInventory().map((i) => ({
        id: i.id,
        name: i.name,
        unit: i.unit,
        currentStock: i.currentStock,
        costPerUnit: i.costPerUnit
      }));
    } catch (e) {
      return [];
    }
  }

  fallbackVoiceCommand(userSpeechText) {
    const text = String(userSpeechText).toLowerCase();
    const caja = this.sqliteDb.getCajaActual();
    const inventory = this.getAvailableInventoryList();

    // 1. Consulta de Caja y Recaudación
    if (text.includes('caja') || text.includes('vendimos') || text.includes('total') || text.includes('recaud')) {
      return {
        success: true,
        interpreted: {
          action: 'QUERY_SALES',
          spokenResponse: `El total acumulado en caja al momento es de $${caja.montoTotal.toLocaleString('es-AR')} pesos.`
        },
        executionResult: { totalCaja: caja.montoTotal }
      };
    }

    // 2. Consulta de Stock e Insumos
    if (text.includes('stock') || text.includes('cuanto queda') || text.includes('insumo') || text.includes('carne') || text.includes('cerveza')) {
      const matchItem = inventory.find(i => text.includes(i.name.toLowerCase().split(' ')[0]));
      if (matchItem) {
        return {
          success: true,
          interpreted: {
            action: 'QUERY_STOCK',
            spokenResponse: `En depósito tenemos ${matchItem.currentStock} ${matchItem.unit} de ${matchItem.name}.`
          },
          executionResult: { item: matchItem }
        };
      }
      return {
        success: true,
        interpreted: {
          action: 'QUERY_STOCK',
          spokenResponse: `Actualmente registramos ${inventory.length} insumos en inventario de depósito.`
        },
        executionResult: { inventoryCount: inventory.length }
      };
    }

    // 3. Saludos y Cordialidad
    if (text.includes('hola') || text.includes('buen dia') || text.includes('buenas') || text.includes('nora')) {
      return {
        success: true,
        interpreted: {
          action: 'CHAT_GENERAL',
          spokenResponse: '¡Hola! Aquí está Nora. ¿En qué puedo asistirte en el salón o en la caja hoy?'
        },
        executionResult: { handled: true }
      };
    }

    // 4. Ayuda y Guía Operativa
    if (text.includes('ayuda') || text.includes('que podes hacer') || text.includes('como funciona')) {
      return {
        success: true,
        interpreted: {
          action: 'CHAT_GENERAL',
          spokenResponse: 'Puedo consultar el saldo de caja, verificar stock de insumos, escanear remitos con la cámara para actualizar mercadería y liberar mesas.'
        },
        executionResult: { handled: true }
      };
    }

    // 5. Respuesta conversacional general
    return {
      success: true,
      interpreted: {
        action: 'CHAT_GENERAL',
        spokenResponse: `Comprendido. Registré tu consulta sobre "${userSpeechText}". Si necesitas consultar caja, stock de insumos o escanear un comprobante, estoy lista.`
      },
      executionResult: { handled: true }
    };
  }
}

export const noraBrain = new NoraBrainController();
export default noraBrain;
