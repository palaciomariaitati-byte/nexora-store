import express from 'express';
import cors from 'cors';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { carribarDb } from './server/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3040;

app.use(cors());
app.use(express.json());

// Servir la suite estática completa (index.html, pos, wallet, dashboard, stock_nora)
const ROOT_DIR = path.join(__dirname, '..');
app.use(express.static(ROOT_DIR));

function getLocalIp() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return 'localhost';
}

// 1. ENDPOINTS DE SALUD Y TELEMETRÍA (ESTÁNDAR BARES 2026)
app.get('/api/system/version', (req, res) => {
  res.json({
    version: '2026.1.0',
    system: 'Nexora Club & Carribar Pass',
    build: 'Industrial Release - SQLite WAL',
    licenseStatus: 'active',
    brand: 'Nexora One'
  });
});

app.get('/api/system/status', (req, res) => {
  try {
    const stats = carribarDb.getStats();
    res.json({
      status: 'online',
      system: 'Nexora Club & Carribar Pass',
      version: '2026.1.0',
      database: {
        engine: 'SQLite 3 WAL Mode',
        status: 'healthy',
        file: 'data/carribar.sqlite'
      },
      network: {
        mode: 'Local-First Sovereign (LAN Ready)',
        port: PORT,
        localIp: getLocalIp()
      },
      telemetry: {
        walletsActivas: stats.walletsCount,
        saldoTotalEmitido: stats.saldoTotal,
        totalTransacciones: stats.txCount,
        recaudacionTotal: stats.totalRecaudado
      },
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({ status: 'error', error: err.message });
  }
});

// 2. ENDPOINT: DÉBITO ATÓMICO POR CÓDIGO QR
app.post('/api/pos/cobro-qr', (req, res) => {
  try {
    const { codigoQr, total, puntoVentaId, items } = req.body;
    if (!codigoQr || total === undefined) {
      return res.status(400).json({ success: false, error: 'Se requiere codigoQr y total para el débito.' });
    }

    const resultado = carribarDb.cobroQr({
      codigoQr,
      total: Number(total),
      puntoVentaId: puntoVentaId || 'carribar_exterior',
      items: items || []
    });

    res.json({
      success: true,
      mensaje: 'Cobro atómico procesado en milisegundos.',
      ...resultado
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      error: err.message
    });
  }
});

// 3. ENDPOINT: RECARGA DE SALDO EN CAJA
app.post('/api/caja/recarga', (req, res) => {
  try {
    const { codigoQr, monto, puntoVentaId, metodo } = req.body;
    if (!codigoQr || !monto) {
      return res.status(400).json({ success: false, error: 'Se requiere codigoQr y monto para recargar.' });
    }

    const resultado = carribarDb.recargarSaldo({
      codigoQr,
      monto: Number(monto),
      puntoVentaId: puntoVentaId || 'caja_recargas',
      metodo: metodo || 'efectivo'
    });

    res.json({
      success: true,
      mensaje: 'Saldo acreditado correctamente.',
      ...resultado
    });
  } catch (err) {
    res.status(400).json({
      success: false,
      error: err.message
    });
  }
});

// 4. CONSULTA DE SALDO DE WALLET
app.get('/api/wallets/:codigoQr', (req, res) => {
  const wallet = carribarDb.getWalletByQr(req.params.codigoQr);
  if (!wallet) {
    return res.status(404).json({ success: false, error: 'Wallet no encontrada.' });
  }
  res.json({ success: true, wallet });
});

// Fallback directo a server.js en raíz para compatibilidad
app.listen(PORT, '0.0.0.0', () => {
  console.log(`
  👑 NEXORA CLUB & CARRIBAR PASS — SERVICIO SOBERANO LISTO
  -------------------------------------------------------------
  Firma: Fast-Sales & Closed-Loop Fintech (Nexora One)
  Puerto: ${PORT}
  Host Local: http://localhost:${PORT}/
  Red LAN:    http://${getLocalIp()}:${PORT}/
  Base:       D:\\SUITE BOLICHES-NEXORAPAY\\data\\carribar.sqlite
  Modo:       WAL Mode Concurrente (Cero Caídas)
  -------------------------------------------------------------
  `);
});
