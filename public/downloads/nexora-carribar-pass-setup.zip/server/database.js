import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'carribar.sqlite');

export class CarribarDatabase {
  constructor() {
    this.db = new Database(DB_PATH);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('synchronous = NORMAL');
    this.db.pragma('foreign_keys = ON');

    this.initTables();
    this.seedDefaultsIfEmpty();
  }

  initTables() {
    this.db.exec(`
      -- 1. TABLA: WALLETS
      CREATE TABLE IF NOT EXISTS wallets (
        id TEXT PRIMARY KEY,
        codigo_qr TEXT UNIQUE NOT NULL,
        titular TEXT NOT NULL,
        saldo REAL NOT NULL DEFAULT 0.0 CHECK (saldo >= 0),
        estado TEXT NOT NULL DEFAULT 'activo', -- activo, bloqueado, vip
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      -- 2. TABLA: PRODUCTOS
      CREATE TABLE IF NOT EXISTS productos (
        id TEXT PRIMARY KEY,
        nombre TEXT NOT NULL,
        categoria TEXT NOT NULL, -- comidas, tragos, cervezas, combos
        precio REAL NOT NULL,
        stock INTEGER DEFAULT 100,
        requiere_cocina INTEGER DEFAULT 0, -- 1 si requiere plancha/cocina térmica
        activo INTEGER DEFAULT 1
      );

      -- 3. TABLA: PUNTOS DE VENTA
      CREATE TABLE IF NOT EXISTS puntos_venta (
        id TEXT PRIMARY KEY,
        nombre TEXT NOT NULL,
        tipo TEXT NOT NULL, -- carribar, barra, caja
        pin_hash TEXT
      );

      -- 4. TABLA: TRANSACCIONES
      CREATE TABLE IF NOT EXISTS transacciones (
        id TEXT PRIMARY KEY,
        wallet_id TEXT NOT NULL,
        punto_venta_id TEXT NOT NULL,
        total REAL NOT NULL,
        tipo TEXT NOT NULL, -- debito_compra, recarga_saldo, ajuste
        items_json TEXT,
        comanda_ticket TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (wallet_id) REFERENCES wallets (id)
      );
    `);
  }

  seedDefaultsIfEmpty() {
    const pvCount = this.db.prepare('SELECT COUNT(*) as count FROM puntos_venta').get().count;
    if (pvCount === 0) {
      const insPV = this.db.prepare('INSERT INTO puntos_venta (id, nombre, tipo, pin_hash) VALUES (?, ?, ?, ?)');
      insPV.run('carribar_exterior', 'Carribar Exterior Fast-Food', 'carribar', '2222');
      insPV.run('barra_principal', 'Barra Principal Boliche', 'barra', '1111');
      insPV.run('caja_recargas', 'Caja Central de Recargas', 'caja', '3333');
    }

    const prodCount = this.db.prepare('SELECT COUNT(*) as count FROM productos').get().count;
    if (prodCount === 0) {
      const insProd = this.db.prepare('INSERT INTO productos (id, nombre, categoria, precio, stock, requiere_cocina, activo) VALUES (?, ?, ?, ?, ?, ?, ?)');
      insProd.run('hamb_doble_smash', 'Hamburguesa Doble Smash con Cheddar', 'comidas', 9500, 100, 1, 1);
      insProd.run('lomito_completo', 'Lomito Completo Especial Carribar', 'comidas', 11500, 60, 1, 1);
      insProd.run('papas_cheddar', 'Papas Rústicas con Cheddar & Bacon', 'comidas', 6500, 80, 1, 1);
      insProd.run('fernet_750', 'Fernet con Cola 750cc', 'tragos', 7000, 200, 0, 1);
      insProd.run('ipa_pinta', 'Cerveza IPA Tirada (Pinta)', 'cervezas', 4500, 250, 0, 1);
      insProd.run('gaseosa_500', 'Gaseosa 500ml', 'comidas', 3000, 150, 0, 1);
    }

    const wCount = this.db.prepare('SELECT COUNT(*) as count FROM wallets').get().count;
    if (wCount === 0) {
      const insW = this.db.prepare('INSERT INTO wallets (id, codigo_qr, titular, saldo, estado) VALUES (?, ?, ?, ?, ?)');
      insW.run('w_default_1', 'NEX-CLUB-7821', 'Lucas Benítez (Fan Demo)', 25000, 'activo');
    }
  }

  getWalletByQr(codigoQr) {
    return this.db.prepare('SELECT * FROM wallets WHERE codigo_qr = ? OR id = ?').get(codigoQr, codigoQr);
  }

  // ⚡ DÉBITO ATÓMICO: VERIFICA SALDO, DESCUENTA STOCK Y GENERA TICKET SI REQUIERE COCINA
  cobroQr({ codigoQr, total, puntoVentaId = 'carribar_exterior', items = [] }) {
    const tx = this.db.transaction(() => {
      const wallet = this.getWalletByQr(codigoQr);
      if (!wallet) {
        throw new Error(`Wallet con código ${codigoQr} no encontrada.`);
      }
      if (wallet.estado !== 'activo' && wallet.estado !== 'vip') {
        throw new Error(`Wallet bloqueada o inactiva (estado: ${wallet.estado}).`);
      }
      if (wallet.saldo < total) {
        throw new Error(`Saldo insuficiente. Saldo actual: $${wallet.saldo.toLocaleString('es-AR')}, requerido: $${total.toLocaleString('es-AR')}`);
      }

      const nuevoSaldo = wallet.saldo - total;
      this.db.prepare('UPDATE wallets SET saldo = ? WHERE id = ?').run(nuevoSaldo, wallet.id);

      // Evaluar si incluye productos que requieren cocina / plancha (hamburguesas, lomitos)
      let requiereCocina = false;
      const itemsComanda = [];
      const updateStock = this.db.prepare('UPDATE productos SET stock = MAX(0, stock - ?) WHERE id = ?');

      for (const item of items) {
        if (item.id) {
          const p = this.db.prepare('SELECT requiere_cocina FROM productos WHERE id = ?').get(item.id);
          if (p && p.requiere_cocina === 1) {
            requiereCocina = true;
            itemsComanda.push(`${item.qty || 1}x ${item.name}`);
          }
          updateStock.run(item.qty || 1, item.id);
        }
      }

      let comandaTicket = null;
      if (requiereCocina || puntoVentaId.includes('carribar')) {
        const ticketNum = Math.floor(100 + Math.random() * 900);
        comandaTicket = {
          ticketNumber: ticketNum,
          sector: 'CARRIBAR EXTERIOR - PLANCHA',
          cliente: wallet.titular,
          codigoQr: wallet.codigo_qr,
          items: itemsComanda.length > 0 ? itemsComanda : items.map(i => `${i.qty}x ${i.name}`),
          fechaHora: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        };
      }

      const txId = `tx_${Date.now()}`;
      this.db.prepare(`
        INSERT INTO transacciones (id, wallet_id, punto_venta_id, total, tipo, items_json, comanda_ticket)
        VALUES (?, ?, ?, ?, 'debito_compra', ?, ?)
      `).run(txId, wallet.id, puntoVentaId, total, JSON.stringify(items), JSON.stringify(comandaTicket));

      return {
        txId,
        codigoQr: wallet.codigo_qr,
        titular: wallet.titular,
        totalDebitado: total,
        saldoPrevio: wallet.saldo,
        saldoNuevo: nuevoSaldo,
        requiereCocina,
        comandaTicket
      };
    });

    return tx();
  }

  // ⚡ RECARGA DE SALDO ATÓMICA
  recargarSaldo({ codigoQr, monto, puntoVentaId = 'caja_recargas', metodo = 'efectivo' }) {
    const tx = this.db.transaction(() => {
      const wallet = this.getWalletByQr(codigoQr);
      if (!wallet) throw new Error(`Wallet no encontrada para el código ${codigoQr}`);

      const nuevoSaldo = wallet.saldo + monto;
      this.db.prepare('UPDATE wallets SET saldo = ? WHERE id = ?').run(nuevoSaldo, wallet.id);

      const txId = `rec_${Date.now()}`;
      this.db.prepare(`
        INSERT INTO transacciones (id, wallet_id, punto_venta_id, total, tipo, items_json)
        VALUES (?, ?, ?, ?, 'recarga_saldo', ?)
      `).run(txId, wallet.id, puntoVentaId, monto, JSON.stringify({ metodo }));

      return {
        txId,
        codigoQr: wallet.codigo_qr,
        titular: wallet.titular,
        montoRecargado: monto,
        saldoNuevo: nuevoSaldo
      };
    });

    return tx();
  }

  getStats() {
    const walletsCount = this.db.prepare('SELECT COUNT(*) as c FROM wallets').get().c;
    const saldoTotal = this.db.prepare('SELECT SUM(saldo) as s FROM wallets').get().s || 0;
    const txCount = this.db.prepare('SELECT COUNT(*) as c FROM transacciones').get().c;
    const totalRecaudado = this.db.prepare("SELECT SUM(total) as s FROM transacciones WHERE tipo = 'debito_compra'").get().s || 0;

    return {
      walletsCount,
      saldoTotal,
      txCount,
      totalRecaudado
    };
  }
}

export const carribarDb = new CarribarDatabase();
