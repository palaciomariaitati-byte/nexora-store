@echo off
title Nexora Club & Carribar Pass - Servidor Perimetral Soberano (Puerto 3040)
color 0E

echo ======================================================================
echo       NEXORA CLUB & CARRIBAR PASS - CLOSED LOOP FINTECH SUITE
echo                        Powered by Nexora One
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: 1. Verificacion de red y sincronizacion silenciosa sin demorar apertura
echo  [1/3] Verificando parches y actualizaciones de la suite...
ping -n 1 -w 1000 8.8.8.8 >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    if exist "%ROOT_DIR%\.git" (
        git fetch origin main --quiet 2>nul
        git pull --ff-only origin main --quiet 2>nul
        echo        Sincronizacion exitosa sin tocar la base local SQLite.
    ) else (
        echo        Terminal lista en modo local independiente.
    )
) else (
    echo        Sin internet. Activando Red Local Perimetral 100%% Offline.
)

:: 2. Liberar puerto 3040 en caso de reinicio de terminal
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3040" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

:: 3. Iniciar Servidor Express + SQLite WAL en puerto 3040
echo.
echo  [2/3] Iniciando Servidor Fintech & Base SQLite (Puerto 3040)...
start /min "Nexora Club & Carribar Server" cmd /c "cd /d "%ROOT_DIR%" && node server.js"

:: 4. Esperar 2 segundos para montaje de sockets y tablas
timeout /t 2 /nobreak >nul

:: 5. Apertura de la aplicacion en ventana de escritorio limpia (Modo App)
echo.
echo  [3/3] Abriendo Hub de Control de Sectores...
echo.
echo  ======================================================================
echo   SISTEMA ACTIVO Y OPERANDO
echo   * Hub Central:     http://localhost:3040/
echo   * Terminal POS:    http://localhost:3040/pos/index.html
echo   * Wallet Cliente:  http://localhost:3040/wallet/index.html
echo   * Base de Datos:   %ROOT_DIR%data\carribar.sqlite (Modo WAL)
echo  ======================================================================
echo.

set "BROWSER_FOUND=0"
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3040/
    set "BROWSER_FOUND=1"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3040/
    set "BROWSER_FOUND=1"
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3040/
    set "BROWSER_FOUND=1"
) else (
    start http://localhost:3040/
)

echo La suite opera en segundo plano para atender Carribars, Barras y Wallets.
echo Presione cualquier tecla si desea cerrar esta consola auxiliar.
pause >nul
