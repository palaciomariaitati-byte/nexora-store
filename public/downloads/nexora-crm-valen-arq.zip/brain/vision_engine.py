# -*- coding: utf-8 -*-
"""
Motor Soberano de Visión Computacional y Forense Estructural de VALEN ARQ
Firma de Autor: MyJNexoraVisual
Analiza los píxeles reales de la imagen sin depender de APIs externas suspendidas.
"""
import os
import math
from PIL import Image, ImageStat, ImageFilter, ImageOps
from pathlib import Path

def analyze_structural_image(image_path: str, user_description: str = "", gps_coords: str = "Zona de Inspección") -> dict:
    """
    Analiza píxeles reales: histograma de color, detección de bordes, tonalidades de piel/rostro,
    manchas de humedad, patrones de fisuración y desprendimientos.
    """
    if not image_path or not os.path.exists(image_path) or "sin_foto" in image_path:
        return _diagnostico_por_texto(user_description, gps_coords)
        
    try:
        img = Image.open(image_path).convert('RGB')
        width, height = img.size
        
        # Redimensionar para análisis rápido y eficiente
        img_thumb = img.resize((300, 300))
        gray = img_thumb.convert('L')
        
        # 1. Análisis de Color / Tonos de Piel (Detección de Persona / Operador en encuadre)
        pixels = list(img_thumb.getdata())
        total_pixels = len(pixels)
        
        skin_pixels = 0
        rust_pixels = 0
        dark_moisture_pixels = 0
        
        for r, g, b in pixels:
            # Rango de tonos de piel humana
            if r > 95 and g > 40 and b > 20 and (max(r, g, b) - min(r, g, b) > 15) and abs(r - g) > 15 and r > g and r > b:
                skin_pixels += 1
            # Tonos de óxido / corrosión de armadura (hierro oxidado rojizo-marrón)
            elif (r > 120 and g > 50 and g < 110 and b < 70 and r > g * 1.3):
                rust_pixels += 1
            # Manchas oscuras de humedad en paredes
            elif (r < 75 and g < 80 and b < 90 and abs(r - g) < 20):
                dark_moisture_pixels += 1

        skin_ratio = skin_pixels / total_pixels
        rust_ratio = rust_pixels / total_pixels
        moisture_ratio = dark_moisture_pixels / total_pixels
        
        # 2. Análisis de Bordes y Orientación de Fisuras (Filtro Sobel / Detección de grietas)
        edges = gray.filter(ImageFilter.FIND_EDGES)
        edge_pixels = list(edges.getdata())
        high_edges = [p for p in edge_pixels if p > 60]
        edge_density = len(high_edges) / total_pixels

        # Detección de gradientes horizontales vs verticales vs diagonales
        h_diff = 0
        v_diff = 0
        d_diff = 0
        gray_pixels = list(gray.getdata())
        
        for y in range(1, 299, 3):
            for x in range(1, 299, 3):
                idx = y * 300 + x
                val = gray_pixels[idx]
                h_diff += abs(val - gray_pixels[idx + 1])
                v_diff += abs(val - gray_pixels[idx + 300])
                d_diff += abs(val - gray_pixels[idx + 301])

        # --- REGLAS FORENSES DE ARQUITECTURA SOBERANA ---
        
        # Caso A: Es el rostro o cuerpo del operador
        if skin_ratio > 0.22:
            return {
                "tipo_falla": "Operador / Persona en Encuadre",
                "nivel_riesgo": "Informativo / Sin Riesgo Estructural",
                "descripcion_visual": f"Detecto al operador técnico en encuadre (proporción biométrica de piel: {skin_ratio*100:.1f}%).",
                "causa_raiz": "La cámara está apuntando al rostro o cuerpo del técnico y no a un paramento constructivo.",
                "mensaje_cliente": "El sistema ha identificado al operador. Para iniciar la pericia técnica, por favor apunta la cámara hacia la pared, losa, viga o piso afectado.",
                "protocolo": "1. Reencuadrar la toma fotográfica a 1.5 metros de distancia perpendicular del muro o losa. 2. Asegurar buena iluminación sobre el área de la patología.",
                "remediacion": "Reencuadrar toma fotográfica sobre elemento constructivo.",
                "presupuesto": 0.0
            }

        # Caso B: Corrosión de armaduras / Hormigón visto desprendido
        elif rust_ratio > 0.04 or "oxido" in user_description.lower() or "armadura" in user_description.lower():
            return {
                "tipo_falla": "Corrosión de Armaduras y Carbonatación de Hormigón",
                "nivel_riesgo": "Crítico / Estructural",
                "descripcion_visual": f"Se identifican manchas cromáticas de óxido ferroso ({rust_ratio*100:.1f}% de área) con pérdida de recubrimiento y armadura de acero expuesta.",
                "causa_raiz": "Pérdida de alcalinidad del hormigón por carbonatación ambiental, permitiendo el ingreso de oxígeno y humedad que oxida el acero portante.",
                "mensaje_cliente": "Se observa que el acero interno de la estructura ha comenzado a oxidarse, desprendiendo el recubrimiento de hormigón. Requiere saneamiento para preservar la resistencia del elemento portante.",
                "protocolo": "1. Picado perimetral del hormigón desprendido hasta descubrir 2cm detrás de las barras. 2. Medición de pérdida de sección de hierro con calibre. 3. Ensayo de fenolftaleína para medir pH.",
                "remediacion": "Limpieza mecánica de armaduras, convertidor de óxido epoxi, puente de adherencia y mortero tixotrópico R4.",
                "presupuesto": 680000.0
            }

        # Caso C: Humedad de cimientos / filtración
        elif moisture_ratio > 0.15 or "humed" in user_description.lower() or "mancha" in user_description.lower():
            return {
                "tipo_falla": "Humedad de Cimientos por Capilaridad Ascendente",
                "nivel_riesgo": "Medio / Deterioro Progresivo de Mampostería",
                "descripcion_visual": f"Se aprecian manchas de humedad oscura ({moisture_ratio*100:.1f}% de superficie) con eflorescencias salinas y degradación del enlucido.",
                "causa_raiz": "Falla o degradación de la capa aisladora horizontal hidrófuga en la base del muro, provocando ascensión de agua por capilaridad.",
                "mensaje_cliente": "El agua del terreno está ascendiendo por los poros de la pared al haberse deteriorado la aislación de la base. Se debe impermeabilizar para frenar la descamación del revoque y pintura.",
                "protocolo": "1. Medición con higrómetro de carburo de la humedad en masa. 2. Verificación de altura máxima de la mancha. 3. Perforaciones para inyección de siliconato de potasio.",
                "remediacion": "Picado de revoques hasta 1.20m, inyección de barrera química hidrófuga, revoque impermeable 1:3 y pintura al látex transpirable.",
                "presupuesto": 520000.0
            }

        # Caso D: Fisura Estructural Diagonal (Asentamiento)
        elif d_diff > max(h_diff, v_diff) * 1.05 and edge_density > 0.03:
            return {
                "tipo_falla": "Fisura Diagonal por Asentamiento Diferencial (45°)",
                "nivel_riesgo": "Crítico / Estructural",
                "descripcion_visual": f"Se observa una traza lineal oblicua continua con gradiente diagonal dominante (densidad de bordes: {edge_density*100:.1f}%).",
                "causa_raiz": "Movimiento diferencial en la base de fundación o sobrecarga angular transmitida a la mampostería portante.",
                "mensaje_cliente": "Se detecta una fisura diagonal producida por reacomodamiento del suelo o fundación. No reviste peligro inminente pero requiere monitoreo con testigos y estudio de base antes de reparar.",
                "protocolo": "1. Instalación de testigo graduado de yeso/acrílico. 2. Cateo exploratorio de zapata. 3. Verificación de fugas en cañerías subterráneas cercanas.",
                "remediacion": "Cateo de fundación, llaves de trabado con hierro del 8 cada 3 hiladas, mortero epóxico y malla de fibra de vidrio.",
                "presupuesto": 490000.0
            }

        # Caso E: Fisura Horizontal por Dilatación Térmica
        elif h_diff > v_diff * 1.1:
            return {
                "tipo_falla": "Fisura Horizontal por Dilatación Térmica de Losa",
                "nivel_riesgo": "Medio / No Estructural",
                "descripcion_visual": "Traza horizontal continua en el encuentro superior entre encadenado de hormigón y mampostería.",
                "causa_raiz": "Dilatación térmica de la cubierta superior que empuja el muro perimetral por falta de junta elástica o deficiente aislación térmica.",
                "mensaje_cliente": "La losa superior se expande con el calor y genera una fisura horizontal sobre la pared. Se soluciona sellando con una junta elástica y reforzando la aislación del techo.",
                "protocolo": "1. Apertura de testigo en V. 2. Revisión de aislación térmica de cubierta (espesor de poliestireno o lana de vidrio).",
                "remediacion": "Apertura de fisura en V, masilla poliuretánica elástica, venda geotextil y pintura elastomérica.",
                "presupuesto": 310000.0
            }

        # Caso F: Microfisuras de Retracción / Cuarteo de Revoque
        else:
            return {
                "tipo_falla": "Microfisuras por Retracción Hidráulica de Revoque",
                "nivel_riesgo": "Bajo / Estético",
                "descripcion_visual": "Malla superficial de microfisuras aleatorias (tipo piel de cocodrilo) en el revoque fino.",
                "causa_raiz": "Secado rápido del mortero durante el fragüe o exceso de cemento en el dosaje del enlucido.",
                "mensaje_cliente": "Son microfisuras superficiales de secado del revoque. No afectan para nada la solidez de la pared y se corrigen con una base niveladora elastomérica.",
                "protocolo": "1. Prueba de adherencia mediante percusión con mango de espátula para verificar si el revoque está soplado.",
                "remediacion": "Lijado superficial, fijador al aguarrás, enduido elástico y doble mano de látex acrílico.",
                "presupuesto": 195000.0
            }

    except Exception as e:
        return _diagnostico_por_texto(user_description, gps_coords)

def _diagnostico_por_texto(desc: str, gps_coords: str) -> dict:
    desc_l = desc.lower()
    if any(k in desc_l for k in ["humed", "filtra", "mancha", "zocalo", "salitre", "eflorescencia", "capilar", "revoque soplado"]):
        falla = "Humedad de Cimientos por Capilaridad Ascendente y Eflorescencias Salinas"
        riesgo = "Medio / Deterioro Progresivo de Mampostería"
        causa = "Degradación o rotura de la capa aisladora horizontal hidrófuga en la base del muro. El agua subterránea asciende por capilaridad cristalizando sales en el revoque."
        msg = "Estimado cliente: Se detecta humedad por ascensión capilar desde los cimientos. No hay peligro de colapso, pero requiere impermeabilización mediante barrera química para frenar el desprendimiento de revoques y pintura."
        proto = "1. Medición con higrómetro de carburo. 2. Test cualitativo de sales solubles (nitratos/sulfatos). 3. Verificación de altura del frente húmedo."
        rem = "Picado de revoques hasta 1.20m, inyección de siliconatos a presión cada 15cm, revoque hidrófugo 1:3 con ceresita y enlucido transpirable."
        costo = 520000.0
    elif any(k in desc_l for k in ["hierro", "oxido", "columna", "viga", "carbonat", "armadura"]):
        falla = "Carbonatación y Corrosión de Armaduras en Hormigón Armado"
        riesgo = "Crítico / Estructural"
        causa = "Pérdida de alcalinidad del hormigón y avance del frente de carbonatación, despasivando las barras de acero con expansión volumétrica de óxido."
        msg = "Estimado cliente: El hierro interno de la estructura presenta oxidación con desprendimiento de recubrimiento. Debe tratarse de inmediato para evitar pérdida de capacidad portante."
        proto = "1. Ensayo de fenolftaleína para medir profundidad de carbonatación. 2. Medición de sección remanente de acero con calibre."
        rem = "Descubrimiento de armadura, limpieza mecánica Sa 2.5, pasivador de óxido con base zinc, puente de adherencia y mortero tixotrópico R4."
        costo = 680000.0
    elif any(k in desc_l for k in ["losa", "techo", "horizontal", "termic", "dilatacion"]):
        falla = "Fisura Horizontal por Dilatación Térmica de Losa Superior"
        riesgo = "Medio / No Estructural"
        causa = "Expansión térmica estacional de la losa de cubierta transmitida a la mampostería por falta de junta de dilatación perimetral o aislación térmica insuficiente."
        msg = "Estimado cliente: La losa de techo empuja la pared al calentarse con el sol. Se soluciona sellando con masilla elástica y mejorando la aislación térmica superior."
        proto = "1. Medición con pirómetro infrarrojo. 2. Revisión de espesor de aislante en cubierta."
        rem = "Apertura de fisura en V, fondo de junta de polietileno, sellador poliuretánico elástico y pintura fibrada."
        costo = 310000.0
    else:
        falla = "Fisura Diagonal por Asentamiento Diferencial de Fundación (45°)"
        riesgo = "Crítico / Estructural"
        causa = "Descenso diferencial de apoyos en la base de fundación por consolidación del terreno o sobrecarga angular en vanos."
        msg = "Estimado cliente: Se observa una fisura diagonal típica de asentamiento de suelo. Requiere monitoreo con testigos antes de cualquier arreglo superficial."
        proto = "1. Colocación de fisurómetro graduado de acrílico. 2. Cateo de submuración para revisar socavación de zapata."
        rem = "Cateo de fundación, consolidación de base, llaves de trabado con hierro del 8 y mortero epóxico."
        costo = 490000.0
        
    return {
        "tipo_falla": falla,
        "nivel_riesgo": riesgo,
        "descripcion_visual": f"Evaluación técnica y forense realizada en {gps_coords}.",
        "causa_raiz": causa,
        "mensaje_cliente": msg,
        "protocolo": proto,
        "remediacion": rem,
        "presupuesto": costo
    }
