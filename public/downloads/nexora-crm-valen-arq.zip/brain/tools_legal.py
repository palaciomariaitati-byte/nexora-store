# -*- coding: utf-8 -*-
"""
Módulo de Herramientas Legales, Contratos y Régimen UOCRA/IERIC para VALEN
"""
import sqlite3
import json
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "valen_arq.db"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

def redactar_contrato_locacion_obra(cliente_id: int, monto_total: float, plazo_meses: int, sistema_contratacion: str = "Ajuste Alzado con Redeterminación CAC") -> str:
    """
    Redacta un modelo formal de Contrato de Locación de Obra según los artículos 1251 a 1279 del CCyCN.
    """
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT razon_social, cuit, direccion FROM Clientes WHERE id = ?", (cliente_id,))
    cliente = c.fetchone()
    conn.close()
    
    razon = cliente["razon_social"] if cliente else "EL COMITENTE"
    cuit = cliente["cuit"] if cliente else "30-XXXXXXXX-X"
    domicilio = cliente["direccion"] if cliente else "Domicilio Legal"
    
    contrato = f"""
CONTRATO DE LOCACIÓN DE OBRA MATERIAL E INTELECTUAL

Entre {razon}, CUIT N° {cuit}, con domicilio en {domicilio}, en adelante 'EL COMITENTE', y EL CONSTRUCTOR/DIRECTOR DE OBRA, en adelante 'LA CONTRATISTA', se conviene celebrar el presente contrato bajo las siguientes cláusulas y las previsiones de los artículos 1251 y concordantes del Código Civil y Comercial de la Nación (CCyCN):

PRIMERA (OBJETO): LA CONTRATISTA se obliga a ejecutar los trabajos de construcción y dirección técnica conforme a los planos, memorias descriptivas y pliego de especificaciones técnicas aprobados por ambas partes.
SEGUNDA (SISTEMA DE CONTRATACIÓN): Los trabajos se convienen bajo el sistema de {sistema_contratacion} (Art. 1262 CCyCN).
TERCERA (PRECIO Y CONDICIONES): El precio global convenido asciende a la suma de ${monto_total:,.2f} pesos argentinos. En caso de variaciones de costos de insumos y mano de obra, se aplicará la fórmula polinómica de redeterminación de precios basada en el Índice de la Cámara Argentina de la Construcción (CAC).
CUARTA (PLAZO): El plazo de ejecución se establece en {plazo_meses} meses corridos a partir de la firma del Acta de Replanteo e Inicio de Obra.
QUINTA (RECEPCIÓN PROVISORIA Y FONDO DE REPARO): Finalizada la obra, se labrará Acta de Recepción Provisoria. De cada certificado mensual se retendrá el cinco por ciento (5%) en concepto de Fondo de Reparo (Art. 1270 CCyCN), el cual será reintegrado tras la Recepción Definitiva cumplido el plazo de garantía de 90 días sin vicios aparentes.
SEXTA (RESPONSABILIDAD DECENAL): Rige plenamente la responsabilidad por ruina total o parcial establecida en el Art. 1273 del CCyCN por el término de diez (10) años.
SÉPTIMA (JURISDICCIÓN): Para cualquier controversia, las partes se someten a los Tribunales Ordinarios competentes fijando domicilios en los ut supra indicados.

En prueba de conformidad, se firman dos ejemplares de un mismo tenor y a un solo efecto.
"""
    return contrato

def auditar_personal_ieric(empleado_id: int) -> str:
    """Audita el cumplimiento laboral del personal bajo Ley 22.250 (IERIC) y CCT 76/75."""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Personal_UOCRA WHERE id = ?", (empleado_id,))
    emp = c.fetchone()
    conn.close()
    
    if not emp:
        return f"Error: No existe el operario con ID {empleado_id}."
        
    estado_art = "✅ Vigente (Dec. 911/96 OK)" if emp["art_seguro_vigente"] else "🚨 VENCIDA - URGENTE: No permitir ingreso a obra"
    ieric_status = f"✅ Registrado N° {emp['numero_ieric']}" if emp["numero_ieric"] else "⚠️ Sin N° IERIC - Riesgo de sanción inspectiva"
    
    return f"""
⚖️ [AUDITORÍA LABORAL UOCRA / IERIC - VALEN LEGAL]
👷 Operario: {emp['nombre']} (CUIL: {emp['cuil']})
📋 Categoría CCT 76/75: {emp['categoria']}
🏛️ Registro IERIC (Ley 22.250): {ieric_status}
🛡️ Cobertura ART & EPP: {estado_art}
💵 Salario Base / Hora: ${emp['salario_hora']}
💼 Fondo de Cese Laboral Acumulado: ${emp['fondo_cese_acumulado']:,.2f}
"""

def generar_acta_recepcion_obra(obra_id: int, tipo: str = "Provisoria", observaciones: str = "Sin observaciones visibles.") -> str:
    """Genera el Acta Notarial/Técnica de Recepción Provisoria o Definitiva de Obra (Arts. 1270-1272 CCyCN)."""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT o.nombre, o.direccion, c.razon_social FROM Obras o JOIN Clientes c ON o.cliente_id = c.id WHERE o.id = ?", (obra_id,))
    row = c.fetchone()
    conn.close()
    
    nombre_obra = row["nombre"] if row else f"Obra {obra_id}"
    comitente = row["razon_social"] if row else "El Comitente"
    fecha_actual = datetime.now().strftime("%d/%m/%Y")
    
    return f"""
ACTA DE RECEPCIÓN {tipo.upper()} DE OBRA
En la ciudad de Buenos Aires, a los {fecha_actual}, se reúnen en el predio de la obra '{nombre_obra}', ubicada en {row['direccion'] if row else ''}, el COMITENTE ({comitente}) y LA DIRECCIÓN TÉCNICA (VALEN ARQ).
1. Se procede a la inspección ocular integral de los trabajos ejecutados.
2. Estado general y reservas: {observaciones}.
3. Conforme los artículos 1270 y 1271 del CCyCN, la presente recepción {tipo.lower()} {'habilita el plazo de 90 días para verificación de vicios ocultos y pruebas de instalaciones' if tipo.lower() == 'provisoria' else 'otorga la conformidad final y habilita la devolución íntegra del Fondo de Reparo'}.
Firman al pie en conformidad las partes intervinientes.
"""

tools_legal_list = [redactar_contrato_locacion_obra, auditar_personal_ieric, generar_acta_recepcion_obra]
