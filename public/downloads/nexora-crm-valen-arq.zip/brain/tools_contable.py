# -*- coding: utf-8 -*-
"""
Módulo de Herramientas Contables, Liquidación UOCRA y Costos CAC para VALEN
"""
import sqlite3
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "valen_arq.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

def actualizar_presupuesto_cac(monto_base: float, indice_materiales_var: float, indice_mo_var: float, indice_gg_var: float = 0.0) -> str:
    """
    Calcula la redeterminación de precios aplicando la fórmula polinómica estándar de la Cámara Argentina de la Construcción (CAC).
    P_act = P_base * (0.50*VarMat + 0.40*VarMO + 0.10*VarGG)
    """
    coef_mat = 0.50
    coef_mo = 0.40
    coef_gg = 0.10
    
    factor_ajuste = (coef_mat * (1 + indice_materiales_var/100)) + (coef_mo * (1 + indice_mo_var/100)) + (coef_gg * (1 + indice_gg_var/100))
    monto_redeterminado = monto_base * factor_ajuste
    diferencia = monto_redeterminado - monto_base
    
    return f"""
📊 [REDETERMINACIÓN DE PRECIOS - ÍNDICE CAC / VALEN CONTABLE]
- Monto Base Original: ${monto_base:,.2f}
- Variación Ponderada: Materiales ({indice_materiales_var}%), Mano de Obra ({indice_mo_var}%), Gastos Generales ({indice_gg_var}%)
- Factor Polinómico de Ajuste: {factor_ajuste:.4f}
- Nuevo Monto Actualizado: ${monto_redeterminado:,.2f}
- Variación Neta a Facturar: +${diferencia:,.2f} (+{(factor_ajuste-1)*100:.2f}%)
"""

def liquidar_fondo_cese_laboral(empleado_id: int, meses_antiguedad: int, sueldo_bruto_mensual: float) -> str:
    """
    Liquida el Fondo de Cese Laboral (Ley 22.250) para el personal de la construcción.
    12% durante el primer año (meses 1 a 12) y 8% a partir del segundo año (>12 meses).
    """
    if meses_antiguedad <= 12:
        alicuota = 0.12
        periodo_desc = "Primer Año (12%)"
    else:
        alicuota = 0.08
        periodo_desc = "Segundo Año en adelante (8%)"
        
    deposito_mensual = sueldo_bruto_mensual * alicuota
    total_acumulado_estimado = (min(meses_antiguedad, 12) * (sueldo_bruto_mensual * 0.12)) + (max(0, meses_antiguedad - 12) * (sueldo_bruto_mensual * 0.08))
    
    return f"""
💼 [LIQUIDACIÓN FONDO DE CESE LABORAL - LEY 22.250 UOCRA]
- Operario ID: {empleado_id} | Antigüedad: {meses_antiguedad} meses
- Tramo Aplicable: {periodo_desc}
- Aporte Mensual a Depositar en Libreta IERIC: ${deposito_mensual:,.2f}
- Saldo Acumulado Estimado para Entrega al Cese: ${total_acumulado_estimado:,.2f}
- Nota CPN: Este fondo es inembargable y reemplaza preaviso e indemnización del art. 245 LCT.
"""

def balance_centro_costo_obra(obra_id: int) -> str:
    """Calcula el balance financiero en tiempo real de una obra (Ingresos certificados vs Egresos de materiales y mano de obra)."""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT nombre, monto_contractual, avance_fisico_porcentaje FROM Obras WHERE id = ?", (obra_id,))
    obra = c.fetchone()
    if not obra:
        conn.close()
        return f"Error: No existe la obra {obra_id}."
        
    c.execute("SELECT SUM(monto) as total_ingresos FROM Contabilidad_Obra WHERE obra_id = ? AND tipo_movimiento LIKE 'Ingreso%'", (obra_id,))
    ingresos = c.fetchone()["total_ingresos"] or 0.0
    
    c.execute("SELECT SUM(monto) as total_egresos FROM Contabilidad_Obra WHERE obra_id = ? AND tipo_movimiento LIKE 'Egreso%'", (obra_id,))
    egresos = c.fetchone()["total_egresos"] or 0.0
    
    saldo_obra = ingresos - egresos
    conn.close()
    
    return f"""
💰 [ESTADO FINANCIERO Y CENTRO DE COSTOS - VALEN CPN]
🏗️ Obra: {obra['nombre']} (ID: {obra_id})
📈 Avance de Obra: {obra['avance_fisico_porcentaje']}% | Contrato Total: ${obra['monto_contractual']:,.2f}
🟢 Total Cobrado / Certificado: ${ingresos:,.2f}
🔴 Total Gastos Imputados (Materiales + MO): ${egresos:,.2f}
⚖️ Margen Operativo / Caja de Obra: ${saldo_obra:,.2f}
"""

tools_contable_list = [actualizar_presupuesto_cac, liquidar_fondo_cese_laboral, balance_centro_costo_obra]
