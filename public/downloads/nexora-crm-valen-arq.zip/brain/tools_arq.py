# -*- coding: utf-8 -*-
"""
Módulo de Herramientas de Arquitectura, Patologías Forenses y Dirección de Obra para VALEN ARQ
Firma de Autor: MyJNexoraVisual
"""
import sqlite3
import json
from pathlib import Path
from datetime import datetime
from vision_engine import analyze_structural_image

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "valen_arq.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

def diagnosticar_patologia(falla_tipo: str, ubicacion_obra: str, obra_id: int = 1, observaciones_campo: str = "", image_path: str = "") -> str:
    """
    Analiza la imagen real y emite el dictamen forense y cómputo de remediación oficial.
    """
    analisis = analyze_structural_image(image_path, observaciones_campo or falla_tipo, ubicacion_obra)
    
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        INSERT INTO Patologias_Inspeccion (obra_id, ubicacion_en_obra, tipo_falla, nivel_riesgo, diagnostico_preliminar, comunicado_cliente, protocolo_exhaustivo, remediacion_propuesta, presupuesto_estimado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        obra_id, 
        ubicacion_obra, 
        analisis["tipo_falla"], 
        analisis["nivel_riesgo"], 
        analisis["causa_raiz"], 
        analisis["mensaje_cliente"], 
        analisis["protocolo"], 
        analisis["remediacion"],
        analisis["presupuesto"]
    ))
    conn.commit()
    pat_id = c.lastrowid
    conn.close()

    if analisis["tipo_falla"] == "Operador / Persona en Encuadre":
        return f"""
🔬 [ANÁLISIS PERCEPTUAL DE ENCUADRE - VALEN ARQ #PAT-{pat_id}]
📍 Ubicación: {ubicacion_obra}
👁️ Diagnóstico de Cámara: {analisis['tipo_falla']}
ℹ️ Estado: {analisis['descripcion_visual']}

{analisis['mensaje_cliente']}

📋 Indicación de Campo:
{analisis['protocolo']}

🏛️ VALEN ARQ — Sello Profesional por MyJNexoraVisual
"""

    reporte = f"""
🔬 [DICTAMEN PERICIAL DE PATOLOGÍA EDILICIA - VALEN ARQ #PAT-{pat_id}]
📍 Ubicación GPS / Obra: {ubicacion_obra}
⚠️ Patología Detectada: {analisis['tipo_falla']}
🚨 Nivel de Riesgo Estructural: {analisis['nivel_riesgo']}
👁️ Inspección Visual: {analisis['descripcion_visual']}

1. DIAGNÓSTICO FORENSE (Causa Raíz Mecánica/Física):
{analisis['causa_raiz']}

2. ESTATUS RÁPIDO PARA EL COMITENTE / CLIENTE:
"{analisis['mensaje_cliente']}"

3. PROTOCOLO DE VERIFICACIÓN EXHAUSTIVA OBLIGATORIO:
{analisis['protocolo']}

4. TAREAS DE REMEDIACIÓN Y PRESUPUESTO PRELIMINAR (INTI / CAC):
- Partidas a ejecutar: {analisis['remediacion']}
- Presupuesto de remediación estimado: ${analisis['presupuesto']:,.2f}

🏛️ VALEN ARQ — Sello Profesional por MyJNexoraVisual
"""
    return reporte

def calcular_computo_metrico(rubro: str, dimension_1: float, dimension_2: float, dimension_3: float = 1.0) -> str:
    rubro_lower = rubro.lower()
    
    if "hormigon" in rubro_lower or "losa" in rubro_lower or "columna" in rubro_lower:
        volumen_m3 = dimension_1 * dimension_2 * dimension_3
        cemento_bolsas = (volumen_m3 * 350) / 50
        arena_m3 = volumen_m3 * 0.65
        piedra_m3 = volumen_m3 * 0.65
        hierro_kg = volumen_m3 * 90
        return f"""
📐 [CÓMPUTO MÉTRICO HORMIGÓN H-21 - VALEN ARQ]
- Volumen Total: {volumen_m3:.2f} m³
- Cemento Portland: {cemento_bolsas:.1f} bolsas de 50kg [{cemento_bolsas*50:.0f} kg]
- Arena Gruesa Lavada: {arena_m3:.2f} m³
- Canto Rodado / Piedra Partida 6-20: {piedra_m3:.2f} m³
- Hierro Conformado ADN 420 (Estimado 90kg/m³): {hierro_kg:.1f} kg
"""
    elif "mamposteria" in rubro_lower or "pared" in rubro_lower or "muro" in rubro_lower:
        sup_m2 = dimension_1 * dimension_2
        ladrillos_huecos = sup_m2 * 16
        cemento_kg = sup_m2 * 2.5
        cal_kg = sup_m2 * 5.0
        arena_m3 = sup_m2 * 0.02
        return f"""
📐 [CÓMPUTO MÉTRICO MAMPOSTERÍA HUECO 12x18x33 - VALEN ARQ]
- Superficie Neta de Muro: {sup_m2:.2f} m²
- Ladrillos Huecos 12x18x33: {ladrillos_huecos:.0f} un (+5% desperdicio: {ladrillos_huecos*1.05:.0f} un)
- Cemento: {cemento_kg:.1f} kg ({(cemento_kg/50):.1f} bolsas)
- Cal Aérea Hidratada: {cal_kg:.1f} kg ({(cal_kg/25):.1f} bolsas de 25kg)
- Arena Mediana: {arena_m3:.2f} m³
"""
    else:
        sup_m2 = dimension_1 * dimension_2
        cemento_kg = sup_m2 * 4.5
        ceresita_kg = sup_m2 * 0.45
        arena_m3 = sup_m2 * 0.012
        return f"""
📐 [CÓMPUTO AISLACIÓN HIDRÓFUGA 1:3 + CERESITA 10% - VALEN ARQ]
- Superficie a Tratar: {sup_m2:.2f} m²
- Cemento Portland: {cemento_kg:.1f} kg
- Pasta Hidrófuga Ceresita / Sika 1: {ceresita_kg:.2f} kg
- Arena Fina Zarandeada: {arena_m3:.3f} m³
"""

def certificar_avance_obra(obra_id: int, porcentaje_mes: float, periodo: str) -> str:
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, nombre, monto_contractual, avance_fisico_porcentaje FROM Obras WHERE id = ?", (obra_id,))
    obra = c.fetchone()
    if not obra:
        conn.close()
        return f"Error: No existe la obra {obra_id}."
        
    monto_contrato = obra["monto_contractual"]
    avance_anterior = obra["avance_fisico_porcentaje"]
    nuevo_acumulado = min(100.0, avance_anterior + porcentaje_mes)
    
    monto_bruto_mes = monto_contrato * (porcentaje_mes / 100.0)
    fondo_reparo = monto_bruto_mes * 0.05
    neto_a_cobrar = monto_bruto_mes - fondo_reparo
    
    c.execute("SELECT COUNT(*) as total FROM Certificaciones WHERE obra_id = ?", (obra_id,))
    num_cert = (c.fetchone()["total"] or 0) + 1
    
    c.execute("""
        INSERT INTO Certificaciones (obra_id, numero_certificado, periodo, porcentaje_mes, porcentaje_acumulado, monto_bruto, fondo_reparo_retenido, monto_neto_a_cobrar)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (obra_id, num_cert, periodo, porcentaje_mes, nuevo_acumulado, monto_bruto_mes, fondo_reparo, neto_a_cobrar))
    c.execute("UPDATE Obras SET avance_fisico_porcentaje = ? WHERE id = ?", (nuevo_acumulado, obra_id))
    conn.commit()
    conn.close()
    
    return f"""
📑 [CERTIFICADO OFICIAL DE OBRA N° {num_cert} - VALEN ARQ]
🏢 Obra: {obra['nombre']} (ID: {obra_id})
📅 Período: {periodo}
📈 Avance Físico del Mes: {porcentaje_mes:.2f}% | Acumulado: {nuevo_acumulado:.2f}%
💰 Monto Bruto Certificado: ${monto_bruto_mes:,.2f}
🛡️ Fondo de Reparo Retenido (5% CCyCN Art. 1270): -${fondo_reparo:,.2f}
💵 Total Neto Liquidado a Cobrar: ${neto_a_cobrar:,.2f}

🏛️ VALEN ARQ — Sello Profesional por MyJNexoraVisual
"""

def asentar_libro_ordenes(obra_id: int, tipo_asiento: str, texto_asiento: str) -> str:
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) as total FROM Libro_Ordenes WHERE obra_id = ?", (obra_id,))
    num_asiento = (c.fetchone()["total"] or 0) + 1
    
    c.execute("""
        INSERT INTO Libro_Ordenes (obra_id, numero_asiento, tipo_asiento, autor_rol, contenido)
        VALUES (?, ?, ?, 'Director de Obra (VALEN)', ?)
    """, (obra_id, num_asiento, tipo_asiento, texto_asiento))
    conn.commit()
    conn.close()
    return f"📖 Asiento N° {num_asiento} registrado en el Libro de Órdenes de la Obra {obra_id} bajo tipo '{tipo_asiento}' (Firma Digital por MyJNexoraVisual)."
