# -*- coding: utf-8 -*-
"""
VALEN CORE v3.0 - Motor Autónomo Humano de Inteligencia Artificial para Arquitectura, Obras y Construcción
Firma de Autor: MyJNexoraVisual
"""
import os
import json
import sqlite3
from pathlib import Path
from tools_arq import diagnosticar_patologia, calcular_computo_metrico, certificar_avance_obra, asentar_libro_ordenes
from tools_legal import redactar_contrato_locacion_obra, auditar_personal_ieric, generar_acta_recepcion_obra
from tools_contable import actualizar_presupuesto_cac, liquidar_fondo_cese_laboral, balance_centro_costo_obra

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "valen_arq.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

def run_valen(user_text: str, rol: str = "gerencia", gps_ubicacion: str = "Obra Local") -> str:
    """
    Motor Conversacional Humano y Fluido de VALEN ARQ.
    Responde con cercanía, solvencia técnica, precisión jurídica y sin clichés robóticos.
    """
    user_lower = user_text.lower()
    
    # Detección y ejecución de herramientas técnicas
    if any(k in user_lower for k in ["patologia", "fisura", "grieta", "humedad", "falla", "revoque"]):
        reporte = diagnosticar_patologia(user_text, gps_ubicacion, obra_id=1, observaciones_campo=user_text)
        return f"""Hola colega. Estuve analizando detalladamente lo que me indicas respecto a la falla observada en {gps_ubicacion}.

Te transmito mi dictamen técnico preliminar para que puedas actuar rápido y darle tranquilidad al cliente antes del cateo:

{reporte}

🏛️ VALEN ARQ — Sello Profesional por MyJNexoraVisual"""

    elif any(k in user_lower for k in ["computo", "cómputo", "losa", "hormigon", "mamposteria", "materiales"]):
        res = calcular_computo_metrico(user_text, 10.0, 5.0, 0.15)
        return f"""Claro que sí, revisemos los números de acopio para esta partida. Conforme a las tablas de dosaje del INTI y considerando un 5% de merma estándar en obra:

{res}

Con estas cantidades estamos cubiertos para la etapa sin sobredimensionar acopio en pañol. ¿Querés que emita la orden de compra o el remito?

🏛️ VALEN ARQ — Dirección Técnica por MyJNexoraVisual"""

    elif any(k in user_lower for k in ["contrato", "locacion", "ccycn"]):
        contrato = redactar_contrato_locacion_obra(1, 485000000.0, 18)
        return f"""Excelente decisión de resguardo jurídico. Preparé el modelo contractual bajo los arts. 1251 a 1279 del Código Civil y Comercial, blindando la responsabilidad decenal y la cláusula de ajuste por índice CAC:

{contrato}

🏛️ VALEN ARQ — Asesoría Legal por MyJNexoraVisual"""

    elif any(k in user_lower for k in ["cac", "redetermin", "inflacion", "ajuste"]):
        res = actualizar_presupuesto_cac(10000000.0, 8.5, 6.2, 5.0)
        return f"""Hice el cálculo de redeterminación de precios aplicando la fórmula polinómica estándar de la Cámara Argentina de la Construcción:

{res}

Ya podemos presentarle este anexo actualizado al comitente para su aprobación.

🏛️ VALEN ARQ — CPN & Finanzas por MyJNexoraVisual"""

    elif any(k in user_lower for k in ["fondo de cese", "ieric", "uocra", "libreta"]):
        res = liquidar_fondo_cese_laboral(1, 14, 850000.0)
        return f"""Revisé la liquidación del Fondo de Cese Laboral según la Ley 22.250 para el personal de obra:

{res}

Todo en regla para evitar cualquier tipo de contingencia en inspecciones de policía de trabajo.

🏛️ VALEN ARQ — Marco Laboral UOCRA por MyJNexoraVisual"""

    else:
        return f"""Comprendido, colega. Analicé lo que planteas sobre "{user_text}". 

Desde la dirección técnica y legal, te confirmo que tenemos el proyecto alineado a las normativas vigentes del CCyCN y los convenios de la UOCRA. ¿Te parece que carguemos una nueva orden en el Libro de Obra, emitamos un certificado de avance o revisemos el acopio de materiales?

🏛️ VALEN ARQ — Dirección Soberana por MyJNexoraVisual"""
