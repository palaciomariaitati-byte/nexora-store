# -*- coding: utf-8 -*-
"""
Motor Generador de Documentos Oficiales en Word (.docx) y PDF (.pdf) - VALEN ARQ
Firma de Autor: MyJNexoraVisual
"""
import io
import os
import sqlite3
from datetime import datetime
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "database" / "valen_arq.db"
STORAGE_DIR = BASE_DIR / "storage" / "documentos"
STORAGE_DIR.mkdir(parents=True, exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

# A. GENERAR CONTRATO DE LOCACIÓN DE OBRA EN WORD (.docx)
def generar_contrato_word(obra_id: int) -> str:
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        SELECT o.*, c.razon_social as cliente_razon_social, c.cuit as cliente_cuit
        FROM Obras o
        LEFT JOIN Clientes c ON o.cliente_id = c.id
        WHERE o.id = ?
    """, (obra_id,))
    obra = c.fetchone()
    conn.close()

    if not obra:
        return ""

    cliente_nombre = obra["cliente_razon_social"] or "Fideicomiso Comitente"
    cuit_texto = f" (CUIT: {obra['cliente_cuit']})" if obra["cliente_cuit"] else ""

    doc = Document()
    
    # Estilos
    header = doc.sections[0].header
    hp = header.paragraphs[0]
    hp.text = "🏛️ VALEN ARQ — Dirección Legal & Técnica | Sello MyJNexoraVisual"
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    # Título Principal
    p_title = doc.add_paragraph()
    run_title = p_title.add_run("CONTRATO DE LOCACIÓN DE OBRA MATERIAL")
    run_title.bold = True
    run_title.font.size = Pt(16)
    run_title.font.color.rgb = RGBColor(15, 23, 42)
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    p_sub = doc.add_paragraph()
    p_sub.add_run(f"Marco Regulatorio: Arts. 1251 a 1279 del Código Civil y Comercial de la Nación Argentina\nObra: {obra['nombre']} | Expediente N°: EXP-2026-VALEN-{obra_id}")
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph()

    # Partes
    doc.add_heading("1. PARTES INTERVINIENTES", level=2)
    p_partes = doc.add_paragraph()
    p_partes.add_run(f"Entre el COMITENTE ({cliente_nombre}{cuit_texto}), con domicilio legal en {obra['direccion']}, por una parte; y la DIRECCIÓN EJECUTIVA & CONSTRUCTORA representada por VALEN ARQ bajo firma institucional MyJNexoraVisual, se conviene en celebrar el presente Contrato de Locación de Obra sujeto a las siguientes cláusulas:\n")

    # Cláusulas
    doc.add_heading("2. OBJETO Y SUPERFICIE", level=2)
    doc.add_paragraph(f"El Contratista se obliga a ejecutar la totalidad de los trabajos de construcción civil correspondientes a la obra '{obra['nombre']}', ubicada en {obra['direccion']}, con una superficie cubierta computable de {obra['superficie_m2']} m², conforme a planos aprobados y pliegos de especificaciones técnicas del INTI / CIRSOC.")

    doc.add_heading("3. PRECIO CONTRACTUAL Y FORMA DE PAGO", level=2)
    doc.add_paragraph(f"El precio total convenido asciende a la suma de PESOS ${obra['monto_contractual']:,.2f}, el cual se cancelará mediante certificaciones mensuales de avance físico conforme al plan de trabajos.")

    doc.add_heading("4. CLÁUSULA DE REDETERMINACIÓN DE PRECIOS (CAC)", level=2)
    doc.add_paragraph("Los precios contractuales serán redeterminados mensualmente aplicando la fórmula polinómica oficial basada en los índices de la Cámara Argentina de la Construcción (CAC - Costo de Construcción Edificio Tipo), garantizando el equilibrio económico-financiero de la obra frente a la inflación.")

    doc.add_heading("5. RESPONSABILIDAD DECENAL Y FONDO DE REPARO (CCyCN)", level=2)
    doc.add_paragraph("De cada certificado mensual de obra se retendrá el cinco por ciento (5%) en concepto de Fondo de Reparo (Art. 1270 CCyCN). Asimismo, rige la responsabilidad decenal por ruina total o parcial de obra consagrada en los Arts. 1273 a 1275 del Código Civil y Comercial de la Nación.")

    # Firmas
    doc.add_paragraph("\n\n\n")
    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cells = table.rows[0].cells
    cells[0].paragraphs[0].text = f"___________________________\nCOMITENTE: {cliente_nombre}\nFirma y Aclaración"
    cells[1].paragraphs[0].text = "___________________________\nDIRECCIÓN DE OBRA VALEN ARQ\nMyJNexoraVisual Oficial"

    clean_name = obra['nombre'].replace(' ', '_').replace('/', '_')
    filename = f"Contrato_Locacion_{clean_name}_{datetime.now().strftime('%Y%m%d')}.docx"
    filepath = STORAGE_DIR / filename
    doc.save(filepath)
    return str(filepath)

# B. GENERAR CERTIFICADO OFICIAL DE OBRA EN PDF (.pdf)
def generar_certificado_pdf(cert_id: int) -> str:
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        SELECT c.*, o.nombre as obra_nombre, o.direccion as obra_direccion, o.monto_contractual,
               cl.razon_social as cliente_razon_social
        FROM Certificaciones c
        JOIN Obras o ON c.obra_id = o.id
        LEFT JOIN Clientes cl ON o.cliente_id = cl.id
        WHERE c.id = ?
    """, (cert_id,))
    cert = c.fetchone()
    conn.close()

    if not cert:
        return ""

    clean_name = cert['obra_nombre'].replace(' ', '_').replace('/', '_')
    filename = f"Certificado_Obra_N{cert['numero_certificado']}_{clean_name}.pdf"
    filepath = STORAGE_DIR / filename

    doc = SimpleDocTemplate(str(filepath), pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('DocTitle', parent=styles['Heading1'], fontSize=16, textColor=colors.HexColor('#0f172a'), alignment=1, spaceAfter=6)
    sub_style = ParagraphStyle('DocSub', parent=styles['Normal'], fontSize=9, textColor=colors.HexColor('#0284c7'), alignment=1, spaceAfter=14)

    elements.append(Paragraph("🏛️ CERTIFICADO OFICIAL DE AVANCE DE OBRA", title_style))
    elements.append(Paragraph("VALEN ARQ — Sistema Soberano de Gestión RPM por MyJNexoraVisual", sub_style))
    elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#0284c7'), spaceAfter=15))

    # Datos Generales
    datos_obra = [
        [Paragraph("<b>Obra:</b>", styles['Normal']), Paragraph(cert['obra_nombre'], styles['Normal']), Paragraph("<b>Certificado N°:</b>", styles['Normal']), Paragraph(str(cert['numero_certificado']), styles['Normal'])],
        [Paragraph("<b>Ubicación:</b>", styles['Normal']), Paragraph(cert['obra_direccion'], styles['Normal']), Paragraph("<b>Período:</b>", styles['Normal']), Paragraph(cert['periodo'], styles['Normal'])],
        [Paragraph("<b>Comitente:</b>", styles['Normal']), Paragraph(cert['cliente_razon_social'] or 'Fideicomiso', styles['Normal']), Paragraph("<b>Fecha de Emisión:</b>", styles['Normal']), Paragraph(cert['fecha_emision'], styles['Normal'])],
    ]
    t_datos = Table(datos_obra, colWidths=[80, 200, 100, 140])
    t_datos.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f8fafc')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('PADDING', (0,0), (-1,-1), 5),
    ]))
    elements.append(t_datos)
    elements.append(Spacer(1, 15))

    # Liquidación Financiera
    elements.append(Paragraph("<b>DESGLOSE DE LIQUIDACIÓN Y FONDO DE REPARO (CCyCN Art. 1270)</b>", styles['Heading3']))
    
    tabla_finanzas = [
        ["Concepto", "Porcentaje (%)", "Importe ($ ARS)"],
        ["Monto Contractual Total", "100.00%", f"${cert['monto_contractual']:,.2f}"],
        ["Avance Físico del Período Certificado", f"{cert['porcentaje_mes']:.2f}%", f"${cert['monto_bruto']:,.2f}"],
        ["Avance Físico Acumulado a la Fecha", f"{cert['porcentaje_acumulado']:.2f}%", "-"],
        ["Fondo de Reparo Retenido (Garantía 5%)", "-5.00%", f"-${cert['fondo_reparo_retenido']:,.2f}"],
        ["TOTAL LÍQUIDO A PERCIBIR POR EL CONTRATISTA", "-", f"${cert['monto_neto_a_cobrar']:,.2f}"]
    ]
    t_fin = Table(tabla_finanzas, colWidths=[240, 120, 160])
    t_fin.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#0f172a')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('BACKGROUND', (0,-1), (-1,-1), colors.HexColor('#dcfce7')),
        ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
        ('TEXTCOLOR', (0,-1), (-1,-1), colors.HexColor('#15803d')),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    elements.append(t_fin)
    elements.append(Spacer(1, 35))

    # Firmas
    firmas = [
        ["__________________________________", "__________________________________"],
        ["DIRECCIÓN TÉCNICA DE OBRA", "COMITENTE / CONTRALOR FINANCIERO"],
        ["VALEN ARQ (MyJNexoraVisual)", cert['cliente_razon_social'] or 'Fideicomiso']
    ]
    t_firmas = Table(firmas, colWidths=[260, 260])
    t_firmas.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('TEXTCOLOR', (0,0), (-1,-1), colors.HexColor('#475569')),
    ]))
    elements.append(t_firmas)

    doc.build(elements)
    return str(filepath)

# C. GENERAR BALANCE Y CIERRE CONTABLE MENSUAL PARA EL CONTADOR EN PDF
def generar_cierre_contable_pdf(mes: str = "03", anio: str = "2026") -> str:
    cierre_key = f"{mes}/{anio}"
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Asientos_Contables WHERE cierre_mes = ? ORDER BY numero_asiento ASC", (cierre_key,))
    asientos = c.fetchall()
    
    c.execute("SELECT SUM(monto) as total_cobros FROM Transacciones_Financieras WHERE tipo='Cobro' AND fecha LIKE ?", (f"{anio}-{mes}%",))
    res_cobros = c.fetchone()
    total_cobros = res_cobros["total_cobros"] if res_cobros and res_cobros["total_cobros"] else 0.0
    
    c.execute("SELECT SUM(monto) as total_pagos FROM Transacciones_Financieras WHERE tipo='Pago' AND fecha LIKE ?", (f"{anio}-{mes}%",))
    res_pagos = c.fetchone()
    total_pagos = res_pagos["total_pagos"] if res_pagos and res_pagos["total_pagos"] else 0.0
    conn.close()

    filename = f"Cierre_Contable_Mensual_{mes}_{anio}_VALEN_ARQ.pdf"
    filepath = STORAGE_DIR / filename

    doc = SimpleDocTemplate(str(filepath), pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    elements = []
    styles = getSampleStyleSheet()

    elements.append(Paragraph(f"📊 BALANCE & CIERRE CONTABLE MENSUAL — PERÍODO {cierre_key}", ParagraphStyle('Title', parent=styles['Heading1'], fontSize=15, alignment=1)))
    elements.append(Paragraph("Informe Oficial para Estudio Contable / Auditoría Impositiva (AFIP / ARBA) — MyJNexoraVisual", ParagraphStyle('Sub', parent=styles['Normal'], fontSize=8, alignment=1, textColor=colors.HexColor('#64748b'))))
    elements.append(Spacer(1, 10))

    # Resumen Ejecutivo
    resumen = [
        ["Total Ingresos / Cobranzas de Obra", f"${total_cobros:,.2f}"],
        ["Total Egresos / Pagos a Proveedores y UOCRA", f"${total_pagos:,.2f}"],
        ["Flujo Neto Operativo del Mes", f"${(total_cobros - total_pagos):,.2f}"]
    ]
    t_res = Table(resumen, colWidths=[320, 200])
    t_res.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f1f5f9')),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    elements.append(t_res)
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("<b>LIBRO DIARIO DE ASIENTOS REGISTRADOS EN EL PERÍODO</b>", styles['Heading3']))
    
    tabla_asientos = [["N°", "Fecha", "Cuenta Debe", "Cuenta Haber", "Monto ($)", "Concepto"]]
    total_debe = 0.0
    for a in asientos:
        tabla_asientos.append([
            str(a["numero_asiento"]),
            a["fecha"],
            a["cuenta_debe"],
            a["cuenta_haber"],
            f"${a['monto']:,.2f}",
            a["concepto"][:35]
        ])
        total_debe += a["monto"]

    tabla_asientos.append(["-", "TOTAL", "BALANCE CUADRADO", "SUMAS IGUALES", f"${total_debe:,.2f}", "Cierre Balanceado"])

    t_as = Table(tabla_asientos, colWidths=[25, 60, 125, 125, 85, 100])
    t_as.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#0f172a')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('FONTSIZE', (0,0), (-1,-1), 7.5),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
        ('BACKGROUND', (0,-1), (-1,-1), colors.HexColor('#dcfce7')),
        ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
        ('PADDING', (0,0), (-1,-1), 4),
    ]))
    elements.append(t_as)

    doc.build(elements)
    return str(filepath)
