# -*- coding: utf-8 -*-
import os
import sys
import socket
import sqlite3
import qrcode
import io
import base64
from pathlib import Path
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from typing import Optional, List
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.append(str(BASE_DIR / "brain"))

import valen_core
from tools_arq import diagnosticar_patologia, calcular_computo_metrico, certificar_avance_obra, asentar_libro_ordenes
from tools_legal import redactar_contrato_locacion_obra, auditar_personal_ieric, generar_acta_recepcion_obra
from tools_contable import actualizar_presupuesto_cac, liquidar_fondo_cese_laboral, balance_centro_costo_obra
from document_generator import generar_contrato_word, generar_certificado_pdf, generar_cierre_contable_pdf

app = FastAPI(title="CRM VALEN ARQ - Sistema Soberano de Arquitectura y Construcción")

DB_PATH = BASE_DIR / "database" / "valen_arq.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

def get_local_ip():
    """Detecta la IP local de la PC para acceso desde el celular en la misma red Wi-Fi."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

# Montar estáticos
FRONTEND_PATH = BASE_DIR / "frontend"
STORAGE_PATH = BASE_DIR / "storage"
STORAGE_PATH.mkdir(exist_ok=True)

app.mount("/static", StaticFiles(directory=str(FRONTEND_PATH)), name="static")
app.mount("/storage", StaticFiles(directory=str(STORAGE_PATH)), name="storage")

@app.get("/", response_class=HTMLResponse)
async def serve_home():
    index_file = FRONTEND_PATH / "index.html"
    if index_file.exists():
        return index_file.read_text(encoding="utf-8")
    return "<h1>CRM VALEN ARQ Online</h1>"

@app.get("/manifest.json")
async def get_manifest():
    return FileResponse(FRONTEND_PATH / "manifest.json", media_type="application/manifest+json")

@app.get("/sw.js")
async def get_sw():
    return FileResponse(FRONTEND_PATH / "sw.js", media_type="application/javascript")

def get_public_or_local_url():
    """Detecta si hay un tunel Cloudflare activo para conexion 4G/5G; de lo contrario usa la IP local."""
    tunnel_log = BASE_DIR / "tunnel.log"
    if tunnel_log.exists():
        try:
            with open(tunnel_log, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                import re
                matches = re.findall(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", content)
                if matches:
                    return matches[-1], "4G/5G Remoto (Cloudflare HTTPS)"
        except Exception:
            pass
            
    local_ip = get_local_ip()
    return f"http://{local_ip}:8000", "Red Local Wi-Fi"

@app.get("/api/qr_acceso")
async def get_qr_acceso():
    """Genera codigo QR dinamico con la mejor URL disponible (4G Remoto o Wi-Fi Local)."""
    target_url, tipo_conexion = get_public_or_local_url()
    
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=8,
        border=2,
    )
    qr.add_data(target_url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0d1117", back_color="#ffffff")
    
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    qr_b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    
    return {
        "status": "success",
        "url": target_url,
        "tipo_conexion": tipo_conexion,
        "qr_image_base64": f"data:image/png;base64,{qr_b64}"
    }

class ChatRequest(BaseModel):
    mensaje: str
    rol: str = "gerencia"
    usuario: str = "Director de Obra"

@app.post("/api/chat")
async def chat_valen(data: ChatRequest):
    try:
        respuesta = valen_core.run_valen(data.mensaje, rol=data.rol)
        conn = get_db()
        c = conn.cursor()
        c.execute("INSERT INTO Historial_Valen (usuario, rol, mensaje, respuesta) VALUES (?, ?, ?, ?)",
                  (data.usuario, data.rol, data.mensaje, respuesta))
        conn.commit()
        conn.close()
        return {"status": "success", "respuesta": respuesta}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/obras")
async def get_obras():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        SELECT o.*, c.razon_social as cliente_nombre 
        FROM Obras o 
        LEFT JOIN Clientes c ON o.cliente_id = c.id
        ORDER BY o.id DESC
    """)
    obras = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": obras}

@app.post("/api/patologias/analizar")
async def analizar_patologia(
    descripcion: str = Form(...),
    ubicacion: str = Form("Obra en Zona de Inspección"),
    obra_id: int = Form(1),
    imagen: UploadFile = File(None)
):
    foto_path_str = ""
    foto_nombre = "sin_foto.jpg"
    
    # 1. Guardado de foto local tolerante a fallos
    if imagen and imagen.filename:
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_filename = Path(imagen.filename).name.replace(" ", "_")
            foto_nombre = f"pat_{timestamp}_{safe_filename}"
            foto_path = STORAGE_PATH / "patologias" / foto_nombre
            foto_path.parent.mkdir(parents=True, exist_ok=True)
            contenido_bytes = await imagen.read()
            with open(foto_path, "wb") as f:
                f.write(contenido_bytes)
            foto_path_str = str(foto_path)
        except Exception as e_foto:
            print(f"[AVISO FOTO LOCAL] Error al persistir archivo: {e_foto}")

    # 2. Diagnóstico con tolerancia total a fallos de IA / Conexión
    try:
        resultado = diagnosticar_patologia(
            falla_tipo=descripcion,
            ubicacion_obra=ubicacion,
            obra_id=obra_id,
            observaciones_campo=descripcion,
            image_path=foto_path_str
        )
        return {"status": "success", "diagnostico": resultado, "foto_url": f"/storage/patologias/{foto_nombre}"}
    except Exception as e_diag:
        # Fallback soberano offline: Registrar inspección localmente en BD sin romper la UI (sin 500)
        try:
            conn = get_db()
            c = conn.cursor()
            c.execute("""
                INSERT INTO Patologias_Inspeccion (
                    obra_id, ubicacion_en_obra, tipo_falla, nivel_riesgo, 
                    diagnostico_preliminar, comunicado_cliente, protocolo_exhaustivo, 
                    remediacion_propuesta, presupuesto_estimado
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                obra_id,
                ubicacion,
                "Inspección Registrada (Modo Soberano Offline)",
                "A Evaluar en Campo",
                descripcion,
                "Se ha registrado la fotografía e inspección localmente de manera segura.",
                "1. Verificación presencial en obra. 2. Seguimiento de evolución.",
                "Saneamiento y evaluación preliminar.",
                0.0
            ))
            conn.commit()
            pat_id = c.lastrowid
            conn.close()
            
            fallback_msg = f"""
🔬 [REGISTRO SOBERANO OFFLINE - VALEN ARQ #PAT-{pat_id}]
📍 Ubicación: {ubicacion}
📷 Foto: Almacenada localmente ({foto_nombre})
📝 Observaciones de Campo: {descripcion}
✅ Guardado correctamente en la base soberana sin conexión externa.
"""
            return {"status": "success", "diagnostico": fallback_msg, "foto_url": f"/storage/patologias/{foto_nombre}"}
        except Exception as e_db:
            return {"status": "error", "message": f"Error al registrar inspección local: {e_db}"}

class ComputoRequest(BaseModel):
    rubro: str
    d1: float
    d2: float
    d3: float = 1.0

@app.post("/api/computos/calcular")
async def calcular_computo(data: ComputoRequest):
    res = calcular_computo_metrico(data.rubro, data.d1, data.d2, data.d3)
    return {"status": "success", "resultado": res}

class CertificacionRequest(BaseModel):
    obra_id: int
    porcentaje_mes: float
    periodo: str

@app.post("/api/certificaciones")
async def crear_certificacion(data: CertificacionRequest):
    res = certificar_avance_obra(data.obra_id, data.porcentaje_mes, data.periodo)
    return {"status": "success", "resultado": res}

@app.get("/api/personal_uocra")
async def get_personal():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Personal_UOCRA ORDER BY id ASC")
    personal = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": personal}

@app.get("/api/libro_ordenes/{obra_id}")
async def get_libro_ordenes(obra_id: int):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Libro_Ordenes WHERE obra_id = ? ORDER BY numero_asiento DESC", (obra_id,))
    asientos = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": asientos}

class AsientoRequest(BaseModel):
    obra_id: int
    tipo_asiento: str
    contenido: str

@app.post("/api/libro_ordenes")
async def post_asiento(data: AsientoRequest):
    res = asentar_libro_ordenes(data.obra_id, data.tipo_asiento, data.contenido)
    return {"status": "success", "resultado": res}


# --- MODELOS Y ENDPOINTS DE CARGA (CRUD CRM-RPM) ---
class ClienteCreate(BaseModel):
    nombre: str
    razon_social: Optional[str] = ""
    cuit: Optional[str] = ""
    email: Optional[str] = ""
    telefono: Optional[str] = ""
    direccion: Optional[str] = ""
    tipo_comitente: Optional[str] = "Fideicomiso"

@app.post("/api/clientes/nuevo")
async def nuevo_cliente(req: ClienteCreate):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        INSERT INTO Clientes (nombre, razon_social, cuit, email, telefono, direccion, tipo_comitente)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (req.nombre, req.razon_social or req.nombre, req.cuit, req.email, req.telefono, req.direccion, req.tipo_comitente))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Cliente registrado exitosamente."}

class ProveedorCreate(BaseModel):
    razon_social: str
    cuit: Optional[str] = ""
    rubro: str
    contacto: Optional[str] = ""
    telefono: Optional[str] = ""

@app.post("/api/proveedores/nuevo")
async def nuevo_proveedor(req: ProveedorCreate):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        INSERT INTO Proveedores (razon_social, cuit, rubro, contacto, telefono)
        VALUES (?, ?, ?, ?, ?)
    """, (req.razon_social, req.cuit, req.rubro, req.contacto, req.telefono))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Proveedor guardado exitosamente."}

class PanolCreate(BaseModel):
    codigo: str
    descripcion: str
    categoria: str
    cantidad: float
    unidad_medida: str
    obra_asignada_id: Optional[int] = None
    estado_herramienta: Optional[str] = "Operativo"

@app.post("/api/panol/nuevo")
async def nuevo_panol(req: PanolCreate):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        INSERT INTO Panol_Stock (codigo, descripcion, categoria, cantidad, unidad_medida, obra_asignada_id, estado_herramienta)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (req.codigo, req.descripcion, req.categoria, req.cantidad, req.unidad_medida, req.obra_asignada_id, req.estado_herramienta))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Ítem incorporado al pañol."}

class TransaccionCreate(BaseModel):
    tipo: str
    obra_id: int
    entidad_tipo: str
    entidad_nombre: str
    monto: float
    concepto: str
    medio_pago: str
    fecha: str

@app.post("/api/finanzas/nuevo")
async def nueva_transaccion(req: TransaccionCreate):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        INSERT INTO Transacciones_Financieras (tipo, obra_id, entidad_tipo, entidad_nombre, monto, concepto, medio_pago, fecha, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Acreditado')
    """, (req.tipo, req.obra_id, req.entidad_tipo, req.entidad_nombre, req.monto, req.concepto, req.medio_pago, req.fecha))
    
    c.execute("SELECT COUNT(*) as total FROM Asientos_Contables")
    num_as = (c.fetchone()["total"] or 0) + 1
    
    c_debe = "1.1.01 Caja y Bancos" if req.tipo == "Cobro" else "5.1.02 Compras y Gastos de Obra"
    c_haber = "4.1.01 Ingresos por Obras" if req.tipo == "Cobro" else "1.1.01 Caja y Bancos"
    
    mes_cierre = req.fecha[:7].replace('-', '/')
    
    c.execute("""
        INSERT INTO Asientos_Contables (numero_asiento, fecha, cuenta_debe, cuenta_haber, monto, concepto, obra_id, cierre_mes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (num_as, req.fecha, c_debe, c_haber, req.monto, req.concepto, req.obra_id, mes_cierre))
    
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Movimiento de tesorería y asiento contable registrados."}

class ObraCreate(BaseModel):
    codigo: str
    nombre: str
    direccion: str
    superficie_m2: float
    monto_contractual: float
    cliente_id: Optional[int] = 1

@app.post("/api/obras/nueva")
async def nueva_obra(req: ObraCreate):
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        INSERT INTO Obras (codigo, nombre, direccion, superficie_m2, monto_contractual, cliente_id, estado, avance_fisico_porcentaje)
        VALUES (?, ?, ?, ?, ?, ?, 'En Ejecución', 0.0)
    """, (req.codigo, req.nombre, req.direccion, req.superficie_m2, req.monto_contractual, req.cliente_id))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Nueva obra dada de alta con éxito."}



# --- ENDPOINTS GET SOBERANOS DESCONECTADOS (CORE CRM-RPM) ---
@app.get("/api/clientes")
async def get_clientes():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Clientes ORDER BY id DESC")
    clientes = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": clientes}

@app.get("/api/proveedores")
async def get_proveedores():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Proveedores ORDER BY id DESC")
    provs = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": provs}

@app.get("/api/panol")
async def get_panol():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        SELECT p.*, o.nombre as obra_nombre
        FROM Panol_Stock p
        LEFT JOIN Obras o ON p.obra_asignada_id = o.id
        ORDER BY p.id DESC
    """)
    items = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": items}

@app.get("/api/finanzas/transacciones")
async def get_transacciones():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        SELECT t.*, o.nombre as obra_nombre
        FROM Transacciones_Financieras t
        LEFT JOIN Obras o ON t.obra_id = o.id
        ORDER BY t.id DESC
    """)
    txs = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": txs}

@app.get("/api/contabilidad/asientos")
async def get_asientos():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM Asientos_Contables ORDER BY numero_asiento DESC")
    asientos = [dict(r) for r in c.fetchall()]
    conn.close()
    return {"status": "success", "data": asientos}

# --- ENDPOINTS DE DESCARGA DE DOCUMENTOS OFICIALES ---
@app.get("/api/descargar/contrato_word/{obra_id}")
async def descargar_contrato_word(obra_id: int):
    try:
        path_docx = generar_contrato_word(obra_id)
        if path_docx and Path(path_docx).exists():
            return FileResponse(
                path_docx,
                media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                filename=Path(path_docx).name
            )
        return JSONResponse(status_code=404, content={"status": "error", "message": "Contrato no encontrado"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})

@app.get("/api/descargar/certificado_pdf/{cert_id}")
async def descargar_certificado_pdf(cert_id: int):
    try:
        path_pdf = generar_certificado_pdf(cert_id)
        if path_pdf and Path(path_pdf).exists():
            return FileResponse(
                path_pdf,
                media_type="application/pdf",
                filename=Path(path_pdf).name
            )
        return JSONResponse(status_code=404, content={"status": "error", "message": "Certificado no encontrado"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})

@app.get("/api/descargar/cierre_contable_pdf/{mes}/{anio}")
async def descargar_cierre_contable_pdf(mes: str, anio: str):
    try:
        path_pdf = generar_cierre_contable_pdf(mes, anio)
        if path_pdf and Path(path_pdf).exists():
            return FileResponse(
                path_pdf,
                media_type="application/pdf",
                filename=Path(path_pdf).name
            )
        return JSONResponse(status_code=404, content={"status": "error", "message": "Cierre contable no encontrado"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


if __name__ == "__main__":
    import uvicorn
    local_ip = get_local_ip()
    print("=================================================================")
    print(f" 🌐 CRM VALEN ARQ EN EJECUCIÓN")
    print(f" 💻 Acceso PC Oficina:  http://127.0.0.1:8000")
    print(f" 📱 Acceso Celular Obra: http://{local_ip}:8000")
    print("=================================================================")
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)


from forensic_dialogue import evaluar_con_feedback_operador

class FeedbackForensicRequest(BaseModel):
    orientacion: str
    espesor: str
    ubicacion: str
    sonido: str
    gps_coords: str = "Zona de Inspección Obra"

@app.post("/api/patologias/feedback_forense")
async def feedback_forense_endpoint(data: FeedbackForensicRequest):
    try:
        resultado = evaluar_con_feedback_operador(
            orientacion=data.orientacion,
            espesor=data.espesor,
            ubicacion=data.ubicacion,
            sonido=data.sonido,
            gps_coords=data.gps_coords
        )
        return resultado
    except Exception as e:
        return {"status": "error", "message": str(e)}