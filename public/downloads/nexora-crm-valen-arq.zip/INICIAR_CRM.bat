@echo off
setlocal enabledelayedexpansion
title CRM VALEN ARQ - Sistema Soberano Nexora (2-Clics)
cls

echo ===============================================================================
echo               SISTEMA SOBERANO CRM VALEN ARQ - NEXORA v3.5
echo      Arquitectura Colegiada ^| CCyCN Locacion de Obra ^| Gestion CAC y UOCRA
echo ===============================================================================
echo.

set "PROJECT_DIR=%~dp0"
cd /d "%PROJECT_DIR%"
set PYTHONIOENCODING=utf-8
set APP_URL=http://127.0.0.1:8000

:: 1. Cierre preventivo de procesos colgados en el puerto 8000
echo [1/4] Verificando y liberando puerto 8000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8000" ^| findstr "LISTENING"') do (
    echo [i] Terminando proceso colgado en puerto 8000 (PID: %%a)...
    taskkill /F /PID %%a >nul 2>&1
)

:: 2. Deteccion de entorno Python / venv
echo [2/4] Configurando entorno de ejecucion Python...
set "PYTHON_EXE="

if exist "%PROJECT_DIR%venv\Scripts\python.exe" (
    set "PYTHON_EXE=%PROJECT_DIR%venv\Scripts\python.exe"
    echo [OK] Entorno virtual detectado: venv
) else if exist "%PROJECT_DIR%.venv\Scripts\python.exe" (
    set "PYTHON_EXE=%PROJECT_DIR%.venv\Scripts\python.exe"
    echo [OK] Entorno virtual detectado: .venv
) else if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    echo [OK] Python 3.12 del sistema detectado
) else (
    set "PYTHON_EXE=python"
    echo [OK] Usando Python predeterminado de PATH
)

:: 3. Lanzador silencioso de navegador en modo aplicacion
echo [3/4] Programando lanzamiento del navegador en modo app...
start "" cmd /c "powershell -Command ^"for ($i=0; $i -lt 30; $i++) { try { $r = Invoke-WebRequest -Uri 'http://127.0.0.1:8000' -UseBasicParsing -TimeoutSec 1; if ($r.StatusCode -eq 200) { break } } catch { Start-Sleep -Milliseconds 500 } }^" & (if exist \"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe\" (start \"\" \"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe\" --app=%APP_URL%) else if exist \"C:\Program Files\Google\Chrome\Application\chrome.exe\" (start \"\" \"C:\Program Files\Google\Chrome\Application\chrome.exe\" --app=%APP_URL%) else (start %APP_URL%))"

:: 4. Arranque del servidor de produccion
echo [4/4] Iniciando nucleo de produccion CRM VALEN ARQ...
echo.
echo ===============================================================================
echo  Acceso Local Directo: %APP_URL%
echo  Presione Ctrl+C en esta consola para detener el servidor de manera segura.
echo ===============================================================================
echo.

"%PYTHON_EXE%" "%PROJECT_DIR%backend\app\main.py"

pause

