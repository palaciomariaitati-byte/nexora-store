@echo off
title CRM VALEN ARQ - Sistema Soberano de Arquitectura y Construccion (MyJNexoraVisual)
cls
echo =====================================================================
echo   INICIANDO CRM VALEN ARQ v3.0 - MyJNexoraVisual
echo   Cerebro Tripartito: Arquitecto Colegiado + Abogado CCyCN + CPN UOCRA
echo   Tema de Arquitectura Luminoso + GPS Satelital + Camara Directa
echo =====================================================================

set PROJECT_DIR=%~dp0
cd /d "%PROJECT_DIR%"
set PYTHONIOENCODING=utf-8

:: Cerrar cualquier proceso previo colgado en puerto 8000
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8000" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

:: Buscar interprete de Python
set "PYTHON_CMD=python"
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)

:: Abrir navegador automaticamente tras 1 segundo
start "" cmd /c "timeout /t 1 >nul & start http://127.0.0.1:8000"

:: Iniciar Servidor
"%PYTHON_CMD%" "%PROJECT_DIR%backend\app\main.py"
pause
