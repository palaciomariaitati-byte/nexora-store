// CONTROLADOR PRINCIPAL - CRM-RPM VALEN ARQ (MyJNexoraVisual)
let selectedPhotoFile = null;
let webcamStream = null;
let userGpsCoordinates = "Ubicacion Satelital Pendiente";

function initGPS() {
  const gpsDisplay = document.getElementById('gps-display');
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude.toFixed(5);
        const lon = pos.coords.longitude.toFixed(5);
        userGpsCoordinates = `Lat: ${lat}, Lon: ${lon}`;
        if(gpsDisplay) {
          gpsDisplay.innerHTML = `📍 Coordenadas GPS en Obra: <strong>${userGpsCoordinates}</strong> (Precisión: ±${Math.round(pos.coords.accuracy)}m)`;
        }
      },
      (err) => {
        userGpsCoordinates = "Obra en Zona de Inspeccion (GPS Manual)";
        if(gpsDisplay) gpsDisplay.innerText = "📍 GPS: Obra en Zona de Inspección";
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }
}

function triggerNativeCamera() {
  const fileInput = document.getElementById('camera-file-input');
  if (fileInput) fileInput.click();
}

function handleFileSelected(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  selectedPhotoFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    const video = document.getElementById('camera-preview');
    const photo = document.getElementById('photo-preview');
    const placeholder = document.getElementById('scanner-placeholder');
    
    if (webcamStream) {
      webcamStream.getTracks().forEach(t => t.stop());
      webcamStream = null;
    }
    if(video) video.style.display = 'none';
    if(placeholder) placeholder.style.display = 'none';
    if(photo) {
      photo.src = e.target.result;
      photo.style.display = 'block';
    }
    
    const resBox = document.getElementById('pat-resultado');
    if(resBox) resBox.innerText = "📷 Foto de obra cargada.\nPresiona '🔍 Diagnosticar con VALEN' o completa el interrogatorio forense abajo.";
  };
  reader.readAsDataURL(file);
}

async function toggleWebcam() {
  const video = document.getElementById('camera-preview');
  const photo = document.getElementById('photo-preview');
  const placeholder = document.getElementById('scanner-placeholder');

  if (webcamStream) {
    webcamStream.getTracks().forEach(t => t.stop());
    webcamStream = null;
    if(video) video.style.display = 'none';
    if(placeholder) placeholder.style.display = 'block';
    return;
  }

  try {
    webcamStream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 } }
    });
    if(video) {
      video.srcObject = webcamStream;
      video.style.display = 'block';
    }
    if(photo) photo.style.display = 'none';
    if(placeholder) placeholder.style.display = 'none';
    
    const resBox = document.getElementById('pat-resultado');
    if(resBox) resBox.innerText = "📹 Transmitiendo webcam en vivo.\nEncuadra la patología y presiona '🔍 Diagnosticar con VALEN'.";
  } catch(e) {
    alert("No se pudo acceder a la webcam. Usa el botón '📸 Foto / Celular' para capturar o subir una imagen.");
  }
}

async function captureAndAnalyze() {
  const descInput = document.getElementById('pat-desc');
  const orientacionEl = document.getElementById('feed-orientacion');
  const espesorEl = document.getElementById('feed-espesor');
  const ubicacionEl = document.getElementById('feed-ubicacion');
  const sonidoEl = document.getElementById('feed-sonido');
  
  const descTexto = (descInput && descInput.value.trim()) ? descInput.value.trim() : "";
  const orientacion = orientacionEl ? orientacionEl.value : "diagonal";
  const espesor = espesorEl ? espesorEl.value : "media";
  const ubicacion = ubicacionEl ? ubicacionEl.value : "ventanas";
  const sonido = sonidoEl ? sonidoEl.value : "macizo";
  
  const descripcionCompleta = descTexto || `${orientacion} en ${ubicacion}, espesor ${espesor}, sonido ${sonido}`;
  
  const resultadoBox = document.getElementById('pat-resultado');
  if(resultadoBox) resultadoBox.innerText = "🔍 VALEN Vision procesando geometría, imagen y parámetros forenses...";

  const formData = new FormData();
  formData.append('descripcion', descripcionCompleta);
  formData.append('ubicacion', userGpsCoordinates || 'Obra en Zona de Inspección');
  formData.append('obra_id', 1);

  const video = document.getElementById('camera-preview');

  if (webcamStream && video && video.videoWidth > 0) {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    canvas.toBlob(async (blob) => {
      formData.append('imagen', blob, 'captura_webcam.jpg');
      await enviarPeticionDiagnostico(formData);
    }, 'image/jpeg', 0.9);
    return;
  }

  if (selectedPhotoFile) {
    formData.append('imagen', selectedPhotoFile);
  }

  await enviarPeticionDiagnostico(formData);
}

async function enviarPeticionDiagnostico(formData) {
  const resultadoBox = document.getElementById('pat-resultado');
  try {
    const res = await fetch('/api/patologias/analizar', {
      method: 'POST',
      body: formData
    });
    const json = await res.json();
    if(json.status === 'success') {
      if(resultadoBox) resultadoBox.innerText = json.diagnostico;
    } else {
      if(resultadoBox) resultadoBox.innerText = "Error: " + (json.message || "No se pudo procesar la imagen");
    }
  } catch(e) {
    if(resultadoBox) resultadoBox.innerText = "Error de enlace con VALEN: " + e;
  }
}

async function ejecutarFeedbackForense() {
  const orientacionEl = document.getElementById('feed-orientacion');
  const espesorEl = document.getElementById('feed-espesor');
  const ubicacionEl = document.getElementById('feed-ubicacion');
  const sonidoEl = document.getElementById('feed-sonido');
  
  const orientacion = orientacionEl ? orientacionEl.value : 'diagonal';
  const espesor = espesorEl ? espesorEl.value : 'media';
  const ubicacion = ubicacionEl ? ubicacionEl.value : 'ventanas';
  const sonido = sonidoEl ? sonidoEl.value : 'macizo';
  
  const resultadoBox = document.getElementById('pat-resultado');
  if(resultadoBox) {
    resultadoBox.innerText = "🔬 VALEN cruzando parámetros con tratados ACI 224, CIRSOC 201/501, UBA y UPC Barcelona...";
  }
  
  try {
    const res = await fetch('/api/patologias/feedback_forense', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orientacion: orientacion,
        espesor: espesor,
        ubicacion: ubicacion,
        sonido: sonido,
        gps_coords: userGpsCoordinates
      })
    });
    
    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      const msg = errJson.detail || errJson.message || `Error HTTP ${res.status}`;
      if(resultadoBox) resultadoBox.innerText = "Aviso del servidor: " + msg;
      return;
    }
    
    const json = await res.json();
    if(json.status === 'success') {
      if(resultadoBox) resultadoBox.innerText = json.dictamen;
    } else {
      if(resultadoBox) resultadoBox.innerText = "Error procesando feedback: " + (json.message || JSON.stringify(json));
    }
  } catch(e) {
    if(resultadoBox) resultadoBox.innerText = "Error de conexión con el motor forense: " + e;
  }
}

// DESCARGAS DE DOCUMENTOS WORD Y PDF
function descargarContratoWord(obraId) {
  window.open(`/api/descargar/contrato_word/${obraId}`, '_blank');
}

function descargarCertificadoPDF(certId) {
  window.open(`/api/descargar/certificado_pdf/${certId}`, '_blank');
}

function descargarCierrePDF() {
  window.open('/api/descargar/cierre_contable_pdf/03/2026', '_blank');
}

// CARGA DE DATOS CRM-RPM
async function loadObras() {
  try {
    const res = await fetch('/api/obras');
    const json = await res.json();
    const container = document.getElementById('obras-list');
    if (!container) return;
    container.innerHTML = '';
    
    json.data.forEach(obra => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <div class="card-header">
          <div class="card-title">🏗️ ${obra.nombre}</div>
          <span style="font-size:0.75rem; background:#e0f2fe; color:#0369a1; padding:0.2rem 0.5rem; border-radius:12px; font-weight:700;">${obra.estado}</span>
        </div>
        <p style="color:var(--text-muted); font-size:0.8rem; margin-bottom:0.4rem;">📍 ${obra.direccion} | ${obra.superficie_m2} m²</p>
        <p style="font-size:0.85rem; margin-bottom:0.4rem;"><strong>Comitente:</strong> ${obra.cliente_nombre || 'Fideicomiso'}</p>
        <p style="font-size:0.85rem; margin-bottom:0.4rem;"><strong>Contrato:</strong> $${obra.monto_contractual.toLocaleString('es-AR')}</p>
        <div>
          <div style="display:flex; justify-content:space-between; font-size:0.75rem; color:var(--text-muted); font-weight:600;">
            <span>Avance Físico Certificado</span>
            <span>${obra.avance_fisico_porcentaje}%</span>
          </div>
          <div style="background:#e2e8f0; height:8px; border-radius:4px; overflow:hidden; margin-top:0.4rem;">
            <div style="background:var(--color-blueprint); height:100%; width: ${obra.avance_fisico_porcentaje}%;"></div>
          </div>
        </div>
        <div style="margin-top:1rem; display:flex; gap:0.5rem; flex-wrap:wrap;">
          <button class="btn btn-primary" style="font-size:0.75rem; padding:0.35rem 0.7rem;" onclick="certificarModal(${obra.id})">Emitir Certificado</button>
          <button class="btn btn-terracotta" style="font-size:0.75rem; padding:0.35rem 0.7rem;" onclick="descargarContratoWord(${obra.id})">📄 Contrato Word (.docx)</button>
          <button class="btn btn-gold" style="font-size:0.75rem; padding:0.35rem 0.7rem;" onclick="descargarCertificadoPDF(1)">📑 Certificado PDF</button>
        </div>
      `;
      container.appendChild(card);
    });
  } catch(e) {
    console.error("Error cargando obras:", e);
  }
}

async function loadClientes() {
  try {
    const res = await fetch('/api/clientes');
    const json = await res.json();
    const tbody = document.getElementById('clientes-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    json.data.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${c.razon_social || c.nombre}</strong></td>
        <td>${c.cuit || 'S/D'}</td>
        <td><span style="color:var(--color-blueprint); font-weight:600;">${c.tipo_comitente || 'Fideicomiso'}</span></td>
        <td>${c.telefono || '-'} <br><small style="color:var(--text-muted);">${c.email || ''}</small></td>
        <td>${c.direccion || '-'}</td>
        <td><strong style="color:var(--color-success);">$${(c.saldo_cuenta || 0).toLocaleString('es-AR')}</strong></td>
      `;
      tbody.appendChild(tr);
    });
  } catch(e) {
    console.error("Error cargando clientes:", e);
  }
}

async function loadProveedores() {
  try {
    const res = await fetch('/api/proveedores');
    const json = await res.json();
    const tbody = document.getElementById('proveedores-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    json.data.forEach(p => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${p.razon_social}</strong></td>
        <td>${p.cuit}</td>
        <td><span style="color:var(--color-terracotta); font-weight:600;">${p.rubro}</span></td>
        <td>${p.contacto || 'Administración'}</td>
        <td>${p.telefono}</td>
        <td><strong style="color:var(--color-danger);">$${(p.saldo_adeudado || 0).toLocaleString('es-AR')}</strong></td>
      `;
      tbody.appendChild(tr);
    });
  } catch(e) {
    console.error("Error cargando proveedores:", e);
  }
}

async function loadPanol() {
  try {
    const res = await fetch('/api/panol');
    const json = await res.json();
    const tbody = document.getElementById('panol-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    json.data.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span style="font-family:var(--font-mono); font-weight:700; color:var(--color-blueprint);">${item.codigo}</span></td>
        <td><strong>${item.descripcion}</strong></td>
        <td>${item.categoria}</td>
        <td><strong>${item.cantidad}</strong> ${item.unidad_medida}</td>
        <td>📍 ${item.obra_nombre || 'Pañol Central'}</td>
        <td><span style="color:var(--color-success); font-weight:700;">✅ ${item.estado_herramienta}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch(e) {
    console.error("Error cargando pañol:", e);
  }
}

async function loadFinanzas() {
  try {
    const res = await fetch('/api/finanzas/transacciones');
    const json = await res.json();
    const tbody = document.getElementById('finanzas-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    json.data.forEach(tx => {
      const tr = document.createElement('tr');
      const esCobro = tx.tipo === 'Cobro';
      tr.innerHTML = `
        <td><span style="padding:0.2rem 0.5rem; border-radius:10px; font-weight:700; font-size:0.75rem; background:${esCobro ? '#dcfce7' : '#fee2e2'}; color:${esCobro ? '#15803d' : '#b91c1c'};">${tx.tipo}</span></td>
        <td>${tx.fecha}</td>
        <td>${tx.obra_nombre || 'General'}</td>
        <td><strong>${tx.entidad_nombre}</strong> (${tx.entidad_tipo})</td>
        <td>${tx.concepto}</td>
        <td>${tx.medio_pago}</td>
        <td><strong style="color:${esCobro ? '#15803d' : '#b91c1c'};">${esCobro ? '+' : '-'}$${tx.monto.toLocaleString('es-AR')}</strong></td>
        <td><span style="color:var(--color-success); font-weight:600;">${tx.estado}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch(e) {
    console.error("Error cargando finanzas:", e);
  }
}

async function loadContabilidad() {
  try {
    const res = await fetch('/api/contabilidad/asientos');
    const json = await res.json();
    const tbody = document.getElementById('contabilidad-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    json.data.forEach(a => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>#${a.numero_asiento}</strong></td>
        <td>${a.fecha}</td>
        <td><span style="color:var(--color-blueprint); font-weight:600;">${a.cuenta_debe}</span></td>
        <td><span style="color:var(--color-terracotta); font-weight:600;">${a.cuenta_haber}</span></td>
        <td><strong>$${a.monto.toLocaleString('es-AR')}</strong></td>
        <td>${a.concepto}</td>
        <td><span style="background:#f1f5f9; padding:0.2rem 0.4rem; border-radius:4px; font-size:0.75rem;">${a.cierre_mes}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch(e) {
    console.error("Error cargando contabilidad:", e);
  }
}

async function loadPersonal() {
  try {
    const res = await fetch('/api/personal_uocra');
    const json = await res.json();
    const tbody = document.getElementById('personal-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    json.data.forEach(p => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${p.nombre}</strong></td>
        <td>${p.cuil}</td>
        <td><span style="color:var(--color-terracotta); font-weight:600;">${p.categoria}</span></td>
        <td>${p.numero_ieric || 'Sin Libreta'}</td>
        <td>$${p.fondo_cese_acumulado.toLocaleString('es-AR')}</td>
        <td><span style="color:var(--color-success); font-weight:700;">✅ ART Vigente</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch(e) {
    console.error("Error cargando personal:", e);
  }
}

async function loadLibro() {
  try {
    const res = await fetch('/api/libro_ordenes/1');
    const json = await res.json();
    const container = document.getElementById('libro-asientos');
    if (!container) return;
    container.innerHTML = '';
    
    json.data.forEach(a => {
      const item = document.createElement('div');
      item.style.background = '#f8fafc';
      item.style.border = '1px solid var(--border-color)';
      item.style.borderRadius = '8px';
      item.style.padding = '0.85rem';
      item.style.marginBottom = '0.65rem';
      item.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:0.3rem;">
          <strong style="color:var(--color-terracotta); font-size:0.85rem;">Asiento N° ${a.numero_asiento} - ${a.tipo_asiento}</strong>
          <span style="font-size:0.7rem; color:var(--text-muted);">${a.fecha}</span>
        </div>
        <p style="font-size:0.85rem; line-height:1.4;">${a.contenido}</p>
        <div style="font-size:0.7rem; color:var(--color-blueprint); font-weight:600; margin-top:0.3rem;">✍️ Firmado Digitalmente por ${a.autor_rol}</div>
      `;
      container.appendChild(item);
    });
  } catch(e) {
    console.error("Error cargando libro:", e);
  }
}

async function calcularComputo() {
  const rubro = document.getElementById('comp-rubro').value;
  const d1 = parseFloat(document.getElementById('comp-d1').value);
  const d2 = parseFloat(document.getElementById('comp-d2').value);
  const d3 = parseFloat(document.getElementById('comp-d3').value);
  
  const res = await fetch('/api/computos/calcular', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ rubro, d1, d2, d3 })
  });
  const json = await res.json();
  const resBox = document.getElementById('comp-resultado');
  if(resBox) resBox.innerText = json.resultado;
}

async function asentarOrden() {
  const tipo = document.getElementById('libro-tipo').value;
  const texto = document.getElementById('libro-texto').value;
  if(!texto) return alert("Ingrese el contenido de la orden");
  
  const res = await fetch('/api/libro_ordenes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ obra_id: 1, tipo_asiento: tipo, contenido: texto })
  });
  const json = await res.json();
  alert(json.resultado);
  document.getElementById('libro-texto').value = '';
  loadLibro();
}

async function certificarModal(obraId) {
  const pct = prompt("Ingrese el porcentaje de avance del mes a certificar (ej: 12.5):", "10.0");
  if(!pct) return;
  
  const res = await fetch('/api/certificaciones', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ obra_id: obraId, porcentaje_mes: parseFloat(pct), periodo: '03/2026' })
  });
  const json = await res.json();
  alert(json.resultado);
  loadObras();
}

async function sendChat() {
  const input = document.getElementById('chat-input');
  if(!input) return;
  const msg = input.value.trim();
  if(!msg) return;
  
  const chatBox = document.getElementById('chat-box');
  const userMsg = document.createElement('div');
  userMsg.className = 'msg msg-user';
  userMsg.innerText = msg;
  chatBox.appendChild(userMsg);
  input.value = '';
  chatBox.scrollTop = chatBox.scrollHeight;
  
  const valenMsg = document.createElement('div');
  valenMsg.className = 'msg msg-valen';
  valenMsg.innerText = "Analizando con rigor técnico y legal...";
  chatBox.appendChild(valenMsg);
  
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensaje: msg, rol: 'gerencia', usuario: 'Director Técnico' })
    });
    const json = await res.json();
    valenMsg.innerText = json.respuesta;
    chatBox.scrollTop = chatBox.scrollHeight;
  } catch(e) {
    valenMsg.innerText = "Error de enlace con VALEN: " + e;
  }
}

function toggleDrawer() {
  const drawer = document.getElementById('sidebar-drawer');
  const overlay = document.getElementById('sidebar-overlay');
  if(drawer) drawer.classList.toggle('drawer-open');
  if(overlay) overlay.classList.toggle('drawer-open');
}

function showTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  document.querySelectorAll('.bnav-item').forEach(item => item.classList.remove('active'));
  
  const targetTab = document.getElementById(tabId);
  if(targetTab) targetTab.classList.add('active');
}

async function openQrModal() {
  const modal = document.getElementById('qr-modal');
  if(modal) modal.style.display = 'flex';
  const qrContainer = document.getElementById('qr-container');
  const qrText = document.getElementById('qr-url-text');
  const qrTipo = document.getElementById('qr-tipo-conexion');
  if(qrContainer) qrContainer.innerHTML = '<p style="color:#0f172a;">Generando código QR...</p>';
  
  try {
    const res = await fetch('/api/qr_acceso');
    const data = await res.json();
    if(data.status === 'success') {
      if(qrContainer) qrContainer.innerHTML = `<img src="${data.qr_image_base64}" alt="QR Acceso Móvil" style="width:200px; height:200px; display:block;">`;
      if(qrText) qrText.innerText = data.url;
      if(qrTipo) qrTipo.innerText = `📡 Conexión: ${data.tipo_conexion}`;
    }
  } catch(e) {
    if(qrContainer) qrContainer.innerHTML = '<p style="color:red;">Error generando QR: ' + e + '</p>';
  }
}

function closeQrModal() {
  const modal = document.getElementById('qr-modal');
  if(modal) modal.style.display = 'none';
}

function activarProModal() {
  const modal = document.getElementById('pro-modal');
  if(modal) modal.style.display = 'flex';
}

function closeProModal() {
  const modal = document.getElementById('pro-modal');
  if(modal) modal.style.display = 'none';
}

function procesarPagoPro() {
  alert("¡Pago procesado con éxito! Tu licencia de CRM VALEN ARQ Enterprise ha sido extendida por 30 DÍAS PRO.");
  const statusEl = document.getElementById('saas-status-text');
  const detailEl = document.getElementById('saas-detail-text');
  if(statusEl) statusEl.innerText = "30 DÍAS PRO";
  if(detailEl) detailEl.innerText = "Licencia Activa: 30 días PRO";
  closeProModal();
}

window.onload = () => {
  initGPS();
  loadObras();
  loadClientes();
  loadProveedores();
  loadPanol();
  loadPersonal();
  loadFinanzas();
  loadContabilidad();
  loadLibro();
};



// --- CONTROL DE MODALES DE ALTA RÁPIDA ---
function abrirModalCliente() { document.getElementById('modal-cliente').style.display = 'flex'; }
function abrirModalProveedor() { document.getElementById('modal-proveedor').style.display = 'flex'; }
function abrirModalPanol() { document.getElementById('modal-panol').style.display = 'flex'; }
function abrirModalFinanzas() { 
  document.getElementById('modal-finanzas').style.display = 'flex'; 
  const hoy = new Date().toISOString().split('T')[0];
  document.getElementById('fin-fecha').value = hoy;
}
function abrirModalObra() { document.getElementById('modal-obra').style.display = 'flex'; }

function cerrarModales() {
  document.querySelectorAll('[id^="modal-"]').forEach(m => m.style.display = 'none');
}

async function guardarCliente() {
  const nombre = document.getElementById('cli-nombre').value.trim();
  if(!nombre) return alert("Ingrese el nombre o razón social");
  
  const cuit = document.getElementById('cli-cuit').value.trim();
  const tipo = document.getElementById('cli-tipo').value;
  const tel = document.getElementById('cli-tel').value.trim();
  const email = document.getElementById('cli-email').value.trim();
  const dir = document.getElementById('cli-dir').value.trim();
  
  await fetch('/api/clientes/nuevo', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ nombre, razon_social: nombre, cuit, tipo_comitente: tipo, telefono: tel, email, direccion: dir })
  });
  cerrarModales();
  loadClientes();
}

async function guardarProveedor() {
  const nombre = document.getElementById('prov-nombre').value.trim();
  const rubro = document.getElementById('prov-rubro').value.trim();
  if(!nombre || !rubro) return alert("Complete razón social y rubro");
  
  const cuit = document.getElementById('prov-cuit').value.trim();
  const contacto = document.getElementById('prov-contacto').value.trim();
  const tel = document.getElementById('prov-tel').value.trim();
  
  await fetch('/api/proveedores/nuevo', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ razon_social: nombre, rubro, cuit, contacto, telefono: tel })
  });
  cerrarModales();
  loadProveedores();
}

async function guardarPanol() {
  const codigo = document.getElementById('pan-cod').value.trim();
  const desc = document.getElementById('pan-desc').value.trim();
  const cat = document.getElementById('pan-cat').value.trim() || 'General';
  const cant = parseFloat(document.getElementById('pan-cant').value) || 1;
  const un = document.getElementById('pan-un').value.trim() || 'un';
  if(!codigo || !desc) return alert("Ingrese código y descripción del ítem");
  
  await fetch('/api/panol/nuevo', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ codigo, descripcion: desc, categoria: cat, cantidad: cant, unidad_medida: un, obra_asignada_id: 1 })
  });
  cerrarModales();
  loadPanol();
}

async function guardarFinanza() {
  const tipo = document.getElementById('fin-tipo').value;
  const fecha = document.getElementById('fin-fecha').value || new Date().toISOString().split('T')[0];
  const monto = parseFloat(document.getElementById('fin-monto').value);
  const medio = document.getElementById('fin-medio').value;
  const entidad = document.getElementById('fin-entidad').value.trim();
  const concepto = document.getElementById('fin-concepto').value.trim();
  if(!monto || !entidad || !concepto) return alert("Complete monto, destinatario y concepto");
  
  await fetch('/api/finanzas/nuevo', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      tipo,
      fecha,
      monto,
      medio_pago: medio,
      entidad_tipo: tipo === 'Cobro' ? 'Cliente' : 'Proveedor',
      entidad_nombre: entidad,
      concepto,
      obra_id: 1
    })
  });
  cerrarModales();
  loadFinanzas();
  loadContabilidad();
}

async function guardarObra() {
  const cod = document.getElementById('obra-cod').value.trim();
  const nom = document.getElementById('obra-nom').value.trim();
  const dir = document.getElementById('obra-dir').value.trim();
  const m2 = parseFloat(document.getElementById('obra-m2').value) || 100;
  const monto = parseFloat(document.getElementById('obra-monto').value) || 10000000;
  if(!cod || !nom) return alert("Complete código y nombre del proyecto");
  
  await fetch('/api/obras/nueva', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ codigo: cod, nombre: nom, direccion: dir, superficie_m2: m2, monto_contractual: monto, cliente_id: 1 })
  });
  cerrarModales();
  loadObras();
}
