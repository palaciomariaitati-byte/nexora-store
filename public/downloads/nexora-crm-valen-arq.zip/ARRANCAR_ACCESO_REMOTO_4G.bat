@echo off
title CRM VALEN ARQ - Acceso Remoto 4G/5G
cls
echo =====================================================================
echo   INICIANDO VALEN ARQ CON TUNEL REMOTO SEGURO HTTPS (4G / 5G)
echo   El codigo QR funcionara en cualquier parte del mundo con datos moviles
echo =====================================================================

set PROJECT_DIR=%~dp0
cd /d "%PROJECT_DIR%"
set PYTHONIOENCODING=utf-8

:: Buscar interprete de Python
set "PYTHON_CMD=python"
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)

:: Descargar cloudflared.exe si no existe (Herramienta oficial gratuita y segura de Cloudflare)
if not exist "%PROJECT_DIR%cloudflared.exe" (
    echo [i] Descargando conector de tunel seguro Cloudflare (Solo la primera vez)...
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile '%PROJECT_DIR%cloudflared.exe'"
)

:: Iniciar Cloudflare Tunnel en segundo plano y capturar URL
start "" "%PROJECT_DIR%cloudflared.exe" tunnel --url http://127.0.0.1:8000 --logfile "%PROJECT_DIR%tunnel.log"

echo [i] Esperando conexion del tunel seguro HTTPS...
timeout /t 3 >nul

:: Iniciar Servidor VALEN ARQ
"%PYTHON_CMD%" "%PROJECT_DIR%backend\app\main.py"
pause
