/**
 * ibera_bridge.js - Conector y Autodescubridor Universal para IberáSoft POS (Windows)
 * Proyecto: Tren Agéntico Nexora One Engine ("By Nora")
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { db } from './database.js';

export class IberaSoftBridge {
  constructor() {
    this.lastScan = null;
  }

  /**
   * Busca automáticamente el acceso directo "IberáSoft.lnk" en el Escritorio de Windows
   * o carpetas de instalación habituales y detecta su motor de base de datos.
   */
  detectarInstalacionIberaSoft() {
    const candidatosLnk = [
      path.join(process.env.USERPROFILE || '', 'Desktop', 'IberáSoft.lnk'),
      path.join(process.env.USERPROFILE || '', 'Desktop', 'IberaSoft.lnk'),
      path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop', 'IberáSoft.lnk'),
      path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop', 'IberaSoft.lnk')
    ];

    const carpetasCandidatas = [
      'C:\\IberaSoft',
      'C:\\IberáSoft',
      'C:\\Sistemas\\IberaSoft',
      'C:\\Program Files (x86)\\IberaSoft',
      'C:\\Program Files\\IberaSoft',
      'D:\\IberaSoft'
    ];

    let lnkEncontrado = candidatosLnk.find((p) => fs.existsSync(p)) || null;
    let exeDestino = null;
    let carpetaInstalacion = null;

    if (lnkEncontrado) {
      try {
        const psCmd = `(New-Object -ComObject WScript.Shell).CreateShortcut('${lnkEncontrado.replace(/'/g, "''")}').TargetPath`;
        exeDestino = execSync(`powershell -NoProfile -Command "${psCmd}"`, { encoding: 'utf8', timeout: 3000 }).trim();
        if (exeDestino && fs.existsSync(exeDestino)) {
          carpetaInstalacion = path.dirname(exeDestino);
        }
      } catch (e) {
        // Fallback silencioso
      }
    }

    if (!carpetaInstalacion) {
      carpetaInstalacion = carpetasCandidatas.find((d) => fs.existsSync(d)) || null;
    }

    let archivosBaseDatos = [];
    let motorDetectado = 'SQLite Espejo + Sincronizador CSV Universal IberáSoft';

    if (carpetaInstalacion && fs.existsSync(carpetaInstalacion)) {
      try {
        const files = fs.readdirSync(carpetaInstalacion);
        archivosBaseDatos = files.filter((f) =>
          /\.(mdb|accdb|fdb|gdb|sqlite|sqlite3|db|sdf|ini|cfg)$/i.test(f)
        );
        if (archivosBaseDatos.some((f) => /\.(mdb|accdb)$/i.test(f))) {
          motorDetectado = 'Microsoft Access Jet/ACE (.mdb/.accdb)';
        } else if (archivosBaseDatos.some((f) => /\.(fdb|gdb)$/i.test(f))) {
          motorDetectado = 'Firebird SQL (.fdb/.gdb)';
        } else if (archivosBaseDatos.some((f) => /\.(sqlite|sqlite3|db)$/i.test(f))) {
          motorDetectado = 'SQLite Nativo (.db/.sqlite)';
        }
      } catch (e) {
        // Permisos o lectura
      }
    }

    const csvPath = db.exportarCSVCompatibleIberaSoft();

    const resultado = {
      conectado: true,
      modo: carpetaInstalacion ? 'CONEXION_DIRECTA_DETECTADA' : 'MODO_ESPEJO_PLUG_AND_PLAY',
      accesoDirectoDetectado: lnkEncontrado,
      ejecutableIberaSoft: exeDestino,
      carpetaInstalacion: carpetaInstalacion || 'Pendiente (Operando sobre Base Espejo Local + CSV IberáSoft)',
      motorDetectado,
      archivosBaseDatos,
      archivoSincronizacionCSV: csvPath,
      timestamp: new Date().toISOString()
    };

    db.updateConfig({
      iberasoft_ruta_detectada: carpetaInstalacion
        ? `${carpetaInstalacion} (${motorDetectado})`
        : 'Base Espejo Activa + CSV Universal IberáSoft (Listo para vincular en PC del Kiosco)'
    });

    this.lastScan = resultado;
    return resultado;
  }
}

export const iberaBridge = new IberaSoftBridge();
export default iberaBridge;
