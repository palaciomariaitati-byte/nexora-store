const path = require('path');
const dotenv = require('dotenv');
dotenv.config({ path: path.resolve(__dirname, '.env') });
const apiKey = process.env.GROQ_API_KEY;
console.log('API Key present:', !!apiKey, 'prefix:', apiKey ? apiKey.slice(0, 10) : '');

fetch('https://api.groq.com/openai/v1/models', {
  headers: { 'Authorization': 'Bearer ' + apiKey }
})
.then(r => r.json())
.then(data => {
  if (data.error) {
    console.error('Groq Error:', data.error);
    return;
  }
  const models = (data.data || []).map(m => m.id);
  console.log('Total models:', models.length);
  console.log('Vision models:', models.filter(m => m.includes('vision') || m.includes('qwen') || m.includes('llama') || m.includes('scout')));
  console.log('All models:', models);
})
.catch(console.error);
