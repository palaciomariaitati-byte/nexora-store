const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

async function processImages() {
  const publicDir = path.resolve(__dirname, '..', 'public');

  const logoBuf = await sharp(path.join(publicDir, 'app-logo.png'))
    .resize({ height: 44, fit: 'inside' })
    .png({ quality: 85, compressionLevel: 9 })
    .toBuffer();
  console.log('Optimized logo size:', logoBuf.length, 'bytes');
  fs.writeFileSync(path.join(publicDir, 'app-logo.png'), logoBuf);

  const avatarBuf = await sharp(path.join(publicDir, 'nora-avatar-circle.png'))
    .resize({ width: 96, height: 96, fit: 'cover' })
    .png({ quality: 85, compressionLevel: 9 })
    .toBuffer();
  console.log('Optimized avatar size:', avatarBuf.length, 'bytes');
  fs.writeFileSync(path.join(publicDir, 'nora-avatar-circle.png'), avatarBuf);

  // Generate base64 data URLs for inlining
  const logoDataUrl = `data:image/png;base64,${logoBuf.toString('base64')}`;
  const avatarDataUrl = `data:image/png;base64,${avatarBuf.toString('base64')}`;

  fs.writeFileSync(path.join(publicDir, 'assets_inline.json'), JSON.stringify({
    logoDataUrl,
    avatarDataUrl
  }, null, 2));

  console.log('Done generating assets_inline.json!');
}

processImages().catch(console.error);
