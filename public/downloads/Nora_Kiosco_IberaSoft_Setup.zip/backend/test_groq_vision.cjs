const path = require('path');
const dotenv = require('dotenv');
const sharp = require('sharp');
dotenv.config({ path: path.resolve(__dirname, '.env') });
const apiKey = process.env.GROQ_API_KEY;

async function testGroqVision() {
  console.log('Testing Groq Vision with model qwen/qwen3.8-27b and 200x200 image...');
  
  const imgBuffer = await sharp({
    create: {
      width: 200,
      height: 200,
      channels: 3,
      background: { r: 255, g: 255, b: 255 }
    }
  }).jpeg().toBuffer();

  const dataUrl = `data:image/jpeg;base64,${imgBuffer.toString('base64')}`;

  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'qwen/qwen3.8-27b',
      messages: [
        { role: 'system', content: 'Devuelve JSON: {"status": "ok", "descripcion": "imagen recibida"}' },
        {
          role: 'user',
          content: [
            { type: 'image_url', image_url: { url: dataUrl } },
            { type: 'text', text: 'Responde JSON' }
          ]
        }
      ],
      temperature: 0.1,
      response_format: { type: 'json_object' }
    })
  });

  console.log('Status:', res.status);
  const data = await res.json();
  console.log('Response content:', data.choices?.[0]?.message?.content);
}

testGroqVision().catch(console.error);
