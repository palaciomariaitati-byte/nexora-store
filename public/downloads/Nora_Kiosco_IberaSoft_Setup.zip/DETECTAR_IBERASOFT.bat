@echo off
title Detector Automatico de IberaSoft POS - Nexora One
color 0B

echo ======================================================================
echo         RADIOGRAFIA AUTOMATICA DE IBERASOFT POS (NEXORA ONE)
echo ======================================================================
echo.
echo Buscando acceso directo "IberaSoft" en el Escritorio de Windows...
echo.

powershell -NoProfile -Command ^
  "$lnks = Get-ChildItem -Path \"$env:USERPROFILE\Desktop\", \"$env:PUBLIC\Desktop\" -Filter '*Iber*Soft*.lnk' -ErrorAction SilentlyContinue; " ^
  "if ($lnks) { " ^
  "  foreach ($l in $lnks) { " ^
  "    $sh = New-Object -ComObject WScript.Shell; " ^
  "    $target = $sh.CreateShortcut($l.FullName).TargetPath; " ^
  "    Write-Host 'Acceso directo encontrado:' $l.FullName -ForegroundColor Green; " ^
  "    Write-Host 'Ejecutable destino:' $target -ForegroundColor Yellow; " ^
  "    $dir = Split-Path $target -Parent; " ^
  "    if (Test-Path $dir) { " ^
  "      Write-Host 'Archivos de Base de Datos y Configuracion en' $dir ':' -ForegroundColor Cyan; " ^
  "      Get-ChildItem -Path $dir -Recurse -Include *.mdb,*.accdb,*.fdb,*.gdb,*.sqlite,*.db,*.ini,*.cfg,*.xls,*.csv -ErrorAction SilentlyContinue | Select-Object FullName, Length | Format-Table -AutoSize " ^
  "    } " ^
  "  } " ^
  "} else { " ^
  "  Write-Host 'No se encontro el acceso directo IberaSoft.lnk en este Escritorio. Operando en Modo Espejo + CSV Universal.' -ForegroundColor Yellow " ^
  "}"

echo.
pause
