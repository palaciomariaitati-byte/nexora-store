@echo off
title Instalador Automatico - Nora AI x IberaSoft POS (Nexora One)
color 0A

echo ======================================================================
echo    INSTALADOR PLUG ^& PLAY EN PC DEL KIOSCO: NORA AI x IBERASOFT POS
echo                     Tren Agentico Nexora One Engine
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: Asegurar rutas estandar de Node en PATH para la sesion actual
set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs;%LOCALAPPDATA%\Programs\nodejs"

:: 1. Verificar si Node.js ya esta instalado
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [1/4] Node.js no detectado en PATH. Instalando motor Node.js LTS...
    winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs"
)

:: Re-verificar despues de winget o busqueda directa en Program Files
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\nodejs\node.exe" (
        set "PATH=%PATH%;C:\Program Files\nodejs"
        echo [1/4] Motor Node.js detectado en C:\Program Files\nodejs.
    ) else (
        echo [AVISO] Node.js se instalo en el sistema. Si ocurre algun error, reinicie esta ventana.
    )
) else (
    echo [1/4] Motor Node.js detectado y verificado correctamente.
)

:: 2. Verificar librerias del backend (vienen pre-instaladas en el paquete)
if not exist "%ROOT_DIR%backend\node_modules\express" (
    echo [2/4] Configurando librerias de Nora AI (primera ejecucion)...
    cd /d "%ROOT_DIR%backend"
    call npm install --no-audit --no-fund
    cd /d "%ROOT_DIR%"
) else (
    echo [2/4] Librerias de Nora AI, Conector IberaSoft y WhatsApp listas.
)

:: 3. Crear Accesos Directos en el Escritorio y en Inicio de Windows
echo [3/4] Creando accesos directos (Escritorio e Inicio Automatico de Windows)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$desktops = @($WshShell.SpecialFolders.Item('Desktop'), [Environment]::GetFolderPath('Desktop'), \"$env:USERPROFILE\Desktop\", \"$env:USERPROFILE\OneDrive\Escritorio\", \"$env:USERPROFILE\OneDrive\Desktop\") | Select-Object -Unique | Where-Object { Test-Path $_ }; " ^
  "foreach ($d in $desktops) { " ^
  "  $s1 = $WshShell.CreateShortcut((Join-Path $d 'Nora AI x IberaSoft (1 Clic).lnk')); " ^
  "  $s1.TargetPath = '%ROOT_DIR%INICIAR_SISTEMA_1_CLIC.bat'; " ^
  "  $s1.WorkingDirectory = '%ROOT_DIR%'; " ^
  "  $s1.IconLocation = '%ROOT_DIR%icon.ico,0'; " ^
  "  $s1.Description = 'Nora AI Copilot e IberaSoft POS - 1 Solo Clic'; " ^
  "  $s1.Save(); " ^
  "  $s2 = $WshShell.CreateShortcut((Join-Path $d 'Nora AI - Modo Remoto Celular.lnk')); " ^
  "  $s2.TargetPath = '%ROOT_DIR%ACCESO_REMOTO_CELULAR_DUENIO.bat'; " ^
  "  $s2.WorkingDirectory = '%ROOT_DIR%'; " ^
  "  $s2.IconLocation = '%ROOT_DIR%icon.ico,0'; " ^
  "  $s2.Description = 'Acceso Remoto 4G Celular Duenio'; " ^
  "  $s2.Save(); " ^
  "}; " ^
  "$startupFolder = $WshShell.SpecialFolders.Item('Startup'); " ^
  "$sAuto = $WshShell.CreateShortcut((Join-Path $startupFolder 'Nora_AI_x_IberaSoft_Arranque_Automatico.lnk')); " ^
  "$sAuto.TargetPath = '%ROOT_DIR%INICIAR_SISTEMA_1_CLIC.bat'; " ^
  "$sAuto.WorkingDirectory = '%ROOT_DIR%'; " ^
  "$sAuto.IconLocation = '%ROOT_DIR%icon.ico,0'; " ^
  "$sAuto.Description = 'Arranque Automatico en la Manana de Nora e IberaSoft'; " ^
  "$sAuto.Save();"

echo [OK] Accesos directos creados:
echo      - Escritorio: 'Nora AI x IberaSoft (1 Clic)'
echo      - Inicio de Windows: se abrira automaticamente al prender la PC.

:: 4. Lanzar el sistema a 1 Clic
echo.
echo ======================================================================
echo    INSTALACION COMPLETADA CON EXITO
echo    Iniciando Nora AI e IberaSoft POS a 1 Clic...
echo ======================================================================
timeout /t 2 >nul
call "%ROOT_DIR%INICIAR_SISTEMA_1_CLIC.bat"
