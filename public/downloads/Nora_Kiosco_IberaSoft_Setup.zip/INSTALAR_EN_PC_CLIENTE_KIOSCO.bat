@echo off
title Instalador Automatico - Nora AI x IberaSoft POS (Nexora One)
color 0A

echo ======================================================================
echo    INSTALADOR PLUG ^& PLAY EN PC DEL KIOSCO: NORA AI x IBERASOFT POS
echo                     Tren Agentico Nexora One Engine
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: 1. Verificar Node.js en la PC del cliente
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [1/5] Instalando motor Node.js LTS automaticamente...
    winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    set "PATH=%PATH%;C:\Program Files\nodejs"
) else (
    echo [1/5] Motor Node.js detectado correctamente.
)

:: 2. Instalar dependencias del backend si viene del paquete liviano de WhatsApp
if not exist "%ROOT_DIR%backend\node_modules\@whiskeysockets" (
    echo [2/5] Configurando librerias de Nora AI y Conector WhatsApp QR (1 sola vez)...
    cd /d "%ROOT_DIR%backend"
    call npm install --no-audit --no-fund
    cd /d "%ROOT_DIR%"
) else (
    echo [2/5] Librerias de Nora AI y WhatsApp listas.
)

:: 3. Descargar conector de Tunel Remoto HTTPS (Cloudflare) si no existe
if not exist "%ROOT_DIR%backend\cloudflared.exe" (
    echo [3/5] Configurando Tunel Remoto Seguro 4G/Soporte Nexora...
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile '%ROOT_DIR%backend\cloudflared.exe' -UseBasicParsing"
) else (
    echo [3/5] Tunel Remoto Seguro 4G listo.
)

:: 4. Crear Acceso Directo "Nora AI - Administradora IberaSoft" en el Escritorio del Kiosco
echo [4/5] Creando acceso directo "Nora AI - Administradora IberaSoft" en el Escritorio...
powershell -NoProfile -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$Desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$Shortcut = $WshShell.CreateShortcut(\"$Desktop\Nora AI - Administradora IberaSoft.lnk\"); " ^
  "$Shortcut.TargetPath = \"%ROOT_DIR%INICIAR_KIOSCO_NORA_IBERASOFT.bat\"; " ^
  "$Shortcut.WorkingDirectory = \"%ROOT_DIR%\"; " ^
  "$Shortcut.Description = 'Tren Agentico Nexora One (By Nora) para IberaSoft POS'; " ^
  "$Shortcut.Save();"

:: 5. Iniciar el sistema y abrir el panel
echo [5/5] Iniciando Nora AI conectada a IberaSoft...
call "%ROOT_DIR%INICIAR_KIOSCO_NORA_IBERASOFT.bat"
