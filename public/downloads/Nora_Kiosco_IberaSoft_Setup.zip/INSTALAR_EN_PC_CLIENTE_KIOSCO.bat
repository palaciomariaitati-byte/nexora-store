@echo off
title Instalador Automatico - Nora AI x IberaSoft POS (Nexora One)
color 0A

echo ======================================================================
echo    INSTALADOR PLUG ^& PLAY EN PC DEL KIOSCO: NORA AI x IBERASOFT POS
echo                     Tren Agentico Nexora One Engine
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: Asegurar rutas estandar de Node en PATH para la sesion actual
set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs;%LOCALAPPDATA%\Programs\nodejs"

:: 1. Verificar si Node.js ya esta instalado
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [1/4] Node.js no detectado en PATH. Instalando motor Node.js LTS...
    winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs"
)

:: Re-verificar despues de winget o busqueda directa en Program Files
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\nodejs\node.exe" (
        set "PATH=%PATH%;C:\Program Files\nodejs"
        echo [1/4] Motor Node.js detectado en C:\Program Files\nodejs.
    ) else (
        echo [AVISO] Node.js se instalo en el sistema. Si ocurre algun error, reinicie esta ventana.
    )
) else (
    echo [1/4] Motor Node.js detectado y verificado correctamente.
)

:: 2. Verificar librerias del backend (vienen pre-instaladas en el paquete)
if not exist "%ROOT_DIR%backend\node_modules\express" (
    echo [2/4] Configurando librerias de Nora AI (primera ejecucion)...
    cd /d "%ROOT_DIR%backend"
    call npm install --no-audit --no-fund
    cd /d "%ROOT_DIR%"
) else (
    echo [2/4] Librerias de Nora AI, Conector IberaSoft y WhatsApp listas.
)

:: 3. Crear Accesos Directos en el Escritorio
echo [3/4] Creando accesos directos en el Escritorio de Windows...
powershell -NoProfile -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$Desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$s1 = $WshShell.CreateShortcut(\"$Desktop\Nora AI - Kiosco & IberaSoft.lnk\"); " ^
  "$s1.TargetPath = \"%ROOT_DIR%INICIAR_KIOSCO_NORA_IBERASOFT.bat\"; " ^
  "$s1.WorkingDirectory = \"%ROOT_DIR%\"; " ^
  "$s1.Description = 'Tren Agentico Nexora One (By Nora) para IberaSoft POS'; " ^
  "$s1.Save(); " ^
  "$s2 = $WshShell.CreateShortcut(\"$Desktop\Nora AI - Modo Remoto Celular.lnk\"); " ^
  "$s2.TargetPath = \"%ROOT_DIR%ACCESO_REMOTO_CELULAR_DUENIO.bat\"; " ^
  "$s2.WorkingDirectory = \"%ROOT_DIR%\"; " ^
  "$s2.Description = 'Acceso Remoto 4G para el Celular del Duenio'; " ^
  "$s2.Save(); " ^
  "$s3 = $WshShell.CreateShortcut(\"$Desktop\Nora AI - Detectar IberaSoft.lnk\"); " ^
  "$s3.TargetPath = \"%ROOT_DIR%DETECTAR_IBERASOFT.bat\"; " ^
  "$s3.WorkingDirectory = \"%ROOT_DIR%\"; " ^
  "$s3.Description = 'Radiografia del sistema IberaSoft POS instalado'; " ^
  "$s3.Save();"

echo [OK] Accesos directos creados en el Escritorio.

:: 4. Lanzar el sistema
echo.
echo ======================================================================
echo    INSTALACION COMPLETADA CON EXITO
echo    Presione cualquier tecla para iniciar Nora AI y abrir el mostrador...
echo ======================================================================
pause >nul
call "%ROOT_DIR%INICIAR_KIOSCO_NORA_IBERASOFT.bat"
