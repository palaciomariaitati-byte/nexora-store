@echo off
title Grupo Nexora - Panel Maestro de Control, Productos, Clientes y Soporte OTA
start "" "http://localhost:3040/master.html"
