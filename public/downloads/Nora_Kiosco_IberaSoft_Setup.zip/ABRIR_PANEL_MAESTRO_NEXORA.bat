@echo off
title Grupo Nexora - Panel Maestro de Control, Productos, Clientes y Soporte OTA
color 0B

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"
set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs;%LOCALAPPDATA%\Programs\nodejs"

netstat -ano | findstr ":3040" | findstr "LISTENING" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [!] Servidor no detectado en puerto 3040. Iniciando...
    start "Nora Kioscos 2026 - Servidor Activo" cmd /k "title Servidor Nora AI - Kiosco 2026 && cd /d "%ROOT_DIR%backend" && node server.js"
    timeout /t 3 >nul
)

echo Abriendo Panel Maestro de Control y Soporte OTA...
start "" "http://localhost:3040/master.html"
exit
