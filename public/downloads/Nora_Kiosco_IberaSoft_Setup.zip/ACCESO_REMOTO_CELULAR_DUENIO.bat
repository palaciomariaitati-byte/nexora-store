@echo off
title Nora Kioscos 2026 - Acceso Remoto 4G para Celular del Duenio
color 0A

echo ======================================================================
echo      NORA AI x IBERASOFT - ACCESO REMOTO CELULAR DEL DUENIO (4G)
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"
set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs;%LOCALAPPDATA%\Programs\nodejs"

:: 1. Verificar si el servidor local esta activo en el puerto 3040
netstat -ano | findstr ":3040" | findstr "LISTENING" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [!] El servidor Nora no estaba encendido.
    echo     Iniciando servidor local en puerto 3040 primero...
    start "Nora Kioscos 2026 - Servidor Activo" cmd /k "title Servidor Nora AI - Kiosco 2026 && cd /d "%ROOT_DIR%backend" && node server.js"
    timeout /t 3 >nul
)

echo.
echo  [OK] Servidor local verificado en puerto 3040.
echo  Conectando tunel remoto seguro para acceso desde el celular...
echo.

if exist "%ROOT_DIR%backend\cloudflared.exe" (
    echo Conectando via Cloudflare Secure Tunnel (Enlace directo HTTPS)...
    "%ROOT_DIR%backend\cloudflared.exe" tunnel --url http://localhost:3040
) else (
    echo Conectando via LocalTunnel...
    call npx localtunnel --port 3040
)

pause
