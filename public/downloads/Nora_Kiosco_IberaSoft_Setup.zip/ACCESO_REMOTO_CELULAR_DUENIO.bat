@echo off
title Nora Kioscos 2026 - Acceso Remoto 4G para Celular del Duenio
color 0A

echo ======================================================================
echo      NORA AI x IBERASOFT - ACCESO REMOTO CELULAR DEL DUENIO (4G)
echo ======================================================================
echo.
echo  Generando enlace HTTPS seguro para que el duenio supervise la caja,
echo  reciba alertas de faltantes y cargue o apruebe facturas desde su celular...
echo.

:loop
echo [%time%] Conectando tunel remoto en puerto 3040...
npx localtunnel --port 3040
echo.
echo Reconectando en 5 segundos...
timeout /t 5 /nobreak >nul
goto loop
