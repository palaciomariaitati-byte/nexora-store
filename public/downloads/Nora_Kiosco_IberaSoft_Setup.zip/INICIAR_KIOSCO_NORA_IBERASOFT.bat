@echo off
title Nora COO x IberaSoft POS - Tren Agentico Nexora One (Kioscos 2026)
color 0E

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"
set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs;%LOCALAPPDATA%\Programs\nodejs"

echo ======================================================================
echo       TREN AGENTICO NEXORA ONE ("BY NORA") x IBERASOFT POS
echo       Administradora de Stock, Precios (%%), Turnos y Libro Diario
echo ======================================================================
echo.

:: 1. Verificar si Node.js esta disponible
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\nodejs\node.exe" (
        set "PATH=%PATH%;C:\Program Files\nodejs"
    ) else (
        echo [ERROR CRITICO] No se encontro Node.js en este equipo.
        echo Por favor ejecute primero "INSTALAR_EN_PC_CLIENTE_KIOSCO.bat"
        echo.
        pause
        exit /b 1
    )
)

:: 2. Verificar dependencias en backend
if not exist "%ROOT_DIR%backend\node_modules\express" (
    echo [!] Dependencias no detectadas. Instalando librerias necesarias...
    cd /d "%ROOT_DIR%backend"
    call npm install --no-audit --no-fund
    cd /d "%ROOT_DIR%"
)

:: 3. Liberar puerto 3040 si habia una instancia previa colgada
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3040" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

:: 4. Iniciar Servidor con registro visible y proteccion contra cierres inesperados
echo  [1/2] Iniciando Cerebro Nora AI y Conector IberaSoft en puerto 3040...
start "Nora Kioscos 2026 - Servidor Activo" cmd /k "title Servidor Nora AI - Kiosco 2026 && cd /d "%ROOT_DIR%backend" && node server.js"

:: 5. Esperar a que el servidor responda activamente
echo  [2/2] Verificando inicio del servidor...
set TRIES=0
:wait_server
timeout /t 1 /nobreak >nul
set /a TRIES=%TRIES%+1
netstat -ano | findstr ":3040" | findstr "LISTENING" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if %TRIES% LEQ 10 (
        goto wait_server
    ) else (
        echo [AVISO] El servidor esta iniciando. Abriendo navegador...
    )
) else (
    echo  [OK] Servidor activo y escuchando en puerto 3040.
)

:: 6. Abrir Navegador
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3040/
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3040/
) else (
    start http://localhost:3040/
)

echo.
echo  ======================================================================
echo   SISTEMA NORA AI ACTIVO:
echo   - Mostrador Kiosco:         http://localhost:3040/
echo   - Vista Celular del Duenio: http://localhost:3040/?rol=duenio
echo   - Planilla IberaSoft CSV:   %ROOT_DIR%sincronizacion_iberasoft\
echo  ======================================================================
echo.
pause
