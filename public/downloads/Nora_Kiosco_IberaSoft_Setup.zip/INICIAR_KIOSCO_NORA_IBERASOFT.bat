@echo off
title Nora COO x IberaSoft POS - Tren Agentico Nexora One (Kioscos 2026)
color 0E

echo ======================================================================
echo       TREN AGENTICO NEXORA ONE ("BY NORA") x IBERASOFT POS
echo       Administradora de Stock, Precios (%%), Turnos y Libro Diario
echo ======================================================================
echo.

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

:: 1. Liberar puerto 3040 si habia una instancia previa
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":3040" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

:: 2. Iniciar Servidor Unificado Ultraligero (Node/Express + SQLite WAL + Groq Vision)
echo  [1/2] Iniciando Cerebro Nora AI y Conector IberaSoft en puerto 3040...
start /min "Nora Kioscos 2026 - Server" cmd /c "cd /d "%ROOT_DIR%backend" && node server.js"

timeout /t 2 /nobreak >nul

echo  [2/2] Abriendo Panel de Control de Mostrador y Supervision...
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:3040/
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:3040/
) else (
    start http://localhost:3040/
)

echo.
echo  ======================================================================
echo   SISTEMA ACTIVO:
echo   - Mostrador Kiosco:         http://localhost:3040/
echo   - Vista Celular del Duenio: http://localhost:3040/?rol=duenio
echo   - Planilla IberaSoft CSV:   %ROOT_DIR%sincronizacion_iberasoft\
echo  ======================================================================
echo.
pause >nul
